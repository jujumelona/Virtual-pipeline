# Live2D 상반신 / 의상만 출력 이미지

**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.


> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 기준 원화 먼저 생성 → 2D 원본 분리/3D 참조 확장 → 숨은 부분 보완. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
결과 ZIP: `live2d_upper__outfit__ARTWORK.zip`
```text
isolated_parts/outfit_front.png
isolated_parts/outfit_back.png
isolated_parts/sleeve_L_upper.png
isolated_parts/sleeve_R_upper.png
layer_order.txt
previews/overlay_preview.png
```
**실제 있는 파츠만 생성**하며, 고급 독립 움직임/가림이 있는 경우 02의 세부 이름 추가. 액세서리 headpiece 명칭은 해당 사용자가 요청한 물건의 이름으로 교체. 개별 RGBA 원화·동일 캔버스/원점·뒤→앞 목록. 미리보기는 생성된 파츠의 실제 합성.

**09 + 10의 고급 애니풍 품질 기준과 07 반복 점검을 충족한 경우에만 최종 ZIP 제공.**


## ZIP 고유 작업 범위 잠금: live2d_upper / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 보이는 상체 앞·뒷판·카라·양소매·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식·별도 하체 원화를 생성하지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기존 신체 원화의 목·어깨·팔 위치 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 

04의 파일명은 이 ZIP의 대상 부위에만 적용한다. 다른 종류 파츠는 기준 몸체 overlay에만 참조할 수 있고 isolated_parts/나 source로 출력하면 안 된다.

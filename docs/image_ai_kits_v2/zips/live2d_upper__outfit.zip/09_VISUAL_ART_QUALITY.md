## [ART_SOURCE_AND_SEPARATION_V3]
### live2d_upper / outfit — 자산·모드·담당 단계 잠금
- 자산 경계: OUTFIT: 실제 옷감·소매·옷깃·밑단·의상에 붙은 디자인 요소만. BODY·얼굴·눈·피부·헤어·독립 장신구 픽셀은 0개. OUTFIT 납품물에는 피부·눈·얼굴·머리카락을 복사하지 않는다. 합성은 previews에서만 가능.
- 명시적 생성 제외: OUTFIT에서는 옷감과 의복 일체형 부속만. 머리카락·얼굴·눈·입·몸통 피부·양팔·양손·다리 피부·장신구 독립 파츠 생성 금지. 기준 BODY/HAIR는 참조이고 의상 이미지에 합치지 않는다.
- 실물 납품 차단: OUTFIT master/납품 PNG에 피부·얼굴·눈·머리카락·독립 장신구가 있으면 CROSS_ASSET_CONTAMINATION: FAIL. 기준 캐릭터 합성은 별도 previews/에서만 허용.
- 구도 경계: 상반신은 머리부터 허리 부근, 양팔·양손 끝까지. 다리·발 금지.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. outfit 실제 세분화 판단: OUTFIT: 앞뒤 몸판·좌우 소매·독립 이동하는 칼라/리본/밑단·치맛자락을 필요한 경우 나눈다. 봉제선·무늬는 본래 천에 유지. 감춰진 겹침면 색 복원, 피부·헤어 픽셀 혼입 금지.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

## [GPT_ARTWORK_SEGMENTER_HANDOFF_V5]
### live2d_upper / outfit — GPT 마스터 원화에서 실제 분리 AI까지
**최상위 역할 계약. 이 ZIP은 GPT의 원화 생성 지시서이지 GPT에게 PSD·파츠 분리를 시키는 지시서가 아니다.** 모든 14개 MD의 기존 `part_art/`, `_order.txt`, `isolated_parts/`, PSD, 알파, 개별 눈·목 세분화, 합성 검수 지시는 **별도 후속 분리 엔진의 출력/검사 명세**로 해석한다. 이미지 생성 AI가 그 파일을 생성했다고 주장해서는 안 된다.
1. GPT는 `outputs/master.png` **실제 정면 원화 PNG 1장**(RGB 또는 진짜 RGBA)을 생성한다. 콜라주, 부품을 떨어뜨려 배치한 시트, 가짜 투명 PNG, 기존 이미지와 다른 인물로 그린 설정화는 불합격이다.
2. 다음은 투명 파츠가 아닌, 같은 캐릭터의 다른 시점/숨은 부분 참고 원화이다. **각각 별도의 실제 PNG**로 그린다.
  - `reference_views/outfit_front.png`
  - `reference_views/outfit_three_quarter_L.png`
  - `reference_views/outfit_three_quarter_R.png`
  - `reference_views/outfit_profile_L.png`
  - `reference_views/outfit_profile_R.png`
  - `reference_views/outfit_back.png`
  - `reference_views/outfit_inside_seams.png`
  - `reference_views/outfit_joint_clearance.png`
3. 마스터와 front/three_quarter/profile/pitch 참고는 **동일한 원본 캔버스 가로·세로 픽셀 크기, 인물 스케일·중심좌표**를 유지한다. 뷰 이름을 바꾸거나 정면을 복제해 다른 시점으로 위장하지 않는다.
4. **모드 구도:** 머리~허리 부근, 양어깨·양팔·양손 포함. 다리·발 없음.
5. **자산 경계:** 기준 BODY 위에 교체해 입힐 요청 의상·안감·소매만. 몸체·얼굴·눈·머리카락·별개 장신구 제외.
6. **See-through 분리를 고려한 원화:** 한 이미지에 한 시점·한 캐릭터, 흰색/단순 단색 배경, 선명한 애니 셀 셰이딩/파츠 윤곽·깔끔한 경계; 글자·워터마크·장식 배경·눈 위의 불필요한 손/머리카락 겹침·과도한 발광 금지. 구분을 위해 머리·팔을 물리적으로 잘라 떼어 놓거나 전체 원화 품질을 저하시키지 않는다.
- 현재 자산 외의 BODY/얼굴/눈/의상/장신구 픽셀을 결과 이미지에 합치지 않는다. 원래 캐릭터는 위치·색·디자인 참조로만 사용한다.
7. **GPT 결과물:** `live2d_upper__outfit__ARTWORK.zip`에 `outputs/master.png`, 위 `reference_views/*.png` 및 BODY에서 `expression_refs/*.png`만 저장한다. `manifest.json`, `layer_order.txt`, `part_art/_order.txt`, `part_art/*.png`, `isolated_parts/`, PSD, MOC3 등 분리/리깅 파일은 생성하지 않는다. 원화 ZIP 납품과 Live2D 완료를 혼동하지 않는다.
8. **후속 파이프라인:** `tools/vts_source_only_pack.py`가 실물 마스터·뷰의 PNG 형식/중복/크기 등을 확인한다. 이후 See-through V3/NF4로 분리 PSD 후보를 만들고, 관찰된 파츠를 공식 좌우/깊이 세분화 또는 SAM 정밀 마스크로 필요 시 개선한다. Qwen-Image-Layered는 기존 런타임에서 해당 자산에 **실제로 연결된 경우에만** 추가 RGBA 분해에 사용한다. Qwen은 텍스트만으로 L/R 홍채·흰자·속눈썹 레이어를 정확히 지정하는 기능을 보장하지 않는다.
9. **후속 검수:** 원본 보이는 RGB 보존, 실제 알파, 가려진 부분 복원, PSD 순서/캔버스 좌표, 좌우 눈 흰자·홍채·속눈썹, 턱-목-몸통·팔-손 접합, 마스터 중립 합성 일치와 변형을 검사한다. 불합격 부위는 분리 작업에서만 재시도/인페인팅하고 GPT가 파츠 시트를 대신 그리게 하지 않는다. 결과 PSD는 Cubism/Inochi2D 모델 리깅/방송 동작 성공을 뜻하지 않는다.
10. 위에 적힌 PNG를 실제 제작할 수 없으면 그 누락을 명확히 보고한다. 분리 엔진 오류는 GPT 원화 생성 완료와 별도로 보고한다.
## [/GPT_ARTWORK_SEGMENTER_HANDOFF_V5]

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 옷감·주름·봉제선·몸판·소매·옷깃·가려진 원단과 다른 자산 픽셀 혼입을 실제 시각 확인. 예시의 완성 캐릭터 눈·몸을 그대로 복사하지 않는다.
- **모드별 실제 구도:** Live2D 상반신: 머리부터 허리 부근까지, 양어깨·양팔·양손 포함. 골반 아래 다리·발·전신 생성 금지. OUTFIT: 실제 옷감·소매·옷깃·밑단·의상에 붙은 디자인 요소만. BODY·얼굴·눈·피부·헤어·독립 장신구 픽셀은 0개.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 옷감·주름·봉제선·몸판·소매·옷깃·가려진 원단과 다른 자산 픽셀 혼입을 실제 시각 확인. 증거 없으면 ART_QUALITY_UNVERIFIED.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-13 v5 live2d_upper/outfit 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.

# Live2D 상반신 의상 독립 원화 품질 조건

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 보이는 상체 앞·뒷판·카라·양소매·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식·별도 하체 원화를 생성하지 않는다.


- 스타일: 원단 두께·탄성·솔기를 표현하는 정돈된 테이퍼 선화, 재질별 2~3단 셀 음영과 일관된 주름 방향.
- 제작 범위: **사용자가 선택한 의상 한 벌의 보이는 상체 앞·뒷판·카라·양소매·실제로 달린 의상 장식**. 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식·별도 하체 원화를 생성하지 않는다.
- 원화는 숙련 애니 일러스트레이터의 실물 레이어처럼 선폭 강약·테이퍼·소재별 명암·가림과 실루엣을 유지한다. SVG/Pillow/Matplotlib 도형 인형이나 단순 색면을 실제 완성 이미지로 제출하지 않는다.
- 샘플 https://www.live2d.com/en/learn/sample/ 는 화풍·완성도만 참고한다. 특정 기존 캐릭터 외형을 복제하거나 예시 캐릭터의 옷/헤어/얼굴을 덧그리지 않는다.
- 필요한 그림을 직접 생성·검토하지 못하면 완료를 주장하지 않는다. 최종 ZIP은 해당 자산의 실제 원화·PNG·미리보기로 구성한다.


## [2026-10-13 원화·애니풍 심화: live2d_upper/outfit]
카라·어깨·소매·안감 연결, 재질별 일관된 명암, 실제 옷에 있는 장식만, 신체/헤어·하체 의상/탈착 소품 혼입 없음.
선화·테이퍼·2~3톤 중심 채색의 가독성을 확인하고 파일 수로 실제 그림 품질을 판정하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_upper/outfit]
**[소재/선화 미술]** 겹치는 옷깃·주름의 깊은 틈은 명확한 접촉선, 천 내부/고정 문양은 가는 선, 소재의 진짜 주름·두께·명암은 원본 그림체에 맞게 통일한다. 없는 복잡한 자수나 투명 재질을 품질을 이유로 강제하지 않는다.



## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [BROADCAST_HANDS_BODY_COLOR_V1]
### 방송 화면 축소와 확대에서 그림 품질 평가
**범위 우선순위:** 이 지침은 같은 ZIP의 오래된 '가슴 위까지만', '손이 보일 때만 손' 같은 조건보다 우선한다. BODY 원본의 양손 누락은 허용하지 않는다. 작업 자산 소유권·2D/3D 형식 규칙은 유지한다.
### 상반신 OUTFIT: BODY 양손·목 보존과 자산별 정확한 정렬

- 기준 BODY는 해당 모드의 실제 프레임을 사용한다. BODY 양손은 손가락 끝까지 완성된 참조여야 하며, 상반신이라 손과 손목·어깨를 잘라서는 안 된다.
- **현재 ZIP은 OUTFIT만 생성한다.** 기준 BODY의 양손·팔·목과 윗배는 위치 및 가림 참조로만 사용한다. BODY의 피부/클레이 RGB 픽셀을 현재 자산의 독립 산출물에 복사하거나, BODY 손이 잘린 상태로 둔 채 의상·머리카락·장식으로 숨기지 않는다. 소매 좌우의 윗단은 옷판 안쪽, 소매 끝은 손목 피부 바깥에 실제로 겹치게 한다. 커프를 그려 손가락 잘림을 감추지 않는다. 옷깃 안쪽과 겨드랑이/어깨의 숨은 천만 의상 재질색으로 채색한다. 2D는 실제 독립 자산 PNG만 납품하고, BODY 원화는 참고 합성으로만 사용한다.
- **보정색:** 가림에 감춰지는 BODY 피부/무광 외피를 임의 회색 면으로 교체하지 않는다. 보이는 BODY RGB와 연속된 원래 색을 유지하도록 참고하되, 현재 자산의 숨은 픽셀은 현재 자산 고유의 재질색으로 그린다. 별도의 알파/클리핑 마스크를 몸색 RGB로 채워 버리지 않는다.
- 현재 자산만 고품질로 그리고, 기준 BODY 손·목·얼굴을 복제해 원화에 섞지 않는다. 방송에서 축소해도 소재의 끝·가림이 읽히고 BODY 손/목이 잘리지 않는다.
## [/BROADCAST_HANDS_BODY_COLOR_V1]

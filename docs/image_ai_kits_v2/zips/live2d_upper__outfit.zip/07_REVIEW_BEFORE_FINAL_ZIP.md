# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 live2d_upper/outfit 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
   단, 특정 기존 캐릭터·BODY와 동일성을 보존해야 하는데 필수 사용자 참조가 없거나, 실제 시각 참고 이미지를 전혀 볼 수 없다면 사유를 정확하게 보고하고 해당 단계만 보류한다. 허위 열람 완료 금지.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** 정수리~허리의 애니풍 상반신. 큰 얼굴/눈 중심, 짧고 넓은 얼굴과 정확히 연결된 목·어깨·자연스러운 팔과 양손을 그린다. 가로로 뻗은 팔·작은 머리·길쭉한 실사 비율·납작한 밴드형 캐릭터는 거절한다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
live2d_upper/outfit 최종 검수 강제 조건. 충돌하는 구형 미술 지침보다 우선한다.
- OUTFIT: 큰 머리·짧은 둥근 얼굴·부드러운 턱 인상을 보존. 넓은 어깨선·소매·칼라로 머리가 작아 보이거나 목이 길어 보이면 불합격. BODY 비율 변경 금지. 터틀넥은 의상에서는 허용, BODY에 병합 금지.
- 공통: **큰 머리, 큰 눈과 홍채, 짧고 넓은 얼굴, 둥근 볼, 짧고 매끈한 U형 턱, 작은 코·입.** 말상·좁은 얼굴·길게 내려오는 V턱·성숙 실사 얼굴은 절대 불합격.
- 정면 얼굴 높이/폭 약 1.10~1.30은 참고 범위이며 강제 크롭/화면 점유율은 아님. 전신 6등신 유지, 바스트업·상반신은 머리를 작게 만들지 않음.
- 실패 판정: 머리가 작다 / 눈이 작다 / 얼굴이 길거나 좁다 / 턱이 뾰족하다 / 목이 길다 / 다른 자산이 혼입됐다. 하나라도 해당하면 불합격이며 무검증 납품 금지.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_upper/outfit]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **OUTFIT만 생성:** 제공된 BODY 좌표에 옷깃·소매·안감·장식·그림자·숨은 옷감을 정렬한다. 터틀넥·민소매·드레스 등 의상 형태는 허용되나 BODY 피부에 절대 합치지 않는다. BODY 신체를 새로 그리지 않는다.
- 프레임: 정수리부터 허리와 양손까지 상반신. 자산 소유 범위에만 적용. 전신 캐릭터 기본 디자인은 6등신을 지향하나 크롭에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY 제공 시 얼굴 비율을 변경하지 않는다.


## [2026-10-13 v5 live2d_upper/outfit 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.

# Live2D 상반신 의상만 시각검수 → 오류 수정 → 재검수

00_MASTER_FIRST.md 및 00_DELIVERY_AND_RECHECK.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 보이는 상체 앞·뒷판·카라·양소매·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식·별도 하체 원화를 생성하지 않는다.


- **범위 누출:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식·별도 하체 원화를 생성하지 않는다.
- 파일마다 해당 부위만 존재하며 다른 자산을 섞어 납품하지 않았는가? 후면 그림이 단순 확대/복사나 빈 투명도는 아닌가?
- 오류가 발견되면 **해당 자산 그림만 수정**하고 PNG·미리보기·목록을 갱신해 시각검수를 반복한다. 인위적인 품질 점수·임의 레이어 수로 합격 처리하지 않는다.

## 상반신 / outfit 독립 화질·범위 검토

의상만의 목깃·어깨·소매 및 실제 보이는 옷감 안쪽을 검수한다. **상반신** 의상 ZIP에서 치마·바지·신발을 자동으로 만들지 않는다. 얇은 리본·장식은 옷 자체에 실제 붙어 있을 때만 포함하며, 기준 얼굴·피부·머리카락 PNG가 섞이면 실패다.



## [2026-10-13 원화·애니풍 심화: live2d_upper/outfit]
카라·어깨·소매·안감 연결, 재질별 일관된 명암, 실제 옷에 있는 장식만, 신체/헤어·하체 의상/탈착 소품 혼입 없음.
원본 기준 원화·독립 RGBA/재합성 그림을 보고 오류가 남으면 수정·반복.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_upper/outfit]
[의상 측면/목 접합 QA] 기준 신체(참조)의 목·귀 뒤 피부와 요청 의상의 옷깃 사이 틈/목 관통/카라 잘림이 있는가? 의상 PNG에는 피부·얼굴·헤어가 없어야 한다. 디자인에 없는 후드·넥타이·하의·목걸이를 임의 생성하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_upper/outfit]
**[의상 QC]** 실제 요청 의상에 체크/줄무늬가 있다면 소매·카라·몸판의 무늬가 연결되는가? 반투명/망사 재질이 있을 때 겹침이 예상보다 지나치게 검거나 하얀 프린지가 생기는가? 주름이 봉제/장력 위치와 무관하게 임의로 흩뿌려지지 않는가? 옷깃/소매 경계가 잘리거나 피부 픽셀을 옷 안에 끌어오지 않았는가? 없는 치마·신발/별도 귀걸이 생성 금지.


## [필수: 2D 결과 ZIP 레이어 정확성 사전 차단]
- [ ] `04_OUTPUT_FILES.md`의 Python 코드를 납품 ZIP에 실행해 PASS를 확인했다. 실패 시 수정·재압축·재실행했으며 허위 PASS 금지.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** live2d_upper / outfit; OUTFIT — 요청받은 의상 한 종류와 의상에 종속된 단추·프릴·리본. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 상반신: 두상부터 허리/상반신 지정 끝까지. 하체를 강제로 만들지 않는다.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png.
- 최소 참고 파일 후보: reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: 신체 피부와 눈·목 등 BODY 원화를 의상 속에 합성한 독립 부품으로 납품하지 않는다. 별도 착용 소품은 ACCESSORY의 몫이다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 후속 Colab에서 See-through가 파츠를 분리하고 리깅 단계가 사용한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다.
- 옷깃·소매·안감·등 뒤 겹침을 참고 시점 그림으로 보여준다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. See-through 분리 이후 리깅 시 실제 관절·가림·회전 연결을 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

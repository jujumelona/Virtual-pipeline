
## [2026-10-13 v5 live2d_upper/outfit 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
OUTFIT: 요청한 옷 한 벌만 별도 제작하고, 기준 BODY에 피부·근육·살접힘을 새로 그리지 않는다. 카라/목깃/소매/옷 주름은 의상 소유 파츠로만 만든다. 기준 BODY와 동일 좌표/캔버스 정합, 움직일 때 필요한 안감/숨은 소매/어깨 이음새, 완성 합성 QA 후 납품. 요청하지 않은 액세서리/신발/다른 옷 강제 금지.

# 의상만 — 완성 의상 원화에서 필요한 구성 파츠 추출·보완

> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 해당 2D 자산의 완성 기준 원화 먼저 제작 → 실제 RGBA 파츠만 분리 → 해당 자산의 숨은 면 추가 작화. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.

옷 종류를 묻거나 사용자의 설명(원피스/재킷/셔츠/교복/드레스 등)에 따른다. **옷 한 벌의 실제 구조만** 그린다. 몸·헤어·별도 귀걸이/안경 세트는 생성하지 않는다.

| 파츠 예 | 별도 생성 기준 |
|---|---|
| outfit_front.png / outfit_back.png | 앞·뒤 옷감이 깊이가 다른 경우, 팔/목 아래 가린 안감 보완 |
| sleeve_L_upper.png / sleeve_R_upper.png | 어깨부터 팔꿈치까지 별도 움직일 소매 |
| sleeve_L_lower.png / sleeve_R_lower.png | 팔꿈치/손목에서 실제 별도 움직이는 구조면 분리 |
| collar_L.png / collar_R.png / hood.png | 옷깃/후드가 다른 깊이·독립 움직임이면 분리 |
| frill_01.png / outfit_ribbon.png | **옷에 부착된** 프릴·리본: 액세서리 ZIP이 아닌 **의상 내부**의 해당 부품 |
| skirt_front.png / skirt_back.png / pants_L.png / pants_R.png | **전신이고 실제 있는 하의만** 제작. 없는 치마/바지를 상상해서 추가하지 않음 |
| belt.png / shoe_L.png / shoe_R.png | 그 의상에 실제 포함될 때만 |

옷의 고정 문양, 자수, 인쇄는 다른 움직임이 없으면 옷감 파츠에 남긴다. 프릴·리본/카디건 안쪽처럼 독립 움직임/깊이가 있으면 **완성 원화에서 별도 이미지로 추출하고 숨은 부분만 보완한다**. 기준 몸의 크기·원점과 맞추며 **신체 픽셀을 의상 파츠에 섞지 않는다**.


## [2026-10-13 원화·애니풍 심화: live2d_upper/outfit]
실제 요청된 의상의 목깃·좌우 카라·어깨/소매·몸판 및 보이는 안쪽 옷감을 원화에서 분리한다. 소매 안감·옷깃 뒤 천·리본의 가림을 보완하며 피부·얼굴/눈·헤어를 복제하지 않는다. 바지·치마·신발은 화면 밖으로 내려가는 상반신 의상 ZIP의 필수가 아니다. 교체 장신구 생성 금지.


## [고급 그림자·모근·소재·선폭 | live2d_upper/outfit]
**[의상만/재질·패턴·그림자]** 요청된 한 벌의 실제 소매·카라·몸판·하의(존재 시)에만 그림을 배분한다. 천에 고정된 체크무늬/줄무늬/자수는 옷감 자체의 색면이며 필요 없이 별도 파츠로 쪼개지 않는다. **어깨·팔꿈치·옷깃 등 움직임/장력이 생기는 이음**에서 실제 무늬·솔기·천의 앞뒤가 맞도록 이어 그린다. 피부의 자체 그림자는 신체, 옷감 주름/접촉 그림자는 의상이다. 투명/망사 소재는 실제 요청되었을 때만 적용하고, 같은 불투명/반투명 겹침을 두 번 채색해 검게 만들지 않는다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** live2d_upper / outfit; OUTFIT — 요청받은 의상 한 종류와 의상에 종속된 단추·프릴·리본. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 상반신: 두상부터 허리/상반신 지정 끝까지. 하체를 강제로 만들지 않는다.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png.
- 최소 참고 파일 후보: reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png.
- 위 PNG 목록은 **납품 필수**이고 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 앞/뒤 판·옷깃·목둘레·소매·어깨·팔꿈치·손목·옷 아래 가려진 원단과 안감, 필요한 경우 허리·치맛단·무릎 주변의 실제 천을 작화한다. 가동 부위와 가려지는 속면, 천의 두께·주름 방향이 다각도에서 이어져야 한다. 의상 고유 장식만 의상 파츠로 포함한다.
- Colab 입력 파츠·경로 계약: OUTFIT의 isolated_parts/ 파츠 ID는 outfit/cloth 계열로 시작하도록 적고, 한 파츠의 좌우·깊이 정보를 이름에 명확히 표시한다. 다른 자산의 이름이나 픽셀은 독립 파츠로 포함하지 않는다. layer_order.txt의 경로는 실제 isolated_parts/ PNG와 1:1 매칭한다.
- 자산 소유권 금지: 신체 피부와 눈·목 등 BODY 원화를 의상 속에 합성한 독립 부품으로 납품하지 않는다. 별도 착용 소품은 ACCESSORY의 몫이다.
- 2D ZIP의 실제 납품은 해당 자산의 기준 마스터 원화, 추가 참고 시점 그림, 독립 RGBA 원화 파츠와 마스크, 합성 미리보기, 편집 가능한 레이어 PSD 및 검수표다. 참고 시점 PNG가 자동으로 모션 키폼·메시가 되지는 않는다.
- 기존 MD에서 reference_views/를 '필요한 경우만' 또는 선택 사항으로 표현했더라도 위 지정 시점 파일은 최종 ZIP에서 필수다. 파일명 대소문자/확장자/경로를 변경하지 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

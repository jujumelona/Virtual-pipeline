# Live2D 상반신 의상 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 보이는 상체 앞·뒷판·카라·양소매·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식·별도 하체 원화를 생성하지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기존 신체 원화의 목·어깨·팔 위치 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 공식 근거를 이미지 제작에 적용
- 공식 Live2D 파츠 가공: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . 이미지 AI는 실제 의상 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.live2d.com/en/cubism-editor-manual/glue/ . Cubism의 Skinning/Glue/Clipping 등의 기능이 그림 AI가 실제로 ArtMesh나 리깅을 만들었다는 증거는 아니다.
- 옷깃 안쪽, 어깨와 소매 아래 안감·겹침 여유를 추가 작화한다. 좌우 소매, 흔들릴 리본·옷자락만 필요한 만큼 분리한다. 사용자가 요청하지 않은 넥타이·리본·장신구나 전신 바지·치마·신발을 강제하지 않는다.
- 독립 ArtMesh 수나 그림자/하이라이트 PNG 수를 고정하지 않는다. 고정 문양은 본체에, 실제 다른 움직임·앞뒤 순서가 필요한 요소만 나눈다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 미리보기는 실제 파츠를 조립한 그림으로 만들고 기준 몸체는 좌표 참고용으로만 사용한다.
- 커뮤니티 원화 사례: https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ — 개별 작업자 경험이며 공식 필수 조건이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. 공식 PSD 주의사항: https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ .


## [2026-10-13 원화·애니풍 심화: live2d_upper/outfit]
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ (옷깃·리본·가디건의 선택적 분할); https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ (Editor 단계 참고). **제작자 경험:** 가려진 옷감 보완·소재별 명암.
공식의 분리·가림·PSD 준비 기준과 아티스트의 비율/채색 경험칙을 구별한다. Cubism의 ArtMesh·키폼은 Editor 후속 작업.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_upper/outfit]
[Live2D 공식 참고] https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 카라·가디건의 움직일 부분은 필요에 따라 분리; 목 자체는 신체 원화. [아티스트 작업 팁] 얼굴과 목 3/4 회전을 참조해 카라 안쪽·뒤칼라와 좌우 목깃에 가려진 옷감을 추가 작화한다.
Live2D/Cubism의 원화 처리 원칙을 참고하되 실제 Cubism 모델·물리·키폼을 이미지 AI에 강제하지 않는다.

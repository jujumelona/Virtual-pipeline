# Live2D 공식 Photoshop 소재 분리 플러그인

공식: https://docs.live2d.com/ko/cubism-editor-manual/material-separation-ps-plugin-manual/
원화 가공: https://docs.live2d.com/en/cubism-editor-tutorials/psd/

1. 먼저 해당 자산의 완성 원화 한 장을 생성하고 복제·보관한다.
2. Photoshop에서 필요한 영역을 선택·마스크하고 공식 플러그인으로 잘라내기/빈 영역 채우기/투명 영역 보완을 진행한다.
3. 복원되지 않은 숨은 피부·머리뿌리·관절·안감 부분만 후작업으로 채운다.
4. 같은 위치·캔버스로 투명 PNG들을 배치하고 다시 합성한다.

플러그인 사용은 실제 Photoshop 접근이 가능한 경우에만. 자동 완성/자동 리깅을 보장하지 않으며 Photoshop이 없는 이미지 생성 AI에 사용을 강제하지 않는다.

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

### 실제 대형 이미지 AI 생성 → 고품질 원화 승인 → 다각도 → 분리 (최상위 품질 규칙)
- **작업 순서 강제:** 기존 14개 MD/이미지 참고 실제 열람 → 대상 자산·구도 확정 → 이미지 생성 AI 기능으로 고품질 기준 마스터 원화 직접 생성 → 마스터를 눈으로 보고 합격/재생성 결정 → 해당 캐릭터의 다각도/표정/숨은 면 실제 이미지 추가 생성 → 개별 파츠 채색 보존 분리·PSD/ZIP 조립 → 실제 완성본 시각 검증. 첫 번째 이미지 품질 통과 전에 PSD·파츠 개수 맞추기부터 하지 않는다.
- **이미지 생성 방식:** 마스터와 시점 원화의 **그림 자체를 생성형 이미지 모델로 그린다**. Python/Pillow/cairoSVG/SVG path/ellipse/rectangle/polygon/HTML Canvas/Matplotlib 좌표로 캐릭터의 얼굴·팔·손·헤어·옷을 조합하여 이미지로 출력한 것, 벡터 아이콘/교재용 도형/프록시는 **불합격**이다. 기존 벡터 도형 그림에 그림자·그라데이션만 더해도 불합격이다. 코드·스크립트는 완성도 높은 **실제 생성 원화**를 PSD·마스크·레이어로 가공/검증할 때만 사용한다. 이미지 생성 기능을 못 썼다면 코드로 대체하여 성공이라고 주장하지 않는다.
- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** Inochi2D 6등신 전신. 얼굴 표정·양손·발과 독립 관절의 2D 원화를 숙련된 애니 일러스트 수준으로 표현한다.
- **해당 자산의 고품질 제작 조건:** HAIR 전용. 요청된 머리 스타일의 뿌리·앞머리·옆머리·뒷머리·가닥의 크기 차·겹침·광택·그림자를 실제 세밀한 애니 선화로 그린다. 한 장의 투구/헬멧 같은 둥근 면과 삼각형 복제 가닥, 정면의 단순 반전 측면은 불합격. 얼굴·신체·옷은 원화 파츠에 넣지 않는다.
- **반드시 실제로 비교:** 마스터 원본과 다각도/표정 PNG를 열어 동일 인물·눈매·선 굵기·명암·가림·관절 이음의 일관성을 확인한다. 옆모습은 정면의 미러링/눌러 늘이기가 아니어야 하며, 정면의 분할 이미지를 다른 각도 파일에 복제하는 것은 실패다.
- **결과물:** 완성 마스터는 outputs/master.png, 독립 RGBA 파츠는 isolated_parts/*.png, 실제 가림 순서는 layer_order.txt, 고품질 다각도 원화는 reference_views/에 저장한다. 실제 생성한 원화에서 레이어를 분리하고 세부를 손상시키지 않는다. 편집 가능한 PSD는 고품질 기준 원화와 파츠 분리를 마친 후에 제작한다. 기본 layer_order.txt에는 중립 상태에서 실제 보이는 파츠만 한 번씩 포함하고, 눈 감김·입 벌림 등의 배타적인 추가 원화는 expression_refs/에서 따로 보존한다. 대체 표정 PNG를 중립 PSD에 모두 켜서 중복 눈·입이 보이게 하지 않는다.
- **반려 기준:** 임시 벡터 도형 사람/투박한 몸통/손가락 없는 손/정면을 압축한 프로필/눈 감김과 입 벌림 원화 누락, 리깅용 목 연결 빈 공간, 이상한 이중 파츠, 낮은 미술 품질, 참조 이미지와 크게 다른 얼굴. 파츠 24개·PNG 9장·PSD 합성 오차 0·ZIP CRC 성공만으로 절대 승인하지 않는다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**inochi2d_full/hair 생성 최상위 기준**: 아래 구형 규칙과 충돌하면 이 규칙을 우선한다.
- HAIR는 기준 BODY의 큰 두상과 짧고 둥근 얼굴을 변경하지 않는다. 정수리·양옆의 헤어 볼륨이 머리를 작게 보이게 하거나 옆머리가 얼굴을 좁고 길게 만들면 실패. 눈/턱/피부 재생성 금지; 요청받은 모발만.
- 큰 머리, 큰 눈/홍채, 짧고 폭 넓은 얼굴, 둥근 볼, 부드럽고 짧은 U턱, 작은 코·입을 기본으로 한다. **긴/좁은 얼굴과 말상, 뾰족한 V턱, 성숙·실사 모델 인상은 절대 불합격.**
- 정면 얼굴 세로/가로 약 1.10~1.30은 귀여운 스타일의 권장 출발점이며 절대적인 크롭 수치가 아니다. 전신은 프로젝트 6등신, 상반신/바스트업은 큰 머리 존재감을 유지한다.
- BODY 원본을 제공받았으면 얼굴형·눈 크기·두상·목을 재설계하지 않는다. 2D 원화와 분리 레이어 재합성 이미지 비교.
- 불합격 항목: 머리가 작아 보임, 눈이 작음, 얼굴이 길고 좁음, 뾰족한 턱, 긴 목, 다른 자산 혼입. 눈으로 검사하여 하나라도 발견되면 결과물 납품 금지.

## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_full/hair]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 헤어만 제작. 기준 신체/눈/얼굴 재생성 금지. 두피·가닥·모근의 숨은 면 보완.
- 구도: 전신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 실제 PSD·3D 템플릿이 없으면 없다고 알린다. URL 및 그림 도식은 원본 템플릿이 아니다.
- 2D 완성 원화 먼저, 움직임별 분리와 가려진 면 보완, 실제 파일 산출 시에만 납품 완료.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.


## [2026-10-13 v5 inochi2d_full/hair 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
HAIR: 지정된 머리 하나만 독립 파츠 제작. BODY·귀·눈·목·의상을 새로 생성하지 않고 동일 캔버스/원점/스케일을 따르며 모근/이마/귀 뒤 숨은 가닥과 좌우 앞뒤 레이어, 알파/단정한 선화를 검수. 특정 헤어스타일·고정 눈색·장식 강제 금지. Inochi2D 노드/정렬은 후속 Creator 작업이다.

# Inochi2D 전신 헤어 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 전신 캔버스에서 해당 헤어스타일의 실제 영역만. 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


볼륨 있는 애니 헤어 덩어리, 뿌리에서 끝까지 자연스러운 흐름, 테이퍼 끝·재질별 하이라이트·2~3톤 셀 채색. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber hair-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested hair asset on the reference canvas, no unrelated character parts or props.”

특정 캐릭터의 디자인 복제 금지. 실제 2D 그림까지만, PSD/Inochi Creator 키폼은 사용자가 나중에 처리한다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / hair]
Premium Japanese anime Inochi2D HAIR ONLY, authentic requested hairstyle, root-directed front side and back tufts, elegant crown volume and tapered strands, material-dependent cel highlights with nonduplicated shadow pixels, clean independent RGBA hair textures; no face, outfit, skin or ornamental items.
Tapered, refined anime ink lines and material-aware cel shadows; keep the user's exact original design. No native Creator modeling output.


## [고급 그림자·모근·소재·선폭 | inochi2d_full/hair]
Anime VTuber HAIR ONLY: authentic scalp-rooted silhouette, layered front side and back tufts, tapered fine ink at the strand tips, depth-aware cel shadows and flowing highlights; only if needed provide a hair-owned cast-shadow layer instead of baking hair shadows into face skin, never add eyes, ears, outfit or ornamental hairpins.


## [2026-10-13 v5 inochi2d_full/hair 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
HAIR: 지정된 머리 하나만 독립 파츠 제작. BODY·귀·눈·목·의상을 새로 생성하지 않고 동일 캔버스/원점/스케일을 따르며 모근/이마/귀 뒤 숨은 가닥과 좌우 앞뒤 레이어, 알파/단정한 선화를 검수. 특정 헤어스타일·고정 눈색·장식 강제 금지. Inochi2D 노드/정렬은 후속 Creator 작업이다.
Inochi2D 공식 자료 https://docs.inochi2d.com/ 와 애니 버튜버 실제 샘플 https://www.live2d.com/en/learn/sample/ 를 *이미지로* 볼 것. Cubism 기능을 Inochi에 요구하지 않음.

# Inochi2D 전신 헤어에만 적용하는 공식 원화 시각 사례

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 전신 캔버스에서 해당 헤어스타일의 실제 영역만. 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


- 아래 Live2D 공개 캐릭터 샘플은 **화풍·선화·명암·완성도만 참고**한다. 샘플 전체 캐릭터를 다시 그리거나 hair 이외의 신체·헤어·의상을 제작하라는 뜻이 아니다.
- 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥. 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
- 공식 예시 이미지는 ZIP에 동봉하지 않았다. 열람 불가면 보았다고 주장하지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

화풍 참고용 Live2D 갤러리: https://www.live2d.com/en/learn/sample/ ; **Inochi2D 실제 원화/노드는 별도 엔진**: https://docs.inochi2d.com/en/latest/creator/nodes/node.html . 샘플 외형은 복제하지 않는다.

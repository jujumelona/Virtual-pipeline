# Inochi2D 전신 헤어 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 전신 캔버스에서 해당 헤어스타일의 실제 영역만. 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 공식 근거를 이미지 제작에 적용
- 공식 Inochi2D Creator 파츠 원화/PSD: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . 이미지 AI는 실제 헤어 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.inochi2d.com/en/latest/creator/nodes/node.html . Inochi Creator의 노드·파츠 계층과 메시 조절은 후속 모델링 단계이다. 이미지 AI가 Inochi 네이티브 리깅을 완료했다는 뜻이 아니다.
- 큰 머리 실루엣과 정수리 볼륨, 머리카락 뿌리·귀 앞뒤·목 뒤 가림을 넉넉히 보완한다. 개별 흔들림이 필요한 가닥만 분리하고 고정 명암은 합친다. 테이퍼 끝과 아호게 등은 실제 디자인에 있는 것만 적용한다.
- 독립 ArtMesh 수나 그림자/하이라이트 PNG 수를 고정하지 않는다. 고정 문양은 본체에, 실제 다른 움직임·앞뒤 순서가 필요한 요소만 나눈다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 미리보기는 실제 파츠를 조립한 그림으로 만들고 기준 몸체는 좌표 참고용으로만 사용한다.
- 커뮤니티 원화 사례: https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ — 개별 작업자 경험이며 공식 필수 조건이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. Inochi Creator PSD/Nodes 사용법: https://docs.inochi2d.com/en/latest/creator/nodes/node.html .

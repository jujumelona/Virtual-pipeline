# Inochi2D 전신 헤어 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 전신 캔버스에서 해당 헤어스타일의 실제 영역만. 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 공식 근거를 이미지 제작에 적용
- 공식 Inochi2D Creator 파츠 원화/PSD: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . 이미지 AI는 실제 헤어 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.inochi2d.com/en/latest/creator/nodes/node.html . Inochi Creator의 노드·파츠 계층과 메시 조절은 후속 모델링 단계이다. 이미지 AI가 Inochi 네이티브 리깅을 완료했다는 뜻이 아니다.
- 큰 머리 실루엣과 정수리 볼륨, 머리카락 뿌리·귀 앞뒤·목 뒤 가림을 넉넉히 보완한다. 개별 흔들림이 필요한 가닥만 분리하고 고정 명암은 합친다. 테이퍼 끝과 아호게 등은 실제 디자인에 있는 것만 적용한다.
- 독립 원화 파츠 수나 그림자/하이라이트 PNG 수를 고정하지 않는다. 고정 문양은 본체에, 실제 다른 움직임·앞뒤 순서가 필요한 요소만 나눈다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 미리보기는 실제 파츠를 조립한 그림으로 만들고 기준 몸체는 좌표 참고용으로만 사용한다.
- 개별 아티스트의 작업 경험은 Inochi2D의 고정 파츠 수나 Cubism 작업 절차를 요구하는 공식 규격이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. Inochi Creator PSD/Nodes 사용법: https://docs.inochi2d.com/en/latest/creator/nodes/node.html .


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / hair]
**Inochi2D 공식:** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — PSD 가져오기 예시와 중복 그림자 합성 주의. https://docs.inochi2d.com/en/latest/creator/nodes/node.html — Node 자식 Transform/Sorting은 후속 Creator 작업. **개인 작가 참고:** https://tips.clip-studio.com/en-us/articles/5958 (헤어 덩어리·모근·가닥의 원화 흐름). 이 팁의 고정 수치를 기술 규격이라 주장하지 않는다.
**해당 자산:** 요청된 한 헤어스타일만 앞머리·좌우 옆머리·뒷머리의 실제 독립 움직임 단위로 분리한다. 모근·뒤통수·귀 앞뒤와 긴 가닥의 숨은 부분을 같은 컬러와 라인으로 연장한다. 아호게·포니테일은 디자인에 실제 있을 때만. 기준 피부·눈·귀·의상은 캔버스 정합 참조이며 독립 헤어 텍스처로 출력하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_full/hair]
[Inochi2D 공식 PSD 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — 독립된 원화 그림 요소와 합성 상태 참고. **헤어 앞·옆·뒤 모근/숨은 가닥을 보완하는 방법**은 캐릭터 원화 작업 원칙이다. [개인 작가] https://tips.clip-studio.com/en-us/articles/8014 — 측면 머리 실루엣 참고. 눈 크기·목 피부 원화는 신체 ZIP에서만 제작한다.
공식 Inochi Creator PSD 가져오기에서는 그림자 레이어가 중복 합성될 수 있음: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . Node 정렬·블렌드·리깅은 후속 Creator 사용자 작업이다.


## [고급 그림자·모근·소재·선폭 | inochi2d_full/hair]
**[Inochi2D 공식과 아티스트 작업 구분]** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html 은 PSD 이미지 합성 시 그림자 겹침의 참고다. 볼에서 자라는 것처럼 보이는 모근 오류, 움직이는 헤어와 어긋나는 앞머리 투사 그림자, 뿌리부터 가닥 끝까지 이어지는 하이라이트는 **원화 미술 검수**이며 Inochi에서 강제하는 그림자/노드 수가 아니다.
[Inochi2D 공식 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html : PSD 가져오기 이후 그림자 레이어들이 중첩되어 원본과 다르게 보일 수 있다. 이미지 AI는 원본과 각 자산의 투명 RGBA/중립 합성을 점검하고, Creator Node/Sorting/실제 블렌드 설정은 후속 사용자가 수행한다.

## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 실제 생성·PSD 파츠·PNG에는 요청받은 머리카락만 포함한다. 필요하면 모발이 목/어깨 위로 드리워져도 되지만, BODY의 숨은 피부/모델 실루엣은 별도로 보존한다. 마네킹형 몸체를 HAIR 출력으로 납품하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

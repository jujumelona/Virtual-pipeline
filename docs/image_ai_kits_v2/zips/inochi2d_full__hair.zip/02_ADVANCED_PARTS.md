
## [2026-10-13 v5 inochi2d_full/hair 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
HAIR: 지정된 머리 하나만 독립 파츠 제작. BODY·귀·눈·목·의상을 새로 생성하지 않고 동일 캔버스/원점/스케일을 따르며 모근/이마/귀 뒤 숨은 가닥과 좌우 앞뒤 레이어, 알파/단정한 선화를 검수. 특정 헤어스타일·고정 눈색·장식 강제 금지. Inochi2D 노드/정렬은 후속 Creator 작업이다.

# 헤어만 — 지정된 한 헤어스타일의 고급 독립 원화

> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 해당 2D 자산의 고품질 완성 기준 원화 먼저 생성 → 같은 캔버스에서 실제 RGBA 파츠만 분리 → 해당 자산의 숨은 면 추가 작화. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.

**신체·눈·입·의상·장식 세트를 새로 만들지 않는다.** 사용자가 준 기본 신체 얼굴/머리 크기와 좌우 비대칭에 맞춘다.

| 파츠 이름 예 | 그리기 기준 |
|---|---|
| hair_back_base.png | 뒤통수 뒤쪽 실루엣과 뿌리, 귀 뒤로 가려진 부분 |
| hair_back_layer_01.png | 뒤쪽 머리의 실제 서로 다른 깊이/흔들림 층 |
| hair_front_center.png, hair_front_L.png, hair_front_R.png | 앞머리 묶음이 서로 따로 흔들리는 경우 원화에서 분리 |
| hair_side_L.png, hair_side_R.png | 옆머리, 귀·얼굴 측면을 덮는 부위에 충분한 뿌리 |
| hair_lock_L_01.png, hair_lock_R_01.png | 독립 움직임이 있는 긴 가닥에만 추가. **긴 가닥을 억지로 여러 이미지로 자르지 않음** |
| hair_ahoge.png, hair_twin_L.png, hair_twin_R.png | **사용자 헤어스타일에 있을 때에만**. 머리카락 없는 스타일에 추가 금지 |

완성 헤어 원화에서 필요한 파츠를 마스크로 분리한다. **머리뿌리·안쪽 색상·가려진 영역만 추가로 보완하여 자연스럽게 연결**한다. 사용자 지정 헤어스타일 하나만 ZIP에 넣는다. 미리보기에서만 기존 얼굴 위에 합성할 수 있다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / hair]
요청된 한 헤어스타일만 앞머리·좌우 옆머리·뒷머리의 실제 독립 움직임 단위로 분리한다. 모근·뒤통수·귀 앞뒤와 긴 가닥의 숨은 부분을 같은 컬러와 라인으로 연장한다. 아호게·포니테일은 디자인에 실제 있을 때만. 기준 피부·눈·귀·의상은 캔버스 정합 참조이며 독립 헤어 텍스처로 출력하지 않는다.


## [고급 그림자·모근·소재·선폭 | inochi2d_full/hair]
**[헤어만/모근·그림자 소유]** 완성 헤어 원화에서 뿌리 위치가 두피 곡면을 따라 앞·옆·뒤로 연결되는지를 먼저 판단하고 실제 독립적으로 흔들리는 가닥만 분리한다. 눈/피부를 새로 만들지 않되, **앞머리가 얼굴에 만드는 그림자가 실제 디자인에서 필요하고 별도로 움직여야 한다면** 피부 베이스에 굽지 않고 **헤어 소유의 선택적 별도 투명 그림자**로 계획한다. 필요 없으면 만들지 않는다. 헤어 자체의 뿌리·가닥·뒷면 명암은 해당 헤어 PNG에만 포함한다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** inochi2d_full / hair; HAIR — 요청받은 헤어스타일 한 종류의 가닥·후두부·머리뿌리·그림자. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: Inochi2D 전신: 6등신 애니풍 전신과 사지의 연결. Cubism 네이티브 파일은 요구하지 않는다.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png.
- 최소 참고 파일 후보: reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png.
- 위 PNG 목록은 **납품 필수**이고 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 앞머리/옆머리/뒷머리/아호게 등 독립적으로 움직일 실제 묶음만 생성한다. 앞머리 아래 이마를 머리카락으로 새로 그리면 안 되며, 귀 앞뒤와 정수리·후두부의 숨은 가닥·뿌리·끝의 실제 픽셀을 추가한다. 좌우 프로필 및 후면에서 머리카락 질량·뿌리 방향·가닥 겹침을 정합시킨다.
- Colab 입력 파츠·경로 계약: HAIR의 isolated_parts/ 파츠 ID는 hair 계열로 시작하도록 적고, 한 파츠의 좌우·깊이 정보를 이름에 명확히 표시한다. 다른 자산의 이름이나 픽셀은 독립 파츠로 포함하지 않는다. layer_order.txt의 경로는 실제 isolated_parts/ PNG와 1:1 매칭한다.
- 자산 소유권 금지: BODY의 눈·피부·목·손, OUTFIT, ACCESSORY를 새 완성 자산으로 그리거나 PSD 파츠에 혼입하지 않는다.
- 2D ZIP의 실제 납품은 해당 자산의 기준 마스터 원화, 추가 참고 시점 그림, 독립 RGBA 원화 파츠와 마스크, 합성 미리보기, 편집 가능한 레이어 PSD 및 검수표다. 참고 시점 PNG가 자동으로 모션 키폼·메시가 되지는 않는다.
- 기존 MD에서 reference_views/를 '필요한 경우만' 또는 선택 사항으로 표현했더라도 위 지정 시점 파일은 최종 ZIP에서 필수다. 파일명 대소문자/확장자/경로를 변경하지 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

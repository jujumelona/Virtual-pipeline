# inochi2d_full / hair — Inochi2D 해당 자산 공식 근거

> 00_MASTER_FIRST.md의 완성 원화 우선 계약을 따른다. Inochi Creator 실행/노드/리깅은 이 ZIP의 출력물이 아니다.

## 적용 대상: Inochi2D용 헤어 한 종류
[Inochi Creator 공식 첫 모델](https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html)은 가져올 PSD 일러스트 파츠와 그림자 합성의 주의점을 안내한다. [공식 Node 문서](https://docs.inochi2d.com/en/latest/creator/nodes/node.html)는 모델링 후 노드와 앞뒤 정렬의 참고다.
이미지 AI는 **실제 헤어 원화와 모근·앞·옆·뒤 헤어 RGBA**만 출력한다. 얼굴·눈·귀·목 피부·의상 제작과 Creator Node/메시/리깅 작업은 이 ZIP의 대상이 아니다.

각 ZIP은 `00_MASTER_FIRST.md`의 자산·모드 범위를 우선한다. 이 문서에 열거된 파일명/예제는 이 프로젝트 산출 기준이지 공식 엔진의 고정 파츠/이미지 개수 규정이 아니다. 링크는 기법의 출처이며 모델링·PSD 처리 도구 실행 및 외부 다운로드/라이선스 확보를 이미지 생성 AI의 필수 단계로 만들지 않는다.

## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 실제 생성·PSD 파츠·PNG에는 요청받은 머리카락만 포함한다. 필요하면 모발이 목/어깨 위로 드리워져도 되지만, BODY의 숨은 피부/모델 실루엣은 별도로 보존한다. 마네킹형 몸체를 HAIR 출력으로 납품하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

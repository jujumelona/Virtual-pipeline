# Inochi2D 전신 / 헤어만 결과 이미지 ZIP

**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.


> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 해당 2D 자산의 고품질 완성 기준 원화 먼저 생성 → 같은 캔버스에서 실제 RGBA 파츠만 분리 → 해당 자산의 숨은 면 추가 작화. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
`inochi2d_full__hair__ARTWORK.zip`
```text
isolated_parts/hair_back_base.png
isolated_parts/hair_front_center.png
isolated_parts/hair_side_L.png
isolated_parts/hair_side_R.png
layer_order.txt
previews/overlay_preview.png
```
파츠명 예시로 실제 있는 부위만 그린다. headpiece는 사용자가 머리장식을 요청한 경우에만 사용. 02의 고급 개별 움직임에 맞춰 파츠 추가, 동일 원점·투명 RGBA, 마지막 합성, 뒤→앞 목록. **07+09+10의 애니풍 품질·파일 조건 확인 후 최종 ZIP 납품**.


## ZIP 고유 작업 범위 잠금: inochi2d_full / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 전신 캔버스에서 해당 헤어스타일의 실제 영역만. 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 

실제 디자인에 포함된 해당 hair 파츠만 isolated_parts/에 납품한다. 몸체와 얼굴은 기준 좌표 참조 전용이며 다른 자산을 재제작하지 않는다.

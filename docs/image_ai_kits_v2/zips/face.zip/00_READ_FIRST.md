【SEE_THROUGH_ONLY_2D_V1 / 2D 원화 생성 최우선】
- GPT/Gemini 이미지 생성은 각 자산의 고품질 애니풍 원화(master.png)와 시점별 참고 PNG만 담당한다. 독립 눈·입·머리 PNG, alpha mask, PSD, 메시, 리깅 파일을 생성하지 않는다.
- See-through(내부 LayerDiff/Marigold 및 공식 SemanticSAM 후처리)만 파츠 분리 모델로 사용한다. Qwen/Stable-Layers 및 기타 이미지 생성 AI를 분리 모델로 사용하지 않는다.
- FACE·HAIR·OUTFIT·ACCESSORY 단독 그림을 See-through 전체 캐릭터 입력에 직접 주지 않는다. 반드시 OUTFIT(착의 몸체) → FACE(얼굴·목) → HAIR(앞·옆·뒤 머리) → ACCESSORY(선택 소품)를 동일 캔버스로 정렬·합성해 완성된 정면 캐릭터 PNG 한 장을 만든 후 See-through를 실행한다. 순서는 기본 합성 순서이며 목·옷깃·머리/얼굴 가림은 시각 검수한다.
- outputs/master.png는 해당 자산만 담긴 실제 RGBA 투명 원화여야 한다. 흰색 RGB 배경을 RGBA로 단순 변환한 것은 무효. 불투명 배경만 가능하다면 합성 준비 미완료를 알리고 실제 투명 PNG로 수정한다.
- 공통 FACE와 구도별 자산은 머리 크기/목 끝/옷깃/어깨/두상 중심 및 픽셀 좌표를 일치시킨다. 캔버스 크기 불일치 시 임의 확대·축소하지 말고 실제 좌표 정합을 요구한다. 피부색은 사용자의 참고 캐릭터가 최우선이며 FACE·목·손에서 같아야 한다.
- 정면 원화는 눈 좌우의 흰자·홍채·동공·윗속눈썹, 입 닫힘/벌림 참고, 모근·앞옆뒤 머리, 목·옷깃 경계가 뚜렷한 전문 애니 VTuber 그림이다. 원화는 분리 시트가 아니며 숨겨진 면은 참고 시점에서 제시한다.
- 기존 04_OUTPUT_FILES.md의 원화·reference_views·expression_refs PNG 이름과 자산 경계를 준수한다. 결과 ZIP에 PSD, 마스크, isolated_parts, layer_order.txt 등 추가하지 않는다. 분리 PSD 구조 검사와 실제 움직임/Pro2D 사용 검증은 별개이다.

---

# 고품질 애니 VTuber FACE 원화 필수 — 원시 도형 얼굴 금지

【PRIMARY MASTER IMAGE PROMPT / 최우선】

Professional original Japanese anime VTuber character concept art, premium 2D Live2D-ready adult anime face and neck ONLY, elegant youthful adult expression, clean bald scalp as a base for separate hair, beautifully drawn rounded short U-shaped face and natural chin, gorgeous large mint-green anime eyes containing detailed sclera, eyelid shapes, refined upper and lower eyelashes, layered irises, pupils and reflective highlights, subtle natural eyebrows, delicate anime nose and soft expressive mouth, realistically structured-in-anime ears, well-proportioned jaw-to-neck connection, subtle peach blush, uniform soft-peach skin #F2D4BE on head, ears and neck, polished thin line art with graceful tapered stroke weights and carefully controlled two-to-three-tone cel shading. High-end streaming anime avatar illustration, NOT a diagram.

Negative: kindergarten clipart, minimalist icon, flat oval head with sticker eyes, stick or cylindrical neck, primitive SVG circles, generic mannequin, plastic 3D render, photoreal skin, simple line smile, emoji, cartoon mascot, sloppy profiles, detached ears, hair, clothes, shoulders, torso, arms, multiple panels, labels or watermarks.

정면 outputs/master.png를 **한 장의 고품질 애니 원화**로 먼저 그린다. 실제로 이 품질이 합격하기 전에는 나머지 11장의 제작을 시작하지 않는다.

---

【VTUBER_FACE_ART_QUALITY_V2】 '버추얼'은 방송에서 얼굴·눈·입이 움직이는 아름다운 2D 일본 애니 캐릭터를 뜻한다. 동그라미·타원·직선 도형을 합성한 교육용 대머리 마네킹이 아니다.
- 미형: 자연스러운 이마·두상·뒷통수, 짧고 부드러운 U형 턱, 균형 잡힌 눈의 크기와 간격, 작은 코·입, 실제 구조를 이해한 귀와 턱 아래로 유기적으로 이어지는 목. 성인 애니 VTuber 얼굴 원화의 유려한 곡선과 아름다운 비율을 유지.
- 눈 필수: 양눈 각각 흰자·윗/아랫 눈꺼풀·속눈썹·다층 황금 민트색 홍채·동공·빛 반사 하이라이트. 민트 점 두 개나 정면 눈 스티커로 대체하지 않는다.
- 선화: 가늘고 깨끗한 선 + 위치별 굵기 변화/끝의 테이퍼링, 볼의 은은한 홍조, 얼굴·두피·귀·목에 같은 피부색 #F2D4BE와 세련된 2~3단계 셀 쉐이딩. 실사·해부학적 목근육 디테일 금지.
- 얼굴만 그리되 머리가 빠진 인형처럼 보여서는 안 된다. 후속 HAIR를 얹을 두상 볼륨은 자연스럽고, 목은 후속 OUTFIT 목깃으로 이어질 수 있게 그린다.
- 출력은 image generation으로 실제 일러스트를 제작한다. Python/SVG/Cairo 원/타원/사각형/펜선 도형을 조립해 그럴듯한 아바타처럼 꾸미는 것은 **제작 실패**.
- FACE 원화에는 어깨·몸통·팔·손·옷·헤어·액세서리가 없어야 한다. 파츠 분리·PSD·마스크·리깅은 후속 Colab의 책임이다.

---

# 생성 시작 전 확인

**SOURCE_ART_ONLY_V7 — 이미지 생성 AI 전용.** 이 ZIP에서는 완성 원화와 여러 시점의 참고 원화 PNG만 제작한다. 잘라낸 파츠 PNG, 각 파츠별 재생성, 마스크, 레이어 PSD, 메시, 리깅, MOC3, VRM 완성을 이미지 생성 AI에 절대 요구하지 않는다. **실제 파츠 분리·PSD 생성·리깅은 후속 Colab 노트북의 책임**이며, 노트북의 미구현 기능을 성공으로 표시해서는 안 된다.

**선택:** 공통 FACE (제작 모드·프레이밍 독립) / FACE 얼굴·목 전용

**구도:** 두상에서 목 끝까지만. 몸통·어깨·팔·손 제외.

**자산 경계:** 성인 애니 VTuber 얼굴(민머리·눈·코·입·귀·턱)과 목만 생성한다. 몸통·가슴·복부·어깨·팔·손·의상은 생성하지 않는다.

**색·위치:** 얼굴·귀·두피·목 피부톤 #F2D4BE 통일. 2~3단 셀 명암, 큰 민트 홍채, 자연스러운 U형 턱. 목은 후속 의상 목깃 속에 들어갈 부분만 남긴다.

**원화 세부:** 실제 정면·좌우 45도·측면 90도·상하 고개 각도의 얼굴·귀·턱·목 투영을 그린다

사용자가 준 이미지가 있다면 그 캐릭터의 얼굴·눈·기본색·디자인을 우선 확인한다. 기존 FACE 기준이 없는 신규 자산은 새 디자인으로 생성 가능하지만 기존 몸체와 정확히 맞는다고 주장하지 않는다.

## FACE_ONLY_V1
얼굴·눈·귀·코·입·턱·목만 그린다. 몸통·가슴·어깨·팔·손·복부 및 의상은 어떤 참고 이미지에도 그리지 않는다.


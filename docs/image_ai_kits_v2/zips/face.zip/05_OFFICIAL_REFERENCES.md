# 공식 참고

Live2D https://docs.live2d.com/en/cubism-editor-tutorials/psd/ · Inochi2D https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html · VRoid https://vroid.com/en/studio . 공통 얼굴 원화는 어느 구도에도 종속되지 않는다.

참고 링크를 실제로 열지 못했다면 봤다고 주장하지 않는다. 원화 제작은 사용자 기준 이미지와 SOURCE_ART_ONLY_V7 계약을 따라 진행한다.

## FACE_ONLY_V1
얼굴·눈·귀·코·입·턱·목만 그린다. 몸통·가슴·어깨·팔·손·복부 및 의상은 어떤 참고 이미지에도 그리지 않는다.


# 고품질 애니 VTuber FACE 원화 필수 — 원시 도형 얼굴 금지

【PRIMARY MASTER IMAGE PROMPT / 최우선】

Professional original Japanese anime VTuber character concept art, premium 2D Live2D-ready adult anime face and neck ONLY, elegant youthful adult expression, clean bald scalp as a base for separate hair, beautifully drawn rounded short U-shaped face and natural chin, gorgeous large amber-orange anime eyes containing detailed sclera, eyelid shapes, refined upper and lower eyelashes, layered irises, pupils and reflective highlights, subtle natural eyebrows, delicate anime nose and soft expressive mouth, realistically structured-in-anime ears, well-proportioned jaw-to-neck connection, subtle peach blush, uniform soft-peach skin #F2D4BE on head, ears and neck, polished thin line art with graceful tapered stroke weights and carefully controlled two-to-three-tone cel shading. High-end streaming anime avatar illustration, NOT a diagram.

Negative: kindergarten clipart, minimalist icon, flat oval head with sticker eyes, stick or cylindrical neck, primitive SVG circles, generic mannequin, plastic 3D render, photoreal skin, simple line smile, emoji, cartoon mascot, sloppy profiles, detached ears, hair, clothes, shoulders, torso, arms, multiple panels, labels or watermarks.

정면 outputs/master.png를 **한 장의 고품질 애니 원화**로 먼저 그린다. 실제로 이 품질이 합격하기 전에는 나머지 11장의 제작을 시작하지 않는다.

---

【VTUBER_FACE_ART_QUALITY_V2】 '버추얼'은 방송에서 얼굴·눈·입이 움직이는 아름다운 2D 일본 애니 캐릭터를 뜻한다. 동그라미·타원·직선 도형을 합성한 교육용 대머리 마네킹이 아니다.
- 미형: 자연스러운 이마·두상·뒷통수, 짧고 부드러운 U형 턱, 균형 잡힌 눈의 크기와 간격, 작은 코·입, 실제 구조를 이해한 귀와 턱 아래로 유기적으로 이어지는 목. 성인 애니 VTuber 얼굴 원화의 유려한 곡선과 아름다운 비율을 유지.
- 눈 필수: 양눈 각각 흰자·윗/아랫 눈꺼풀·속눈썹·다층 황금 주황색 홍채·동공·빛 반사 하이라이트. 주황 점 두 개나 정면 눈 스티커로 대체하지 않는다.
- 선화: 가늘고 깨끗한 선 + 위치별 굵기 변화/끝의 테이퍼링, 볼의 은은한 홍조, 얼굴·두피·귀·목에 같은 피부색 #F2D4BE와 세련된 2~3단계 셀 쉐이딩. 실사·해부학적 목근육 디테일 금지.
- 얼굴만 그리되 머리가 빠진 인형처럼 보여서는 안 된다. 후속 HAIR를 얹을 두상 볼륨은 자연스럽고, 목은 후속 OUTFIT 목깃으로 이어질 수 있게 그린다.
- 출력은 image generation으로 실제 일러스트를 제작한다. Python/SVG/Cairo 원/타원/사각형/펜선 도형을 조립해 그럴듯한 아바타처럼 꾸미는 것은 **제작 실패**.
- FACE 원화에는 어깨·몸통·팔·손·옷·헤어·액세서리가 없어야 한다. 파츠 분리·PSD·마스크·리깅은 후속 Colab의 책임이다.

---

# 공식 참고

Live2D https://docs.live2d.com/en/cubism-editor-tutorials/psd/ · Inochi2D https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . 2D FACE는 3D VRM 복원과 분리되는 공통 얼굴/목 원화다.

참고 링크를 실제로 열지 못했다면 봤다고 주장하지 않는다. 원화 제작은 사용자 기준 이미지와 SOURCE_ART_ONLY_V7 계약을 따라 진행한다.

## FACE_ONLY_V1
얼굴·눈·귀·코·입·턱·목만 그린다. 몸통·가슴·어깨·팔·손·복부 및 의상은 어떤 참고 이미지에도 그리지 않는다.


# 고품질 애니 VTuber FACE 원화 필수 — 원시 도형 얼굴 금지

【작업 순서】 master.png 한 장 제작 → 시각적 미형/애니 품질 합격 → 동일 인물 시점별 한 장씩 독립 제작 → 모든 12장 확인 → ZIP 납품.
- 12칸 컨택트시트를 만들어 잘라서 PNG 파일 수를 맞추거나 같은 그림을 이름만 바꾸는 것 금지. 한 파일=한 고해상도 시점. 권장 단일 캔버스 1200×1600 이상, 동일 두상 크기/중심 앵커, 머리와 목 전체가 크게 보이도록.
- 원화 12장의 파일명·색상·해상도가 맞아도 화풍이 '단순 벡터 얼굴'이면 전체 제작 실패. 선화/눈/턱/목이 전문 VTuber 수준이 아니라면 다른 시점을 만들지 말고 마스터부터 다시 생성한다.
- PNG 배경은 실제 투명 RGBA를 우선. 투명 출력이 안 되면 균일 단색으로 두고 투명하다고 주장하지 않는다.

---

master/front: 실제 같은 인물의 정면 애니 얼굴·목. master 합격 원화를 face_front 기준으로 재사용할 수 있지만 해상도/배치/캐릭터 정체성은 바꾸지 않는다.
- three_quarter_L/R: 두개골·코·턱·귀가 실제 약 45도 회전. 가까운 눈과 먼 눈의 크기/형태가 바뀐다. 정면 그림에서 눈/코 위치만 옮기거나 단순 거울반전하면 실패.
- profile_L/R: 약 90도 측면. 한쪽 눈만 측면 형태로 보이고 이마/코끝/입/턱/귀/뒤통수 실루엣이 실제 애니 측면으로 바뀐다. 눈이 두 개 보이거나 옆으로 움직인 정면 얼굴이면 실패.
- pitch_up: 턱밑 면과 코/눈 원근이 변하는 실제 상향 회전. pitch_down: 정수리와 이마 면적·눈·턱 원근이 변하는 실제 하향 회전. 이미지를 위아래 이동만 시킨 형태면 실패.
- neck_underpaint: 얼굴과 턱 뒤 목이 실제로 이어지는 완성 원화 참고. 단색 마스크 아님. face_neck_overlap: 3/4 턱과 목의 자연스러운 전후 가림 완성 원화. 원통형 목 금지.
- mouth_closed / mouth_open: 같은 정면 얼굴의 입만 자연스러운 다문/벌린 발화 형태로 다르고 얼굴형·눈매·눈동자·피부색은 일관. 벌린 입에는 자연스러운 입안·혀를 그린다.

---

# 출력 파일 계약

**SOURCE_ART_ONLY_V7 — 이미지 생성 AI 전용.** 이 ZIP에서는 완성 원화와 여러 시점의 참고 원화 PNG만 제작한다. 잘라낸 파츠 PNG, 각 파츠별 재생성, 마스크, 레이어 PSD, 메시, 리깅, MOC3, VRM 완성을 이미지 생성 AI에 절대 요구하지 않는다. **실제 파츠 분리·PSD 생성·리깅은 후속 Colab 노트북의 책임**이며, 노트북의 미구현 기능을 성공으로 표시해서는 안 된다.

ZIP: `face__ARTWORK.zip`

- `outputs/master.png`
- `reference_views/face_front.png`
- `reference_views/head_three_quarter_L.png`
- `reference_views/head_three_quarter_R.png`
- `reference_views/head_profile_L.png`
- `reference_views/head_profile_R.png`
- `reference_views/head_pitch_up.png`
- `reference_views/head_pitch_down.png`
- `reference_views/neck_underpaint.png`
- `reference_views/face_neck_overlap.png`
- `expression_refs/mouth_closed.png`
- `expression_refs/mouth_open.png`

PNG 파일 이름·폴더 이름을 정확히 지킨다. 그 외의 파츠 파일, PSD·레イヤ 순서 파일, JSON·가짜 MOC3/VRM은 넣지 않는다.

## FACE_ONLY_V1
얼굴·눈·귀·코·입·턱·목만 그린다. 몸통·가슴·어깨·팔·손·복부 및 의상은 어떤 참고 이미지에도 그리지 않는다.


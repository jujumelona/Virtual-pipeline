【SEE_THROUGH_ONLY_2D_V1 / 2D 원화 생성 최우선】
- GPT/Gemini 이미지 생성은 각 자산의 고품질 애니풍 원화(master.png)와 시점별 참고 PNG만 담당한다. 독립 눈·입·머리 PNG, alpha mask, PSD, 메시, 리깅 파일을 생성하지 않는다.
- See-through(내부 LayerDiff/Marigold 및 공식 SemanticSAM 후처리)만 파츠 분리 모델로 사용한다. Qwen/Stable-Layers 및 기타 이미지 생성 AI를 분리 모델로 사용하지 않는다.
- FACE·HAIR·OUTFIT·ACCESSORY 단독 그림을 See-through 전체 캐릭터 입력에 직접 주지 않는다. 반드시 OUTFIT(착의 몸체) → FACE(얼굴·목) → HAIR(앞·옆·뒤 머리) → ACCESSORY(선택 소품)를 동일 캔버스로 정렬·합성해 완성된 정면 캐릭터 PNG 한 장을 만든 후 See-through를 실행한다. 순서는 기본 합성 순서이며 목·옷깃·머리/얼굴 가림은 시각 검수한다.
- outputs/master.png는 해당 자산만 담긴 실제 RGBA 투명 원화여야 한다. 흰색 RGB 배경을 RGBA로 단순 변환한 것은 무효. 불투명 배경만 가능하다면 합성 준비 미완료를 알리고 실제 투명 PNG로 수정한다.
- 공통 FACE와 구도별 자산은 머리 크기/목 끝/옷깃/어깨/두상 중심 및 픽셀 좌표를 일치시킨다. 캔버스 크기 불일치 시 임의 확대·축소하지 말고 실제 좌표 정합을 요구한다. 피부색은 사용자의 참고 캐릭터가 최우선이며 FACE·목·손에서 같아야 한다.
- 정면 원화는 눈 좌우의 흰자·홍채·동공·윗속눈썹, 입 닫힘/벌림 참고, 모근·앞옆뒤 머리, 목·옷깃 경계가 뚜렷한 전문 애니 VTuber 그림이다. 원화는 분리 시트가 아니며 숨겨진 면은 참고 시점에서 제시한다.
- 기존 04_OUTPUT_FILES.md의 원화·reference_views·expression_refs PNG 이름과 자산 경계를 준수한다. 결과 ZIP에 PSD, 마스크, isolated_parts, layer_order.txt 등 추가하지 않는다. 분리 PSD 구조 검사와 실제 움직임/Pro2D 사용 검증은 별개이다.

---

# 고품질 애니 VTuber FACE 원화 필수 — 원시 도형 얼굴 금지

【작업 순서】 master.png 한 장 제작 → 시각적 미형/애니 품질 합격 → 동일 인물 시점별 한 장씩 독립 제작 → 모든 12장 확인 → ZIP 납품.
- 12칸 컨택트시트를 만들어 잘라서 PNG 파일 수를 맞추거나 같은 그림을 이름만 바꾸는 것 금지. 한 파일=한 고해상도 시점. 권장 단일 캔버스 1200×1600 이상, 동일 두상 크기/중심 앵커, 머리와 목 전체가 크게 보이도록.
- 원화 12장의 파일명·색상·해상도가 맞아도 화풍이 '단순 벡터 얼굴'이면 전체 제작 실패. 선화/눈/턱/목이 전문 VTuber 수준이 아니라면 다른 시점을 만들지 말고 마스터부터 다시 생성한다.
- PNG 배경은 실제 투명 RGBA를 우선. 투명 출력이 안 되면 균일 단색으로 두고 투명하다고 주장하지 않는다.

---

master/front: 실제 같은 인물의 정면 애니 얼굴·목. master 합격 원화를 face_front 기준으로 재사용할 수 있지만 해상도/배치/캐릭터 정체성은 바꾸지 않는다.
- three_quarter_L/R: 두개골·코·턱·귀가 실제 약 45도 회전. 가까운 눈과 먼 눈의 크기/형태가 바뀐다. 정면 그림에서 눈/코 위치만 옮기거나 단순 거울반전하면 실패.
- profile_L/R: 약 90도 측면. 한쪽 눈만 측면 형태로 보이고 이마/코끝/입/턱/귀/뒤통수 실루엣이 실제 애니 측면으로 바뀐다. 눈이 두 개 보이거나 옆으로 움직인 정면 얼굴이면 실패.
- pitch_up: 턱밑 면과 코/눈 원근이 변하는 실제 상향 회전. pitch_down: 정수리와 이마 면적·눈·턱 원근이 변하는 실제 하향 회전. 이미지를 위아래 이동만 시킨 형태면 실패.
- neck_underpaint: 얼굴과 턱 뒤 목이 실제로 이어지는 완성 원화 참고. 단색 마스크 아님. face_neck_overlap: 3/4 턱과 목의 자연스러운 전후 가림 완성 원화. 원통형 목 금지.
- mouth_closed / mouth_open: 같은 정면 얼굴의 입만 자연스러운 다문/벌린 발화 형태로 다르고 얼굴형·눈매·눈동자·피부색은 일관. 벌린 입에는 자연스러운 입안·혀를 그린다.

---

# 출력 파일 계약

**SOURCE_ART_ONLY_V7 — 이미지 생성 AI 전용.** 이 ZIP에서는 완성 원화와 여러 시점의 참고 원화 PNG만 제작한다. 잘라낸 파츠 PNG, 각 파츠별 재생성, 마스크, 레이어 PSD, 메시, 리깅, MOC3, VRM 완성을 이미지 생성 AI에 절대 요구하지 않는다. **실제 파츠 분리·PSD 생성·리깅은 후속 Colab 노트북의 책임**이며, 노트북의 미구현 기능을 성공으로 표시해서는 안 된다.

ZIP: `face__ARTWORK.zip`

- `outputs/master.png`
- `reference_views/face_front.png`
- `reference_views/head_three_quarter_L.png`
- `reference_views/head_three_quarter_R.png`
- `reference_views/head_profile_L.png`
- `reference_views/head_profile_R.png`
- `reference_views/head_pitch_up.png`
- `reference_views/head_pitch_down.png`
- `reference_views/neck_underpaint.png`
- `reference_views/face_neck_overlap.png`
- `expression_refs/mouth_closed.png`
- `expression_refs/mouth_open.png`

PNG 파일 이름·폴더 이름을 정확히 지킨다. 그 외의 파츠 파일, PSD·레イヤ 순서 파일, JSON·가짜 MOC3/VRM은 넣지 않는다.

## FACE_ONLY_V1
얼굴·눈·귀·코·입·턱·목만 그린다. 몸통·가슴·어깨·팔·손·복부 및 의상은 어떤 참고 이미지에도 그리지 않는다.


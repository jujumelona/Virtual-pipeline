## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **live2d_bust_up / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 기존 자료 형식: PSD
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.
- 3. **Live2D Mark-kun original example with sample PSD (FREE learning)** — https://www.live2d.com/en/learn/sample/mark/
   - 기존 자료 형식: PSD
   - 실제 활용: Small/simple FREE scene topology and rig structure study, not a target face style; preserve its character-specific license.
   - 권리 확인: Official sample terms; structural learning only. Do not transform Mark-kun into user's anime character.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** head to upper abdomen/waist with complete shoulders arms and hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 live2d_bust_up/body 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.
BODY는 얼굴/눈/입 애니 작화와 몸통을 **별도 제작**한다. 짧고 둥근 U형 턱, 볼, 작고 내부선 1~2개 귀, 긴 목/큰 정수리 방지. 눈색은 사용자 지정값을 우선하여 분홍/노랑 기본 고정 금지. 몸통은 코드로 만든 불투명 중립색 단색 프록시 도형으로 구성하여 튜브탑/옷/속옷/가슴·쇄골·겨드랑이 살접힘/압박 주름/근육 음영을 넣지 않는다. 옛 전신 한 장 생성 지침·기본 슈트 지시보다 이 계약 우선. 실제 도형 코드 실행, 얼굴과 동일 캔버스 합성, 마스크/파츠·비교 QA 없으면 완료 금지. 방송용 가슴 위 프레임만 생성.

## 2026-10-13 사용자 지정 BODY 최상위 제작 규칙 — 기존 묘사 지시보다 우선
이 ZIP은 머리·얼굴 및 재사용용 몸체 실루엣을 위한 신체 전용 지시서다. 외부 생성 AI에게 얼굴부터 몸까지 완성한 인체 일러스트를 한 장으로 요구하지 않는다.
얼굴·눈·입을 애니풍으로 작업하고 BODY 몸체는 별도의 중립색 불투명 2D 도형 프록시를 프로그램으로 만든다. 몸체 도형에는 옷/속옷/튜브탑/리본/목깃/어깨 압박 주름/쇄골 윤곽/가슴 굴곡/겨드랑이 피부 접힘/근육/갈비뼈의 그림과 음영을 그리지 않는다.
정면 얼굴은 짧고 부드러운 U형 하관과 둥근 볼, 작은 애니 귀(내부 선 1~2개), 균형 잡힌 두상과 단순한 목을 사용한다. 기존의 긴 V자 턱과 실사형 큰 귀, 과도한 정수리와 긴 목을 다시 생성하면 FAIL이다. 눈 크기만으로 애니형 판정하지 않는다.
홍채 색은 사용자가 지정하거나 캐릭터별 팔레트에서 선정한다. 특정 분홍/노랑 눈색 고정 금지. 헤어와 의상, 액세서리는 BODY에 병합하지 않는다.
제작 순서: 공식 완성 VTuber 참고 이미지를 실제로 열어 비교·기록 → 얼굴 원화 시각 검수 → 단색 BODY 도형 생성 → 한 캔버스에서 조립 → RGBA 분리/가려진 면 검사 → 합성 QA → 최종 ZIP. 링크 확인만으로 이미지 시각검수 완료라고 보고하지 않는다.
도형 코드를 실행하지 않고 생성 AI에 통짜 몸통을 그리게 하면 본 지시 미준수다. 실행이 막히면 거짓 완료 판정 대신 제작 불가를 보고한다. PSD/리깅은 별도 단계.
신체 도형은 완성 캐릭터 일러스트가 아니라 의상 교체용 레이어이므로 미술적 화려함/인체 곡선을 요구하지 않는다. 사용자 얼굴 정체성과 전체 6등신 디자인 계약(전신인 경우)을 보존한다.

# Live2D 바스트업 신체 고유 제작·납품 모드

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / body
**실제 제작:** 고품질 애니 얼굴·눈·입·귀 원화와 별도 코드로 만든 목·어깨·상체의 단색 중립 BODY 실루엣만.
**금지:** 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
**구도:** 얼굴 중심의 고급 2D 애니 VTuber 근접 바스트업. 두피 정수리~턱 H가 전체 화면 세로의 52~61%를 차지하는 비율을 우선 시작값으로 삼고, 길게 펼쳐진 몸통 없이 짧은 목까지 얼굴 원화로 제작하고 어깨·몸통은 별도 단색 BODY 도형으로 합성한다.


- 전신 6등신 원화를 잘라 사용하는 구도가 아니라 처음부터 방송에 보이는 영역을 디자인한다. 헤어/의상/액세서리만의 경우 **기준 몸체는 합성 preview에만 참조**하고 생성하지 않는다.
- 이미지 AI 원화는 얼굴·눈·입·귀에 한정하고 목·어깨·상체는 별도의 단색 BODY 도형을 조립한다. 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
- 파츠 출력은 오직 이 자산의 실제 투명 RGBA PNG. 기준 원화의 원점·축척을 바꾸지 않는다.
- 파일은 실제 `isolated_parts/` 및 `layer_order.txt`의 L/R·뒤→앞 순서를 일치시킨다. 합성 미리보기는 해당 PNG를 실제 조립한 결과다.
- 실제 3D 또는 Cubism ArtMesh/Deformer/키폼/물리/모션은 제작하지 않는다.


## 바스트업 프레이밍 — 이 자산만 적용
- **얼굴 중심 근접 컷:** 두상 H가 프레임 세로의 52~61% 정도인 선택적 시작값. 아래쪽에는 목·어깨·짧은 단색 상체 프록시만 보인다. 전신을 축소·크롭하지 않는다.
- **골반·다리·발을 포함한 하체 그림은 바스트업에서 제작/납품하지 않는다.** 이 ZIP은 기준 캐릭터가 아니라 선택된 자산 한 종류만 실제 그림으로 만든다.
- 큰 애니풍 눈과 표정은 기준 캐릭터의 외형·프레이밍을 확인하기 위한 것이지, 헤어·의상·액세서리 ZIP에 얼굴 파츠 생성 의무를 부과하는 뜻이 아니다.


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / body]
### 바스트업 고유 구도(기술 강제가 아닌 프로젝트 설계)
얼굴 중심 근접 바스트업. H=두피 정수리~턱. 전체 프레임 세로는 약 1.65~1.95H를 시작값으로 하고, 두피~턱이 화면 세로 52~61% 정도로 크게 보이게 한다. 목·어깨·BODY 프록시 윗부분만 짧게 보이고 허리·긴 몸통·팔꿈치·손은 그리지 않는다. 이 수치는 공식 규격이 아닌 이 프로젝트의 얼굴 중심 미술 시작값이며 사용자 참조가 우선이다. 신체 파츠만 생성하고 다른 자산은 참조만 한다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/body]
**얼굴 중심 방송 구도 — 공식 규격이 아닌 선택값:** 얼굴 중심 근접 바스트업. H=두피 정수리~턱. 전체 프레임 세로는 약 1.65~1.95H를 시작값으로 하고, 두피~턱이 화면 세로 52~61% 정도로 크게 보이게 한다. 목·어깨·BODY 프록시 윗부분만 짧게 보이고 허리·긴 몸통·팔꿈치·손은 그리지 않는다. 이 수치는 공식 규격이 아닌 이 프로젝트의 얼굴 중심 미술 시작값이며 사용자 참조가 우선이다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/body]
방송용 가슴 위 프레임에서 해당 자산의 축소 가독성과 기준 얼굴·표정의 조화를 검수하되 화면 바깥 하체 제작을 강제하지 않는다. 스타일·원화가 지정되면 그 디자인을 우선하고, 잘려 있는 부위는 추측해 늘리지 않는다.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | body]
얼굴 중심 근접 바스트업. H=두피 정수리~턱. 전체 프레임 세로는 약 1.65~1.95H를 시작값으로 하고, 두피~턱이 화면 세로 52~61% 정도로 크게 보이게 한다. 목·어깨·BODY 프록시 윗부분만 짧게 보이고 허리·긴 몸통·팔꿈치·손은 그리지 않는다. 이 수치는 공식 규격이 아닌 이 프로젝트의 얼굴 중심 미술 시작값이며 사용자 참조가 우선이다.

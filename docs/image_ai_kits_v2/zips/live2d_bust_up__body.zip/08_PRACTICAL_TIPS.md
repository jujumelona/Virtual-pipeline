## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 독창적인 완성 원화를 처음부터 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **live2d_bust_up / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 기존 자료 형식: PSD
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.
- 3. **Live2D Mark-kun original example with sample PSD (FREE learning)** — https://www.live2d.com/en/learn/sample/mark/
   - 기존 자료 형식: PSD
   - 실제 활용: Small/simple FREE scene topology and rig structure study, not a target face style; preserve its character-specific license.
   - 권리 확인: Official sample terms; structural learning only. Do not transform Mark-kun into user's anime character.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** head to upper abdomen/waist with complete shoulders arms and hands
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참조 PSD의 존재는 작화 학습에 도움을 주지만 납품 필수 사용자 첨부물이 아니다. 공개 샘플의 실제 픽셀을 재사용하지 않고 원본 캐릭터를 직접 디자인하며, 완성 마스터에서 편집 가능한 PSD를 만든다. 일러스트 생성/PSD 쓰기 도구가 없으면 그 도구의 한계를 보고한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# Live2D 바스트업 body 고유 실무 노하우

2. 눈과 홍채를 충분히 크게, 코와 입은 애니풍으로 작고 간결하게 표현한다. 작은 방송 화면에서도 감정 전달력이 유지되는지 축소 미리보기로 본다.
3. 홍채 뒤 흰자, 눈꺼풀, 입 내부와 피부색 가림, 좌우 눈썹을 실제 분리해서 표정 변화에 빈 픽셀이 생기지 않게 한다.
4. 목은 겉보기 길이를 늘리지 않으면서 턱 뒤로 길게 그려 고개를 돌려도 끊김이 없게 한다. 귀 뒤·어깨선도 보완한다.
5. 원본 기준 원화와 투명 파츠를 재합성한 그림에서 눈/입 이중 표시, 피부 잔상, 목 절단과 어깨 접합을 확인한다.
6. 다른 자산에 속하는 머리카락, 교체 의상, 장식을 만들어 넣지 않는다. 불투명 베이스를 유지한다.

공통 작업: 실제 원본 기준 원화의 동일 캔버스·원점·스케일을 보존하고 투명 PNG를 원래 순서로 재합성합니다. 다른 자산 원화를 새로 만들거나 리깅 결과를 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / body]
### 작업 순서·아티스트 실전 노하우
2. 큰 눈/홍채·작은 코/입·단순한 귀·부드러운 턱을 같은 애니풍 조형언어로 통일한다. 눈·속눈썹 외곽은 선명하게, 피부 보조선은 얇고 채색색에 가까운 선으로 그린다.
3. 홍채 뒤 흰자·눈꺼풀 아래 피부·입안·귀 뒤·턱 뒤 목을 중립 원화에서 가려진 경우에도 이어 그린다.
4. 3/4·측면 참조가 실제 필요한 경우 먼 눈의 폭·코/턱 돌출·귀의 위치·목 피부가 바뀐 **별도 그림**으로 준비한다. 이미지 AI가 Cubism X/Y/Z 키폼을 자동 생성했다고 주장하지 않는다.
5. 중립 합성본의 입은 하나여야 하며 눈썹/눈꺼풀/홍채가 이중으로 남아 있으면 해당 레이어를 고친다. 불투명 기본 가림 아래 노출 신체를 복원하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/body]
**목 회전 대비 실제 원화 작업:** 중립 얼굴 외곽 아래에 피부색 목 파츠를 덧그린다. 목 피부 상단은 턱 뒤로만 살짝 연장하는 수준에 머무르지 않고 **입 높이 근처까지 가려져 있게** 준비하고, 턱 밑 앞목·귀 뒤 옆목·뒤통수 밑 뒷목과 쇄골 위 연결을 한 원화에서 연속적으로 만든다. 측면의 앞목 시작점은 턱 끝 바로 아래로 수직 낙하시키지 말고 턱 뒤, 뒷목은 귀 뒤~뒤통수 아래에서 어깨로 잇는다. 정면 목을 단순 눌러 측면이라고 부르지 않는다. 얼굴 좌/우 회전, 3/4, 옆모습을 상정한 참조 합성에서 턱 아래 구멍·목이 두 개 보이는 현상·귀 뒤 피부 누락·의복 가장자리 노출이 없는지 검사한다. 실제 에디터 리깅/회전 테스트를 수행한 것으로 주장하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/body]
**[고급 애니풍 신체 원화 작업]** 얼굴 외곽·턱 아래 깊은 겹침은 읽히는 선폭을, 속눈썹 끝·피부색 보조선·입은 필요한 만큼 가는 선을 사용한다. 원본의 검은/채색 선화 취향을 바꾸지 않는다. 분리한 눈·입·목 그림을 단색으로 때우지 말고 원화의 라인·밑색·셀 명암이 파츠 가장자리 안으로 이어지게 새로 그린다. 실제 표정/눈 움직임이 필요한 부위만 선택 분리하며 피부에 머리 모양 그림자를 지워지지 않게 붙이지 않는다.

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
방송용 바스트업: 머리부터 배 위~허리 위까지 완성된 캐릭터 신체 원화. 양쪽 어깨·상완·전완·손과 자연스러운 목 연결을 포함하며 손을 가린 포즈도 숨은 파츠를 준비한다. 고정된 얼굴 초근접 구도와 단색 몸통 프록시를 금지한다. 사용자가 요구한 고유 애니풍 얼굴형과 큰 눈·좌우 홍채 정합을 유지한다. 턱 뒤 목 언더페인트, 양어깨·상완·전완·양손·복부를 실제 일러스트로 그린다. 귀·입·코는 간결한 애니풍으로 유지하고 하나의 U형 턱으로 고정하지 않는다. 교체 헤어·의상·액세서리는 독립 자산으로 남긴다.
실제 다층 PSD, 같은 캔버스 투명 RGBA PNG와 파츠별 알파 마스크, 원본 입력과 원본 PSD(있다면), 원본-결과 및 PRO BODY 정합 미리보기, 레이어 좌표/순서·검증·분할 JSON, 사용자 제작·시각검수·Cubism 안내 MD는 최종 필수. PSD와 마스크가 없으면 중간 PNG 검사 PASS여도 최종 납품 불가. BODY 최종 납품에 --final-live2d-body를 사용한다. HAIR/OUTFIT/ACCESSORY도 PSD·마스크 필수. 실제 이미지/Editor 확인 없이 미술·리깅 품질 PASS 금지.
회색 단색 몸통, 프록시 도형, 끊긴 목, 누락된 팔/손, 짧은 상체는 최종 FAIL. 완성 원화→파츠 분리 순서. 최종 ZIP은 실제 다층 PSD·투명 파츠 PNG·알파 마스크·원본 입력·미리보기·레이어 좌표·분리/검증 JSON·Cubism 안내 필수. 중간 PNG 검사 통과만으로 납품 성공 주장 금지.

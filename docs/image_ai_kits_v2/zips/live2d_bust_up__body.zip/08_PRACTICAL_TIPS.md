## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **live2d_bust_up / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 기존 자료 형식: PSD
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.
- 3. **Live2D Mark-kun original example with sample PSD (FREE learning)** — https://www.live2d.com/en/learn/sample/mark/
   - 기존 자료 형식: PSD
   - 실제 활용: Small/simple FREE scene topology and rig structure study, not a target face style; preserve its character-specific license.
   - 권리 확인: Official sample terms; structural learning only. Do not transform Mark-kun into user's anime character.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** head to upper abdomen/waist with complete shoulders arms and hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# Live2D 바스트업 body 고유 실무 노하우

1. 두피 정수리~턱 H를 기준으로 얼굴이 화면을 주도하는 약 1.65~1.95H 프레임으로 시작한다. 긴 상체를 그리지 않는다.
2. 눈과 홍채를 충분히 크게, 코와 입은 애니풍으로 작고 간결하게 표현한다. 작은 방송 화면에서도 감정 전달력이 유지되는지 축소 미리보기로 본다.
3. 홍채 뒤 흰자, 눈꺼풀, 입 내부와 피부색 가림, 좌우 눈썹을 실제 분리해서 표정 변화에 빈 픽셀이 생기지 않게 한다.
4. 목은 겉보기 길이를 늘리지 않으면서 턱 뒤로 길게 그려 고개를 돌려도 끊김이 없게 한다. 귀 뒤·어깨선도 보완한다.
5. 원본 기준 원화와 투명 파츠를 재합성한 그림에서 눈/입 이중 표시, 피부 잔상, 목 절단과 어깨 접합을 확인한다.
6. 다른 자산에 속하는 머리카락, 교체 의상, 장식을 만들어 넣지 않는다. 불투명 베이스를 유지한다.

공통 작업: 실제 원본 기준 원화의 동일 캔버스·원점·스케일을 보존하고 투명 PNG를 원래 순서로 재합성합니다. 다른 자산 원화를 새로 만들거나 리깅 결과를 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / body]
### 작업 순서·아티스트 실전 노하우
1. 두상 H는 화면 높이 52~61%의 얼굴 중심 추천값이다. 셀셰이딩과 큰 애니 눈을 우선하며 사용자 디자인이 정하면 그에 맞춘다.
2. 큰 눈/홍채·작은 코/입·단순한 귀·부드러운 턱을 같은 애니풍 조형언어로 통일한다. 눈·속눈썹 외곽은 선명하게, 피부 보조선은 얇고 채색색에 가까운 선으로 그린다.
3. 홍채 뒤 흰자·눈꺼풀 아래 피부·입안·귀 뒤·턱 뒤 목을 중립 원화에서 가려진 경우에도 이어 그린다.
4. 3/4·측면 참조가 실제 필요한 경우 먼 눈의 폭·코/턱 돌출·귀의 위치·목 피부가 바뀐 **별도 그림**으로 준비한다. 이미지 AI가 Cubism X/Y/Z 키폼을 자동 생성했다고 주장하지 않는다.
5. 중립 합성본의 입은 하나여야 하며 눈썹/눈꺼풀/홍채가 이중으로 남아 있으면 해당 레이어를 고친다. 불투명 기본 가림 아래 노출 신체를 복원하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/body]
**목 회전 대비 실제 원화 작업:** 중립 얼굴 외곽 아래에 피부색 목 파츠를 덧그린다. 목 피부 상단은 턱 뒤로만 살짝 연장하는 수준에 머무르지 않고 **입 높이 근처까지 가려져 있게** 준비하고, 턱 밑 앞목·귀 뒤 옆목·뒤통수 밑 뒷목과 쇄골 위 연결을 한 원화에서 연속적으로 만든다. 측면의 앞목 시작점은 턱 끝 바로 아래로 수직 낙하시키지 말고 턱 뒤, 뒷목은 귀 뒤~뒤통수 아래에서 어깨로 잇는다. 정면 목을 단순 눌러 측면이라고 부르지 않는다. 얼굴 좌/우 회전, 3/4, 옆모습을 상정한 참조 합성에서 턱 아래 구멍·목이 두 개 보이는 현상·귀 뒤 피부 누락·의복 가장자리 노출이 없는지 검사한다. 실제 에디터 리깅/회전 테스트를 수행한 것으로 주장하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/body]
**[고급 애니풍 신체 원화 작업]** 얼굴 외곽·턱 아래 깊은 겹침은 읽히는 선폭을, 속눈썹 끝·피부색 보조선·입은 필요한 만큼 가는 선을 사용한다. 원본의 검은/채색 선화 취향을 바꾸지 않는다. 분리한 눈·입·목 그림을 단색으로 때우지 말고 원화의 라인·밑색·셀 명암이 파츠 가장자리 안으로 이어지게 새로 그린다. 실제 표정/눈 움직임이 필요한 부위만 선택 분리하며 피부에 머리 모양 그림자를 지워지지 않게 붙이지 않는다.

# Live2D 바스트업 body 공식·제작자 팁

공식 Live2D 일러스트 가공 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 눈·입·얼굴·목 원화 분리와 underpaint. 공식 눈 깜빡임 https://docs.live2d.com/en/cubism-editor-tutorials/eye-blink/ — 최종 키폼은 Cubism Editor 사용자 작업. 비공식 Live2dTree https://live2dtree.com/tutorial — 방송용 얼굴 중심 작화·표정 파츠 설계 참고.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / body]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 눈·입·목 레이어 분리, 흰자/입안/턱 뒤 숨은 영역 작화. **CLIP STUDIO TIPS 개인 작가:** https://tips.clip-studio.com/en-us/articles/6615 — 정면·3/4·옆얼굴의 눈 원근과 스타일 변화. 단, 이 작가의 수치는 Cubism 필수 규격이 아니다.
**공통 주의:** Live2D/Cubism 공식은 원화 분리·편집기 구현을 설명하지만, '정확한 6등신', '홍채 가로폭 몇 %', '2~3톤만 허용'을 기술 규격으로 요구하지 않는다. Cubism Editor의 키폼·클리핑·Skinning은 이미지 AI의 자동 납품 대상이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/body]
**[Live2D 공식]** https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 목 피부를 턱 뒤 입 높이 부근까지 추가 작화해 회전 시 끊김 방지. **[개인 작가]** https://tips.clip-studio.com/ko-kr/articles/11807 , https://tips.clip-studio.com/en-us/articles/8014 — 애니 얼굴과 측면 눈·귀 원근 참고. **[본 프로젝트 선택적 목표]** 바스트업 1.65~1.95H, 눈/얼굴 폭 23~29%, 홍채/눈 폭 62~80%는 공식 규격·통계적 일반값이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/body]
**[공식 vs 작업 경험]** Live2D 공식은 눈꼬리 속눈썹의 분리 편의와 숨은 흰자·입안 보완을 설명한다: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . Live2D 공식 가져오기 PSD 자료는 파츠당 선화/칠을 합치는 제작 단계를 설명한다: https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ . **피부 고정 그림자와 움직이는 앞머리 그림자의 소유권 분리**는 원화 품질을 위한 선택적 제작자 운영 원칙이며 Cubism에서 의무적으로 생성할 별도 그림자 수가 아니다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

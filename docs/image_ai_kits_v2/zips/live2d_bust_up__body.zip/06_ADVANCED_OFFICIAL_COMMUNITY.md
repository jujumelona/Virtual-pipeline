# Live2D 바스트업 body 공식·제작자 팁

공식 Live2D 일러스트 가공 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 눈·입·얼굴·목 원화 분리와 underpaint. 공식 눈 깜빡임 https://docs.live2d.com/en/cubism-editor-tutorials/eye-blink/ — 최종 키폼은 Cubism Editor 사용자 작업. 비공식 Live2dTree https://live2dtree.com/tutorial — 방송용 얼굴 중심 작화·표정 파츠 설계 참고.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / body]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 눈·입·목 레이어 분리, 흰자/입안/턱 뒤 숨은 영역 작화. **CLIP STUDIO TIPS 개인 작가:** https://tips.clip-studio.com/en-us/articles/6615 — 정면·3/4·옆얼굴의 눈 원근과 스타일 변화. 단, 이 작가의 수치는 Cubism 필수 규격이 아니다.
**공통 주의:** Live2D/Cubism 공식은 원화 분리·편집기 구현을 설명하지만, '정확한 6등신', '홍채 가로폭 몇 %', '2~3톤만 허용'을 기술 규격으로 요구하지 않는다. Cubism Editor의 키폼·클리핑·Skinning은 이미지 AI의 자동 납품 대상이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/body]
**[Live2D 공식/목 연결]** https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 얼굴이 움직일 때 목이 잘리지 않도록 목 피부 파츠를 겉보기보다 크게, **대략 입 높이까지** 위쪽으로 숨겨 그리라고 한다. 눈·입 내부·헤어에서 가려진 부분도 보완한다. **[작가 경험/눈·옆얼굴]** https://tips.clip-studio.com/ko-kr/articles/11807 , https://tips.clip-studio.com/ko-kr/articles/6599 , https://tips.clip-studio.com/en-us/articles/8014 — 양눈 간격의 한 눈 너비 출발점, 측면 눈의 코 뒤 위치, 3/4 먼 눈 축소를 설명한다. **[이 프로젝트 제안치]** 프레임 2.2~2.8H, 머리 약 40~50%, 한눈/얼굴폭 18~22%, 홍채/눈 55~70%는 이 자료들이 직접 확정한 측정 통계가 아니며 업계 표준이라고 주장하지 않는다.

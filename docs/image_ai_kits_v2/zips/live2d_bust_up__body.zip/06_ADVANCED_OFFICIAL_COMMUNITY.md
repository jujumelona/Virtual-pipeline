# Live2D 바스트업 body 공식·제작자 팁

공식 Live2D 일러스트 가공 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 눈·입·얼굴·목 원화 분리와 underpaint. 공식 눈 깜빡임 https://docs.live2d.com/en/cubism-editor-tutorials/eye-blink/ — 최종 키폼은 Cubism Editor 사용자 작업. 비공식 Live2dTree https://live2dtree.com/tutorial — 방송용 얼굴 중심 작화·표정 파츠 설계 참고.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.
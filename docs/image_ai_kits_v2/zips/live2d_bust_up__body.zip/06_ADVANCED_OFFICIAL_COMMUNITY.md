# Live2D 바스트업 body 공식·제작자 팁

공식 Live2D 일러스트 가공 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 눈·입·얼굴·목 원화 분리와 underpaint. 공식 눈 깜빡임 https://docs.live2d.com/en/cubism-editor-tutorials/eye-blink/ — 최종 키폼은 Cubism Editor 사용자 작업. 비공식 Live2dTree https://live2dtree.com/tutorial — 방송용 얼굴 중심 작화·표정 파츠 설계 참고.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / body]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 눈·입·목 레이어 분리, 흰자/입안/턱 뒤 숨은 영역 작화. **CLIP STUDIO TIPS 개인 작가:** https://tips.clip-studio.com/en-us/articles/6615 — 정면·3/4·옆얼굴의 눈 원근과 스타일 변화. 단, 이 작가의 수치는 Cubism 필수 규격이 아니다.
**공통 주의:** Live2D/Cubism 공식은 원화 분리·편집기 구현을 설명하지만, '정확한 6등신', '홍채 가로폭 몇 %', '2~3톤만 허용'을 기술 규격으로 요구하지 않는다. Cubism Editor의 키폼·클리핑·Skinning은 이미지 AI의 자동 납품 대상이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/body]


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/body]
**[공식 vs 작업 경험]** Live2D 공식은 눈꼬리 속눈썹의 분리 편의와 숨은 흰자·입안 보완을 설명한다: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . Live2D 공식 가져오기 PSD 자료는 파츠당 선화/칠을 합치는 제작 단계를 설명한다: https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ . **피부 고정 그림자와 움직이는 앞머리 그림자의 소유권 분리**는 원화 품질을 위한 선택적 제작자 운영 원칙이며 Cubism에서 의무적으로 생성할 별도 그림자 수가 아니다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
방송용 바스트업: 머리부터 배 위~허리 위까지 완성된 캐릭터 신체 원화. 양쪽 어깨·상완·전완·손과 자연스러운 목 연결을 포함하며 손을 가린 포즈도 숨은 파츠를 준비한다. 얼굴만 잘린 과도한 크롭과 단색 몸통 프록시를 금지하며 큰 얼굴·눈 중심으로 어깨·양팔·손까지 자연스럽게 그린다. 사용자가 요구한 큰 눈·좌우 홍채와 짧고 넓은 부드러운 U형 턱의 귀여운 얼굴 인상을 유지한다. 각도별로 턱의 투영 실루엣은 자연스럽게 변화시킨다. 턱 뒤 목 언더페인트, 양어깨·상완·전완·양손·복부를 실제 애니 일러스트로 그린다. 교체 헤어·의상·액세서리는 독립 자산으로 남긴다.
실제 다층 PSD, 같은 캔버스 투명 RGBA PNG와 파츠별 알파 마스크, 원본 입력과 원본 PSD(있다면), 원본-결과 및 PRO BODY 정합 미리보기, 레이어 좌표/순서·검증·분할 JSON, 사용자 제작·시각검수·Cubism 안내 MD는 최종 필수. PSD와 마스크가 없으면 중간 PNG 검사 PASS여도 최종 납품 불가. BODY 최종 납품에 --final-live2d-body를 사용한다. HAIR/OUTFIT/ACCESSORY도 PSD·마스크 필수. 실제 이미지/Editor 확인 없이 미술·리깅 품질 PASS 금지.
회색 단색 몸통, 프록시 도형, 끊긴 목, 누락된 팔/손, 짧은 상체는 최종 FAIL. 완성 원화→파츠 분리 순서. 최종 ZIP은 실제 다층 PSD·투명 파츠 PNG·알파 마스크·원본 입력·미리보기·레이어 좌표·분리/검증 JSON·Cubism 안내 필수. 중간 PNG 검사 통과만으로 납품 성공 주장 금지.

# Live2D 방송용 바스트업 신체 애니풍 기준

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / body
**실제 제작:** 머리·얼굴·눈·입·귀·목·어깨와 가슴 위쪽의 안전하게 가려진 애니풍 신체 원화만.
**금지:** 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
**구도:** 방송용 바스트업은 머리 높이 1 : 보이는 목·어깨·상체 약 1~2의 레이아웃 기준이며, 신체 ZIP에서는 머리·얼굴·목·어깨의 완성 신체 원화를 직접 새로 그린다.


- 대상: 머리·얼굴·눈·입·귀·목·어깨와 가슴 위쪽의 안전하게 가려진 애니풍 신체 원화만. 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
- 애니풍: 검정에 가까운 짙은 가변 굵기 선화와 가늘어지는 테이퍼, 깔끔한 소재별 내부선, 2~3톤 셀 명암·높은 디자인 일관성.
- 이 자산의 미술적 특징: 얼굴 표정, 좌우 눈/입안 독립성, 목 언더페인트, 어깨·쇄골의 과장 없는 연결, 불투명 기본 상의·속옷 또는 불투명 마스킹 유지.
- 기준 캐릭터의 눈매·머리/얼굴 비율은 **참조를 통한 크기·정체성 맞춤**이며 신체 얼굴 자체 이외 자산을 새로 생성하는 요구가 아니다.
- 머리 1높이에 화면에 보이는 상체 1~2높이라는 구도 기준만 적용한다. 전신의 하체/다리/발을 강제하지 않는다.

영어 이미지 프롬프트: “Professional premium anime VTuber bust-up body-only artwork, variable-weight tapered dark linework, detailed consistent 2-3 tone cel shading, faithful original character aesthetics, isolated requested body art on matching full canvas, no extra character parts or props.”


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / body]
### 이 ZIP에만 적용할 애니풍 프롬프트
High-quality Japanese anime VTuber BUST-UP BODY BASE ONLY, expressive large layered irises, delicate tapering upper lashes, compact stylized nose and mouth, polished face and ear contours, continuous neck under the chin and elegant shoulders, consistent cel shading, opaque modest base top, no hair / detachable outfit / jewelry / pelvis / legs; original art, not photorealistic anatomy.
**소유 픽셀:** 캐릭터 기준 이미지의 다른 범주는 좌표/컬러 참조일 뿐 새 그림 산출 대상이 아니다.

# Live2D 방송용 바스트업 신체 애니풍 기준

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / body
**실제 제작:** 머리·얼굴·눈·입·귀·목·어깨와 가슴 위쪽의 안전하게 가려진 애니풍 신체 원화만.
**금지:** 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
**구도:** 얼굴 중심의 고급 2D 애니 VTuber 근접 바스트업. 두피 정수리~턱 H가 전체 화면 세로의 52~61%를 차지하는 비율을 우선 시작값으로 삼고, 길게 펼쳐진 몸통 없이 짧은 목·어깨·쇄골·가린 윗가슴까지만 실제 신체 원화로 그린다.


- 대상: 머리·얼굴·눈·입·귀·목·어깨와 가슴 위쪽의 안전하게 가려진 애니풍 신체 원화만. 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
- 애니풍: 검정에 가까운 짙은 가변 굵기 선화와 가늘어지는 테이퍼, 깔끔한 소재별 내부선, 2~3톤 셀 명암·높은 디자인 일관성.
- 이 자산의 미술적 특징: 얼굴 표정, 좌우 눈/입안 독립성, 목 언더페인트, 어깨·쇄골의 과장 없는 연결, 불투명 기본 상의·속옷 또는 불투명 마스킹 유지.
- 기준 캐릭터의 눈매·머리/얼굴 비율은 **참조를 통한 크기·정체성 맞춤**이며 신체 얼굴 자체 이외 자산을 새로 생성하는 요구가 아니다.
- 바스트업은 얼굴과 눈·입이 화면의 중심인 근접 컷이며 목·어깨 아래 몸통은 짧게 잘린다.

영어 이미지 프롬프트: “Professional premium anime VTuber bust-up body-only artwork, variable-weight tapered dark linework, detailed consistent 2-3 tone cel shading, faithful original character aesthetics, isolated requested body art on matching full canvas, no extra character parts or props.”


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / body]
### 이 ZIP에만 적용할 애니풍 프롬프트
High-quality Japanese anime VTuber BUST-UP BODY BASE ONLY, expressive large layered irises, delicate tapering upper lashes, compact stylized nose and mouth, polished face and ear contours, continuous neck under the chin and elegant shoulders, consistent cel shading, opaque modest base top, no hair / detachable outfit / jewelry / pelvis / legs; original art, not photorealistic anatomy.
**소유 픽셀:** 캐릭터 기준 이미지의 다른 범주는 좌표/컬러 참조일 뿐 새 그림 산출 대상이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/body]
Anime VTuber BODY ONLY: preserve the existing eye shape and facial identity, tapered eyelash and mouth linework, delicate colored interior contours and clean skin cel-shadows, no baked-in moving hair-cast shadow on the permanent face skin, no duplicated facial linework, no hairstyle/clothing/accessory generation.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | body]
Masterpiece 2D hand-drawn Japanese anime VTuber FACE-DOMINANT CLOSE BUST-UP BODY BASE artwork, FRONT VIEW; composition centered on an oversized expressive anime head and face, scalp-to-chin taking approximately 52-61 percent of canvas height, only a short neck, shoulders, collarbone and the very top of safely opaque covered chest visible at the lower edge, absolutely no long torso, no waist and no elbows or hands. Beautiful distinctly ANIME eyes large relative to face width, large multilayer irises and bold tapering upper eyelashes, luminous eye highlights and clean whites; soft anime cheek silhouette tapering toward a smaller chin; tiny stylized nose, small clean mouth, reduced realistic anatomy, smooth controlled cel shading with refined colored inner lineart. Bald/without detachable hair because BODY asset only; no wigs, fashion outfit, jewelry or photo-like texture. Not photorealism, not 3D render, not realistic person, not fashion photography, not realistic small eyes/irises, not human anatomy study, not large torso/shoulder portrait, not a crude mannequin; draw an actual high-end anime VTuber bust-up illustration.

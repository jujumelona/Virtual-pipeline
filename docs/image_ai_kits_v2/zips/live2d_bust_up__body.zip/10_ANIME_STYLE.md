## [BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

### BODY 전용 기본 복장 — 모든 결과 이미지에 적용 (우선 규칙)
- **성인(20세 이상)**의 귀여운 애니풍 VTuber 캐릭터를 작업한다. 짧고 둥근 얼굴, 큰 눈, 6등신 디자인은 유지하되 미성년으로 묘사하지 않는다.
- **정면·3/4·측면·후면·상하 시점, 표정 시트, 최종 마스터, 합성 미리보기 전체에** 불투명한 **비키니형 스포츠 수영복**을 입힌다. 기본 디자인은 **노출을 줄인 운동용 상의 + 하이웨이스트 쇼츠형 하의**이며, 단색 무지 원단에 비침·절개·노출 강조가 없다.
- **단독 신체 원화, 투명 원화 파츠, PSD, 최종 결과 어디에도 복장 없는 신체 이미지를 만들거나 제공하지 않는다.** 수영복 안쪽은 사실적인 피부나 신체 세부가 아닌 단색 비표현적 밑색으로 처리한다. 복장 없이 보이는 숨은 시점·보조 이미지도 제작하지 않는다.
- 2D에서 수영복 상·하의는 BODY 납품의 **기본 안전 가림 파츠**이다. fashion OUTFIT이 아니다. 안전 복장 파츠는 `removable_neutral_modesty_band_upper`, `removable_neutral_modesty_band_lower`처럼 각각 독립 RGBA를 만들되 **완성본에서는 두 파츠가 항상 켜져 있어야 한다**. 상·하의 없이 기본 마스터/미리보기를 만들지 않는다. 기존 단일 `removable_neutral_modesty_band` 이름도 하위 호환으로만 허용한다.
- 3D에서는 동일한 수영복을 **모든 필수 9방향 턴어라운드에** 동일하게 착용시킨다. 3D ZIP은 PSD 분리나 스킨·리깅 실행을 요구하지 않는다.
- 수영복은 눈·얼굴·목·어깨·양팔·양손·관절·발의 위치를 가리지 않는다. 턱 뒤 목, 어깨/팔꿈치/손목 등 회전용 숨은 면과 눈/입 레이어는 충분히 그리되, 수영복 아래의 자세한 신체를 만들 필요는 없다.
- **충돌 해결:** 옛 지침의 '의상 금지', '상의를 그리지 않기', '최소 면적의 밴드만', '맨몸처럼 보이는 베이스'보다 이 기본 수영복 규칙이 우선한다. 헤어·디자인 의상·액세서리는 여전히 다른 ZIP의 소유이고 기본 안전 수영복만 BODY가 소유한다.

## [/BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**live2d_bust_up/body 전용 생성 최우선 규칙.** 이 조항보다 아래의 구형 구도·얼굴형 설명이 충돌하면 이 조항을 우선한다.
- BODY는 얼굴과 두상 비율의 유일한 원본. 큰 두상, 넓고 짧은 얼굴, 짧은 둥근 U형 턱, 부드러운 볼, 크고 세로 높이도 충분한 눈과 홍채. 좁고 길쭉한 타원형 얼굴·말상·뾰족한 V턱·성숙한 역삼각형·긴 중안부/인중/하관·작은 눈·과도하게 긴 목 금지. 민머리의 윗두피만 지나치게 높고 눈이 작아 보이는 불균형도 금지. 어깨 대비 작은 머리·실사 패션 비례 금지. 전신 6등신 유지. 갈비뼈/배꼽/쇄골/복근 세밀 묘사 억제. BODY의 터틀넥·상의·보디슈트 금지, 불투명 스포츠 수영복만 분리 레이어.
- 공통 스타일: 귀여운 애니/VTuber, 머리가 상대적으로 크게 보이고, **짧고 폭이 있는 얼굴·부드럽고 짧은 U형 턱·큰 눈과 홍채·작은 코와 입**. 긴/좁은 얼굴, 말상, 길게 내려온 뾰족한 턱, 현실/성숙 모델 인상은 절대 불합격.
- 정면 얼굴 높이/폭(귀 제외) 약 1.10~1.30은 스타일 **출발 참고값**이며 신체/프레임 전체 비율은 강제하지 않는다. 전신은 프로젝트의 6등신 유지, 바스트업·상반신은 실사형으로 머리를 축소하지 않는다.
- 실물 기준 BODY가 제공되면 원본 두상/얼굴을 바꾸지 않는다. 2D는 완성 원화·파트 재합성에서 기준 얼굴과 실제 시각 비교한다.
- **검수 필수:** 머리 크기, 얼굴의 넓고 짧은 윤곽, 둥근 턱끝, 눈/홍채 크기, 자연스러운 목·어깨 비율, 기준 캐릭터 동일성, 다른 자산 혼입 여부. 상의 혼입·해부학적 내부선 과잉·손 누락 발견 시 불합격.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_bust_up/body]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **BODY만 생성:** 귀여운 애니풍 두상·큰 눈/홍채·짧고 둥근 하관, 단순한 피부와 목·어깨·필요한 신체·손. 피부에 갈비뼈/복근/배꼽/쇄골·힘줄을 선으로 과잉 묘사하지 않는다. 디자인 의상은 OUTFIT 전용이며 BODY에는 위 기본 불투명 스포츠 수영복을 착용한다. 체형은 회색 찰흙/기하 프록시가 아닌 실제 애니풍 채색 원화로 만든다. 헤어·탈착 의상·액세서리를 BODY에 붙이지 않는다.
- 프레임: 정수리부터 상복부/허리 위 및 양손까지 방송용 바스트업. 자산 소유 범위에만 적용. 전신 캐릭터의 기본 디자인은 6등신을 지향하나 크롭 프레임에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 극단적 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY가 제공되면 얼굴 비율을 변경하지 않는다.
- 작업절차: 2D는 해당 자산의 완성 원화를 먼저 만들고 필요 파츠/숨은 면을 분리·보완한다. 실제 다층 PSD·PNG·마스크는 만들고 검증했을 때만 납품 완료로 기록한다.
- 실물 템플릿 계약: 외부 URL이나 비율 도식은 원본 PSD/PNG/3D 템플릿이 아니다. 실제 템플릿 파일이 ZIP에 없으면 없다고 명시한다. 사용자 기준 원화가 있으면 해당 이미지를 참조한다. 비BODY 자산에 BODY 원본이 없으면 정합 검증을 완료했다고 주장하지 않는다.
- 검증: 원화·그림 품질과 파일 구조를 따로 판정. 비어 있는 파츠나 가려진 영역 미보완, 다른 자산 혼입, 구도 절단은 불합격. 구형 문구로 상반된 지시를 부활시키지 않는다.


## [2026-10-13 v5 live2d_bust_up/body 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.

## 2026-10-13 사용자 지정 BODY 최상위 제작 규칙 — 기존 묘사 지시보다 우선
이 ZIP은 머리·얼굴 및 재사용용 몸체 실루엣을 위한 신체 전용 지시서다. 외부 생성 AI에게 얼굴부터 몸까지 완성한 인체 일러스트를 한 장으로 요구하지 않는다.
정면 얼굴은 짧고 부드러운 U형 하관과 둥근 볼, 작은 애니 귀(내부 선 1~2개), 균형 잡힌 두상과 단순한 목을 사용한다. 기존의 긴 V자 턱과 실사형 큰 귀, 과도한 정수리와 긴 목을 다시 생성하면 FAIL이다. 눈 크기만으로 애니형 판정하지 않는다.
홍채 색은 사용자가 지정하거나 캐릭터별 팔레트에서 선정한다. 특정 분홍/노랑 눈색 고정 금지. 헤어와 의상, 액세서리는 BODY에 병합하지 않는다.
BODY는 의상 교체용 공통 신체이지만 실제로 완성된 애니풍 피부 원화여야 한다. 해부학적 내부선은 생략하고 큰 머리·짧고 둥근 얼굴·부드러운 턱·큰 눈을 유지한다.

# Live2D 방송용 바스트업 신체 애니풍 기준

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / body
**금지:** 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.


- 대상: 머리·얼굴·눈·입·귀·목·어깨·팔·손 및 해당 모드의 상복부/전신 범위를 포함한 단순 애니풍 신체 원화. 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
- 애니풍: 검정에 가까운 짙은 가변 굵기 선화와 가늘어지는 테이퍼, 깔끔한 소재별 내부선, 2~3톤 셀 명암·높은 디자인 일관성.
- 기준 캐릭터의 눈매·머리/얼굴 비율은 **참조를 통한 크기·정체성 맞춤**이며 신체 얼굴 자체 이외 자산을 새로 생성하는 요구가 아니다.
- 바스트업은 얼굴과 눈·입이 화면의 중심인 근접 컷이며 목·어깨 아래 몸통은 짧게 잘린다.

영어 이미지 프롬프트: “Professional premium anime VTuber bust-up body-only artwork, variable-weight tapered dark linework, detailed consistent 2-3 tone cel shading, faithful original character aesthetics, isolated requested body art on matching full canvas, no extra character parts or props.”


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / body]
### 이 ZIP에만 적용할 애니풍 프롬프트
High-quality Japanese anime VTuber BUST-UP BODY BASE ONLY, expressive large layered irises, delicate tapering upper lashes, compact stylized nose and mouth, polished face and ear contours, continuous neck under the chin and elegant shoulders, consistent cel shading, opaque modest base top, no hair / detachable outfit / jewelry / pelvis / legs; original art, not photorealistic anatomy.
**소유 픽셀:** 캐릭터 기준 이미지의 다른 범주는 좌표/컬러 참조일 뿐 새 그림 산출 대상이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/body]
Anime VTuber BODY ONLY: preserve the existing eye shape and facial identity, tapered eyelash and mouth linework, delicate colored interior contours and clean skin cel-shadows, no baked-in moving hair-cast shadow on the permanent face skin, no duplicated facial linework, no hairstyle/clothing/accessory generation.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | body]

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
방송용 바스트업: 머리부터 배 위~허리 위까지 완성된 캐릭터 신체 원화. 양쪽 어깨·상완·전완·손과 자연스러운 목 연결을 포함하며 손을 가린 포즈도 숨은 파츠를 준비한다. 고정된 얼굴 초근접 구도와 단색 몸통 프록시를 금지한다. 사용자가 요구한 고유 애니풍 얼굴형과 큰 눈·좌우 홍채 정합을 유지한다. 턱 뒤 목 언더페인트, 양어깨·상완·전완·양손·복부를 실제 일러스트로 그린다. 귀·입·코는 간결한 애니풍으로 유지하고 하나의 U형 턱으로 고정하지 않는다. 교체 헤어·의상·액세서리는 독립 자산으로 남긴다.
실제 다층 PSD, 같은 캔버스 투명 RGBA PNG와 파츠별 알파 마스크, 원본 입력과 원본 PSD(있다면), 원본-결과 및 PRO BODY 정합 미리보기, 레이어 좌표/순서·검증·분할 JSON, 사용자 제작·시각검수·Cubism 안내 MD는 최종 필수. PSD와 마스크가 없으면 중간 PNG 검사 PASS여도 최종 납품 불가. BODY 최종 납품에 --final-live2d-body를 사용한다. HAIR/OUTFIT/ACCESSORY도 PSD·마스크 필수. 실제 이미지/Editor 확인 없이 미술·리깅 품질 PASS 금지.
회색 단색 몸통, 프록시 도형, 끊긴 목, 누락된 팔/손, 짧은 상체는 최종 FAIL. 완성 원화→파츠 분리 순서. 최종 ZIP은 실제 다층 PSD·투명 파츠 PNG·알파 마스크·원본 입력·미리보기·레이어 좌표·분리/검증 JSON·Cubism 안내 필수. 중간 PNG 검사 통과만으로 납품 성공 주장 금지.
High quality finished anime VTuber upper-body BODY illustration down to the abdomen with natural neck, both shoulders, upper arms, forearms and hands, individual face and aligned irises, separate minimal neutral modesty-cover overlay, NO attached clothing. No gray polygon torso, no missing hands, no head-only crop, no fake PSD.

# 공식 문서 참고

00_MASTER_FIRST.md 적용.

- Live2D PSD용 파츠 분리: https://docs.live2d.com/en/cubism-editor-tutorials/psd/
- 공식 샘플: https://www.live2d.com/en/learn/sample/
- 공식 클리핑: https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/

링크를 열 수 없으면 읽었다고 주장하지 않는다. 실제 리깅은 Cubism Editor 사용자 작업이다.
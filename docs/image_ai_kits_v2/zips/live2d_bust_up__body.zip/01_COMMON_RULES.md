## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **live2d_bust_up / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
- 3. **Live2D Mark-kun original example with sample PSD (FREE learning)** — https://www.live2d.com/en/learn/sample/mark/
   - 실제 활용: Small/simple FREE scene topology and rig structure study, not a target face style; preserve its character-specific license.
   - 권리 확인: Official sample terms; structural learning only. Do not transform Mark-kun into user's anime character.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`

- **구도:** head to upper abdomen/waist with complete shoulders arms and hands
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 원화가 우선이다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.


## [2026-10-13 v5 live2d_bust_up/body 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.

## 2026-10-13 사용자 지정 BODY 최상위 제작 규칙 — 기존 묘사 지시보다 우선
이 ZIP은 머리·얼굴 및 재사용용 몸체 실루엣을 위한 신체 전용 지시서다. 외부 생성 AI에게 얼굴부터 몸까지 완성한 인체 일러스트를 한 장으로 요구하지 않는다.
정면 얼굴은 짧고 부드러운 U형 하관과 둥근 볼, 작은 애니 귀(내부 선 1~2개), 균형 잡힌 두상과 단순한 목을 사용한다. 기존의 긴 V자 턱과 실사형 큰 귀, 과도한 정수리와 긴 목을 다시 생성하면 FAIL이다. 눈 크기만으로 애니형 판정하지 않는다.
홍채 색은 사용자가 지정하거나 캐릭터별 팔레트에서 선정한다. 특정 분홍/노랑 눈색 고정 금지. 헤어와 의상, 액세서리는 BODY에 병합하지 않는다.
BODY는 의상 교체용 공통 베이스로서 몸통은 불투명한 비해부학적 무광 단색 찰흙 외피로 제작한다. 해부학적 내부선은 생략하고 큰 머리·짧고 둥근 얼굴·부드러운 턱·큰 눈을 유지한다.

# Live2D 바스트업 신체 독립 원화 공통 원칙

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / body
**금지:** 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.


1. 기준 몸체는 **좌표·캐릭터 정체성·선화와 색감의 참조**이며, 실제 제작은 신체 하나만이다. 얼굴/눈·입과 목/어깨를 예술적 품질 기준으로 그리되 별도 패션 의상과 헤어는 만들지 않는다.




## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 회색/살구색/중립 파스텔색 등의 균일한 불투명 색 면을 허용한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.live2d.com/en/cubism-editor-tutorials/template/
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** 해당 플랫폼의 실제 템플릿 PSD 레이어 구조와 앞뒤 가림, 눈-흰자/홍채/윗속눈썹, 입-닫힌선/입안/윗니/혀, 얼굴/귀/목, 좌우 상완/전완/손. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: live2d_bust_up/body; 얼굴 크게, 목·양어깨·양팔·양손·상복부까지. 다른 자산을 새로 제작하지 않는다.
- 1) 해당 자산의 디자인 마스터를 확정하고 정면 실루엣과 얼굴·눈·입·목·팔다리와 마스터 색상을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: face, ear.left, ear.right, eye.left.white, eye.left.iris, eye.left.upper.lash, eye.right.white, eye.right.iris, eye.right.upper.lash, eyebrow.left, eyebrow.right, nose, mouth.close, mouth.open, mouth.tooth.t, mouth.tongue, neck, torso, arm.left.upper, arm.left.forearm, hand.left, arm.right.upper, arm.right.forearm, hand.right. 양쪽 눈은 흰자·홍채·윗속눈썹을 각각 그린다. 입은 닫힌 선·열린 입안·윗니·혀로 나누고 팔은 상완·전완·손으로 독립 작화한다. 실제로 없는 다른 자산 파츠를 납품하지 않는다.
- 5) `part_art/_order.txt`에는 앞에 보이는 파츠부터 뒤에 보이는 순서로 파일 경로를 하나씩 쓴다. 각 PNG는 한 파츠만 담는다. PSD·마스크·리깅 산출물은 이미지 AI가 만들지 않는다. 열린 입·치아·혀 대체 파츠는 각각 그리되 중립 합성에서는 숨긴다.
- 6) 양쪽 눈·턱·목·팔·손목과 가림·관절을 실제 정면·좌우 3/4·측면 참고 그림과 대조한다. 중립 파츠 합성은 `outputs/master.png`와 같은 원화여야 하며 중복·부유 파츠·가림 구멍은 불합격이다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png. BODY는 `expression_refs/mouth_closed.png` 및 `expression_refs/mouth_open.png`도 실제로 다른 표정의 완성 참고 원화로 제출한다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 목·턱·좌우 어깨·상완·전완·손의 실루엣을 시점마다 정합되게 그린다. 단색 무광 찰흙형 비해부학 BODY를 유지한다. neck_underpaint와 body_joint_overlaps는 **부품이 아니라 목·턱·몸통·어깨의 가림·연결을 설명하는 완성 참고 그림**이다. 정면·좌우 3/4·측면에서 턱 아래 목과 귀 뒤, 목-어깨 접점을 보여준다. 정면 그림을 늘이거나 머리만 좌우 이동해 옆모습으로 속이지 않는다.
- **제작 단계 확정:** 이미지 AI는 위에 명시한 독립 파츠의 실제 그림과 다각도 참조를 하나씩 제작한다. PSD 인코딩·메시·키폼·리깅은 별도 단계다. 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] part_art/neck.png는 턱 아래 잘린 얇은 조각이 아니어야 한다. 정면에서 턱 뒤 피부를 입 높이 가까이까지 위쪽으로 실제 그려 두고, 아래는 part_art/torso.png의 상부와 실질적인 알파 교집합을 만들어 놓는다. 얼굴 아래·목·몸통이 알파로 단순히 접하는 선은 실패다. head_three_quarter_L/R는 약 45°, head_profile_L/R는 실제 90° 형태 참고다. 각각 코·입·턱·귀·목뿌리·양어깨가 한 그림 안에서 연결되고 좌우 반전 복제로 대체하지 않는다. head_pitch_up/down에서 턱 아래 목의 드러남/가림을 실제로 바꾼다. neck_underpaint와 body_joint_overlaps 참고 그림을 따로 그리는 것만으로는 실제 part_art/neck.png의 가려진 픽셀이 생기지 않는다.
- [좌표/참조] 정면·좌우 3/4·양측면 및 상하 자세 비교 원화는 outputs/master.png와 동일한 전체 캔버스 치수·기준 크기로 그린다. 확대 클로즈업은 별도 보조 그림으로만 남긴다. 이미지 AI의 다각도 그림은 PSD2Live/Inochi 실제 키폼에 자동 등록되지 않는다.
- [엔진 확인] PSD2Live 기본 머리 ParamAngleX 범위는 -45..+45°, ParamAngleY는 -30..+30°다. 실제 -90/+90° 옆모습 PNG는 자동으로 키폼이 되지 않는다. 실제 MOC3 극한 각도 렌더링과 턱·목·귀·헤어 가림을 확인할 때까지 90° 가능이라고 보고하지 않는다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

# 04 — 이미지 생성 AI 원화 납품만

## [MATTE_CLAY_BODY_V1]
불투명 단색 무광 찰흙형 BODY
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 2D 후속 Colab에서 See-through가 파츠를 분리하고 PSD2Live가 리깅을 수행한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다. - BODY의 입은 닫힘/벌림을 각각 실제로 그린 expression_refs/mouth_closed.png 및 expression_refs/mouth_open.png도 생성한다. 열린 입에는 입안의 어두운 공간·윗니·혀가 실제로 구별되게 보이고, 다른 얼굴과 위치·선화·색조가 일치해야 한다. 이 둘은 상태별 완성 참고 원화이며 PSD 레이어/마스크가 아니다.
- 목·턱·좌우 어깨·상완·전완·손의 실루엣을 시점마다 정합되게 그린다. 단색 무광 찰흙형 비해부학 BODY를 유지한다. neck_underpaint와 body_joint_overlaps는 **부품이 아니라 목·턱·몸통·어깨의 가림·연결을 설명하는 완성 참고 그림**이다. 정면·좌우 3/4·측면에서 턱 아래 목과 귀 뒤, 목-어깨 접점을 보여준다. 정면 그림을 늘이거나 머리만 좌우 이동해 옆모습으로 속이지 않는다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## 납품 검사

완성 PNG를 실제 열어서 동일 캐릭터·색·실루엣·시점별 목·어깨 연결을 확인한다. 파일명과 PNG 바이트를 확인한다. PSD·개별 파츠·마스크는 이 ZIP에서 만들지 않는다.

# 신체만 납품 파일 구조

00_MASTER_FIRST.md에 따라 실제 그림 제작. live2d_bust_up__body__ARTWORK.zip
outputs/master.png — 최종 바스트업 기준 원화
outputs/master_original.png — 원본 저장
isolated_parts/ — 실제 RGBA PNG 파츠
layer_order.txt — 레이어 순서와 L/R
previews/composite_preview.png — 재합성 원화 비교
previews/reference_bust_up.png — 머리~가슴 윗부분 구도 비교
reference_views/ — 회전 보조(필요한 경우만)
README.md — 수작업 보완 및 실제 납품 범위

원화가 없는 그림·가짜 PSD·moc3·cmo3는 제출하지 않는다. 신체만이라는 이유로 PRO를 강제하지 않는다.

## ZIP 고유 작업 범위 잠금: live2d_bust_up / body
**실제 제작:** 머리·얼굴·눈·입·귀·목·어깨와 가슴 위쪽의 안전하게 가려진 애니풍 신체 원화만.
**금지:** 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
**구도:** 얼굴 중심의 고급 2D 애니 VTuber 근접 바스트업. 두피 정수리~턱 H가 전체 화면 세로의 52~61%를 차지하는 비율을 우선 시작값으로 삼고, 길게 펼쳐진 몸통 없이 짧은 목·어깨·쇄골·가린 윗가슴까지만 실제 신체 원화로 그린다.

`outputs/master.png`는 이 ZIP의 신체 원화만, `isolated_parts/`는 신체의 RGBA PNG만 의미한다. 기준 몸체가 들어간 화면은 위치 확인용 preview로 구분한다. 다른 카테고리 픽셀을 파츠로 납품하지 않는다.

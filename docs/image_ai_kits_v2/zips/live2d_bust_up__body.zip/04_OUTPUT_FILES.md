# 신체만 납품 파일 구조

00_MASTER_FIRST.md에 따라 실제 그림 제작. live2d_bust_up__body__ARTWORK.zip
outputs/master.png — 최종 바스트업 기준 원화
outputs/master_original.png — 원본 저장
isolated_parts/ — 실제 RGBA PNG 파츠
layer_order.txt — 레이어 순서와 L/R
previews/composite_preview.png — 재합성 원화 비교
previews/reference_bust_up.png — 머리~가슴 윗부분 구도 비교
reference_views/ — 회전 보조(필요한 경우만)
README.md — 수작업 보완 및 실제 납품 범위

원화가 없는 그림·가짜 PSD·moc3·cmo3는 제출하지 않는다. 신체만이라는 이유로 PRO를 강제하지 않는다.

## ZIP 고유 작업 범위 잠금: live2d_bust_up / body
**실제 제작:** 고품질 애니 얼굴·눈·입·귀 원화와 별도 코드로 만든 목·어깨·상체의 단색 중립 BODY 실루엣만.
**금지:** 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
**구도:** 얼굴 중심의 고급 2D 애니 VTuber 근접 바스트업. 두피 정수리~턱 H가 전체 화면 세로의 52~61%를 차지하는 비율을 우선 시작값으로 삼고, 길게 펼쳐진 몸통 없이 짧은 목까지 얼굴 원화로 제작하고 어깨·몸통은 별도 단색 BODY 도형으로 합성한다.

`outputs/master.png`는 이 ZIP의 신체 원화만, `isolated_parts/`는 신체의 RGBA PNG만 의미한다. 기준 몸체가 들어간 화면은 위치 확인용 preview로 구분한다. 다른 카테고리 픽셀을 파츠로 납품하지 않는다.


## [필수: 2D 결과 ZIP 레이어 정확성 사전 차단]
# 2D 제작 AI 최종 ZIP: 레이어 순서·실제 PNG 일치 필수 계약

이 규칙은 Live2D/Inochi2D 2D 지시 ZIP에만 적용한다. 3D에는 적용하지 않는다.
외부 AI가 작성하는 결과 원화 ZIP을 검사하는 규칙이지 지시서 ZIP 자체의 레이어 목록은 아니다.

1. 고품질 기준 원화 `outputs/master.png`를 먼저 만든 다음, 해당 자산의 실제 움직이는 파츠만 분리·숨은 면을 보완한다. 파일명은 각 파츠 원화를 내보낼 때 확정한다. 27개 등 정해진 숫자를 맞추지 않는다.
2. 실제 PNG를 만들 때 작성한 **파츠 계획표**에 `part_id / 정확한 상대 경로 / 화면 뒤→앞 순서`를 기록한다. 파츠를 삭제·추가·이름 변경하면 계획표와 실파일을 함께 갱신하고 순서를 다시 사람이 판단한다.
3. 최종 결과 ZIP의 경로는 `outputs/master.png`, `isolated_parts/<part_id>.png`, `layer_order.txt`를 같은 루트에 놓는다. ZIP 내 한 개 최상위 폴더 안에 모두 넣는 방식도 가능하지만 두 구조를 섞지 않는다.
4. `layer_order.txt`는 **실제 존재하는 독립 PNG 각각을 정확히 한 번**, `isolated_parts/eye_L_iris.png` 같은 **루트 기준 상대 경로**로 한 줄씩 기록한다. ZIP 파일 전체 경로, `./` 접두, 대소문자 다른 이름, 디렉터리 접두를 쓰지 않는다. 순서는 ZIP 내부 저장 순서/알파벳순이 아니라 시각적으로 결정한 **뒤→앞 순서**다.
5. `previews/`, `reference_views/`, `outputs/` 내 PNG는 `layer_order.txt`에 포함하지 않는다. `isolated_parts/` 안의 실제 PNG는 누락·중복·미등록이 하나도 없어야 한다. 결과 ZIP에 `manifest.json`을 별도 생성하지 않는다 (단순 2D 형식).
6. 모든 파츠 PNG는 기준 원화와 동일한 **픽셀 크기·원점**, 실제 RGBA 알파, 의미 있는 불투명 픽셀과 일부 투명 픽셀을 갖는다. 부위가 삭제됐는데도 미리보기만 남거나, 시트 PNG만 남기는 납품은 금지한다.
7. **최종 ZIP을 완성한 뒤** 이 ZIP의 `04_OUTPUT_FILES.md`에 포함된 Python 검증 코드를 별도 검사 파일에 복사하여 **실제 결과 ZIP**을 대상으로 실행한다. 파일을 고친 경우 압축·검사를 다시 수행한다. 오류 하나라도 있으면 납품하지 말고 문제가 된 PNG/순서를 수정한다.
8. 코드 검증은 경로·개수·형식만 검증한다. 고급 원화 품질·목 회전용 언더페인트·전후 가림·알파 테두리·합성 비교는 별도로 시각 검수한다. 실제 실행하지 않았는데 PASS라고 쓰지 않는다.

**우회 금지:** 검사 통과를 위해 존재하는 PNG를 몰래 버리거나 임의로 `layer_order.txt`를 알파벳 정렬하거나, 비어 있는 가짜 PNG를 생성하거나, 이미지 AI 대신 PSD/리깅을 요구하지 않는다.

### 반드시 실행하는 결과 ZIP 검증
아래 코드를 작업 임시 폴더의 `validate_artwork_zip.py`로 저장해 **최종 압축 이후** `python validate_artwork_zip.py live2d_bust_up__body__ARTWORK.zip free`를 실행한다. PRO일 경우 마지막 인자를 `pro`로 설정한다. `PASS`가 안 나오면 수정·재압축하며, 실제 실행할 수 없으면 완료라고 하지 않는다. 이 검사 코드는 납품 그림 ZIP에 포함하지 않는다.

```python
"""Fail-closed structural validator for externally generated 2D artwork ZIPs.

Run: python validate_artwork_zip.py artwork.zip [free|pro]
This checks files and pixels, not whether the artwork is aesthetically correct.
"""
from collections import Counter
from io import BytesIO
from pathlib import Path
import re
import sys
from zipfile import ZipFile

from PIL import Image

_PART_ID = re.compile(r"[A-Za-z][A-Za-z0-9_-]*(?:\.[A-Za-z][A-Za-z0-9_-]*)*\Z")


def validate(path: str | Path, edition: str = "pro", *, final_live2d_body: bool = False) -> None:
    if edition not in ("free", "pro"):
        raise ValueError("edition must be free or pro")
    with ZipFile(path) as archive:
        members = [m for m in archive.infolist() if not m.is_dir()]
        filenames = [m.filename for m in members]
        if len(filenames) != len(set(filenames)):
            raise ValueError("ZIP contains duplicate member paths")
        if not members or len(members) > 500:
            raise ValueError("ZIP empty or too many files")
        if sum(m.file_size for m in members) > 650 * 1024 * 1024:
            raise ValueError("ZIP uncompressed size limit exceeded")
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC verification failed")
        order_paths = [n for n in filenames
                       if n == "layer_order.txt"
                       or (n.endswith("/layer_order.txt") and n.count("/") == 1)]
        if len(order_paths) != 1:
            raise ValueError("One root or single-parent layer_order.txt required")
        prefix = order_paths[0][:-len("layer_order.txt")]
        if any(not name.startswith(prefix) for name in filenames):
            raise ValueError("Mixed root and wrapped folders: choose one layout")
        if prefix + "manifest.json" in filenames:
            raise ValueError("Do not include manifest.json in simple image-only ZIP")
        if final_live2d_body:
            # This stricter gate is for actual hand-off, not intermediate PNG sprite packs.
            # Do not mistake a correctly composited flat proxy for finished VTuber art.
            if any(n.rsplit("/", 1)[-1].lower() == "body_flat_proxy.png"
                   for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: flat BODY proxy is not completed torso art")
            if not any(n.lower().endswith(".psd") for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: layered PSD is missing")
            if not any(n.startswith(prefix + "alpha_masks/") and n.endswith(".png")
                       for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: per-part alpha masks are missing")
            if not any(n.startswith(prefix + "inputs/") for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: original input is missing")
            if not any(n.endswith(".json") for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: layer/validation JSON is missing")
            if not any(n.startswith(prefix + "previews/") for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: visual comparison previews missing")
            # Art quality remains subject to visual review; this code cannot certify it.
        master_name = prefix + "outputs/master.png"
        if master_name not in filenames:
            raise ValueError("Missing outputs/master.png")
        names = [n.strip() for n in archive.read(order_paths[0]).decode("utf-8-sig").splitlines()
                 if n.strip() and not n.lstrip().startswith("#")]
        counts = Counter(names)
        dupes = sorted(n for n, count in counts.items() if count != 1)
        isolated = [n[len(prefix):] for n in filenames
                    if n.startswith(prefix + "isolated_parts/")]
        invalid = sorted(n for n in isolated
                         if not n.startswith("isolated_parts/")
                         or not n.endswith(".png")
                         or not _PART_ID.fullmatch(n[len("isolated_parts/"):-4]))
        if invalid:
            raise ValueError(f"Invalid isolated sprite paths: {invalid}")
        actual = set(isolated)
        listed = set(names)
        missing = sorted(listed - actual)
        unlisted = sorted(actual - listed)
        if dupes or missing or unlisted:
            raise ValueError(
                f"layer_order mismatch: duplicate={dupes}; "
                f"listed_but_missing_png={missing}; "
                f"png_not_in_layer_order={unlisted}"
            )
        if not (1 if edition == "pro" else 2) <= len(names) <= (500 if edition == "pro" else 100):
            raise ValueError(f"Invalid part count for {edition}: {len(names)}")
        for name in names:
            if (not name.startswith("isolated_parts/") or not name.endswith(".png")
                    or not _PART_ID.fullmatch(name[len("isolated_parts/"):-4])):
                raise ValueError(f"Invalid sprite path: {name!r}")
        with Image.open(BytesIO(archive.read(master_name))) as master:
            if master.format != "PNG" or master.mode not in ("RGB", "RGBA"):
                raise ValueError("Master must be RGB/RGBA PNG")
            size = master.size
        if min(size) < 256 or size[0] * size[1] > 32_000_000:
            raise ValueError("Invalid master size")
        for name in names:
            with Image.open(BytesIO(archive.read(prefix + name))) as im:
                if im.format != "PNG" or im.mode != "RGBA" or im.size != size:
                    raise ValueError(f"PNG mode/canvas mismatch: {name}: {im.mode} {im.size} != {size}")
                alpha = im.getchannel("A")
                if alpha.getbbox() is None or alpha.getextrema()[0] == 255:
                    raise ValueError(f"Empty or fully opaque sprite: {name}")
        print(f"PASS: {len(names)} unique RGBA sprites match layer_order.txt and master canvas {size}")


if __name__ == "__main__":
    args = sys.argv[1:]
    production = "--final-live2d-body" in args
    args = [arg for arg in args if arg != "--final-live2d-body"]
    if len(args) not in (1, 2):
        raise SystemExit("Usage: python validate_artwork_zip.py ARTWORK.zip [free|pro] [--final-live2d-body]")
    validate(args[0], args[1] if len(args) == 2 else "pro", final_live2d_body=production)
```


**최종 Live2D BODY 결과 ZIP:** `python validate_artwork_zip.py live2d_bust_up__body__ARTWORK.zip pro --final-live2d-body`로 PSD·입력·마스크·JSON·미리보기를 추가 검사한다. FREE 캐릭터는 `free`로 실행한다. 이 검사는 실제 미술 품질이나 Cubism 리깅을 인증하지 않는다.

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
방송용 바스트업: 머리부터 배 위~허리 위까지 완성된 캐릭터 신체 원화. 양쪽 어깨·상완·전완·손과 자연스러운 목 연결을 포함하며 손을 가린 포즈도 숨은 파츠를 준비한다. 고정된 얼굴 초근접 구도와 단색 몸통 프록시를 금지한다. 사용자가 요구한 고유 애니풍 얼굴형과 큰 눈·좌우 홍채 정합을 유지한다. 턱 뒤 목 언더페인트, 양어깨·상완·전완·양손·복부를 실제 일러스트로 그린다. 귀·입·코는 간결한 애니풍으로 유지하고 하나의 U형 턱으로 고정하지 않는다. 교체 헤어·의상·액세서리는 독립 자산으로 남긴다.
실제 다층 PSD, 같은 캔버스 투명 RGBA PNG와 파츠별 알파 마스크, 원본 입력과 원본 PSD(있다면), 원본-결과 및 PRO BODY 정합 미리보기, 레이어 좌표/순서·검증·분할 JSON, 사용자 제작·시각검수·Cubism 안내 MD는 최종 필수. PSD와 마스크가 없으면 중간 PNG 검사 PASS여도 최종 납품 불가. BODY 최종 납품에 --final-live2d-body를 사용한다. HAIR/OUTFIT/ACCESSORY도 PSD·마스크 필수. 실제 이미지/Editor 확인 없이 미술·리깅 품질 PASS 금지.
회색 단색 몸통, 프록시 도형, 끊긴 목, 누락된 팔/손, 짧은 상체는 최종 FAIL. 완성 원화→파츠 분리 순서. 최종 ZIP은 실제 다층 PSD·투명 파츠 PNG·알파 마스크·원본 입력·미리보기·레이어 좌표·분리/검증 JSON·Cubism 안내 필수. 중간 PNG 검사 통과만으로 납품 성공 주장 금지.

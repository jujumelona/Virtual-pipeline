# Live2D 바스트업 신체 전용 시각 참고

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / body
**실제 제작:** 머리·얼굴·눈·입·귀·목·어깨와 가슴 위쪽의 안전하게 가려진 애니풍 신체 원화만.
**금지:** 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
**구도:** 방송용 바스트업은 머리 높이 1 : 보이는 목·어깨·상체 약 1~2의 레이아웃 기준이며, 신체 ZIP에서는 머리·얼굴·목·어깨의 완성 신체 원화를 직접 새로 그린다.


아래 공식 Live2D 전체 캐릭터 샘플은 **애니풍 선화·작화 수준을 참고할 목적만** 있고, 신체 외의 얼굴/옷/머리/악세서리를 추가로 그리라는 명령은 아니다. 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

공식 샘플: https://www.live2d.com/en/learn/sample/ . 원본 파일을 ZIP에 복제하지 않았으며 열람 불가면 보았다고 주장하지 않는다.

# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 live2d_bust_up/body 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지·예시와 참고 이미지를 **모두 실제 비전으로 연다.**
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 자료 접근이 안 되거나 참고 그림이 보이지 않으면 **생성 중단** 후
   확인할 수 없는 항목을 구체적으로 보고하고 원본 이미지 첨부를 요청한다.
   허위 열람 완료나 임의 참고 그림 대체 금지.
7. 모든 자료가 실제 확인되고 충돌이 해결된 뒤에만 완성 원화 한 장 제작.
   그 원화의 품질 확인 후 파츠 분리/PSD 제작/합성·최종 ZIP 검수로 진행한다.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **live2d_bust_up / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 기존 자료 형식: PSD
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.
- 3. **Live2D Mark-kun original example with sample PSD (FREE learning)** — https://www.live2d.com/en/learn/sample/mark/
   - 기존 자료 형식: PSD
   - 실제 활용: Small/simple FREE scene topology and rig structure study, not a target face style; preserve its character-specific license.
   - 권리 확인: Official sample terms; structural learning only. Do not transform Mark-kun into user's anime character.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** head to upper abdomen/waist with complete shoulders arms and hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 live2d_bust_up/body 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.
BODY는 얼굴/눈/입 애니 작화와 몸통을 **별도 제작**한다. 짧고 둥근 U형 턱, 볼, 작고 내부선 1~2개 귀, 긴 목/큰 정수리 방지. 눈색은 사용자 지정값을 우선하여 분홍/노랑 기본 고정 금지. 몸통은 코드로 만든 불투명 중립색 단색 프록시 도형으로 구성하여 튜브탑/옷/속옷/가슴·쇄골·겨드랑이 살접힘/압박 주름/근육 음영을 넣지 않는다. 옛 전신 한 장 생성 지침·기본 슈트 지시보다 이 계약 우선. 실제 도형 코드 실행, 얼굴과 동일 캔버스 합성, 마스크/파츠·비교 QA 없으면 완료 금지. 방송용 가슴 위 프레임만 생성.

## 2026-10-13 사용자 지정 BODY 최상위 제작 규칙 — 기존 묘사 지시보다 우선
이 ZIP은 머리·얼굴 및 재사용용 몸체 실루엣을 위한 신체 전용 지시서다. 외부 생성 AI에게 얼굴부터 몸까지 완성한 인체 일러스트를 한 장으로 요구하지 않는다.
얼굴·눈·입을 애니풍으로 작업하고 BODY 몸체는 별도의 중립색 불투명 2D 도형 프록시를 프로그램으로 만든다. 몸체 도형에는 옷/속옷/튜브탑/리본/목깃/어깨 압박 주름/쇄골 윤곽/가슴 굴곡/겨드랑이 피부 접힘/근육/갈비뼈의 그림과 음영을 그리지 않는다.
정면 얼굴은 짧고 부드러운 U형 하관과 둥근 볼, 작은 애니 귀(내부 선 1~2개), 균형 잡힌 두상과 단순한 목을 사용한다. 기존의 긴 V자 턱과 실사형 큰 귀, 과도한 정수리와 긴 목을 다시 생성하면 FAIL이다. 눈 크기만으로 애니형 판정하지 않는다.
홍채 색은 사용자가 지정하거나 캐릭터별 팔레트에서 선정한다. 특정 분홍/노랑 눈색 고정 금지. 헤어와 의상, 액세서리는 BODY에 병합하지 않는다.
제작 순서: 공식 완성 VTuber 참고 이미지를 실제로 열어 비교·기록 → 얼굴 원화 시각 검수 → 단색 BODY 도형 생성 → 한 캔버스에서 조립 → RGBA 분리/가려진 면 검사 → 합성 QA → 최종 ZIP. 링크 확인만으로 이미지 시각검수 완료라고 보고하지 않는다.
도형 코드를 실행하지 않고 생성 AI에 통짜 몸통을 그리게 하면 본 지시 미준수다. 실행이 막히면 거짓 완료 판정 대신 제작 불가를 보고한다. PSD/리깅은 별도 단계.
신체 도형은 완성 캐릭터 일러스트가 아니라 의상 교체용 레이어이므로 미술적 화려함/인체 곡선을 요구하지 않는다. 사용자 얼굴 정체성과 전체 6등신 디자인 계약(전신인 경우)을 보존한다.

# Live2D 바스트업 — 신체 전용 시작 지시

00_MASTER_FIRST.md, 02_ADVANCED_PARTS.md, 08_PRACTICAL_TIPS.md, 07_REVIEW_BEFORE_FINAL_ZIP.md를 반드시 읽는다.

## ZIP 고유 작업 범위 잠금: live2d_bust_up / body
**실제 제작:** 고품질 애니 얼굴·눈·입·귀 원화와 별도 코드로 만든 목·어깨·상체의 단색 중립 BODY 실루엣만.
**금지:** 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다.
**구도:** 얼굴 중심의 고급 2D 애니 VTuber 근접 바스트업. 두피 정수리~턱 H가 전체 화면 세로의 52~61%를 차지하는 비율을 우선 시작값으로 삼고, 길게 펼쳐진 몸통 없이 짧은 목까지 얼굴 원화로 제작하고 어깨·몸통은 별도 단색 BODY 도형으로 합성한다.


**한 가지 자산만 실제 생성:** 얼굴·눈·입·귀 원화와 목·어깨·상체 단색 BODY 도형을 같은 캔버스에 조립한다. 큰 홍채·좌우 흰자·속눈썹·눈꺼풀·작은 코/입·입 내부를 분할하고 턱 뒤 목·양어깨 피부를 그려 회전 시 끊김을 막는다. 실사 가슴/갈비뼈/복근을 강조하지 않는다.

**구도/미술 품질:** 짙은 가변 외곽선과 테이퍼·작은 방송 화면에서도 읽히는 2~3톤 셀 셰이딩의 고급 애니풍 VTuber 원화. 기준 몸체가 있을 경우 실제 캔버스·원점·좌우·배율·선화와 정합한다. 얼굴/눈·입과 목/어깨를 예술적 품질 기준으로 그리되 별도 패션 의상과 헤어는 만들지 않는다.

**경계:** 독립 헤어·탈착 의상·액세서리·골반·다리·발을 제작하지 않는다. 목 아래 몸통은 불투명 중립색 프록시/마스크로만 구성하고 추가 신체·의복 텍스처를 생성하지 않는다. 바스트업에 전신 6등신·골반/다리를 강제하지 않는다.

실제 대상 원화 → 해당 자산 RGBA 분리 → 움직임으로 드러날 해당 자산의 가림 부위 보완 → 실제 합성 비교 → 그림 결함만 다시 보완 → `live2d_bust_up__body__ARTWORK.zip` 납품. 이미지 AI는 PSD·Cubism Editor·MOC3·리깅 수행을 주장하지 않는다.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | body]
얼굴 중심 근접 바스트업. H=두피 정수리~턱. 전체 프레임 세로는 약 1.65~1.95H를 시작값으로 하고, 두피~턱이 화면 세로 52~61% 정도로 크게 보이게 한다. 목·어깨·BODY 프록시 윗부분만 짧게 보이고 허리·긴 몸통·팔꿈치·손은 그리지 않는다. 이 수치는 공식 규격이 아닌 이 프로젝트의 얼굴 중심 미술 시작값이며 사용자 참조가 우선이다.
신체 ZIP 한정: F=정면 관자놀이 사이 얼굴폭(귀·모발 제외), E=눈꺼풀 외곽 눈 한쪽 너비(긴 속눈썹 제외). 큰 애니 VTuber 표정을 위한 선택적 시작값 E/F=23~29%, 양눈 간격/E=0.65~0.95, 보이는 홍채 폭/E=62~80%. 단순히 숫자를 채우는 것이 아니라 큰 상안부·도드라진 홍채/상안검 곡선·섬세한 눈꼬리, 작고 단정한 코/입, 짧고 둥근 U형 애니 턱, 단순화된 귀·목 그림자가 시각적으로 애니풍이어야 한다. 실사 인물 피부·안와 뼈·광대·콧대·넓은 어깨·긴 몸통을 금지. 숫자는 업계 실측 평균/검수용 강제 조건이 아니고 사용자 설정 외형이 우선.

# Live2D 전신 / 신체만 이미지 결과 구조
결과 ZIP: live2d_full__body__ARTWORK.zip
isolated_parts/face_skin.png
isolated_parts/nose.png
isolated_parts/ear_L.png
isolated_parts/ear_R.png
isolated_parts/brow_L.png
isolated_parts/brow_R.png
isolated_parts/eye_L_white.png
isolated_parts/eye_L_iris.png
isolated_parts/eye_L_upper_lash.png
isolated_parts/eye_R_white.png
isolated_parts/eye_R_iris.png
isolated_parts/eye_R_upper_lash.png
isolated_parts/mouth_upper.png
isolated_parts/mouth_lower.png
isolated_parts/mouth_inside.png
isolated_parts/neck.png
isolated_parts/torso.png
isolated_parts/arm_L_upper.png
isolated_parts/arm_L_forearm.png
isolated_parts/hand_L.png
isolated_parts/arm_R_upper.png
isolated_parts/arm_R_forearm.png
isolated_parts/hand_R.png
isolated_parts/pelvis.png
isolated_parts/thigh_L.png
isolated_parts/thigh_R.png
isolated_parts/shin_L.png
isolated_parts/shin_R.png
isolated_parts/foot_L.png
isolated_parts/foot_R.png
layer_order.txt
previews/composite_preview.png
위 파일명은 구조의 예시. 실제 없는 파츠를 만들지 말고 02_ADVANCED_PARTS에 따라 필요한 고급 파츠를 추가하라.
모든 파츠 PNG는 같은 기준 캔버스·원점의 **실제 RGBA 투명 그림**. 시트로 한 번에 생성해도 최종 개별 파일을 각각 납품한다. layer_order.txt에는 뒤→앞 목록만 적는다.
합성 미리보기는 마지막에 실제 파츠로 만들며 합성본을 다시 마스킹하지 않는다. 신체 외 다른 자산은 참조 몸 자체를 다시 만들거나 결과물에 신체 레이어를 섞지 않는다.
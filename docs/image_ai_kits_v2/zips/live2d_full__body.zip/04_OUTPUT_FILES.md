# Live2D 전신 / 신체만 — 최종 원화 ZIP
결과: **`live2d_full__body__ARTWORK.zip`**

```text
live2d_full__body__ARTWORK.zip
  isolated_parts/face_skin.png
  isolated_parts/nose.png
  isolated_parts/ear_L.png
  isolated_parts/ear_R.png
  isolated_parts/brow_L.png
  isolated_parts/brow_R.png
  isolated_parts/eye_L_white.png
  isolated_parts/eye_L_iris.png
  isolated_parts/eye_L_upper_lash.png
  isolated_parts/eye_L_lower_lash.png
  isolated_parts/eye_R_white.png
  isolated_parts/eye_R_iris.png
  isolated_parts/eye_R_upper_lash.png
  isolated_parts/eye_R_lower_lash.png
  isolated_parts/mouth_upper.png
  isolated_parts/mouth_lower.png
  isolated_parts/mouth_inside.png
  isolated_parts/neck.png
  isolated_parts/torso.png
  isolated_parts/arm_L_upper.png
  isolated_parts/arm_L_forearm.png
  isolated_parts/hand_L.png
  isolated_parts/arm_R_upper.png
  isolated_parts/arm_R_forearm.png
  isolated_parts/hand_R.png
  isolated_parts/pelvis.png
  isolated_parts/thigh_L.png
  isolated_parts/thigh_R.png
  isolated_parts/shin_L.png
  isolated_parts/shin_R.png
  isolated_parts/foot_L.png
  isolated_parts/foot_R.png
  layer_order.txt
  previews/composite_preview.png
```

위 목록은 **실제 디자인에 존재하는 파츠명 예시**다. 고급 그림의 별도 움직임/가림을 위해 필요한 파일은 02·06·08을 참고해 처음부터 생성하고, 없는 부위나 미요청 다른 자산은 제외한다.

파츠 하나당 진짜 RGBA 투명 PNG 하나이며 **동일 캔버스 크기·원점·부착 위치**에 그 부분만 배치한다. `layer_order.txt`에는 실제 상대경로를 뒤→앞 순서로 적는다. 최종 합성은 PNG를 모두 만든 후 시행한다. 

**07의 반복 원화·파일 확인에서 적용 가능한 모든 요구를 충족해야만 최종 결과 ZIP 제공.** 보고서/리깅/구동 인증을 만들지 않는다.



## [FACE_BODY_COLOR_LOCK_V4 / 파츠 원화 생성 강제]
캐릭터 얼굴(홍조·하이라이트·그림자 제외)에서 고른 단 하나의 피부 중간톤 `FACE_SKIN_BASE=#RRGGBB`를 먼저 확정하고, 매 이미지 생성 요청에 **실제 HEX 값**과 마스터 참조를 함께 전달한다. 얼굴·귀·두피·목·어깨·몸통 커버의 보이는 기본색·양쪽 상완·전완·양손·손가락·모든 RGB 가림 뒤 연장 픽셀은 같은 베이스색으로 작화한다. 보이는 몸통은 불투명한 무광 비해부학적 가림형 커버로 남기되 **커버의 기본색을 얼굴색과 다르게(회색/보라/라벤더) 만들지 않는다**. 실제 의상 또는 별도 수영복 레이어의 디자인색은 피부가 아니므로 임의로 피부색으로 바꾸지 않는다. 이미 존재하는 보라색 BODY 원화는 정면 마스터 단계에서 얼굴색에 맞게 다시 채색한 뒤 파츠를 자른다. 마스크는 별도 알파 데이터이며 RGB를 회색/흰색으로 덮어 틈을 감추지 않는다. 정면·3/4·측면·고개 상하 모든 뷰에서 동일한 팔레트를 사용한다. 얼굴↔목↔몸통↔상완↔전완↔손의 각 연결부를 **합성 이미지로 확인**, 베이스색이 분리되면 `COLOR_CONTINUITY_FAIL` 처리하고 잘못된 신체 파츠를 재생성할 때까지 납품하지 않는다.
## [/FACE_BODY_COLOR_LOCK_V4]

# 04 — 이미지 생성 AI 개별 파츠 원화 납품

## [MATTE_CLAY_BODY_V1]
불투명 단색 무광 찰흙형 BODY
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.live2d.com/en/cubism-editor-tutorials/template/
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** 해당 플랫폼 실제 PSD 템플릿의 레이어·가림 계층, 눈-흰자/홍채/윗속눈썹, 입-닫힌선/입안/윗니/혀, 얼굴/귀/목, 좌우 상완/전완/손. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: live2d_full/body; 정수리부터 두 발까지 일관된 6등신. 다른 자산을 새로 제작하지 않는다.
- 1) 이 자산의 디자인 마스터를 확정하고 얼굴·눈·입·목·몸통·팔과 색상을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: face, ear.left, ear.right, eye.left.white, eye.left.iris, eye.left.upper.lash, eye.right.white, eye.right.iris, eye.right.upper.lash, eyebrow.left, eyebrow.right, nose, mouth.close, mouth.open, mouth.tooth.t, mouth.tongue, neck, torso, arm.left.upper, arm.left.forearm, hand.left, arm.right.upper, arm.right.forearm, hand.right, pelvis, thigh.left, thigh.right, shin.left, shin.right, foot.left, foot.right. 눈 흰자·홍채·윗속눈썹, 닫힌 입·열린 입안·윗니·혀, 상완·전완·손을 각각 독립 작화한다. 다른 자산에 속한 파츠를 추가하거나 누락을 이름만으로 통과시키지 않는다.
- 5) `part_art/_order.txt`에는 앞에서 뒤로 각 개별 PNG 경로를 한 줄씩 쓴다. PSD·마스크·MOC3·리깅은 제작하지 않는다. 열린 입안·치아·혀의 대체 그림은 각각 생성하되 중립 합성에서만 감춘다.
- 6) 양쪽 눈·목·어깨·팔·손목을 정면·3/4·측면 참조와 대조하고, 중립 파츠 합성이 `outputs/master.png`와 일치해야 한다. 접합 틈·중복·부유 파츠는 반려한다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png. BODY는 `expression_refs/mouth_closed.png` 및 `expression_refs/mouth_open.png`를 별개의 완성 표정 참고 원화로 추가한다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 목·턱·좌우 어깨·상완·전완·손의 실루엣을 시점마다 정합되게 그린다. 단색 무광 찰흙형 비해부학 BODY를 유지한다. neck_underpaint와 body_joint_overlaps는 **부품이 아니라 목·턱·몸통·어깨의 가림·연결을 설명하는 완성 참고 그림**이다. 정면·좌우 3/4·측면에서 턱 아래 목과 귀 뒤, 목-어깨 접점을 보여준다. 정면 그림을 늘이거나 머리만 좌우 이동해 옆모습으로 속이지 않는다.
- **제작 단계 확정:** 이미지 AI는 위에 명시한 독립 파츠의 실제 그림과 다각도 참조를 하나씩 제작한다. PSD 인코딩·메시·키폼·리깅은 별도 단계다. 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] part_art/neck.png는 턱 아래 잘린 얇은 조각이 아니어야 한다. 정면에서 턱 뒤 피부를 입 높이 가까이까지 위쪽으로 실제 그려 두고, 아래는 part_art/torso.png의 상부와 실질적인 알파 교집합을 만들어 놓는다. 얼굴 아래·목·몸통이 알파로 단순히 접하는 선은 실패다. head_three_quarter_L/R는 약 45°, head_profile_L/R는 실제 90° 형태 참고다. 각각 코·입·턱·귀·목뿌리·양어깨가 한 그림 안에서 연결되고 좌우 반전 복제로 대체하지 않는다. head_pitch_up/down에서 턱 아래 목의 드러남/가림을 실제로 바꾼다. neck_underpaint와 body_joint_overlaps 참고 그림을 따로 그리는 것만으로는 실제 part_art/neck.png의 가려진 픽셀이 생기지 않는다.
- [좌표/참조] 정면·좌우 3/4·양측면 및 상하 자세 비교 원화는 outputs/master.png와 동일한 전체 캔버스 치수·기준 크기로 그린다. 확대 클로즈업은 별도 보조 그림으로만 남긴다. 이미지 AI의 다각도 그림은 PSD2Live/Inochi 실제 키폼에 자동 등록되지 않는다.
- [엔진 확인] PSD2Live 기본 머리 ParamAngleX 범위는 -45..+45°, ParamAngleY는 -30..+30°다. 실제 -90/+90° 옆모습 PNG는 자동으로 키폼이 되지 않는다. 실제 MOC3 극한 각도 렌더링과 턱·목·귀·헤어 가림을 확인할 때까지 90° 가능이라고 보고하지 않는다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## 납품 검사

완성 마스터와 각 파츠 PNG를 실제 열어 동일한 캐릭터·색·좌표·투명도·가림을 확인한다. 파츠별 원화를 하나씩 생성하되 PSD 인코딩·메시·리깅은 여기서 하지 않는다.

## 파츠 실제 제작 근거
02_ADVANCED_PARTS.md의 [SINGLE_PART_VISUAL_TASK_CARDS_V1]을 확인하고 한 번에 한 파츠를 그리며 실제 투명도·원본 합성·숨은 픽셀·측면 접합을 확인한다. 파일명만 맞아도 그림의 기능이 틀리면 불합격이다.

## [BROADCAST_HANDS_BODY_COLOR_V1]
### 최종 파일에 반드시 실제로 존재해야 하는 그림
**범위 우선순위:** 이 지침은 같은 ZIP의 오래된 '가슴 위까지만', '손이 보일 때만 손' 같은 조건보다 우선한다. BODY 원본의 양손 누락은 허용하지 않는다. 작업 자산 소유권·2D/3D 형식 규칙은 유지한다.
### 전신 BODY: 실제로 무엇을 완성하고 어떻게 합성할지

- **전체 범위:** 정수리에서 양발 끝까지의 자연스러운 몸통·양어깨·양팔·양손을 전부 생성한다. 하단·좌우 캔버스 가장자리는 손가락을 자르지 않고 움직임을 위한 여백을 둔다.
- **양손 전체 필수:** 손목에서 멈추지 않고 왼손·오른손 각각 손바닥, 엄지, 검지·중지·약지·새끼손가락의 **끝까지 완전한 그림**을 만든다. 양쪽 상완·전완·손은 각각 독립 RGBA PNG다. 화면 뒤로 숨기는 것을 '손 생성 완료'라고 기록하지 않는다.
- **방송 기본 자세:** T/A자 팔벌림이 아니라 어깨 힘을 뺀 자연스러운 자세에서 팔꿈치를 편안하게 굽혀 양손을 윗배·몸통 옆쪽 가까이에 배치한다. 두 손을 몸 앞에 둬도 좋으나 얼굴을 가리지 않는다. 좌우 팔 길이·손목 방향·엄지 위치가 실제 같은 사람이어야 한다.
- **마스킹 색 구분:** 색으로 가려진 면을 메우는 BODY 보정용 원화/언더페인트의 **RGB는 주변의 실제 BODY에 보이는 픽셀과 동일하게** 한다. 목·얼굴 아래 피부는 해당 목/얼굴 피부색을, 어깨·몸통 찰흙형 외피의 뒤받침은 실제 외피 베이스색을, 팔꿈치·손목 안쪽은 각각 이어지는 팔/손의 지정색을 사용한다. 몸통 커버·목·팔·손 베이스색이 다르면 마스터부터 수정하여 얼굴과 반드시 동일하게 통일한다. 다만 별도 의복 레이어는 예외다. **임의의 회색·검정·흰색·반창고색으로 틈을 덮지 않는다.** 가장자리는 기존 원화의 셀 명암/선폭을 그대로 이어 그리되 가려지는 단면에 검은 절단선을 새로 긋지 않는다.
- **알파/클리핑 마스크는 다른 것:** 투명도·가림을 정의하는 알파/클리핑 마스크는 채색 피부가 아니다. 마스크 채널은 투명도 데이터로 유지한다. '몸색과 같게'라는 규칙을 알파 채널이나 별도의 회색조 클리핑 마스크에 적용해 불투명으로 덮으면 안 된다. 실제 같은 BODY 색상으로 칠하는 대상은 **보정용 RGB 그림**뿐이다.
- **턱·목·어깨 OFF/ON:** face와 hair를 가린 뒤 part_art/neck.png를 열었을 때 목 위쪽은 턱 양옆 뒤·귀 아래 뒤까지 실제 피부색으로 채워져 있어야 한다. torso를 숨기면 목 아랫단이 가슴 윗면/어깨 아래로 이어져야 한다. 모두 켰을 때 목과 턱 및 어깨 접합에 투명 삼각형이나 검정 이중 테두리가 없고, 옆모습에서 귀 아래→턱 뒤→목 앞·뒷선→어깨로 실제 연속 연결되어야 한다. 3/4/측면 참고 그림만 예쁘게 있고 실제 neck.png가 잘려 있으면 불합격이다.
- **팔 파츠 그림 경계:** 어깨 소켓 안쪽까지 arm.left/right.upper를 실제 외피/피부색으로 연장하고, 팔꿈치 뒤까지 arm.left/right.forearm 윗단을 연장하며, 손목의 숨은 시작부분을 hand.left/right에 실제 손색으로 채운다. 상완→전완→손을 한 번씩 켜고 끄며 색상·선화·가림 순서·자연스러운 길이를 확인한다. 손의 각 다섯 손가락은 만화풍 단순화는 허용하나 벙어리장갑 실루엣·추가 손가락·손가락 잘림은 금지한다.
- **방송 화면 대조:** 원본 전체(양손·윗배 포함)와 방송용 확대 화면(얼굴·목·어깨 위주)을 **별도 미리보기**로 본다. 방송 확대 미리보기에 손이 일부 안 보이더라도 원본·파츠 폴더에서는 완전한 양손을 유지한다. 확대 화면은 컷/카메라 설정이며 손 삭제·프레임 수정 지시가 아니다.
- 필수 독립 PNG: part_art/arm.left.upper.png, part_art/arm.left.forearm.png, part_art/hand.left.png, part_art/arm.right.upper.png, part_art/arm.right.forearm.png, part_art/hand.right.png, part_art/neck.png, part_art/torso.png. 파일 이름과 달리 실제 그림이 잘렸다면 불합격. part_art/_order.txt 및 outputs/master.png도 동일한 전체 캔버스 좌표로 제출한다. 열린 입·감긴 눈 등 대체 파츠는 중립 미리보기에 한꺼번에 켜지 않는다.
## [/BROADCAST_HANDS_BODY_COLOR_V1]

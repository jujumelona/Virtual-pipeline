# Live2D 전신 / 신체만 결과 원화 ZIP
파일명: `live2d_full__body__ARTWORK.zip`

```text
live2d_full__body__ARTWORK.zip
  isolated_parts/face_skin.png
  isolated_parts/nose.png
  isolated_parts/ear_L.png
  isolated_parts/ear_R.png
  isolated_parts/brow_L.png
  isolated_parts/brow_R.png
  isolated_parts/eye_L_white.png
  isolated_parts/eye_L_iris.png
  isolated_parts/eye_L_upper_lash.png
  isolated_parts/eye_L_lower_lash.png
  isolated_parts/eye_R_white.png
  isolated_parts/eye_R_iris.png
  isolated_parts/eye_R_upper_lash.png
  isolated_parts/eye_R_lower_lash.png
  isolated_parts/mouth_upper.png
  isolated_parts/mouth_lower.png
  isolated_parts/mouth_inside.png
  isolated_parts/neck.png
  isolated_parts/torso.png
  isolated_parts/arm_L_upper.png
  isolated_parts/arm_L_forearm.png
  isolated_parts/hand_L.png
  isolated_parts/arm_R_upper.png
  isolated_parts/arm_R_forearm.png
  isolated_parts/hand_R.png
  isolated_parts/pelvis.png
  isolated_parts/thigh_L.png
  isolated_parts/thigh_R.png
  isolated_parts/shin_L.png
  isolated_parts/shin_R.png
  isolated_parts/foot_L.png
  isolated_parts/foot_R.png
  layer_order.txt
  previews/composite_preview.png
```

이름은 **필요한 파츠명 예시**다. 존재하지 않는 항목의 숫자를 채우지 않는다. 실제 필요한 고급 파츠는 처음부터 새 그림으로 만든다. 각 파츠는 해당 부분만 그린 독립 **RGBA 투명 이미지**, 동일 캔버스·원점과 정확한 위치를 사용한다. 실제 PNG들을 최종 합성하고 `layer_order.txt`에 뒤→앞 순서를 기록한다.


**정식 납품 전 `07_REVIEW_BEFORE_FINAL_ZIP.md`와 `09_VISUAL_ART_QUALITY.md`를 함께 확인하여 작화 품질을 포함한 적용 가능한 요구를 충족한다.**

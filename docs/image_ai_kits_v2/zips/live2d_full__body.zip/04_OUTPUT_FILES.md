# Live2D 전신 / 신체만 결과 그림 파일
결과 ZIP: live2d_full__body__ARTWORK.zip
isolated_parts/face_skin.png
isolated_parts/nose.png
isolated_parts/brow_L.png
isolated_parts/brow_R.png
isolated_parts/eye_L_white.png
isolated_parts/eye_L_iris.png
isolated_parts/eye_L_upper_lash.png
isolated_parts/eye_R_white.png
isolated_parts/eye_R_iris.png
isolated_parts/eye_R_upper_lash.png
isolated_parts/mouth_upper.png
isolated_parts/mouth_lower.png
isolated_parts/mouth_inside.png
isolated_parts/neck.png
isolated_parts/torso.png
isolated_parts/arm_L_upper.png
isolated_parts/arm_L_forearm.png
isolated_parts/hand_L.png
isolated_parts/arm_R_upper.png
isolated_parts/arm_R_forearm.png
isolated_parts/hand_R.png
isolated_parts/pelvis.png
isolated_parts/thigh_L.png
isolated_parts/thigh_R.png
isolated_parts/shin_L.png
isolated_parts/shin_R.png
isolated_parts/foot_L.png
isolated_parts/foot_R.png
layer_order.txt
previews/composite_preview.png
각 PNG는 같은 캔버스 크기·원점, 해당 파츠만 진짜 투명 RGBA. 파일은 예시이며 해당 캐릭터 디자인에 없는 항목 생략, 필요한 고급 파츠는 추가.
layer_order.txt에는 실제 만든 상대 경로를 뒤→앞으로 한 줄에 하나. 최종 미리보기는 생성된 파츠만 합성.
액세서리 파일 예시 HEADPIECE 같은 자리 이름은 요청 실제 종류로 치환. 신체 원화는 헤어/의상/장식 ZIP에 포함하지 않는다.
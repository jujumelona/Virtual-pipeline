# Live2D 전신 신체에만 적용하는 공식 원화 시각 사례

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손·골반·양다리·발과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.
**그릴 범위:** 전체 캔버스를 기준으로 안전하게 가린 신체의 머리·상체·팔·손·골반·다리·발. 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


- 아래 Live2D 공식 캐릭터 샘플은 **화풍·선화·명암·완성도만 참고**한다. 샘플 전체 캐릭터를 다시 그리거나 body 이외의 신체·헤어·의상을 제작하라는 뜻이 아니다.
- 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손·골반·양다리·발과 안전하게 가린 신체 베이스. 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.
- 공식 예시 이미지는 ZIP에 동봉하지 않았다. 열람 불가면 보았다고 주장하지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

공식 작품 갤러리: https://www.live2d.com/en/learn/sample/ ; 파츠 가공: https://docs.live2d.com/en/cubism-editor-tutorials/psd/. 샘플 외형은 복제하지 않는다.

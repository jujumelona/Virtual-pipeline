# live2d_full / body — 해당 엔진·자산 공식 근거

> 00_MASTER_FIRST.md의 완성 원화 우선 계약을 따른다. Cubism Editor 실행/리깅은 이 ZIP의 출력물이 아니다.

## 적용 대상: 신체 원화만
[Live2D 공식 일러스트 가공](https://docs.live2d.com/en/cubism-editor-tutorials/psd/)은 눈 흰자·속눈썹·입 내부·귀·목과 가려지는 피부를 해당 움직임에 맞게 나누고 보완하는 기법을 설명한다. [PSD 작업 주의사항](https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/)은 후속 Cubism 가져오기 참고사항이다.
실제 납품은 선택된 화면 범위의 **신체 원화·신체 PNG·재합성 미리보기만**이다. 헤어·탈착 의상·독립 소품 제작이나 Cubism Editor 실행·키폼/리깅·MOC3는 요구하지 않는다.

각 ZIP은 `00_MASTER_FIRST.md`의 자산·모드 범위를 우선한다. 이 문서에 열거된 파일명/예제는 이 프로젝트 산출 기준이지 공식 엔진의 고정 파츠/이미지 개수 규정이 아니다. 링크는 기법의 출처이며 모델링·PSD 처리 도구 실행 및 외부 다운로드/라이선스 확보를 이미지 생성 AI의 필수 단계로 만들지 않는다.

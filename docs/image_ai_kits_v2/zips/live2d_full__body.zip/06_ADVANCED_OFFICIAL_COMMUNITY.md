# Live2D 전신 신체 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손·골반·양다리·발과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.
**그릴 범위:** 전체 캔버스를 기준으로 안전하게 가린 신체의 머리·상체·팔·손·골반·다리·발. 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 공식 근거를 이미지 제작에 적용
- 공식 Live2D 파츠 가공: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . 이미지 AI는 실제 신체 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . Cubism의 Skinning/Glue/Clipping 등의 기능이 그림 AI가 실제로 ArtMesh나 리깅을 만들었다는 증거는 아니다.
- 좌우 눈 흰자 뒤를 채우고 홍채/동공/속눈썹의 픽셀 소유권을 분리한다. 열린 입 안쪽과 닫힌 입 선을 동시에 보이지 않게 한다. 턱 뒤 목 피부·좌우 어깨·팔꿈치·손목·무릎·발목은 겹침 여유를 둔다. 머리 큰 6등신 기반 애니풍을 유지하면서 실사 골격 음영을 줄인다.
- 독립 ArtMesh 수나 그림자/하이라이트 PNG 수를 고정하지 않는다. 고정 문양은 본체에, 실제 다른 움직임·앞뒤 순서가 필요한 요소만 나눈다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 미리보기는 실제 파츠를 조립한 그림으로 만들고 기준 몸체는 좌표 참고용으로만 사용한다.
- 커뮤니티 원화 사례: https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ — 개별 작업자 경험이며 공식 필수 조건이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. 공식 PSD 주의사항: https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ .


## [고급 원화·애니풍 전문 노하우 2026-10-13 / live2d_full / body]
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ (눈·입·목·팔/다리 파츠 분리). **개인 작가:** https://tips.clip-studio.com/en-us/articles/7379 (스타일에 따라 얼굴 비율 조정), https://tips.clip-studio.com/en-us/articles/6615 (정면·3/4·측면 눈).
구별: 6등신·애니풍 채색은 이 프로젝트 디자인 조건이며 Live2D 공식의 필수 비율·톤 수가 아니다. 편집기 리깅/키폼은 이미지 AI 작업이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_full/body]
[공식 Live2D 원화 가공] https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 가려진 흰자·입안·모발을 보완하고 얼굴 이동 시 목이 잘리지 않게 목 피부를 **입 높이 근처까지** 숨겨 그리도록 권장. [개인 작가 CLIP STUDIO TIPS] https://tips.clip-studio.com/ko-kr/articles/11807 , https://tips.clip-studio.com/ko-kr/articles/6599 , https://tips.clip-studio.com/en-us/articles/8014 — 눈 배치·측면의 코 뒤 눈·3/4 먼 눈 축소 참고. 추천 숫자는 이 출처들이 실측한 '흔한 버튜버 평균'이 아니라 프로젝트 제안값이다. Inochi2D에 Cubism 편집 기능 수행을 요구하지 않는다.
Live2D/Cubism의 원화 처리 원칙을 참고하되 실제 Cubism 모델·물리·키폼을 이미지 AI에 강제하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_full/body]
**[공식 vs 작업 경험]** Live2D 공식은 눈꼬리 속눈썹의 분리 편의와 숨은 흰자·입안 보완을 설명한다: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . Live2D 공식 가져오기 PSD 자료는 파츠당 선화/칠을 합치는 제작 단계를 설명한다: https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ . **피부 고정 그림자와 움직이는 앞머리 그림자의 소유권 분리**는 원화 품질을 위한 선택적 제작자 운영 원칙이며 Cubism에서 의무적으로 생성할 별도 그림자 수가 아니다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

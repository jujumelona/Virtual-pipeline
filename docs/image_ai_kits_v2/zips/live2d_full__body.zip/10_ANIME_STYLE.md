## [BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 회색/살구색/중립 파스텔색 등의 균일한 불투명 색 면을 허용한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** 6등신 전신 애니 원화. 큰 눈과 부드러운 얼굴·균형 잡힌 팔다리, 손가락·관절·발까지 모두 고품질로 그린다. 얼굴 확대 별도 이미지로 눈매 디테일을 보존하고 비례를 재검토한다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**live2d_full/body 생성 최상위 기준**: 아래 구형 규칙과 충돌하면 이 규칙을 우선한다.
- BODY에서 크고 둥근 머리, 가로폭 넓고 세로 짧은 얼굴, 부드럽고 짧은 U형 턱, 자연스러운 볼, 큰 눈과 홍채를 실제 완성 원화에 구현한다. 길고 좁은 말상·V형 뾰족한 턱·긴 코 밑·긴 목·작은 눈·머리보다 지나치게 넓은 어깨 금지. 민머리 윗두피만 커서 눈이 작아 보이는 것도 실패. 전신은 6등신. 실제 피부의 갈비뼈/쇄골/배꼽/근육 표현 과장 금지. BODY에는 불투명 무광 단색 찰흙형 상체 가림 외피를 착용하고, 하체가 보이는 경우 쇼츠형 하의를 착용한다. 교체용 패션 의상만 OUTFIT에서 제작한다.
- 큰 머리, 큰 눈/홍채, 짧고 폭 넓은 얼굴, 둥근 볼, 부드럽고 짧은 U턱, 작은 코·입을 기본으로 한다. **긴/좁은 얼굴과 말상, 뾰족한 V턱, 성숙·실사 모델 인상은 절대 불합격.**
- 정면 얼굴 세로/가로 약 1.10~1.30은 귀여운 스타일의 권장 출발점이며 절대적인 크롭 수치가 아니다. 전신은 프로젝트 6등신, 상반신/바스트업은 큰 머리 존재감을 유지한다.
- 불합격 항목: 머리가 작아 보임, 눈이 작음, 얼굴이 길고 좁음, 뾰족한 턱, 긴 목, 다른 자산 혼입. 눈으로 검사하여 하나라도 발견되면 결과물 납품 금지.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_full/body]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **BODY만 생성:** 귀여운 애니풍 두상·큰 눈/홍채·짧고 둥근 하관, 단순한 피부와 목·어깨·필요한 신체·손. 갈비뼈/복근/배꼽/쇄골·힘줄을 선으로 과잉 묘사하지 않는다. 디자인 의상은 OUTFIT 전용이며 BODY에는 위 기본 불투명한 어깨끈 없는 반도형 불투명 단색 외피로 덮인다. 몸통은 불투명 무광 단색 찰흙형 베이스. 얼굴과 눈은 높은 품질의 애니풍 원화. 헤어·탈착 의상·액세서리를 BODY에 붙이지 않는다.
- 프레임: 정수리부터 발끝까지 전체. 자산 소유 범위에만 적용. 전신 캐릭터 기본 디자인은 6등신을 지향하나 크롭에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY 제공 시 얼굴 비율을 변경하지 않는다.


## [2026-10-13 v5 live2d_full/body 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.

## 2026-10-13 사용자 지정 BODY 최상위 제작 규칙 — 기존 묘사 지시보다 우선
이 ZIP은 머리·얼굴 및 재사용용 몸체 실루엣을 위한 신체 전용 지시서다. 외부 생성 AI에게 얼굴부터 몸까지 완성한 인체 일러스트를 한 장으로 요구하지 않는다.
정면 얼굴은 짧고 부드러운 U형 하관과 둥근 볼, 작은 애니 귀(내부 선 1~2개), 균형 잡힌 두상과 단순한 목을 사용한다. 기존의 긴 V자 턱과 실사형 큰 귀, 과도한 정수리와 긴 목을 다시 생성하면 FAIL이다. 눈 크기만으로 애니형 판정하지 않는다.
홍채 색은 사용자가 지정하거나 캐릭터별 팔레트에서 선정한다. 특정 분홍/노랑 눈색 고정 금지. 헤어와 의상, 액세서리는 BODY에 병합하지 않는다.
BODY는 의상 교체용 공통 베이스로서 몸통은 불투명한 비해부학적 무광 단색 찰흙 외피로 제작한다. 해부학적 내부선은 생략하고 큰 머리·짧고 둥근 얼굴·부드러운 턱·큰 눈을 유지한다.

# Live2D 전신 신체 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손·골반·양다리·발과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.


큰 홍채·깊이 있는 속눈썹·작은 코와 입·부드러운 턱·매끈한 셀 피부. 사실적인 갈비뼈/복근/흉근·성인 실사 비례는 금지. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber body-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested body asset on the reference canvas, no unrelated character parts or props.”



## [고급 원화·애니풍 전문 노하우 2026-10-13 / live2d_full / body]
Professional six-head-proportion Japanese anime FULL BODY BASE ONLY, beautiful large layered irises, fine tapered lashes, petite stylized nose/mouth, coherent neck shoulders elbows wrists pelvis knees ankles and feet, modest opaque basewear, no new hair fashion clothing jewelry, studio cel shading.
Crisp tapered outlines, subtle colored inner ink, polished cel shading, consistent original character design.


## [고급 그림자·모근·소재·선폭 | live2d_full/body]
Anime VTuber BODY ONLY: preserve the existing eye shape and facial identity, tapered eyelash and mouth linework, delicate colored interior contours and clean skin cel-shadows, no baked-in moving hair-cast shadow on the permanent face skin, no duplicated facial linework, no hairstyle/clothing/accessory generation.

## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 회색/살구색/중립 파스텔색 등의 균일한 불투명 색 면을 허용한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 후속 Colab에서 See-through가 파츠를 분리하고 리깅 단계가 사용한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다.
- 목·턱·좌우 어깨·상완·전완·손의 실루엣을 시점마다 정합되게 그린다. 단색 무광 찰흙형 비해부학 BODY를 유지한다. neck_underpaint와 body_joint_overlaps는 **부품이 아니라 목·턱·몸통·어깨의 가림·연결을 설명하는 완성 참고 그림**이다. 정면·좌우 3/4·측면에서 턱 아래 목과 귀 뒤, 목-어깨 접점을 보여준다. 정면 그림을 늘이거나 머리만 좌우 이동해 옆모습으로 속이지 않는다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. See-through 분리 이후 리깅 시 실제 관절·가림·회전 연결을 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [SAFE_GENERATION_STAGE_V3]
성인(20세 이상)의 비성적 애니 VTuber 원화. BODY의 몸통과 팔은 단정한 목둘레와 소매 끝이 보이는 **불투명 무광 청회색(#526B7D) 긴소매 스튜디오 제작복**으로 실제 완전히 가린다. 피부/해부학 묘사 대신 민무늬 마네킹형 실루엣을 유지한다. 얼굴·귀·목·손의 노출 피부는 동일한 FACE_SKIN_BASE로 통일하며, 원화 제작복은 피부색과 구분한다. 이후 마스킹도 착의 경계는 지킨다. 민머리·짧고 둥근 얼굴·큰 주황 홍채·자연스러운 목/어깨 연결·양팔/양손 다섯 손가락을 유지한다. 패션 의상·헤어·액세서리 추가 금지. 2D 원화는 master와 각도/표정 PNG만, 3D는 기존 8방향 참조만 생성하며 PSD/리깅 완성을 주장하지 않는다.
IMAGE_MODEL_SOURCE_PROMPT: "Original high-quality Japanese anime adult VTuber reference illustration, fully clothed in an opaque matte slate-blue long-sleeved crew-neck studio practice suit with clearly visible neck opening and cuffs. Smooth simple stylized torso and arms. Big bald rounded head, cute short wide rounded U jaw, large detailed amber eyes, clean small nose and mouth, unified warm-peach visible skin on face, neck and hands. Natural linked shoulders, complete arms and five-finger hands. Crisp tapered anime line art and clean cel shading; single character on plain light background, no hair, costume designs or jewelry."
이미지 생성기에는 이 긍정적 원화 프롬프트 및 모드별 구도/시점만 전달한다. 14개 MD 전체를 생성 프롬프트에 붙이지 않는다. 안전 정책을 끄거나 우회하지 않는다.
## [/SAFE_GENERATION_STAGE_V3]

## [ART_SOURCE_AND_SEPARATION_V3]
### 3d / body — 자산·모드·담당 단계 잠금
- 자산 경계: BODY: 민머리 두상·얼굴 피부·양눈·입·코·귀·목·어깨·몸통 무광 외피·양팔·양손만. 머리카락·패션 의상·장신구 픽셀 0개(기본 스튜디오 제작복은 BODY 필수). BODY 제작 도중 완성 캐릭터 참고 이미지에 보이는 HAIR·OUTFIT·ACCESSORY를 복제하지 않는다. 민머리 완성 BODY만 납품.
- 명시적 생성 제외: BODY에서 머리카락 전부 제외: 앞머리·옆머리·뒷머리·잔머리·묶음머리·포니테일·헤어 장식·머리핀·리본·귀걸이·안경·목걸이·독립 액세서리·패션 의상·불필요한 주름 생성 금지(기술 제작복의 목둘레·소매는 예외). 민머리 신체 베이스만 만든다. 참조 캐릭터에 머리카락/의상이 보여도 BODY 마스터나 각도·표정 참고 그림에 복사하지 않는다.
- 실물 납품 차단: BODY master 및 정면·3/4·측면·후면 참조에서 머리카락 한 가닥, 헤어핀, 의상 디자인, 독립 장신구가 보이면 CROSS_ASSET_CONTAMINATION: FAIL. 참고 합성본은 별도 previews/로 격리하고 실제 BODY 납품에 섞지 않는다. 실제 눈으로 확인하기 전 PASS 선언 금지; 위반 시 BODY 원화를 수정·재검수.
- 구도 경계: 3D: 전/후/좌/우 및 네 대각, 동일 캐릭터 8방향 참조와 가림 세부. 2D PSD·파츠 PNG 요구 금지.
- 이미지 생성 AI는 실제 8방향 원화 및 가림 참조만 생성. 정면 복사/미러링으로 방향을 위조하지 않는다.
- 3D 메시/UV/텍스처 분해/리깅은 후속 모델링 단계다. 2D 눈·머리카락 RGBA 분리나 PSD2Live를 3D 제작 조건으로 넣지 않는다.
## [/ART_SOURCE_AND_SEPARATION_V3]

## [MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
### 3d / body — 24개 자산별 실제 분리 경로
**3D 다각도 원화와 후속 3D 모델링을 구분한다.** 모드·자산을 서로 바꿔 처리하면 실패다.
- 작업 범위: 3D 캐릭터용 전후좌우/다각도 참고 그림. See-through 2D PSD 분리로 VRM 메시를 만들 수 없다.
- 대상 경계: 실제 3D 메시·UV·본·검증된 VRM은 3D 재구성/Blender 후처리에서만 산출. 원화 AI는 다각도 참조로 제한.
- **See-through V3의 실제 기본 태그 중 이 자산 관련 항목:** 사용하지 않음. 23개 태그 이외의 파츠 명칭을 모델이 직접 출력한다고 간주하지 않는다.
- **실제 후속 세부 분리·검수 대상:** 2D RGBA 분리 대상 없음; 3D 전용 다각도·모델링 검수
- **V3만으로 불가능/불충분:** 2D PSD는 3D 메시·스키닝·텍스처·VRM을 대체할 수 없다.
- **어떤 엔진이 실제 수행:** See-through V3 = 사용 금지 (3D VRM 경로가 아님). 3D 참고도 입력 검사와 3D 전용 모델링 경로만 사용.
- **완성 조건:** 이미지 생성 GPT가 한 장짜리 가짜 파츠 시트를 만들면 실패. See-through 결과 PSD만 생성되거나 레이어 이름/개수만 맞으면 **분리 성공 아님**. 실제 움직일 파츠의 서로 다른 원본 RGB/알파/레이어/가려진 면이 검증돼야 한다. 실패 항목은 해당 파츠만 정밀 분리·인페인팅하여 재검사하고, 전체 원화를 매번 재생성하지 않는다.
- 3D HAIR/OUTFIT처럼 제작 엔진이 없는 경우 또는 독립 2D 자산의 세부 분리가 남아 있으면 `NOT_YET_RIG_READY`로 명시한다. 중간 PSD를 완성된 방송 모델로 제출 금지.
- 경로 규정의 코드 기준: `tools/vts_segmentation_profiles.py`. Live2D/Inochi2D 실행은 `notebooks/VTuber_Finished_AI_ZIP_All_Modes.ipynb`의 모드/자산 선택을 따른다.
## [/MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
## [FACE_BODY_COLOR_LOCK_V5]
얼굴·귀·두피·목·손은 동일한 피부색 FACE_SKIN_BASE로 유지한다. 몸통·어깨·팔은 별도 청회색 불투명 긴소매 스튜디오 제작복으로 덮고 목둘레·소매 경계를 유지한다. 숨은 면은 피부/제작복 각 영역에 맞춰 동일 RGB로 보완한다.
## [/FACE_BODY_COLOR_LOCK_V5]

## [BODY_SAFE_STUDIO_SUIT_V3]
성인(20세 이상)의 비성적 애니 VTuber 원화. BODY의 몸통과 팔은 단정한 목둘레와 소매 끝이 보이는 **불투명 무광 청회색(#526B7D) 긴소매 스튜디오 제작복**으로 실제 완전히 가린다. 피부/해부학 묘사 대신 민무늬 마네킹형 실루엣을 유지한다. 얼굴·귀·목·손의 노출 피부는 동일한 FACE_SKIN_BASE로 통일하며, 원화 제작복은 피부색과 구분한다. 이후 마스킹도 착의 경계는 지킨다. 민머리·짧고 둥근 얼굴·큰 주황 홍채·자연스러운 목/어깨 연결·양팔/양손 다섯 손가락을 유지한다. 패션 의상·헤어·액세서리 추가 금지. 2D 원화는 master와 각도/표정 PNG만, 3D는 기존 8방향 참조만 생성하며 PSD/리깅 완성을 주장하지 않는다.
## [/BODY_SAFE_STUDIO_SUIT_V3]

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 얼굴·눈·피부·무광 몸통·팔·손의 선화·채색·연결·구도, 다른 자산 혼입 여부를 실제 시각 확인. 증거 없으면 ART_QUALITY_UNVERIFIED.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-13 v5 3d/body 적용 최상위 기준]

# 3D 신체만을 위한 고급 참조 원화 품질

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 목둘레와 소매 경계가 있는 불투명 스튜디오 제작복로 덮인 성인 애니풍 신체와 얼굴·양팔/손·다리/발의 8방향 턴어라운드.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


- 유일한 제작 대상: 목둘레와 소매 경계가 있는 불투명 스튜디오 제작복로 덮인 성인 애니풍 신체와 얼굴·양팔/손·다리/발의 8방향 턴어라운드. 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
- **디자인 충실도**: 애니풍으로 짙은 가변 굵기 선화·테이퍼, 실제 물체 재질의 2~3단 셀 명암, 8방향에서 같은 실루엣과 기하를 유지한다. 인체 해부는 신체 ZIP에서만 제작하고, 헤어/의상/액세서리만 ZIP에서는 가이드 참조로만 사용한다.
- 초보 도형 SVG/Pillow/Matplotlib·미러/확대 크롭·주석 라벨만 다른 똑같은 그림은 고품질 8방향 턴어라운드가 아니다.
- 각 방향과 세부도를 실제로 생성하고 최종 이미지의 크기·선·색·무늬 일관성을 확인한다. 오류가 남았으면 최종 ZIP이라고 말하지 않는다.
- 일반 미술적 화풍 참고: https://www.live2d.com/en/learn/sample/ ; VRM 실제 모델 구조는 별도: https://vrm.dev/en/vrm1/humanoid/ .


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
8방향 모두 6H·머리/발 같은 수평선 / 독립 작화한 측면 코·턱·귀·눈·목 / 실제 손발/관절의 자연스러운 높이·깊이 / 같은 얼굴·손 색상/같은 애니풍 피부로 그린 몸통 / 헤어·소품 중복 없음.
선 굵기·얼굴/눈의 셀 셰이딩·단색 몸통 프록시와 같은 캐릭터 정체성이 8방향에서 유지되는지 확인한다. 단순 도형 프록시는 BODY 최종 원화에 허용하지 않으며 정면의 반전 복사·확대 크롭만으로 실제 측면 참조라고 납품하지 않는다.


## [고급 그림자·모근·소재·선폭 | 3d/body]
**[신체 다각도 품질]** 8방향의 큰 실루엣·랜드마크·선화 위계와 셀 명암/피부색의 정합을 보며 사진형 과잉 음영이나 가짜 미러링 측면을 허용하지 않는다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** 3d / body; BODY — 눈·얼굴·귀·입·목·어깨·관절·손, 전신이면 다리와 발. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): views/body_front.png, views/body_front_three_quarter_L.png, views/body_left.png, views/body_back_three_quarter_L.png, views/body_back.png, views/body_back_three_quarter_R.png, views/body_right.png, views/body_front_three_quarter_R.png, views/body_detail_occlusion.png.
- 최소 참고 파일 후보: views/body_front.png, views/body_front_three_quarter_L.png, views/body_left.png, views/body_back_three_quarter_L.png, views/body_back.png, views/body_back_three_quarter_R.png, views/body_right.png, views/body_front_three_quarter_R.png, views/body_detail_occlusion.png.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: HAIR·교체 OUTFIT·ACCESSORY를 BODY 완성 자산에 섞지 않는다. 회색 도형, 실사 인체, 길고 좁은 얼굴, 끊긴 목, 두 입, 손 없는 바스트업은 실패다.
- 3D의 필수 8방향 원화와 가림 세부 1장은 모두 views/ 폴더의 명시된 정확한 파일명으로 납품한다. reference_views/ 안의 비율·표정 보조 가이드는 필수 턴어라운드를 대체하지 않는다..

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스
성인(20세 이상)의 비성적 애니 VTuber 원화. BODY의 몸통과 팔은 단정한 목둘레와 소매 끝이 보이는 **불투명 무광 청회색(#526B7D) 긴소매 스튜디오 제작복**으로 실제 완전히 가린다. 피부/해부학 묘사 대신 민무늬 마네킹형 실루엣을 유지한다. 얼굴·귀·목·손의 노출 피부는 동일한 FACE_SKIN_BASE로 통일하며, 원화 제작복은 피부색과 구분한다. 이후 마스킹도 착의 경계는 지킨다. 민머리·짧고 둥근 얼굴·큰 주황 홍채·자연스러운 목/어깨 연결·양팔/양손 다섯 손가락을 유지한다. 패션 의상·헤어·액세서리 추가 금지. 2D 원화는 master와 각도/표정 PNG만, 3D는 기존 8방향 참조만 생성하며 PSD/리깅 완성을 주장하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/body_front.png, views/body_front_three_quarter_L.png 등 8방향 개별 원화와 views/body_detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 3D 가림·관절 참조는 8방향 시점과 `views/body_detail_occlusion.png`로 표현한다. 2D 전용 neck_underpaint/body_joint_overlaps 파일을 3D 결과로 만들라는 뜻이 아니다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] 8방향의 측면 그림에서 코→입→턱 윤곽, 귀 뒤→목→어깨 접합, 팔꿈치·손목을 실제로 보여 주고 관절 깊이/가림이 앞·뒤 그림과 맞는지 눈으로 대조한다. views/body_detail_occlusion.png는 메쉬나 본이 아니다.
- [좌표/참조] 8방향은 각도별 완성 그림이지 움직이는 3D VRM·본·표정 계층 자체가 아니다.
- [엔진 확인] 현재 자동 3D 제작기는 8방향 원화에서 전 방향 메시를 자동 구축하는 것으로 검증되지 않았다. 정면·후면·좌우 참고 이외 대각 시점의 메시·뼈·가림 반영은 추가 구현/검사가 필요하다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [BROADCAST_HANDS_BODY_COLOR_V1]
### 방송 화면 축소와 확대에서 그림 품질 평가
**범위 우선순위:** 이 지침은 같은 ZIP의 오래된 '가슴 위까지만', '손이 보일 때만 손' 같은 조건보다 우선한다. BODY 원본의 양손 누락은 허용하지 않는다. 작업 자산 소유권·2D/3D 형식 규칙은 유지한다.
### 3D BODY: 실제 8방향 원화에서 두 손과 같은 재질색
- 정면부터 좌·우측면, 등 뒤까지 8방향에 양손의 손바닥·엄지·손가락 끝을 모두 실제 해당 시점으로 그린다. 멀리 있는 손이 몸에 가려지는 시점은 그 사실을 가림으로 표현하되, 정면·측면의 손을 잘라 버리지 않는다. 9번째 가림 상세는 어깨·팔꿈치·손목의 실제 연결을 그린다. 기본 자세는 자연스러운 방송형 팔 자세이며 T포즈 강제 금지.
- 몸통은 기존 무광 불투명 BODY 지정색. 목/손 피부와 몸통의 지정 색이 다르면 그 차이를 유지한다. 임의 회색 덧칠 금지. 3D의 머티리얼 색과 2D의 알파 마스크는 다른 개념이다.
- 8방향은 정면 이미지 반전·압축이 아닌 실제 별개 시점이어야 한다. 손은 실제 시점에 맞는 다섯 손가락 실루엣과 엄지 방향을 갖고, 각 신체 재질이 동일하게 유지된다. 참조 그림만으로 3D 메시와 스키닝 성공은 인증할 수 없다.
## [/BROADCAST_HANDS_BODY_COLOR_V1]

**[COLOR_CONTINUITY_FAIL 실제 검수]** 얼굴·목·몸통 무광 커버·양팔·양손과 숨은 RGB를 합성해 비교한다. FACE_SKIN_BASE 불일치·보라/회색 몸통·손목 색 경계·측면 색 역전 중 하나라도 있으면 해당 파츠/마스터 재생성 전까지 PASS 금지.

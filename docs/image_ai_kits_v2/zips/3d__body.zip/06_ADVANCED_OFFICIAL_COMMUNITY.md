# 3D 신체 전용 공식 기술 경계 및 제작자 실무

00_MASTER_FIRST.md 적용. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 안전한 불투명 중립색 도형 프록시을 착용한 애니풍 신체와 얼굴·양팔/손·다리/발의 4면도.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


## 공식 참고 — 미래 모델 제작과 현재 그림 구분
- 공식 VRM 참고: https://vrm.dev/en/vrm1/humanoid/ 및 https://vrm.dev/en/vrm/vrm_features/ . 신체 원화가 실제 VRM/Humanoid 데이터를 생성하는 것은 아니다.
- 해당 자산 구조 참고: https://vrm.dev/en/vrm1/humanoid/ 와 https://docs.blender.org/manual/en/latest/modeling/meshes/uv/unwrapping/introduction.html . Blender UV/머티리얼/메시는 **후속 3D 편집 단계**이지 이미지 AI에게 요구하지 않는다.
- 두상 1 : 전신 6의 프로젝트 비례에서 실제 정면·후면·좌측·우측을 별도 그린다. 동일한 A/T pose, 얼굴·어깨·골반·팔꿈치·손목·무릎·발목 높이를 맞춘다. 눈·코·입·귀/손발은 신체에 속하므로 필요한 부분만 세부 참고 그림으로 만든다. 불투명 의복/마스킹으로 중요 부위를 가리고 노출 버전을 그리지 않는다.
- 같은 캐릭터/같은 물건을 네 방향에서 새로 그리는 것이 목표이며, 실제 원본에 없는 부품을 강제로 만들지 않는다.

## 비공식 실무
- 정면/후면/좌우 그림의 기준 수평선과 상대 배율을 고정하고, 깊이·솔기·뒷면·부착 위치를 서로 비교한다.
- 커뮤니티 3D 참고 시트 사례: https://virmii.com/blog/tutorial/how-to-make-vtuber-reference-sheet . 사용자 요청 자산 한 종류 이외의 것을 시트에 추가하지 않는다.
- 도구로 이미지 배열·크기 맞춤은 가능하지만 SVG/Pillow 기초 도형을 고퀄리티 원화로 가장하지 않는다. 외부 자료를 실제 열지 못했으면 봤다고 주장하지 않는다.
- Blender SpringBone/VRM 본/물리 상태는 그린 이미지의 검증으로 증명할 수 없다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
**공식 VRM:** https://vrm.dev/en/vrm1/humanoid/ — Humanoid는 3D 뼈대/모델링 단계. https://vrm.dev/en/vrm/how_to_make_vrm/convert_from_humanoid_model/ — 실제 FBX/VRM/재질 준비가 요구된다. **CLIP STUDIO TIPS 개인 아티스트:** https://tips.clip-studio.com/en-us/articles/7379 — 얼굴의 각도/비율 참고. **이 자산 전용 실무:** 신체 **전후좌우를 독립 작화**한다. 정수리~턱 H에 전체 높이 6H인 프로젝트 신체 디자인을 네 시점에서 일치시킨다. 기준선(정수리·턱·어깨·팔꿈치·손목·골반·무릎·발목·발바닥)을 정면/후면/좌우에 수평으로 대응시킨다. 측면 눈의 폭·코와 턱 돌출·귀/뒷목 위치·손/발 형상은 정면과 다르게 그려야 한다. 불투명 중립색 도형 프록시과 신체만, 교체 헤어·패션 의상·장식 신규 생성 금지.
VRM 문서는 시트 4장만으로 네이티브 3D 출력이 생성된다고 주장하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/body]
[개인 작가 측면 원화] https://tips.clip-studio.com/en-us/articles/8014 , https://tips.clip-studio.com/ko-kr/articles/11807 — 정면/측면의 눈·코·턱·귀 위치와 애니풍 변형. [Live2D 공식은 2D용 참고일 뿐] https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 2D에서 목 hidden underpaint가 필요한 이유. **3D 참조 원화에서는 목의 정면·측면·후면 실루엣을 직접 그려야 하며 2D 목 레이어를 산출할 필요가 없다.**
3D는 정면·후면·좌측·우측의 실제 그림, 측면 복붙 금지. https://tips.clip-studio.com/en-us/articles/8014 는 비공식 개인 작가 참고.


## [고급 그림자·모근·소재·선폭 | 3d/body]
**[3D/원화 경계]** https://vrm.dev/en/vrm1/humanoid/ 의 Humanoid는 실제 3D 모델 단계다. 정면·후면·좌우의 선화 두께·관절 높이·접촉 그림자 일치는 캐릭터 시트 미술 원칙이며 3D 메시/UV/본을 이미지 AI가 실행할 의무가 아니다.
[3D 참조 자료와 구현 구분] https://vrm.dev/en/vrm1/humanoid/ 는 실제 3D Humanoid 규격이지 4면도 PNG의 자동 모델화가 아니다. 일관된 투시·그림자·재질·실루엣은 원화 제작자의 작업 규칙이며 실제 VRM 메시/UV/본 산출 지시가 아니다.

# 3D 신체 전용 공식 기술 경계 및 제작자 실무

00_MASTER_FIRST.md 적용. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 불투명한 어깨끈 없는 반도형 불투명 단색 외피로 덮인 성인 애니풍 신체와 얼굴·양팔/손·다리/발의 8방향 턴어라운드.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


## 공식 참고 — 미래 모델 제작과 현재 그림 구분
- 공식 VRM 참고: https://vrm.dev/en/vrm1/humanoid/ 및 https://vrm.dev/en/vrm/vrm_features/ . 신체 원화가 실제 VRM/Humanoid 데이터를 생성하는 것은 아니다.
- 해당 자산 구조 참고: https://vrm.dev/en/vrm1/humanoid/ 와 https://docs.blender.org/manual/en/latest/modeling/meshes/uv/unwrapping/introduction.html . Blender UV/머티리얼/메시는 **후속 3D 편집 단계**이지 이미지 AI에게 요구하지 않는다.
- 같은 캐릭터/같은 물건을 8방향에서 새로 그리는 것이 목표이며, 실제 원본에 없는 부품을 강제로 만들지 않는다.

## 비공식 실무
- 정면/후면/좌우 그림의 기준 수평선과 상대 배율을 고정하고, 깊이·솔기·뒷면·부착 위치를 서로 비교한다.
- 커뮤니티 3D 참고 시트 사례: https://virmii.com/blog/tutorial/how-to-make-vtuber-reference-sheet . 사용자 요청 자산 한 종류 이외의 것을 시트에 추가하지 않는다.
- 도구로 이미지 배열·크기 맞춤은 가능하지만 SVG/Pillow 기초 도형을 고퀄리티 원화로 가장하지 않는다. 외부 자료를 실제 열지 못했으면 봤다고 주장하지 않는다.
- Blender SpringBone/VRM 본/물리 상태는 그린 이미지의 검증으로 증명할 수 없다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
**공식 VRM:** https://vrm.dev/en/vrm1/humanoid/ — Humanoid는 3D 뼈대/모델링 단계. https://vrm.dev/en/vrm/how_to_make_vrm/convert_from_humanoid_model/ — 실제 FBX/VRM/재질 준비가 요구된다. **CLIP STUDIO TIPS 개인 아티스트:** https://tips.clip-studio.com/en-us/articles/7379 — 얼굴의 각도/비율 참고. **이 자산 전용 실무:** 신체 **전후좌우를 독립 작화**한다. 정수리~턱 H에 전체 높이 6H인 프로젝트 신체 디자인을 8방향에서 일치시킨다. 기준선(정수리·턱·어깨·팔꿈치·손목·골반·무릎·발목·발바닥)을 정면/후면/좌우에 수평으로 대응시킨다. 측면 눈의 폭·코와 턱 돌출·귀/뒷목 위치·손/발 형상은 정면과 다르게 그려야 한다. 실제 애니풍 피부 표현과 기본 불투명한 어깨끈 없는 반도형 단색 가림 외피만, 교체 헤어·패션 의상·장식 신규 생성 금지.
VRM 문서는 시트 4장만으로 네이티브 3D 출력이 생성된다고 주장하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/body]
[개인 작가 측면 원화] https://tips.clip-studio.com/en-us/articles/8014 , https://tips.clip-studio.com/ko-kr/articles/11807 — 정면/측면의 눈·코·턱·귀 위치와 애니풍 변형. [Live2D 공식은 2D용 참고일 뿐] https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 2D에서 목 hidden underpaint가 필요한 이유. **3D 참조 원화에서는 목의 정면·측면·후면 실루엣을 직접 그려야 하며 2D 목 레이어를 산출할 필요가 없다.**
3D는 정면·후면·좌측·우측의 실제 그림, 측면 복붙 금지. https://tips.clip-studio.com/en-us/articles/8014 는 비공식 개인 작가 참고.


## [고급 그림자·모근·소재·선폭 | 3d/body]
**[3D/원화 경계]** https://vrm.dev/en/vrm1/humanoid/ 의 Humanoid는 실제 3D 모델 단계다. 정면·후면·좌우의 선화 두께·관절 높이·접촉 그림자 일치는 캐릭터 시트 미술 원칙이며 3D 메시/UV/본을 이미지 AI가 실행할 의무가 아니다.
[3D 참조 자료와 구현 구분] https://vrm.dev/en/vrm1/humanoid/ 는 실제 3D Humanoid 규격이지 8방향 턴어라운드 PNG의 자동 모델화가 아니다. 일관된 투시·그림자·재질·실루엣은 원화 제작자의 작업 규칙이며 실제 VRM 메시/UV/본 산출 지시가 아니다.

## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 회색/살구색/중립 파스텔색 등의 균일한 불투명 색 면을 허용한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/body_front.png, views/body_front_three_quarter_L.png 등 8방향 개별 원화와 views/body_detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 3D 가림·관절 참조는 8방향 시점과 `views/body_detail_occlusion.png`로 표현한다. 2D 전용 neck_underpaint/body_joint_overlaps 파일을 3D 결과로 만들라는 뜻이 아니다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

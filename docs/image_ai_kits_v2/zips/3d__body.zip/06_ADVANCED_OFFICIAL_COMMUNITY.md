## [SAFE_GENERATION_STAGE_V3]
성인(20세 이상)의 비성적 애니 VTuber 원화. BODY의 몸통과 팔은 단정한 목둘레와 소매 끝이 보이는 **불투명 무광 청회색(#526B7D) 긴소매 스튜디오 제작복**으로 실제 완전히 가린다. 피부/해부학 묘사 대신 민무늬 마네킹형 실루엣을 유지한다. 얼굴·귀·목·손의 노출 피부는 동일한 FACE_SKIN_BASE로 통일하며, 원화 제작복은 피부색과 구분한다. 이후 마스킹도 착의 경계는 지킨다. 민머리·짧고 둥근 얼굴·큰 주황 홍채·자연스러운 목/어깨 연결·양팔/양손 다섯 손가락을 유지한다. 패션 의상·헤어·액세서리 추가 금지. 2D 원화는 master와 각도/표정 PNG만, 3D는 기존 8방향 참조만 생성하며 PSD/리깅 완성을 주장하지 않는다.
IMAGE_MODEL_SOURCE_PROMPT: "Original high-quality Japanese anime adult VTuber reference illustration, fully clothed in an opaque matte slate-blue long-sleeved crew-neck studio practice suit with clearly visible neck opening and cuffs. Smooth simple stylized torso and arms. Big bald rounded head, cute short wide rounded U jaw, large detailed amber eyes, clean small nose and mouth, unified warm-peach visible skin on face, neck and hands. Natural linked shoulders, complete arms and five-finger hands. Crisp tapered anime line art and clean cel shading; single character on plain light background, no hair, costume designs or jewelry."
이미지 생성기에는 이 긍정적 원화 프롬프트 및 모드별 구도/시점만 전달한다. 14개 MD 전체를 생성 프롬프트에 붙이지 않는다. 안전 정책을 끄거나 우회하지 않는다.
## [/SAFE_GENERATION_STAGE_V3]

## [ART_SOURCE_AND_SEPARATION_V3]
### 3d / body — 자산·모드·담당 단계 잠금
- 자산 경계: BODY: 민머리 두상·얼굴 피부·양눈·입·코·귀·목·어깨·몸통 무광 외피·양팔·양손만. 머리카락·패션 의상·장신구 픽셀 0개(기본 스튜디오 제작복은 BODY 필수). BODY 제작 도중 완성 캐릭터 참고 이미지에 보이는 HAIR·OUTFIT·ACCESSORY를 복제하지 않는다. 민머리 완성 BODY만 납품.
- 명시적 생성 제외: BODY에서 머리카락 전부 제외: 앞머리·옆머리·뒷머리·잔머리·묶음머리·포니테일·헤어 장식·머리핀·리본·귀걸이·안경·목걸이·독립 액세서리·패션 의상·불필요한 주름 생성 금지(기술 제작복의 목둘레·소매는 예외). 민머리 신체 베이스만 만든다. 참조 캐릭터에 머리카락/의상이 보여도 BODY 마스터나 각도·표정 참고 그림에 복사하지 않는다.
- 실물 납품 차단: BODY master 및 정면·3/4·측면·후면 참조에서 머리카락 한 가닥, 헤어핀, 의상 디자인, 독립 장신구가 보이면 CROSS_ASSET_CONTAMINATION: FAIL. 참고 합성본은 별도 previews/로 격리하고 실제 BODY 납품에 섞지 않는다. 실제 눈으로 확인하기 전 PASS 선언 금지; 위반 시 BODY 원화를 수정·재검수.
- 구도 경계: 3D: 전/후/좌/우 및 네 대각, 동일 캐릭터 8방향 참조와 가림 세부. 2D PSD·파츠 PNG 요구 금지.
- 이미지 생성 AI는 실제 8방향 원화 및 가림 참조만 생성. 정면 복사/미러링으로 방향을 위조하지 않는다.
- 3D 메시/UV/텍스처 분해/리깅은 후속 모델링 단계다. 2D 눈·머리카락 RGBA 분리나 PSD2Live를 3D 제작 조건으로 넣지 않는다.
## [/ART_SOURCE_AND_SEPARATION_V3]

## [MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
### 3d / body — 24개 자산별 실제 분리 경로
**3D 다각도 원화와 후속 3D 모델링을 구분한다.** 모드·자산을 서로 바꿔 처리하면 실패다.
- 작업 범위: 3D 캐릭터용 전후좌우/다각도 참고 그림. See-through 2D PSD 분리로 VRM 메시를 만들 수 없다.
- 대상 경계: 실제 3D 메시·UV·본·검증된 VRM은 3D 재구성/Blender 후처리에서만 산출. 원화 AI는 다각도 참조로 제한.
- **See-through V3의 실제 기본 태그 중 이 자산 관련 항목:** 사용하지 않음. 23개 태그 이외의 파츠 명칭을 모델이 직접 출력한다고 간주하지 않는다.
- **실제 후속 세부 분리·검수 대상:** 2D RGBA 분리 대상 없음; 3D 전용 다각도·모델링 검수
- **V3만으로 불가능/불충분:** 2D PSD는 3D 메시·스키닝·텍스처·VRM을 대체할 수 없다.
- **어떤 엔진이 실제 수행:** See-through V3 = 사용 금지 (3D VRM 경로가 아님). 3D 참고도 입력 검사와 3D 전용 모델링 경로만 사용.
- **완성 조건:** 이미지 생성 GPT가 한 장짜리 가짜 파츠 시트를 만들면 실패. See-through 결과 PSD만 생성되거나 레이어 이름/개수만 맞으면 **분리 성공 아님**. 실제 움직일 파츠의 서로 다른 원본 RGB/알파/레이어/가려진 면이 검증돼야 한다. 실패 항목은 해당 파츠만 정밀 분리·인페인팅하여 재검사하고, 전체 원화를 매번 재생성하지 않는다.
- 3D HAIR/OUTFIT처럼 제작 엔진이 없는 경우 또는 독립 2D 자산의 세부 분리가 남아 있으면 `NOT_YET_RIG_READY`로 명시한다. 중간 PSD를 완성된 방송 모델로 제출 금지.
- 경로 규정의 코드 기준: `tools/vts_segmentation_profiles.py`. Live2D/Inochi2D 실행은 `notebooks/VTuber_Finished_AI_ZIP_All_Modes.ipynb`의 모드/자산 선택을 따른다.
## [/MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
## [FACE_BODY_COLOR_LOCK_V5]
얼굴·귀·두피·목·손은 동일한 피부색 FACE_SKIN_BASE로 유지한다. 몸통·어깨·팔은 별도 청회색 불투명 긴소매 스튜디오 제작복으로 덮고 목둘레·소매 경계를 유지한다. 숨은 면은 피부/제작복 각 영역에 맞춰 동일 RGB로 보완한다.
## [/FACE_BODY_COLOR_LOCK_V5]

# 3D 신체 전용 공식 기술 경계 및 제작자 실무

00_MASTER_FIRST.md 적용. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 목둘레와 소매 경계가 있는 불투명 스튜디오 제작복로 덮인 성인 애니풍 신체와 얼굴·양팔/손·다리/발의 8방향 턴어라운드.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


## 공식 참고 — 미래 모델 제작과 현재 그림 구분
- 공식 VRM 참고: https://vrm.dev/en/vrm1/humanoid/ 및 https://vrm.dev/en/vrm/vrm_features/ . 신체 원화가 실제 VRM/Humanoid 데이터를 생성하는 것은 아니다.
- 해당 자산 구조 참고: https://vrm.dev/en/vrm1/humanoid/ 와 https://docs.blender.org/manual/en/latest/modeling/meshes/uv/unwrapping/introduction.html . Blender UV/머티리얼/메시는 **후속 3D 편집 단계**이지 이미지 AI에게 요구하지 않는다.
- 같은 캐릭터/같은 물건을 8방향에서 새로 그리는 것이 목표이며, 실제 원본에 없는 부품을 강제로 만들지 않는다.

## 비공식 실무
- 정면/후면/좌우 그림의 기준 수평선과 상대 배율을 고정하고, 깊이·솔기·뒷면·부착 위치를 서로 비교한다.
- 커뮤니티 3D 참고 시트 사례: https://virmii.com/blog/tutorial/how-to-make-vtuber-reference-sheet . 사용자 요청 자산 한 종류 이외의 것을 시트에 추가하지 않는다.
- 도구로 이미지 배열·크기 맞춤은 가능하지만 SVG/Pillow 기초 도형을 고퀄리티 원화로 가장하지 않는다. 외부 자료를 실제 열지 못했으면 봤다고 주장하지 않는다.
- Blender SpringBone/VRM 본/물리 상태는 그린 이미지의 검증으로 증명할 수 없다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
**공식 VRM:** https://vrm.dev/en/vrm1/humanoid/ — Humanoid는 3D 뼈대/모델링 단계. https://vrm.dev/en/vrm/how_to_make_vrm/convert_from_humanoid_model/ — 실제 FBX/VRM/재질 준비가 요구된다. **CLIP STUDIO TIPS 개인 아티스트:** https://tips.clip-studio.com/en-us/articles/7379 — 얼굴의 각도/비율 참고. **이 자산 전용 실무:** 신체 **전후좌우를 독립 작화**한다. 정수리~턱 H에 전체 높이 6H인 프로젝트 신체 디자인을 8방향에서 일치시킨다. 기준선(정수리·턱·어깨·팔꿈치·손목·골반·무릎·발목·발바닥)을 정면/후면/좌우에 수평으로 대응시킨다. 측면 눈의 폭·코와 턱 돌출·귀/뒷목 위치·손/발 형상은 정면과 다르게 그려야 한다. 실제 애니풍 피부 표현과 기본 불투명한 어깨끈 없는 반도형 단색 가림 외피만, 교체 헤어·패션 의상·장식 신규 생성 금지.
VRM 문서는 시트 4장만으로 네이티브 3D 출력이 생성된다고 주장하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/body]
[개인 작가 측면 원화] https://tips.clip-studio.com/en-us/articles/8014 , https://tips.clip-studio.com/ko-kr/articles/11807 — 정면/측면의 눈·코·턱·귀 위치와 애니풍 변형. [Live2D 공식은 2D용 참고일 뿐] https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 2D에서 목 hidden underpaint가 필요한 이유. **3D 참조 원화에서는 목의 정면·측면·후면 실루엣을 직접 그려야 하며 2D 목 레이어를 산출할 필요가 없다.**
3D는 정면·후면·좌측·우측의 실제 그림, 측면 복붙 금지. https://tips.clip-studio.com/en-us/articles/8014 는 비공식 개인 작가 참고.


## [고급 그림자·모근·소재·선폭 | 3d/body]
**[3D/원화 경계]** https://vrm.dev/en/vrm1/humanoid/ 의 Humanoid는 실제 3D 모델 단계다. 정면·후면·좌우의 선화 두께·관절 높이·접촉 그림자 일치는 캐릭터 시트 미술 원칙이며 3D 메시/UV/본을 이미지 AI가 실행할 의무가 아니다.
[3D 참조 자료와 구현 구분] https://vrm.dev/en/vrm1/humanoid/ 는 실제 3D Humanoid 규격이지 8방향 턴어라운드 PNG의 자동 모델화가 아니다. 일관된 투시·그림자·재질·실루엣은 원화 제작자의 작업 규칙이며 실제 VRM 메시/UV/본 산출 지시가 아니다.

## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스
성인(20세 이상)의 비성적 애니 VTuber 원화. BODY의 몸통과 팔은 단정한 목둘레와 소매 끝이 보이는 **불투명 무광 청회색(#526B7D) 긴소매 스튜디오 제작복**으로 실제 완전히 가린다. 피부/해부학 묘사 대신 민무늬 마네킹형 실루엣을 유지한다. 얼굴·귀·목·손의 노출 피부는 동일한 FACE_SKIN_BASE로 통일하며, 원화 제작복은 피부색과 구분한다. 이후 마스킹도 착의 경계는 지킨다. 민머리·짧고 둥근 얼굴·큰 주황 홍채·자연스러운 목/어깨 연결·양팔/양손 다섯 손가락을 유지한다. 패션 의상·헤어·액세서리 추가 금지. 2D 원화는 master와 각도/표정 PNG만, 3D는 기존 8방향 참조만 생성하며 PSD/리깅 완성을 주장하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/body_front.png, views/body_front_three_quarter_L.png 등 8방향 개별 원화와 views/body_detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 3D 가림·관절 참조는 8방향 시점과 `views/body_detail_occlusion.png`로 표현한다. 2D 전용 neck_underpaint/body_joint_overlaps 파일을 3D 결과로 만들라는 뜻이 아니다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] 8방향의 측면 그림에서 코→입→턱 윤곽, 귀 뒤→목→어깨 접합, 팔꿈치·손목을 실제로 보여 주고 관절 깊이/가림이 앞·뒤 그림과 맞는지 눈으로 대조한다. views/body_detail_occlusion.png는 메쉬나 본이 아니다.
- [좌표/참조] 8방향은 각도별 완성 그림이지 움직이는 3D VRM·본·표정 계층 자체가 아니다.
- [엔진 확인] 현재 자동 3D 제작기는 8방향 원화에서 전 방향 메시를 자동 구축하는 것으로 검증되지 않았다. 정면·후면·좌우 참고 이외 대각 시점의 메시·뼈·가림 반영은 추가 구현/검사가 필요하다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

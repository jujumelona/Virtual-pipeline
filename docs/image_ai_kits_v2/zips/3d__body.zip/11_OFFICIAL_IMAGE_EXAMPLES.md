## [SAFE_GENERATION_STAGE_V3]
성인(20세 이상)의 비성적 애니 VTuber 원화. BODY의 몸통과 팔은 단정한 목둘레와 소매 끝이 보이는 **불투명 무광 청회색(#526B7D) 긴소매 스튜디오 제작복**으로 실제 완전히 가린다. 피부/해부학 묘사 대신 민무늬 마네킹형 실루엣을 유지한다. 얼굴·귀·목·손의 노출 피부는 동일한 FACE_SKIN_BASE로 통일하며, 원화 제작복은 피부색과 구분한다. 이후 마스킹도 착의 경계는 지킨다. 민머리·짧고 둥근 얼굴·큰 주황 홍채·자연스러운 목/어깨 연결·양팔/양손 다섯 손가락을 유지한다. 패션 의상·헤어·액세서리 추가 금지. 2D 원화는 master와 각도/표정 PNG만, 3D는 기존 8방향 참조만 생성하며 PSD/리깅 완성을 주장하지 않는다.
IMAGE_MODEL_SOURCE_PROMPT: "Original high-quality Japanese anime adult VTuber reference illustration, fully clothed in an opaque matte slate-blue long-sleeved crew-neck studio practice suit with clearly visible neck opening and cuffs. Smooth simple stylized torso and arms. Big bald rounded head, cute short wide rounded U jaw, large detailed amber eyes, clean small nose and mouth, unified warm-peach visible skin on face, neck and hands. Natural linked shoulders, complete arms and five-finger hands. Crisp tapered anime line art and clean cel shading; single character on plain light background, no hair, costume designs or jewelry."
이미지 생성기에는 이 긍정적 원화 프롬프트 및 모드별 구도/시점만 전달한다. 14개 MD 전체를 생성 프롬프트에 붙이지 않는다. 안전 정책을 끄거나 우회하지 않는다.
## [/SAFE_GENERATION_STAGE_V3]

## [ART_SOURCE_AND_SEPARATION_V3]
### 3d / body — 자산·모드·담당 단계 잠금
- 자산 경계: BODY: 민머리 두상·얼굴 피부·양눈·입·코·귀·목·어깨·몸통 무광 외피·양팔·양손만. 머리카락·패션 의상·장신구 픽셀 0개(기본 스튜디오 제작복은 BODY 필수). BODY 제작 도중 완성 캐릭터 참고 이미지에 보이는 HAIR·OUTFIT·ACCESSORY를 복제하지 않는다. 민머리 완성 BODY만 납품.
- 명시적 생성 제외: BODY에서 머리카락 전부 제외: 앞머리·옆머리·뒷머리·잔머리·묶음머리·포니테일·헤어 장식·머리핀·리본·귀걸이·안경·목걸이·독립 액세서리·패션 의상·불필요한 주름 생성 금지(기술 제작복의 목둘레·소매는 예외). 민머리 신체 베이스만 만든다. 참조 캐릭터에 머리카락/의상이 보여도 BODY 마스터나 각도·표정 참고 그림에 복사하지 않는다.
- 실물 납품 차단: BODY master 및 정면·3/4·측면·후면 참조에서 머리카락 한 가닥, 헤어핀, 의상 디자인, 독립 장신구가 보이면 CROSS_ASSET_CONTAMINATION: FAIL. 참고 합성본은 별도 previews/로 격리하고 실제 BODY 납품에 섞지 않는다. 실제 눈으로 확인하기 전 PASS 선언 금지; 위반 시 BODY 원화를 수정·재검수.
- 구도 경계: 3D: 전/후/좌/우 및 네 대각, 동일 캐릭터 8방향 참조와 가림 세부. 2D PSD·파츠 PNG 요구 금지.
- 이미지 생성 AI는 실제 8방향 원화 및 가림 참조만 생성. 정면 복사/미러링으로 방향을 위조하지 않는다.
- 3D 메시/UV/텍스처 분해/리깅은 후속 모델링 단계다. 2D 눈·머리카락 RGBA 분리나 PSD2Live를 3D 제작 조건으로 넣지 않는다.
## [/ART_SOURCE_AND_SEPARATION_V3]

## [MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
### 3d / body — 24개 자산별 실제 분리 경로
**3D 다각도 원화와 후속 3D 모델링을 구분한다.** 모드·자산을 서로 바꿔 처리하면 실패다.
- 작업 범위: 3D 캐릭터용 전후좌우/다각도 참고 그림. See-through 2D PSD 분리로 VRM 메시를 만들 수 없다.
- 대상 경계: 실제 3D 메시·UV·본·검증된 VRM은 3D 재구성/Blender 후처리에서만 산출. 원화 AI는 다각도 참조로 제한.
- **See-through V3의 실제 기본 태그 중 이 자산 관련 항목:** 사용하지 않음. 23개 태그 이외의 파츠 명칭을 모델이 직접 출력한다고 간주하지 않는다.
- **실제 후속 세부 분리·검수 대상:** 2D RGBA 분리 대상 없음; 3D 전용 다각도·모델링 검수
- **V3만으로 불가능/불충분:** 2D PSD는 3D 메시·스키닝·텍스처·VRM을 대체할 수 없다.
- **어떤 엔진이 실제 수행:** See-through V3 = 사용 금지 (3D VRM 경로가 아님). 3D 참고도 입력 검사와 3D 전용 모델링 경로만 사용.
- **완성 조건:** 이미지 생성 GPT가 한 장짜리 가짜 파츠 시트를 만들면 실패. See-through 결과 PSD만 생성되거나 레이어 이름/개수만 맞으면 **분리 성공 아님**. 실제 움직일 파츠의 서로 다른 원본 RGB/알파/레이어/가려진 면이 검증돼야 한다. 실패 항목은 해당 파츠만 정밀 분리·인페인팅하여 재검사하고, 전체 원화를 매번 재생성하지 않는다.
- 3D HAIR/OUTFIT처럼 제작 엔진이 없는 경우 또는 독립 2D 자산의 세부 분리가 남아 있으면 `NOT_YET_RIG_READY`로 명시한다. 중간 PSD를 완성된 방송 모델로 제출 금지.
- 경로 규정의 코드 기준: `tools/vts_segmentation_profiles.py`. Live2D/Inochi2D 실행은 `notebooks/VTuber_Finished_AI_ZIP_All_Modes.ipynb`의 모드/자산 선택을 따른다.
## [/MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
## [FACE_BODY_COLOR_LOCK_V5]
얼굴·귀·두피·목·손은 동일한 피부색 FACE_SKIN_BASE로 유지한다. 몸통·어깨·팔은 별도 청회색 불투명 긴소매 스튜디오 제작복으로 덮고 목둘레·소매 경계를 유지한다. 숨은 면은 피부/제작복 각 영역에 맞춰 동일 RGB로 보완한다.
## [/FACE_BODY_COLOR_LOCK_V5]

# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 3d/body 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지가 **제공된 경우** 실제 이미지를 확인한다. 신규 캐릭터의 경우 사용자 PSD·원화가 없어도 정상이며, 실제 접근 가능한 공개 원화 및 파츠 구조 자료를 참고한다.
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 접근 불가능한 외부 참고 링크는 `unavailable` 상태·원인으로 기록하고 실제 열 수 있는 적절한 다른 공개 그림을 조사해 대체한다. 참고용 외부 PSD 하나를 못 열었다는 이유로 사용자에게 BODY PSD 첨부를 요구하거나 신규 캐릭터 제작을 중단하지 않는다.
   단, 특정 기존 캐릭터·BODY와 동일성을 보존해야 하는데 필수 사용자 참조가 없거나, 실제 시각 참고 이미지를 전혀 볼 수 없다면 사유를 정확하게 보고하고 해당 단계만 보류한다. 허위 열람 완료 금지.
7. 필수 사용자 자료·실제 시각 참고·템플릿 슬롯 검토 및 충돌 해결 후 기준 캐릭터 디자인을 확정한다. 공개 예제 캐릭터의 픽셀·외형을 그대로 복제하지 않는다.
   제공된 실제 템플릿·그림을 관찰한 다음 새 캐릭터의 8방향 턴어라운드와 가림 상세 참조를 제작한다. 3D ZIP에는 PSD·2D 파츠·리깅을 넣지 않는다.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**


## [2026-10-13 v5 3d/body 적용 최상위 기준]
3D 관련 공식 참조: https://vrm.dev/en/vrm/how_to_make_vrm/convert_from_humanoid_model/ ; 애니 스타일 실제 시각 참고 https://www.live2d.com/en/learn/sample/ . 외형 복제 금지.

# 3D 신체 시각 참고 링크 — 다른 자산 생성 근거가 아님

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 목둘레와 소매 경계가 있는 불투명 스튜디오 제작복로 덮인 성인 애니풍 신체와 얼굴·양팔/손·다리/발의 8방향 턴어라운드.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


아래 Live2D 캐릭터 샘플은 **애니풍 선화/셀 명암의 미술적 수준만** 참고한다. 이 ZIP은 신체만 제작하며 샘플 전체 캐릭터를 재생성하지 않는다. 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

공식 시각 샘플: https://www.live2d.com/en/learn/sample/ ; 3D 참고 체계: https://vrm.dev/en/vrm1/humanoid/ ; Blender 참고: https://docs.blender.org/manual/en/latest/modeling/meshes/uv/unwrapping/introduction.html . 외부 그림 자체는 ZIP에 복제하지 않았고 직접 열지 못하면 봤다고 주장하지 않는다.

## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스
성인(20세 이상)의 비성적 애니 VTuber 원화. BODY의 몸통과 팔은 단정한 목둘레와 소매 끝이 보이는 **불투명 무광 청회색(#526B7D) 긴소매 스튜디오 제작복**으로 실제 완전히 가린다. 피부/해부학 묘사 대신 민무늬 마네킹형 실루엣을 유지한다. 얼굴·귀·목·손의 노출 피부는 동일한 FACE_SKIN_BASE로 통일하며, 원화 제작복은 피부색과 구분한다. 이후 마스킹도 착의 경계는 지킨다. 민머리·짧고 둥근 얼굴·큰 주황 홍채·자연스러운 목/어깨 연결·양팔/양손 다섯 손가락을 유지한다. 패션 의상·헤어·액세서리 추가 금지. 2D 원화는 master와 각도/표정 PNG만, 3D는 기존 8방향 참조만 생성하며 PSD/리깅 완성을 주장하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/body_front.png, views/body_front_three_quarter_L.png 등 8방향 개별 원화와 views/body_detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 3D 가림·관절 참조는 8방향 시점과 `views/body_detail_occlusion.png`로 표현한다. 2D 전용 neck_underpaint/body_joint_overlaps 파일을 3D 결과로 만들라는 뜻이 아니다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] 8방향의 측면 그림에서 코→입→턱 윤곽, 귀 뒤→목→어깨 접합, 팔꿈치·손목을 실제로 보여 주고 관절 깊이/가림이 앞·뒤 그림과 맞는지 눈으로 대조한다. views/body_detail_occlusion.png는 메쉬나 본이 아니다.
- [좌표/참조] 8방향은 각도별 완성 그림이지 움직이는 3D VRM·본·표정 계층 자체가 아니다.
- [엔진 확인] 현재 자동 3D 제작기는 8방향 원화에서 전 방향 메시를 자동 구축하는 것으로 검증되지 않았다. 정면·후면·좌우 참고 이외 대각 시점의 메시·뼈·가림 반영은 추가 구현/검사가 필요하다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

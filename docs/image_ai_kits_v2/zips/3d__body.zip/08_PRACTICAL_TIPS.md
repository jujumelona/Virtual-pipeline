## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 경우 샘플 복제가 아닌 독창적인 신체 원화를 만든다. 회색 도형 프록시로 대체하지 않는다.**
이 ZIP은 **3d / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 기존 자료 형식: Interactive 3D app/preset; not PSD and not automatically present in ZIP
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.
- 2. **VRM per-model reuse and redistribution permissions** — https://vrm.dev/en/vrm/meta/license/
   - 기존 자료 형식: License reference only
   - 실제 활용: Verify source avatar customization and reuse permissions before using downloaded VRM as a 3D template.
   - 권리 확인: Every VRM may have unique modification and redistributability settings.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`, `hip`, `thigh_L`, `thigh_R`, `calf_L`, `calf_R`, `foot_L`, `foot_R`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** full-body four-view turnaround
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 원화가 우선이다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 해당 자산 원화를 참조, 없으면 요청된 신체 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 모드에 맞는 실물 PSD 또는 참조 PNG·검증 기록·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참고 프리셋/공식 실제 그림을 확인한 뒤 새로운 캐릭터 전후좌우 원화를 만든다. 3D 이미지 AI 지시 ZIP은 PSD나 VRM 내보내기를 약속하지 않고 턴어라운드 참조 PNG와 시각 검증을 납품한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# 3D 신체 전문 다각도 제작 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 불투명 스포츠 수영복을 착용한 성인 애니풍 신체와 얼굴·양팔/손·다리/발의 8방향 턴어라운드.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


## 비공식 3D 레퍼런스 작화 노하우
1. 두상 1 : 전신 6의 프로젝트 비례에서 실제 정면·후면·좌측·우측을 별도 그린다. 동일한 A/T pose, 얼굴·어깨·골반·팔꿈치·손목·무릎·발목 높이를 맞춘다. 눈·코·입·귀/손발은 신체에 속하므로 필요한 부분만 세부 참고 그림으로 만든다. 불투명 의복/마스킹으로 중요 부위를 가리고 노출 버전을 그리지 않는다.
2. 8방향 시점의 머리 높이 6등신·골격 위치·눈매·귀·코·입·양손·발·비대칭 피부 명암이 일치하는가? 불투명 가림이 있는가?
3. 정면 기준 높이·원점·중심축·좌우 비대칭과 빛 방향을 고정하고 후면/좌우 시점마다 깊이와 실제 가려진 면을 새로 그린다.
4. 신체 원화를 직접 제작하고, 첨부된 사용자 참고 이미지는 디자인·비율 비교에만 사용한다. 헤어·옷·장식 원화는 추가로 만들지 않는다.
5. 큰 실루엣/색/무늬·접합의 방향별 정합을 먼저 확인한 뒤 얇은 선화·셀 명암·해당 신체의 눈매·관절·손발 위치와 실제 다른 시점의 체형을 검수한다..
6. 끝에서 하나의 turnaround_sheet.png로 비교하되 별도의 네 그림을 실제 파일로 보관한다.

## 비공식 참고
https://virmii.com/blog/tutorial/how-to-make-vtuber-reference-sheet (일반적인 시트 제작 경험), https://www.reddit.com/r/Live2D/comments/12nhr9v/ (좌우 명칭 팁만, 3D 공식 규격 아님).


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
큰 애니풍 홍채/선명한 윗속눈썹/작은 코·입·귀/2~3톤 셀 채색으로 캐릭터 정체성을 유지한다. 머리카락 볼륨과 액세서리는 H 측정에 넣지 않는다. 정면 그림을 반전하거나 찌그러뜨려 좌우 측면을 가장하지 않는다. 정면/측면에서 얼굴의 원근과 뒤통수/턱·목이 실제 다르도록 그린다. 손가락·손바닥·발·관절은 실제 필요한 별도 상세도에서 설명하고 신체를 선 막대 도형으로 대체하지 않는다. 그림만으로 VRM Humanoid/메시가 구현됐다고 주장하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/body]
[실제 옆목 턴어라운드] 정면의 턱 아래 목 두께·쇄골 시작점, 측면의 턱 뒤 앞목 시작점·귀 뒤 뒷목 시작점, 후면의 목→승모근/어깨 접합선을 서로 일치시킨다. 정면 그림의 목만 가로로 눌러 측면이라 하지 않는다. 앞쪽 눈은 코 뒤 안와에 놓이고 3/4 먼 눈은 더 좁아진다. 눈·코·턱/귀가 **같은 캐릭터의 다른 방향**이라는 것을 기준선으로 확인한다. 8방향 시점 실제 원화일 뿐 메시·스킨·VRM을 구현했다고 주장하지 않는다.


## [고급 그림자·모근·소재·선폭 | 3d/body]
**[다각도 작화]** 한 원화의 전후좌우 기준선을 잡고 움직이지 않는 고정 몸체 형태를 각각 다른 각도에서 새로 그린다. 얼굴 외곽/턱과 관절 깊은 겹침은 읽히는 선폭, 피부 안쪽은 섬세한 색선으로 정리한다. 조명·명암·눈/손 세부 크기를 시점별 일관성 있게 맞추고 이미지 외부 레이어/클리핑/인체 메시를 만들어 냈다고 주장하지 않는다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** 3d / body; BODY — 눈·얼굴·귀·입·목·어깨·관절·손, 전신이면 다리와 발. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 3D용 원화 참고: 앞·좌우 3/4·좌우 옆·좌우 뒤 3/4·후면(최소 8개 방향)의 동일 자산 턴어라운드. 2D PSD 파츠가 아닌 형태·재질·뒷면·앵커 참고 그림.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): views/body_front.png, views/body_front_three_quarter_L.png, views/body_left.png, views/body_back_three_quarter_L.png, views/body_back.png, views/body_back_three_quarter_R.png, views/body_right.png, views/body_front_three_quarter_R.png, views/body_detail_occlusion.png.
- 최소 참고 파일 후보: views/body_front.png, views/body_front_three_quarter_L.png, views/body_left.png, views/body_back_three_quarter_L.png, views/body_back.png, views/body_back_three_quarter_R.png, views/body_right.png, views/body_front_three_quarter_R.png, views/body_detail_occlusion.png.
- 위 PNG 목록은 **납품 필수**이고 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 두상·눈·코·입·귀·목·어깨·팔·손과 전신인 경우 다리·발을 모든 시점에서 일관된 3D 형태·실루엣·구조로 그린다. 눈 뒤·턱 밑·목 뒤·관절 뒤의 보이지 않는 면을 실제 측면/후면 참고로 그린다. 2D 레이어별 눈 흰자/속눈썹 PNG 분리나 PSD 리깅용 파츠는 만들지 않는다.
- Colab 입력 파츠·경로 계약: 3D ZIP은 2D용 개별 PNG 파츠 명세나 2D 전용 레이어 순서표를 요구하지 않는다. views/ 폴더에 명시한 9개 필수 실제 PNG를 저장한다.
- 자산 소유권 금지: HAIR·교체 OUTFIT·ACCESSORY를 BODY 완성 자산에 섞지 않는다. 회색 도형, 실사 인체, 길고 좁은 얼굴, 끊긴 목, 두 입, 손 없는 바스트업은 실패다.
- 3D ZIP의 실제 납품은 동일 캐릭터/자산의 다각도 PNG 턴어라운드, 실루엣·재질·부착 앵커 참조, 상세 클로즈업 및 검수표다. PSD 층, 2D 눈 리깅 파츠, VRM 바이너리, Blender 실행 결과를 요구하거나 성공했다고 주장하지 않는다.
- 기존 MD에서 reference_views/를 '필요한 경우만' 또는 선택 사항으로 표현했더라도 위 지정 시점 파일은 최종 ZIP에서 필수다. 파일명 대소문자/확장자/경로를 변경하지 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

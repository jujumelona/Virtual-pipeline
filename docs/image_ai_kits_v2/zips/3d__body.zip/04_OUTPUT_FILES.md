# 3D / 신체만 결과 그림 ZIP

`3d__body__ARTWORK.zip`
```text
3d__body__ARTWORK.zip
  views/body_front.png
  views/body_back.png
  views/body_left.png
  views/body_right.png
  details/face_front.png
  details/face_three_quarter_L.png
  details/face_three_quarter_R.png
  details/eyes_L_R.png
  details/nose.png
  details/mouth_open_closed.png
  details/hands_front_back.png
  details/feet.png
  previews/turnaround_sheet.png
```
현재 자산에 실제 있는 세부 구조만 생성하며 다른 자산 세트를 자동으로 만들지 않는다. **눈·코·입·손 또는 옷/헤어/액세서리 세부 그림은 실제 별도 원화로 생성**한다. 네 방향은 각각 실제 다른 시점/같은 디자인이고 마지막에 동일 기준선에 배열한다.

**반복 점검: `07_REVIEW_BEFORE_FINAL_ZIP.md` + `09_VISUAL_ART_QUALITY.md`에서 실제 이미지/파일 조건을 충족했을 때만 결과 ZIP을 납품한다.**

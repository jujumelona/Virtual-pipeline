# 3D / 신체만 출력

**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.


> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 기준 원화 먼저 생성 → 2D 원본 분리/3D 참조 확장 → 숨은 부분 보완. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
**`3d__body__ARTWORK.zip`**
```text
views/body_front.png
views/body_back.png
views/body_left.png
views/body_right.png
details/face_front.png
details/face_three_quarter_L.png
details/face_three_quarter_R.png
details/eyes_L_R.png
details/nose.png
details/mouth_open_closed.png
details/hands_front_back.png
details/feet.png
previews/turnaround_sheet.png
```
정면 기준 원화에서 출발해 동일한 캐릭터/지정 자산의 다른 각도를 일관되게 생성한다. 고급 세부 그림은 확정된 정면 기준 원화의 디자인을 참조해 필요한 경우만 추가 제작한다. 07+09+10의 작화·선화·셀셰이딩·정합을 반복 점검하여 최종 결과 ZIP 제공.

**전신 비율 참고 추가:** `reference_views/body_six_heads_guide.png` — 두상 정수리~턱 1, 머리카락을 제외한 키 전체 6, 머리1/상체2/하체3 구성. `reference_views/face_large_anime_eyes.png` — 실사 대비 확실히 큰 눈·큰 홍채의 얼굴 참조. 이 참고 파일들은 4면도의 실제 각도 이미지를 대체하지 않으며 모든 4면도와 동일한 6등신 스타일을 유지한다.

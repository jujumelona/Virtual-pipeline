# 3D / 신체만 — 결과 이미지 ZIP 이름
결과 ZIP: 3d__body__ARTWORK.zip
views/body_front.png
views/body_back.png
views/body_left.png
views/body_right.png
details/face_front.png
details/eyes_L_R.png
details/nose.png
details/mouth_open_closed.png
details/hands_front_back.png
details/feet.png
previews/turnaround_sheet.png
같은 자산의 앞·뒤·좌·우 실제 다른 관찰각도 이미지. 신체/의상에서는 같은 A/T pose와 비율·표현을 유지한다.
details 확대 그림은 같은 캐릭터를 새로 자세히 그린 참조 이미지, 정면을 잘라낸 자투리 이미지는 아님.
3D 도구가 필요로 하는 본·메시/UV/VRM·SpringBone·립싱크 데이터 생성은 요구하지 않는다. 4면도는 이미지 참조일 뿐.
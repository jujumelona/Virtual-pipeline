# 3D / 신체만 이미지 결과 ZIP
파일 이름 예: 3d__body__ARTWORK.zip
views/body_front.png
views/body_back.png
views/body_left.png
views/body_right.png
details/face_front.png
details/face_three_quarter_L.png
details/face_three_quarter_R.png
details/eyes_L_R.png
details/nose.png
details/mouth_open_closed.png
details/hands_front_back.png
details/feet.png
previews/turnaround_sheet.png
각 view 이미지는 실제 서로 다른 각도에서 별도로 그린, 같은 캐릭터/한 물건의 그림이다. 가능한 정투영에 가깝고 신체/의상은 A/T pose를 유지한다.
details/의 눈·코·입·헤어뿌리·옷감·장식 내부 구조는 전신 이미지에서 확대 크롭하지 말고 해당 자산을 자세히 따로 생성한다.
없는 부품을 억지로 만들지 않고 필요한 고급 부분만 추가한다. 결과 ZIP에는 실제 그림 파일과 턴어라운드 미리보기만 요구한다. VRM/3D 파일, 리깅/구동 검증 로그는 요구하지 않는다.
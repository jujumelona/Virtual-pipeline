# 04 — 이미지 생성 AI 원화 납품만

## [MATTE_CLAY_BODY_V1]
불투명 단색 무광 찰흙형 BODY
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/body_front.png, views/body_front_three_quarter_L.png 등 8방향 개별 원화와 views/body_detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 3D 가림·관절 참조는 8방향 시점과 `views/body_detail_occlusion.png`로 표현한다. 2D 전용 neck_underpaint/body_joint_overlaps 파일을 3D 결과로 만들라는 뜻이 아니다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## 납품 검사

완성 PNG를 실제 열어서 동일 캐릭터·색·실루엣·시점별 목·어깨 연결을 확인한다. 파일명과 PNG 바이트를 확인한다. PSD·개별 파츠·마스크는 이 ZIP에서 만들지 않는다.

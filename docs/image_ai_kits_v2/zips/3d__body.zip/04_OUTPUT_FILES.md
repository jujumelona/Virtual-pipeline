# 3D / 신체만 출력

> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 기준 원화 먼저 생성 → 2D 원본 분리/3D 참조 확장 → 숨은 부분 보완. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
**`3d__body__ARTWORK.zip`**
```text
views/body_front.png
views/body_back.png
views/body_left.png
views/body_right.png
details/face_front.png
details/face_three_quarter_L.png
details/face_three_quarter_R.png
details/eyes_L_R.png
details/nose.png
details/mouth_open_closed.png
details/hands_front_back.png
details/feet.png
previews/turnaround_sheet.png
```
네 방향 모두 동일한 애니 캐릭터/지정 자산의 다른 각도 이미지. 고급 세부 그림은 처음부터 독립 생성. 07+09+10의 작화·선화·셀셰이딩·정합을 반복 점검하여 최종 결과 ZIP 제공.

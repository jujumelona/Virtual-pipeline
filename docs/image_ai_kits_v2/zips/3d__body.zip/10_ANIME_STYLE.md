# 3D 신체 고급 애니 스타일 4면도

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 안전한 불투명 기본 의복을 착용한 애니풍 신체와 얼굴·양팔/손·다리/발의 4면도.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


두상 1 : 전신 6의 프로젝트 비례에서 실제 정면·후면·좌측·우측을 별도 그린다. 동일한 A/T pose, 얼굴·어깨·골반·팔꿈치·손목·무릎·발목 높이를 맞춘다. 눈·코·입·귀/손발은 신체에 속하므로 필요한 부분만 세부 참고 그림으로 만든다. 불투명 의복/마스킹으로 중요 부위를 가리고 노출 버전을 그리지 않는다. 검정에 가까운 가변 선폭 테이퍼 윤곽과 소재별 얇은 내부선, 2~3톤 셀 셰이딩을 사용한다. 사용자 지정 화풍이 있다면 우선한다. 없는 얼굴·헤어·의상을 기계적으로 덧붙이지 않는다.

영어 이미지 프롬프트: “Professional anime VTuber body-only reference artwork, actual independently illustrated front, back, left and right orthographic-style views, consistent dimensions and original design, fine tapered ink outlines, expressive material-specific cel shading, accurate depth and silhouettes; show ONLY the requested body, no extra character anatomy or accessory sets.”

VRM/메시/UV/본·리깅 등 3D 네이티브 파일을 그린 것처럼 주장하지 않는다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
Commercial-quality anime VTuber BODY-ONLY 3D MODEL REFERENCE SHEET, four genuinely independently illustrated front back left right orthographic-style views of the SAME six-head tall original character, exact matching height and limb landmarks, expressive large anime eyes, true profile nose chin ears, refined tapered ink and cel shading, opaque modest basewear; NOT a 3D mesh or VRM, no hair/outfit/accessories.
Original Japanese anime character-art design, dark tapered ink strokes, concise cel shading and correct independent viewpoints.

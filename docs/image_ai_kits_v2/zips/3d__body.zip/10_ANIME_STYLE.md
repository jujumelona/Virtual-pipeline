## [2026-10-14 최우선 자산별 제작 규칙: 3d/body]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 신체와 얼굴만. 큰 눈/홍채·둥근 두상·단순한 애니풍 피부. 근육·늑골·배꼽·쇄골 과장 금지. 목 덮는 상의·터틀넥·보디슈트 금지. 최소 면적 무지 가림만 별도 파츠. 팔과 손 포함. 헤어·의상·소품 불포함.
- 구도: 전신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 실제 PSD·3D 템플릿이 없으면 없다고 알린다. URL 및 그림 도식은 원본 템플릿이 아니다.
- 3D는 정·후·좌·우 4면도. 2D 파츠 PSD 요구 없음.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.


## [2026-10-13 v5 3d/body 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D BODY 참조는 사용자가 정한 **6등신 정면/후면/좌/우 일관된 단순 캐릭터 마네킹 형태**이다. 애니 얼굴은 짧고 둥근 U형 하관, 작은 내이선 1~2개 애니 귀, 눈의 요청별 색상, 균형 잡힌 정수리/목을 유지한다. 몸통에 속옷·튜브탑·상의 선·겨드랑이 살접힘·가슴/쇄골 해부학 음영을 추가하지 않는다. 3D는 평면 2D 프록시를 4면 복제하지 말고 실제 각도별 실루엣·입체 축·후면 위치가 서로 맞도록 참조를 **별도 제작**한다. 2D 파츠 추출이나 3D 모델 생성은 요구하지 않는다.

# 3D 신체 고급 애니 스타일 4면도

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 안전한 불투명 중립색 도형 프록시을 착용한 애니풍 신체와 얼굴·양팔/손·다리/발의 4면도.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


두상 1 : 전신 6의 프로젝트 비례에서 실제 정면·후면·좌측·우측을 별도 그린다. 동일한 A/T pose, 얼굴·어깨·골반·팔꿈치·손목·무릎·발목 높이를 맞춘다. 눈·코·입·귀/손발은 신체에 속하므로 필요한 부분만 세부 참고 그림으로 만든다. 불투명 의복/마스킹으로 중요 부위를 가리고 노출 버전을 그리지 않는다. 검정에 가까운 가변 선폭 테이퍼 윤곽과 소재별 얇은 내부선, 2~3톤 셀 셰이딩을 사용한다. 사용자 지정 화풍이 있다면 우선한다. 없는 얼굴·헤어·의상을 기계적으로 덧붙이지 않는다.

영어 이미지 프롬프트: “Professional anime VTuber body-only reference artwork, actual independently illustrated front, back, left and right orthographic-style views, consistent dimensions and original design, fine tapered ink outlines, expressive material-specific cel shading, accurate depth and silhouettes; show ONLY the requested body, no extra character anatomy or accessory sets.”

VRM/메시/UV/본·리깅 등 3D 네이티브 파일을 그린 것처럼 주장하지 않는다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
Commercial-quality anime VTuber BODY-ONLY 3D MODEL REFERENCE SHEET, four genuinely independently illustrated front back left right orthographic-style views of the SAME six-head tall original character, exact matching height and limb landmarks, expressive large anime eyes, true profile nose chin ears, refined tapered ink and cel shading, opaque modest basewear; NOT a 3D mesh or VRM, no hair/outfit/accessories.
Original Japanese anime character-art design, dark tapered ink strokes, concise cel shading and correct independent viewpoints.


## [고급 그림자·모근·소재·선폭 | 3d/body]
ANIME BODY TURNAROUND REFERENCE ONLY: independently illustrated accurate front back left right views, coherent six-head silhouette, readable tapered outline hierarchy and consistent cel-shading; no layered shadow PSD, 3D mesh, VRM, fashion hair or ornament.

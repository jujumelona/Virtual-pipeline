## [BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

### BODY 전용 기본 복장 — 모든 결과 이미지에 적용 (우선 규칙)
- **성인(20세 이상)**의 귀여운 애니풍 VTuber 캐릭터를 작업한다. 짧고 둥근 얼굴, 큰 눈, 6등신 디자인은 유지하되 미성년으로 묘사하지 않는다.
- **정면·3/4·측면·후면·상하 시점, 표정 시트, 최종 마스터, 합성 미리보기 전체에** 불투명한 **비키니형 스포츠 수영복**을 입힌다. 기본 디자인은 **노출을 줄인 운동용 상의 + 하이웨이스트 쇼츠형 하의**이며, 단색 무지 원단에 비침·절개·노출 강조가 없다.
- **단독 신체 원화, 투명 원화 파츠, PSD, 최종 결과 어디에도 복장 없는 신체 이미지를 만들거나 제공하지 않는다.** 수영복 안쪽은 사실적인 피부나 신체 세부가 아닌 단색 비표현적 밑색으로 처리한다. 복장 없이 보이는 숨은 시점·보조 이미지도 제작하지 않는다.
- 2D에서 수영복 상·하의는 BODY 납품의 **기본 안전 가림 파츠**이다. fashion OUTFIT이 아니다. 안전 복장 파츠는 `removable_neutral_modesty_band_upper`, `removable_neutral_modesty_band_lower`처럼 각각 독립 RGBA를 만들되 **완성본에서는 두 파츠가 항상 켜져 있어야 한다**. 상·하의 없이 기본 마스터/미리보기를 만들지 않는다. 기존 단일 `removable_neutral_modesty_band` 이름도 하위 호환으로만 허용한다.
- 3D에서는 동일한 수영복을 **모든 필수 9방향 턴어라운드에** 동일하게 착용시킨다. 3D ZIP은 PSD 분리나 스킨·리깅 실행을 요구하지 않는다.
- 수영복은 눈·얼굴·목·어깨·양팔·양손·관절·발의 위치를 가리지 않는다. 턱 뒤 목, 어깨/팔꿈치/손목 등 회전용 숨은 면과 눈/입 레이어는 충분히 그리되, 수영복 아래의 자세한 신체를 만들 필요는 없다.
- **충돌 해결:** 옛 지침의 '의상 금지', '상의를 그리지 않기', '최소 면적의 밴드만', '맨몸처럼 보이는 베이스'보다 이 기본 수영복 규칙이 우선한다. 헤어·디자인 의상·액세서리는 여전히 다른 ZIP의 소유이고 기본 안전 수영복만 BODY가 소유한다.

## [/BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**3d/body 제작 우선 규칙:** 하위 구형 얼굴/두상 지시와 충돌하면 이 규칙이 우선한다.
- 두상은 크게, 얼굴은 세로가 짧고 가로폭이 충분하게. 부드럽고 짧은 U형 턱·둥근 볼·큰 눈과 홍채를 유지한다. 긴 말상·좁은 얼굴·뾰족한 V턱·긴 목·작은 눈·실사형 비례 불합격. 머리 위쪽만 과도하게 커지는 것도 금지. 전신은 6등신.
- 공통: 상대적으로 큰 머리, 충분히 큰 눈/홍채, 짧고 넓은 얼굴, 부드러운 U형 턱, 작은 코·입. 긴 좁은 얼굴과 V턱 절대 불합격.
- 정면 얼굴 높이/폭 약 1.10~1.30은 권장 출발점이며 절대 화면 크롭 비율이 아니다. 전신 6등신을 유지한다.
- 정면·후면·좌우 4시점에서 머리 크기·얼굴 윤곽의 일치 여부 확인. 기존 3D BODY 재설계 없이 이 ZIP의 대상 자산만 제작한다.
- 불합격 시 재작업: 작아 보이는 두상, 길고 좁은 얼굴, 뾰족한 턱, 작은 눈, 길어 보이는 목, 자산 범위 혼입. 3D에 2D PSD·PNG 파츠 납품을 강제하지 않는다.

## [2026-10-14 최우선 자산별 제작 규칙: 3d/body]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 신체와 얼굴만. 큰 눈/홍채·둥근 두상·단순한 애니풍 피부. 근육·늑골·배꼽·쇄골 과장 금지. 목 회전을 방해하는 패션 의상은 제외하며, 기본 불투명 스포츠 수영복을 안전한 독립 파츠로. 팔과 손 포함. 헤어·의상·소품 불포함.
- 구도: 전신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 실제 PSD·3D 템플릿이 없으면 없다고 알린다. URL 및 그림 도식은 원본 템플릿이 아니다.
- 3D는 정·후·좌·우 4면도. 2D 파츠 PSD 요구 없음.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.


## [2026-10-13 v5 3d/body 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D BODY 참조는 사용자가 정한 **6등신 정면/후면/좌/우 일관된 단순 캐릭터 마네킹 형태**이다. 애니 얼굴은 짧고 둥근 U형 하관, 작은 내이선 1~2개 애니 귀, 눈의 요청별 색상, 균형 잡힌 정수리/목을 유지한다. 몸통에 위 기본 스포츠 수영복 상의·하의를 입히고 해부학적 굴곡은 강조하지 않는다. 3D는 평면 2D 프록시를 4면 복제하지 말고 실제 각도별 실루엣·입체 축·후면 위치가 서로 맞도록 참조를 **별도 제작**한다. 2D 파츠 추출이나 3D 모델 생성은 요구하지 않는다.

# 3D 신체 고급 애니 스타일 4면도

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 안전한 실제 애니풍으로 채색된 매끈한 BODY 피부 베이스을 착용한 애니풍 신체와 얼굴·양팔/손·다리/발의 4면도.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


두상 1 : 전신 6의 프로젝트 비례에서 실제 정면·후면·좌측·우측을 별도 그린다. 동일한 A/T pose, 얼굴·어깨·골반·팔꿈치·손목·무릎·발목 높이를 맞춘다. 눈·코·입·귀/손발은 신체에 속하므로 필요한 부분만 세부 참고 그림으로 만든다. 불투명 의복/마스킹으로 중요 부위를 가리고 노출 버전을 그리지 않는다. 검정에 가까운 가변 선폭 테이퍼 윤곽과 소재별 얇은 내부선, 2~3톤 셀 셰이딩을 사용한다. 사용자 지정 화풍이 있다면 우선한다. 없는 얼굴·헤어·의상을 기계적으로 덧붙이지 않는다.

영어 이미지 프롬프트: “Professional anime VTuber body-only reference artwork, actual independently illustrated front, back, left and right orthographic-style views, consistent dimensions and original design, fine tapered ink outlines, expressive material-specific cel shading, accurate depth and silhouettes; show ONLY the requested body, no extra character anatomy or accessory sets.”

VRM/메시/UV/본·리깅 등 3D 네이티브 파일을 그린 것처럼 주장하지 않는다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
Commercial-quality anime VTuber BODY-ONLY 3D MODEL REFERENCE SHEET, four genuinely independently illustrated front back left right orthographic-style views of the SAME six-head tall original character, exact matching height and limb landmarks, expressive large anime eyes, true profile nose chin ears, refined tapered ink and cel shading, opaque modest basewear; NOT a 3D mesh or VRM, no hair/outfit/accessories.
Original Japanese anime character-art design, dark tapered ink strokes, concise cel shading and correct independent viewpoints.


## [고급 그림자·모근·소재·선폭 | 3d/body]
ANIME BODY TURNAROUND REFERENCE ONLY: independently illustrated accurate front back left right views, coherent six-head silhouette, readable tapered outline hierarchy and consistent cel-shading; no layered shadow PSD, 3D mesh, VRM, fashion hair or ornament.

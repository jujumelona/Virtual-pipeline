## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-13 v5 3d/body 적용 최상위 기준]

# 3D 신체만 — 정면 기준 원화에서 다각도 신체·눈·코·입 참조 확장

## [최우선·강제] 6등신 완전 애니풍 3D VTuber 신체 가이드

**정확히 6등신:** 머리카락/장식을 제외한 정수리~턱 두상 높이 1, 정수리~발바닥 전체 6. 시작 비례 머리1 : 상체2 : 하체3. 정면/후면/좌우 측면에서 머리 크기와 키가 달라지지 않도록 한다. 7~8등신 실사 모델 비율 금지.
**아주 큰 애니 눈·큰 홍채:** 실사 작은 눈 비율·작은 홍채 금지. 선명한 윗속눈썹·하이라이트·눈매를 얼굴의 중심으로 하고, 점/얇은 애니 코와 작은 중립 입, 애니 귀 단순화, 매끈한 셀 셰이딩 신체를 유지한다. 근거 없는 일률적인 눈 폭 퍼센트 제한 금지.
**마네킹 신체:** 갈비뼈·복근·흉근·힘줄·실사 쇄골/피부 질감 금지, 단정한 의상 장착용 버추얼 베이스. 실제 좌/우 측면에서 한쪽 눈 가림/코/귀/턱의 실루엣이 바뀌어야 하며 정면 뒤집기·비틀기는 측면이 아님.
**참고:** https://atam-academy.com/blog/49102/ 및 https://www.live2d.com/en/learn/sample/momose-hiyori/



## 불투명 중립색 BODY 실루엣

BODY 참고도는 매끈하게 채색된 애니풍 신체로 제작한다. 기본 어깨끈 없는 반도형 단색 가림 상·하부만 안전 복장으로 제작하며 다른 디자인 의상은 만들지 않는다.

## 원화 마스터에 일치시키는 고급 참고 이미지

- views/body_front.png, views/body_back.png, views/body_left.png, views/body_right.png: 동일 캐릭터, 같은 높이/체형, A/T pose, 정투영에 가까운 서로 다른 각도의 전신.
- details/face_front.png, details/face_three_quarter_L.png, details/face_three_quarter_R.png: 얼굴 원화와 볼·턱·귀의 볼륨 표현. 새 헤어를 만들지 않음.
- details/eyes_L_R.png: 눈매·흰자·홍채·동공·눈썹 등을 확대해 **전신 캡처를 잘라내지 않고** 상세 그림으로 새로 그린 이미지.
- details/nose.png, details/mouth_open_closed.png, details/ears_L_R.png: 코의 윤곽과 입 개폐·치아·혀가 실제로 필요한 모습의 독립 참조.
- details/hands_front_back.png, details/hands_palm.png, details/feet.png: 손/손가락과 발을 자세히 설명하는 참조 그림.
- previews/turnaround_sheet.png: **실제로 위에서 생성한 정·후·좌·우 그림들을 마지막에 배열**한 8방향 턴어라운드.

서로 다른 각도에 같은 얼굴 비율, 손가락, 같은 애니풍 피부로 그린 몸통, 체형을 유지한다. 완성 정면을 기계적으로 미러링해서 실제 좌우 측면 그림이라고 제출하지 않는다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
신체 **전후좌우를 독립 작화**한다. 정수리~턱 H에 전체 높이 6H인 프로젝트 신체 디자인을 8방향에서 일치시킨다. 기준선(정수리·턱·어깨·팔꿈치·손목·골반·무릎·발목·발바닥)을 정면/후면/좌우에 수평으로 대응시킨다. 측면 눈의 폭·코와 턱 돌출·귀/뒷목 위치·손/발 형상은 정면과 다르게 그려야 한다. 실제 애니풍 피부 표현과 기본 불투명한 어깨끈 없는 반도형 단색 가림 외피만, 교체 헤어·패션 의상·장식 신규 생성 금지.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/body]
[3D 신체 참조도 얼굴 비례] 정수리~턱의 두상 높이 H, 눈높이 얼굴 너비 F(귀 제외), 정면 한눈 너비 E(돌출 속눈썹 제외)를 정의한다. 애니풍 제안 시작값은 E/F=18~22%(중성 16~19%, 귀여운 인상 20~24%), 두 눈 사이/E=0.8~1.0, 보이는 홍채/E=55~70%. 모두 **공식 VRM 스펙이나 업계 통계가 아니라 작화 선택값**. 몸체 전신 6H 설계를 유지하되 실제 8방향 눈 형태를 단순 미러링하지 않는다.


## [고급 그림자·모근·소재·선폭 | 3d/body]

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** 3d / body; BODY — 눈·얼굴·귀·입·목·어깨·관절·손, 전신이면 다리와 발. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): views/body_front.png, views/body_front_three_quarter_L.png, views/body_left.png, views/body_back_three_quarter_L.png, views/body_back.png, views/body_back_three_quarter_R.png, views/body_right.png, views/body_front_three_quarter_R.png, views/body_detail_occlusion.png.
- 최소 참고 파일 후보: views/body_front.png, views/body_front_three_quarter_L.png, views/body_left.png, views/body_back_three_quarter_L.png, views/body_back.png, views/body_back_three_quarter_R.png, views/body_right.png, views/body_front_three_quarter_R.png, views/body_detail_occlusion.png.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: HAIR·교체 OUTFIT·ACCESSORY를 BODY 완성 자산에 섞지 않는다. 회색 도형, 실사 인체, 길고 좁은 얼굴, 끊긴 목, 두 입, 손 없는 바스트업은 실패다.
- 3D의 필수 8방향 원화와 가림 세부 1장은 모두 views/ 폴더의 명시된 정확한 파일명으로 납품한다. reference_views/ 안의 비율·표정 보조 가이드는 필수 턴어라운드를 대체하지 않는다..

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 회색/살구색/중립 파스텔색 등의 균일한 불투명 색 면을 허용한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/body_front.png, views/body_front_three_quarter_L.png 등 8방향 개별 원화와 views/body_detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 3D 가림·관절 참조는 8방향 시점과 `views/body_detail_occlusion.png`로 표현한다. 2D 전용 neck_underpaint/body_joint_overlaps 파일을 3D 결과로 만들라는 뜻이 아니다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] 8방향의 측면 그림에서 코→입→턱 윤곽, 귀 뒤→목→어깨 접합, 팔꿈치·손목을 실제로 보여 주고 관절 깊이/가림이 앞·뒤 그림과 맞는지 눈으로 대조한다. views/body_detail_occlusion.png는 메쉬나 본이 아니다.
- [좌표/참조] 8방향은 각도별 완성 그림이지 움직이는 3D VRM·본·표정 계층 자체가 아니다.
- [엔진 확인] 현재 자동 3D 제작기는 8방향 원화에서 전 방향 메시를 자동 구축하는 것으로 검증되지 않았다. 정면·후면·좌우 참고 이외 대각 시점의 메시·뼈·가림 반영은 추가 구현/검사가 필요하다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

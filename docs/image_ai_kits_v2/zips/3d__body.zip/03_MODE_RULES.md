## [BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

### BODY 전용 기본 복장 — 모든 결과 이미지에 적용 (우선 규칙)
- **성인(20세 이상)**의 귀여운 애니풍 VTuber 캐릭터를 작업한다. 짧고 둥근 얼굴, 큰 눈, 6등신 디자인은 유지하되 미성년으로 묘사하지 않는다.
- **정면·3/4·측면·후면·상하 시점, 표정 시트, 최종 마스터, 합성 미리보기 전체에** 불투명한 **비키니형 스포츠 수영복**을 입힌다. 기본 디자인은 **노출을 줄인 운동용 상의 + 하이웨이스트 쇼츠형 하의**이며, 단색 무지 원단에 비침·절개·노출 강조가 없다.
- **단독 신체 원화, 투명 원화 파츠, PSD, 최종 결과 어디에도 복장 없는 신체 이미지를 만들거나 제공하지 않는다.** 수영복 안쪽은 사실적인 피부나 신체 세부가 아닌 단색 비표현적 밑색으로 처리한다. 복장 없이 보이는 숨은 시점·보조 이미지도 제작하지 않는다.
- 2D 기본 수영복은 BODY 납품의 **안전 가림 파츠**이다. 상의는 `removable_neutral_modesty_band_upper`로 분리하며 실제 하체가 화면에 존재하는 전신/구도에서는 하의를 `removable_neutral_modesty_band_lower`로 분리한다. **최종 마스터·참고 시점에서 화면에 보이는 부위는 항상 착용한 상태**다. 바스트업에서 화면 밖 하체·하의를 그리거나 빈 하의 레이어를 억지로 만들지 않는다. 헤어/교체 디자인 의상은 별도 자산이며 수영복은 BODY에 속한다. 이전 단일 `removable_neutral_modesty_band`는 구형 입력 호환용이다.
- 3D에서는 동일한 불투명 수영복을 **8방향 턴어라운드 및 가림 세부 1장(총 9장)** 모두에 일관되게 착용시킨다. 3D ZIP은 2D PSD 분리나 스킨·리깅 실행을 요구하지 않는다.
- 수영복은 눈·얼굴·목·어깨·양팔·양손·관절·발의 위치를 가리지 않는다. 턱 뒤 목, 어깨/팔꿈치/손목 등 회전용 숨은 면과 눈/입 레이어는 충분히 그리되, 수영복 아래의 자세한 신체를 만들 필요는 없다.
- **충돌 해결:** BODY에서는 위의 불투명 기본 수영복 착용을 항상 유지한다. 다른 디자인 의상·헤어·소품만 각각 OUTFIT·HAIR·ACCESSORY ZIP에서 제작한다.

## [/BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**3d/body 제작 우선 규칙:** 하위 구형 얼굴/두상 지시와 충돌하면 이 규칙이 우선한다.
- 두상은 크게, 얼굴은 세로가 짧고 가로폭이 충분하게. 부드럽고 짧은 U형 턱·둥근 볼·큰 눈과 홍채를 유지한다. 긴 말상·좁은 얼굴·뾰족한 V턱·긴 목·작은 눈·실사형 비례 불합격. 머리 위쪽만 과도하게 커지는 것도 금지. 전신은 6등신.
- 공통: 상대적으로 큰 머리, 충분히 큰 눈/홍채, 짧고 넓은 얼굴, 부드러운 U형 턱, 작은 코·입. 긴 좁은 얼굴과 V턱 절대 불합격.
- 정면 얼굴 높이/폭 약 1.10~1.30은 권장 출발점이며 절대 화면 크롭 비율이 아니다. 전신 6등신을 유지한다.
- 정면·후면·좌우 8방향 시점에서 머리 크기·얼굴 윤곽의 일치 여부 확인. 기존 3D BODY 재설계 없이 이 ZIP의 대상 자산만 제작한다.
- 불합격 시 재작업: 작아 보이는 두상, 길고 좁은 얼굴, 뾰족한 턱, 작은 눈, 길어 보이는 목, 자산 범위 혼입. 3D에 2D PSD·PNG 파츠 납품을 강제하지 않는다.

## [2026-10-14 최우선 자산별 제작 규칙: 3d/body]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 신체와 얼굴만. 큰 눈/홍채·둥근 두상·단순한 애니풍 피부. 근육·늑골·배꼽·쇄골 과장 금지. 목 회전을 방해하는 패션 의상은 제외하며, 기본 불투명 스포츠 수영복을 안전한 독립 파츠로. 팔과 손 포함. 헤어·의상·소품 불포함.
- 구도: 전신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 실제 PSD·3D 템플릿이 없으면 없다고 알린다. URL 및 그림 도식은 원본 템플릿이 아니다.
- 3D는 정·후·좌·우 및 대각 시점을 포함한 8방향 턴어라운드. 2D 파츠 PSD 요구 없음.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 경우 샘플 복제가 아닌 독창적인 신체 원화를 만든다. 회색 도형 프록시로 대체하지 않는다.**
이 ZIP은 **3d / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 기존 자료 형식: Interactive 3D app/preset; not PSD and not automatically present in ZIP
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.
- 2. **VRM per-model reuse and redistribution permissions** — https://vrm.dev/en/vrm/meta/license/
   - 기존 자료 형식: License reference only
   - 실제 활용: Verify source avatar customization and reuse permissions before using downloaded VRM as a 3D template.
   - 권리 확인: Every VRM may have unique modification and redistributability settings.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`, `hip`, `thigh_L`, `thigh_R`, `calf_L`, `calf_R`, `foot_L`, `foot_R`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** full-body four-view turnaround
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 원화가 우선이다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 해당 자산 원화를 참조, 없으면 요청된 신체 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 모드에 맞는 실물 PSD 또는 참조 PNG·검증 기록·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참고 프리셋/공식 실제 그림을 확인한 뒤 새로운 캐릭터 전후좌우 원화를 만든다. 3D 이미지 AI 지시 ZIP은 PSD나 VRM 내보내기를 약속하지 않고 턴어라운드 참조 PNG와 시각 검증을 납품한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 3d/body 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D BODY 참조는 사용자가 정한 **6등신 정면/후면/좌/우 일관된 고품질 애니 캐릭터 실제 원화**이다. 애니 얼굴은 짧고 둥근 U형 하관, 작은 내이선 1~2개 애니 귀, 눈의 요청별 색상, 균형 잡힌 정수리/목을 유지한다. 몸통에 위 기본 스포츠 수영복 상의·하의를 입히고 해부학적 굴곡은 강조하지 않는다. 3D는 평면 2D 프록시를 4면 복제하지 말고 실제 각도별 실루엣·입체 축·후면 위치가 서로 맞도록 참조를 **별도 제작**한다. 2D 파츠 추출이나 3D 모델 생성은 요구하지 않는다.

# 3D 신체만 다각도 그림 제작 — 2D 파츠 리깅과 구분

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 불투명 스포츠 수영복을 착용한 성인 애니풍 신체와 얼굴·양팔/손·다리/발의 8방향 턴어라운드.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


- **views/**: 정면 `views/body_front.png`, 후면 `views/body_back.png`, 좌측 `views/body_left.png`, 우측 `views/body_right.png`의 실제 다른 시점 그림을 제작한다. 구체적 경로가 다를 경우 `04_OUTPUT_FILES.md`의 파일명을 우선한다.
- **고유 대상:** 정면·후면·좌측·우측 및 대각 시점 신체 8방향 턴어라운드, 필요한 얼굴·손·발 세부 참조. 외형에 없는 가닥·후드·리본·안경 등 다른 카테고리는 요구하지 않는다.
- **기준 정합:** 두상 1 : 전신 6의 프로젝트 비례에서 실제 정면·후면·좌측·우측을 별도 그린다. 동일한 A/T pose, 얼굴·어깨·골반·팔꿈치·손목·무릎·발목 높이를 맞춘다. 눈·코·입·귀/손발은 신체에 속하므로 필요한 부분만 세부 참고 그림으로 만든다. 불투명 의복/마스킹으로 중요 부위를 가리고 노출 버전을 그리지 않는다.
- **previews/turnaround_sheet.png**는 실제 8방향 그림을 같은 기준선으로 배열한 비교 결과. 2D 파츠/PSD 파일 대신 3D 자산의 독립적인 8방향 `views/` 이미지와 실제 `turnaround_sheet.png`를 제출한다.
- 결과는 **참조 그림**이지 3D 메시·VRM·UV·본·리깅·모션 파일이 아니다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
**3D 참조도 전용:** 이 ZIP은 모델이나 UV가 아닌 같은 자산의 독립된 정면/후면/좌측/우측 참조 원화를 만든다. 6등신은 신체 ZIP의 디자인 조건이고 헤어/의상/소품에는 같은 몸체 기준선을 정렬하는 데만 사용한다. 실제 3D 모델·Rig·SpringBone·VRM이 완성됐다고 주장하지 않는다. 미러링/크롭·라벨만 바꾼 가짜 측면도 금지.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/body]
3D용은 사용자 요청 자산 하나의 정면·후면·좌우와 네 대각의 8방향 및 가림 세부 1장 원화를 독립 제작한다. 신체 ZIP에서는 프로젝트 6H 전신과 실제 눈·코·턱·목의 8방향 형태를 맞추지만, 헤어·의상·액세서리 ZIP은 이미 주어진 신체의 원점·앵커에만 정렬하고 피부·얼굴·관절 그림을 새로 그리지 않는다. 메시/UV/VRM은 이미지 AI 산출물이 아니다.


## [고급 그림자·모근·소재·선폭 | 3d/body]
그림으로만 전후좌우 독립된 8방향 턴어라운드/세부 참조를 만든다. 2D PNG 레이어·PSD 마스크·Multiply 설정을 요구하지 않고, 재질 하이라이트·선폭·관절 기준선이 같은 물건의 다른 시점에서 일치하는지만 검수한다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** 3d / body; BODY — 눈·얼굴·귀·입·목·어깨·관절·손, 전신이면 다리와 발. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 3D용 원화 참고: 앞·좌우 3/4·좌우 옆·좌우 뒤 3/4·후면(최소 8개 방향)의 동일 자산 턴어라운드. 2D PSD 파츠가 아닌 형태·재질·뒷면·앵커 참고 그림.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): views/body_front.png, views/body_front_three_quarter_L.png, views/body_left.png, views/body_back_three_quarter_L.png, views/body_back.png, views/body_back_three_quarter_R.png, views/body_right.png, views/body_front_three_quarter_R.png, views/body_detail_occlusion.png.
- 최소 참고 파일 후보: views/body_front.png, views/body_front_three_quarter_L.png, views/body_left.png, views/body_back_three_quarter_L.png, views/body_back.png, views/body_back_three_quarter_R.png, views/body_right.png, views/body_front_three_quarter_R.png, views/body_detail_occlusion.png.
- 위 PNG 목록은 **납품 필수**이고 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 두상·눈·코·입·귀·목·어깨·팔·손과 전신인 경우 다리·발을 모든 시점에서 일관된 3D 형태·실루엣·구조로 그린다. 눈 뒤·턱 밑·목 뒤·관절 뒤의 보이지 않는 면을 실제 측면/후면 참고로 그린다. 2D 레이어별 눈 흰자/속눈썹 PNG 분리나 PSD 리깅용 파츠는 만들지 않는다.
- Colab 입력 파츠·경로 계약: 3D ZIP은 2D용 개별 PNG 파츠 명세나 2D 전용 레이어 순서표를 요구하지 않는다. views/ 폴더에 명시한 9개 필수 실제 PNG를 저장한다.
- 자산 소유권 금지: HAIR·교체 OUTFIT·ACCESSORY를 BODY 완성 자산에 섞지 않는다. 회색 도형, 실사 인체, 길고 좁은 얼굴, 끊긴 목, 두 입, 손 없는 바스트업은 실패다.
- 3D ZIP의 실제 납품은 동일 캐릭터/자산의 다각도 PNG 턴어라운드, 실루엣·재질·부착 앵커 참조, 상세 클로즈업 및 검수표다. PSD 층, 2D 눈 리깅 파츠, VRM 바이너리, Blender 실행 결과를 요구하거나 성공했다고 주장하지 않는다.
- 기존 MD에서 reference_views/를 '필요한 경우만' 또는 선택 사항으로 표현했더라도 위 지정 시점 파일은 최종 ZIP에서 필수다. 파일명 대소문자/확장자/경로를 변경하지 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 회색/살구색/중립 파스텔색 등의 균일한 불투명 색 면을 허용한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**3d/body 제작 우선 규칙:** 하위 구형 얼굴/두상 지시와 충돌하면 이 규칙이 우선한다.
- 두상은 크게, 얼굴은 세로가 짧고 가로폭이 충분하게. 부드럽고 짧은 U형 턱·둥근 볼·큰 눈과 홍채를 유지한다. 긴 말상·좁은 얼굴·뾰족한 V턱·긴 목·작은 눈·실사형 비례 불합격. 머리 위쪽만 과도하게 커지는 것도 금지. 전신은 6등신.
- 공통: 상대적으로 큰 머리, 충분히 큰 눈/홍채, 짧고 넓은 얼굴, 부드러운 U형 턱, 작은 코·입. 긴 좁은 얼굴과 V턱 절대 불합격.
- 정면 얼굴 높이/폭 약 1.10~1.30은 권장 출발점이며 절대 화면 크롭 비율이 아니다. 전신 6등신을 유지한다.
- 정면·후면·좌우 8방향 시점에서 머리 크기·얼굴 윤곽의 일치 여부 확인. 기존 3D BODY 재설계 없이 이 ZIP의 대상 자산만 제작한다.

## [2026-10-14 최우선 자산별 제작 규칙: 3d/body]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 구도: 전신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **3d / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.
- 2. **VRM per-model reuse and redistribution permissions** — https://vrm.dev/en/vrm/meta/license/
   - 기존 자료 형식: License reference only
   - 실제 활용: Verify source avatar customization and reuse permissions before using downloaded VRM as a 3D template.
   - 권리 확인: Every VRM may have unique modification and redistributability settings.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`, `hip`, `thigh_L`, `thigh_R`, `calf_L`, `calf_R`, `foot_L`, `foot_R`

- **구도:** full-body four-view turnaround
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 원화가 우선이다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 해당 자산 원화를 참조, 없으면 요청된 신체 완성 원화 생성) → 슬롯 매핑 → 필수 8방향 원화·가림 세부 1장 실제 제작 → 시점 간 디자인 정합·시각 검수 → 3D 참고 PNG·검증 기록·ZIP.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.


## [2026-10-13 v5 3d/body 적용 최상위 기준]


00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: 3d / body
**유일한 생성 대상:** 불투명한 어깨끈 없는 반도형 불투명 단색 외피로 덮인 성인 애니풍 신체와 얼굴·양팔/손·다리/발의 8방향 턴어라운드.
**별도 카테고리 생성 금지:** 별도 헤어스타일·패션 의상·귀걸이/장식 세트는 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


- **views/**: 정면 `views/body_front.png`, 후면 `views/body_back.png`, 좌측 `views/body_left.png`, 우측 `views/body_right.png`의 실제 다른 시점 그림을 제작한다. 구체적 경로가 다를 경우 `04_OUTPUT_FILES.md`의 파일명을 우선한다.
- **고유 대상:** 정면·후면·좌측·우측 및 대각 시점 신체 8방향 턴어라운드, 필요한 얼굴·손·발 세부 참조. 외형에 없는 가닥·후드·리본·안경 등 다른 카테고리는 요구하지 않는다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / body]
**3D 참조도 전용:** 이 ZIP은 모델이나 UV가 아닌 같은 자산의 독립된 정면/후면/좌측/우측 참조 원화를 만든다. 6등신은 신체 ZIP의 디자인 조건이고 헤어/의상/소품에는 같은 몸체 기준선을 정렬하는 데만 사용한다. 실제 3D 모델·Rig·SpringBone·VRM이 완성됐다고 주장하지 않는다. 미러링/크롭·라벨만 바꾼 가짜 측면도 금지.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/body]
3D용은 사용자 요청 자산 하나의 정면·후면·좌우와 네 대각의 8방향 및 가림 세부 1장 원화를 독립 제작한다. 신체 ZIP에서는 프로젝트 6H 전신과 실제 눈·코·턱·목의 8방향 형태를 맞추지만, 헤어·의상·액세서리 ZIP은 이미 주어진 신체의 원점·앵커에만 정렬하고 피부·얼굴·관절 그림을 새로 그리지 않는다. 메시/UV/VRM은 이미지 AI 산출물이 아니다.


## [고급 그림자·모근·소재·선폭 | 3d/body]

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** 3d / body; BODY — 눈·얼굴·귀·입·목·어깨·관절·손, 전신이면 다리와 발. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): views/body_front.png, views/body_front_three_quarter_L.png, views/body_left.png, views/body_back_three_quarter_L.png, views/body_back.png, views/body_back_three_quarter_R.png, views/body_right.png, views/body_front_three_quarter_R.png, views/body_detail_occlusion.png.
- 최소 참고 파일 후보: views/body_front.png, views/body_front_three_quarter_L.png, views/body_left.png, views/body_back_three_quarter_L.png, views/body_back.png, views/body_back_three_quarter_R.png, views/body_right.png, views/body_front_three_quarter_R.png, views/body_detail_occlusion.png.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: HAIR·교체 OUTFIT·ACCESSORY를 BODY 완성 자산에 섞지 않는다. 회색 도형, 실사 인체, 길고 좁은 얼굴, 끊긴 목, 두 입, 손 없는 바스트업은 실패다.
- 3D의 필수 8방향 원화와 가림 세부 1장은 모두 views/ 폴더의 명시된 정확한 파일명으로 납품한다. reference_views/ 안의 비율·표정 보조 가이드는 필수 턴어라운드를 대체하지 않는다..

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 회색/살구색/중립 파스텔색 등의 균일한 불투명 색 면을 허용한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/body_front.png, views/body_front_three_quarter_L.png 등 8방향 개별 원화와 views/body_detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 목·턱·좌우 어깨·상완·전완·손의 실루엣을 시점마다 정합되게 그린다. 단색 무광 찰흙형 비해부학 BODY를 유지한다. neck_underpaint와 body_joint_overlaps는 **부품이 아니라 목·턱·몸통·어깨의 가림·연결을 설명하는 완성 참고 그림**이다. 정면·좌우 3/4·측면에서 턱 아래 목과 귀 뒤, 목-어깨 접점을 보여준다. 정면 그림을 늘이거나 머리만 좌우 이동해 옆모습으로 속이지 않는다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

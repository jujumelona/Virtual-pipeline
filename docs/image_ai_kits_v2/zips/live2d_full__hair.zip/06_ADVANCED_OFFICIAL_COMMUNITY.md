# Live2D 전신 헤어 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 전체 캔버스를 기준으로 요청된 헤어스타일만. 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 공식 근거를 이미지 제작에 적용
- 공식 Live2D 파츠 가공: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . 이미지 AI는 실제 헤어 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.live2d.com/en/cubism-editor-manual/skinning/ . Cubism의 Skinning/Glue/Clipping 등의 기능이 그림 AI가 실제로 ArtMesh나 리깅을 만들었다는 증거는 아니다.
- 큰 머리 실루엣과 정수리 볼륨, 머리카락 뿌리·귀 앞뒤·목 뒤 가림을 넉넉히 보완한다. 개별 흔들림이 필요한 가닥만 분리하고 고정 명암은 합친다. 테이퍼 끝과 아호게 등은 실제 디자인에 있는 것만 적용한다.
- 독립 ArtMesh 수나 그림자/하이라이트 PNG 수를 고정하지 않는다. 고정 문양은 본체에, 실제 다른 움직임·앞뒤 순서가 필요한 요소만 나눈다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 미리보기는 실제 파츠를 조립한 그림으로 만들고 기준 몸체는 좌표 참고용으로만 사용한다.
- 커뮤니티 원화 사례: https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ — 개별 작업자 경험이며 공식 필수 조건이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. 공식 PSD 주의사항: https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ .


## [고급 원화·애니풍 전문 노하우 2026-10-13 / live2d_full / hair]
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ (앞/옆/뒤 헤어와 숨은 면). **개인 작가:** https://tips.clip-studio.com/en-us/articles/5958 , https://tips.clip-studio.com/en-us/articles/6072 (가닥 형태·모근).
구별: 6등신·애니풍 채색은 이 프로젝트 디자인 조건이며 Live2D 공식의 필수 비율·톤 수가 아니다. 편집기 리깅/키폼은 이미지 AI 작업이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_full/hair]
[공식 Live2D 참고] https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 앞머리/옆머리/뒷머리의 파츠 분리, 가려진 뿌리 추가 작화. [개인 작가] https://tips.clip-studio.com/en-us/articles/8014 — 측면 두상 실루엣 참고. 목 피부와 눈의 크기·그리기 비율은 신체 ZIP의 계약이고 헤어의 필수 제작 규격이 아니다.
Live2D/Cubism의 원화 처리 원칙을 참고하되 실제 Cubism 모델·물리·키폼을 이미지 AI에 강제하지 않는다.

# Live2D 전신 헤어 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.


## 공식 근거를 이미지 제작에 적용
- 공식 Live2D 파츠 가공: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . 이미지 AI는 실제 헤어 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.live2d.com/en/cubism-editor-manual/skinning/ . Cubism의 Skinning/Glue/Clipping 등의 기능이 그림 AI가 실제로 ArtMesh나 리깅을 만들었다는 증거는 아니다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 커뮤니티 원화 사례: https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ — 개별 작업자 경험이며 공식 필수 조건이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. 공식 PSD 주의사항: https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ .


## [고급 원화·애니풍 전문 노하우 2026-10-13 / live2d_full / hair]
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ (앞/옆/뒤 헤어와 숨은 면). **개인 작가:** https://tips.clip-studio.com/en-us/articles/5958 , https://tips.clip-studio.com/en-us/articles/6072 (가닥 형태·모근).


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_full/hair]
[공식 Live2D 참고] https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 앞머리/옆머리/뒷머리의 파츠 분리, 가려진 뿌리 추가 작화. [개인 작가] https://tips.clip-studio.com/en-us/articles/8014 — 측면 두상 실루엣 참고. 목 피부와 눈의 크기·그리기 비율은 신체 ZIP의 계약이고 헤어의 필수 제작 규격이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_full/hair]
**[공식과 아티스트 경험 구별]** 공식 Live2D 파츠 분리/숨은 머리뿌리 보완: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . **볼에서 자란 것처럼 보이는 잘못된 옆머리 뿌리, 머리 이동과 따로 노는 앞머리 투사 그림자, 반사광의 흐름·단선 문제**는 실제 작화 품질을 위한 아티스트 검수 항목이지 공식 파츠 개수·그림자 생성 의무가 아니다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 후속 Colab에서 See-through가 파츠를 분리하고 리깅 단계가 사용한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다.
- 모발의 뒷면·모근 및 두상 각도 관계를 참고 원화로 명확하게 그린다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. See-through 분리 이후 리깅 시 실제 관절·가림·회전 연결을 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

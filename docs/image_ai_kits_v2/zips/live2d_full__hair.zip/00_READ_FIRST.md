# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 live2d_full/hair 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지·예시와 참고 이미지를 **모두 실제 비전으로 연다.**
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 자료 접근이 안 되거나 참고 그림이 보이지 않으면 **생성 중단** 후
   확인할 수 없는 항목을 구체적으로 보고하고 원본 이미지 첨부를 요청한다.
   허위 열람 완료나 임의 참고 그림 대체 금지.
7. 모든 자료가 실제 확인되고 충돌이 해결된 뒤에만 완성 원화 한 장 제작.
   그 원화의 품질 확인 후 파츠 분리/PSD 제작/합성·최종 ZIP 검수로 진행한다.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 독창적인 완성 원화를 처음부터 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **live2d_full / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 기존 자료 형식: PSD
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** complete six-head design through feet
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참조 PSD의 존재는 작화 학습에 도움을 주지만 납품 필수 사용자 첨부물이 아니다. 공개 샘플의 실제 픽셀을 재사용하지 않고 원본 캐릭터를 직접 디자인하며, 완성 마스터에서 편집 가능한 PSD를 만든다. 일러스트 생성/PSD 쓰기 도구가 없으면 그 도구의 한계를 보고한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 live2d_full/hair 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
HAIR: 요청한 헤어스타일만; BODY의 얼굴/귀/눈/목/몸통을 재생성하지 않는다. 동일 캔버스·원점·스케일 참조, 모근/뒤통수와 귀 앞뒤 겹침, 실제 필요한 숨은 가닥/후면 underpaint, 왼쪽/오른쪽 파츠와 알파 경계 검수. 머리 장식과 의상은 임의 추가 금지.

# Live2D 전신 헤어만 — 고급 이미지 생성 첫 지시

**ZIP 고유 작업 범위 잠금: live2d_full / hair**
**제작 대상:** 사용자가 지정한 단 하나의 헤어스타일과 앞·옆·뒷머리·실제 있는 가닥.
**범위 밖 금지:** 기준 신체·얼굴·눈·입·옷·별도 액세서리·하체는 제작하지 않는다.

## 제작 순서
1. 기준 캐릭터의 전신 캔버스·원점·선화·색감·정체성을 유지한다. 기준 몸체를 위치 참조로만 사용하고 선택된 헤어 원화 한 장만 먼저 완성한다. 신체 그림은 납품 PNG에 포함하지 않는다.
2. 전신 캔버스의 기준 머리 크기·귀·목 위치만 참조한다. 머리카락 모근·귀 뒤·목 뒤에 가려진 가닥과 셀 명암/테이퍼 끝을 실제 작업한다. 없는 포니테일·트윈테일·헤어핀은 강제하지 않는다.
3. 실제 독립 움직임이나 깊이의 차이가 있는 헤어의 영역만 RGBA PNG로 추출한다. 숨은 부분도 **이 자산만** 후작화하고 다른 종류 픽셀은 혼입하지 않는다. 모든 PNG는 기준 전신 원화의 동일 캔버스·원점·L/R를 유지한다.
4. `isolated_parts/`와 뒤→앞 `layer_order.txt`의 실제 생성 파일 목록을 일치시킨 다음 PNG를 재합성해 미리보기를 만든다. 기준 몸체와의 overlay는 참고 이미지로만 분리한다.
5. `09_VISUAL_ART_QUALITY.md`, `10_ANIME_STYLE.md`, `11_OFFICIAL_IMAGE_EXAMPLES.md`를 적용한다. 애니풍 짙은 가변 외곽선·테이퍼·소재별 2~3단 셀 셰이딩을 적용하되 사용자 지정 스타일을 우선하고 실제 보지 못한 공식 이미지는 봤다고 말하지 않는다.
6. `02_ADVANCED_PARTS.md`와 `07_REVIEW_BEFORE_FINAL_ZIP.md`를 확인하여 부족한 헤어 그림만 수정/재생성하고 다시 시각검수한다. `00_MASTER_FIRST.md`, `00_DELIVERY_AND_RECHECK.md`의 납품 요건에 따라 실제 `live2d_full__hair__ARTWORK.zip`을 최종 제공한다.

**작업 경계:** 이미지 AI는 PNG 원화·합성·ZIP만. PSD·Cubism 리깅/물리/모션·MOC3·VRM을 만들었다고 주장하지 않는다. 그림을 만들지 못하면 허위 완료를 선언하지 않는다.

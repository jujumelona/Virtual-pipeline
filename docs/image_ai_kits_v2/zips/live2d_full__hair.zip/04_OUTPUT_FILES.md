# Live2D 전신 / 헤어만 결과 원화 ZIP
파일명: `live2d_full__hair__ARTWORK.zip`

```text
live2d_full__hair__ARTWORK.zip
  isolated_parts/hair_back_base.png
  isolated_parts/hair_front_center.png
  isolated_parts/hair_side_L.png
  isolated_parts/hair_side_R.png
  layer_order.txt
  previews/overlay_preview.png
```

이름은 **필요한 파츠명 예시**다. 존재하지 않는 항목의 숫자를 채우지 않는다. 실제 필요한 고급 파츠는 처음부터 새 그림으로 만든다. 각 파츠는 해당 부분만 그린 독립 **RGBA 투명 이미지**, 동일 캔버스·원점과 정확한 위치를 사용한다. 실제 PNG들을 최종 합성하고 `layer_order.txt`에 뒤→앞 순서를 기록한다.


**정식 납품 전 `07_REVIEW_BEFORE_FINAL_ZIP.md`와 `09_VISUAL_ART_QUALITY.md`를 함께 확인하여 작화 품질을 포함한 적용 가능한 요구를 충족한다.**

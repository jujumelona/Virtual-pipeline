# Live2D 전신 / 헤어만 결과 그림 ZIP

**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.


> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 해당 2D 자산의 완성 기준 원화 먼저 제작 → 실제 RGBA 파츠만 분리 → 해당 자산의 숨은 면 추가 작화. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
**`live2d_full__hair__ARTWORK.zip`**
```text
isolated_parts/hair_back_base.png
isolated_parts/hair_front_center.png
isolated_parts/hair_side_L.png
isolated_parts/hair_side_R.png
layer_order.txt
previews/overlay_preview.png
```
파일명은 디자인에 실제 있는 부위의 기본 예시. 02에 따라 추가 독립 움직임/깊이 있는 파츠만 원화에서 분리.  모든 PNG는 실제 투명 RGBA·같은 캔버스·원점. `layer_order.txt` 뒤→앞. 실제 파츠를 마지막에 합성.

**07+09+10+11에 따라 실제 애니풍 원화 수준/PNG 요건을 충족할 때만 최종 결과 ZIP을 납품.**


## ZIP 고유 작업 범위 잠금: live2d_full / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 전체 캔버스를 기준으로 요청된 헤어스타일만. 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 

04의 파일명 중 실제 디자인에 존재하는 hair 파츠만 만든다. 다른 ZIP의 자산은 isolated_parts/에 섞지 않는다.

# Live2D 전신 헤어 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 전체 캔버스를 기준으로 요청된 헤어스타일만. 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


볼륨 있는 애니 헤어 덩어리, 뿌리에서 끝까지 자연스러운 흐름, 테이퍼 끝·재질별 하이라이트·2~3톤 셀 채색. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber hair-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested hair asset on the reference canvas, no unrelated character parts or props.”

특정 캐릭터의 디자인 복제 금지. 실제 2D 그림까지만, PSD/Cubism 키폼은 사용자가 나중에 처리한다.


## [고급 원화·애니풍 전문 노하우 2026-10-13 / live2d_full / hair]
Professional anime VTuber FULL CANVAS HAIR ONLY, one requested hairstyle matched to six-head reference body, dimensional crown volume, directional roots front side and back tufts, elegant tapered locks and natural hair cel highlights, transparent hair parts without adding face body outfit or accessories.
Crisp tapered outlines, subtle colored inner ink, polished cel shading, consistent original character design.


## [고급 그림자·모근·소재·선폭 | live2d_full/hair]
Anime VTuber HAIR ONLY: authentic scalp-rooted silhouette, layered front side and back tufts, tapered fine ink at the strand tips, depth-aware cel shadows and flowing highlights; only if needed provide a hair-owned cast-shadow layer instead of baking hair shadows into face skin, never add eyes, ears, outfit or ornamental hairpins.

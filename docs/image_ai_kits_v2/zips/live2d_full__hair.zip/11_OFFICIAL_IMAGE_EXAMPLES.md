# 참고 이미지 자료

Live2D 공식 예제 https://www.live2d.com/en/learn/sample/haru-receptionist/ 와 원화 안내 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 선화·구도·연결을 참고하고 기존 캐릭터를 복제하지 않는다.

예제 캐릭터의 디자인 자체를 베끼지 않는다. Live2D 전신에서 필요한 HAIR 헤어 원화만 제작한다. 출력 경로는 04_OUTPUT_FILES.md의 실제 PNG 목록과 일치해야 한다.

## ASSET_ONLY_V1
FACE·OUTFIT을 복제하지 않고 선택한 자산만 그린다.


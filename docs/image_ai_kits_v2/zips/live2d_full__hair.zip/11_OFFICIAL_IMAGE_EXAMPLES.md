
## [2026-10-13 v5 live2d_full/hair 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
HAIR: 요청한 헤어스타일만; BODY의 얼굴/귀/눈/목/몸통을 재생성하지 않는다. 동일 캔버스·원점·스케일 참조, 모근/뒤통수와 귀 앞뒤 겹침, 실제 필요한 숨은 가닥/후면 underpaint, 왼쪽/오른쪽 파츠와 알파 경계 검수. 머리 장식과 의상은 임의 추가 금지.
이미지 참고: https://www.live2d.com/en/learn/sample/ . 직접 이미지 열람 불가능하면 합격/생성 시작 금지.

# Live2D 전신 헤어에만 적용하는 공식 원화 시각 사례

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 전체 캔버스를 기준으로 요청된 헤어스타일만. 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


- 아래 Live2D 공식 캐릭터 샘플은 **화풍·선화·명암·완성도만 참고**한다. 샘플 전체 캐릭터를 다시 그리거나 hair 이외의 신체·헤어·의상을 제작하라는 뜻이 아니다.
- 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥. 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
- 공식 예시 이미지는 ZIP에 동봉하지 않았다. 열람 불가면 보았다고 주장하지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

공식 작품 갤러리: https://www.live2d.com/en/learn/sample/ ; 파츠 가공: https://docs.live2d.com/en/cubism-editor-tutorials/psd/. 샘플 외형은 복제하지 않는다.

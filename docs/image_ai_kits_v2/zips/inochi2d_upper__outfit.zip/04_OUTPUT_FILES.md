# Inochi2D 상반신 / 의상만 결과물 파일 이름
결과 ZIP: inochi2d_upper__outfit__ARTWORK.zip
isolated_parts/outfit_front.png
isolated_parts/outfit_back.png
isolated_parts/sleeve_L_upper.png
isolated_parts/sleeve_R_upper.png
layer_order.txt
previews/overlay_preview.png
개별 PNG는 실제 독립 RGBA 원화, 같은 기준 캔버스·원점. layer_order.txt에는 실제 그림 파츠 뒤→앞 목록만 기입. 시트에 함께 생성해도 최종은 분리 PNG.
고급 분리 파일명을 더 추가할 때는 02_ADVANCED_PARTS를 따른다. 스케치/참고가 필요해도 완성 그림을 자동으로 뜯어내지 않는다. 결과 합성 미리보기는 마지막에 만든다.
Inochi 리깅/PSD 제작/구동 검증/인증서는 이미지 AI 결과에 포함시키지 않는다.
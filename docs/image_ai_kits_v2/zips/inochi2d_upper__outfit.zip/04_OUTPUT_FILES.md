# Inochi2D 상반신 / 의상만 이미지 납품 구조
결과 ZIP: inochi2d_upper__outfit__ARTWORK.zip
isolated_parts/outfit_front.png
isolated_parts/outfit_back.png
isolated_parts/sleeve_L_upper.png
isolated_parts/sleeve_R_upper.png
layer_order.txt
previews/overlay_preview.png
명칭은 실제 있는 구성만 사용하며 02의 고급 파츠 필요 시 추가한다. 액세서리 자리 이름 HEADPIECE는 요청 제품 이름으로 바꾼다.
각 PNG는 동일 캔버스/원점의 실제 투명 RGBA, 각 움직임 부위만 포함. 시트는 생성 호출에 활용 가능하나 최종 별도 PNG 필수.
뒤→앞 목록만 쓰고 Inochi 엔진의 노드 sorting 숫자를 이미지 AI가 예측해 작성하게 하지 않는다. 합성은 완성된 파츠를 마지막에 사용한다.
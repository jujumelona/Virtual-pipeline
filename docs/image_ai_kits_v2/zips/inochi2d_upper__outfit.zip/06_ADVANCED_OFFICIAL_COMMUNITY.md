# Inochi2D 상반신 의상 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 보이는 상체 앞·뒷판·카라·양소매·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식·별도 하체 원화를 생성하지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기존 신체 원화의 목·어깨·팔 위치 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 공식 근거를 이미지 제작에 적용
- 공식 Inochi2D Creator 파츠 원화/PSD: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . 이미지 AI는 실제 의상 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.inochi2d.com/en/latest/creator/nodes/node.html . Inochi Creator의 노드·파츠 계층과 메시 조절은 후속 모델링 단계이다. 이미지 AI가 Inochi 네이티브 리깅을 완료했다는 뜻이 아니다.
- 옷깃 안쪽, 어깨와 소매 아래 안감·겹침 여유를 추가 작화한다. 좌우 소매, 흔들릴 리본·옷자락만 필요한 만큼 분리한다. 사용자가 요청하지 않은 넥타이·리본·장신구나 전신 바지·치마·신발을 강제하지 않는다.
- 독립 원화 파츠 수나 그림자/하이라이트 PNG 수를 고정하지 않는다. 고정 문양은 본체에, 실제 다른 움직임·앞뒤 순서가 필요한 요소만 나눈다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 미리보기는 실제 파츠를 조립한 그림으로 만들고 기준 몸체는 좌표 참고용으로만 사용한다.
- 개별 아티스트의 작업 경험은 Inochi2D의 고정 파츠 수나 Cubism 작업 절차를 요구하는 공식 규격이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. Inochi Creator PSD/Nodes 사용법: https://docs.inochi2d.com/en/latest/creator/nodes/node.html .


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / outfit]
**Inochi2D 공식:** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — PSD 가져오기 예시와 중복 그림자 합성 주의. https://docs.inochi2d.com/en/latest/creator/nodes/node.html — Node 자식 Transform/Sorting은 후속 Creator 작업. **의상 작가 실무:** 옷깃·소매·솔기·천의 두께·장력점에서 시작되는 실제 주름과 문양의 연속성. 이 팁의 고정 수치를 기술 규격이라 주장하지 않는다.
**해당 자산:** 사용자가 요청한 의상 한 벌의 실제 몸판·카라·좌우 소매·옷깃 안쪽·앞뒤 천/안감을 필요한 움직임 단위로 추출한다. 전신일 때만 디자인에 실제 있는 치마·바지·신발을 포함한다. 니트·천·가죽 등 사용자 선택 재질의 주름·두께와 고정 문양을 한 스타일로 그린다. 몸 피부·눈·헤어·독립 액세서리를 옷 텍스처에 넣지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_upper/outfit]
[Inochi2D 공식 PSD 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — 의상 파츠의 투명 합성·겹침을 위한 참고. [작가 실무] 목 회전이 가능한 신체 참조를 기준으로 카라 안쪽·뒤옷깃·어깨 아래의 숨은 옷감을 실제 해당 의상에만 추가 작화한다. 신체 목 피부는 의상 ZIP에서 그리지 않는다.
공식 Inochi Creator PSD 가져오기에서는 그림자 레이어가 중복 합성될 수 있음: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . Node 정렬·블렌드·리깅은 후속 Creator 사용자 작업이다.


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/outfit]
**[Inochi2D 공식과 아티스트 작업 구분]** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html 은 가져온 PSD의 그림자 중첩을 설명하는 후속 참고다. 봉제선·장력점의 천 주름, 무늬/망사 연속성, 실제 반투명 소매의 이중 음영 방지는 **요청된 의상의 그림 품질을 위한 조건부 작가 노하우**이지 Creator의 필수 원단/노드/파트 수가 아니다.
[Inochi2D 공식 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html : PSD 가져오기 이후 그림자 레이어들이 중첩되어 원본과 다르게 보일 수 있다. 이미지 AI는 원본과 각 자산의 투명 RGBA/중립 합성을 점검하고, Creator Node/Sorting/실제 블렌드 설정은 후속 사용자가 수행한다.

## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
- 동일 캔버스·앵커에 맞춘 독립 의상 파츠·가림 후면·마스크·PSD를 납품한다. 합성 미리보기의 BODY는 언제나 불투명 단색 베이스 상태다.
## [/MATTE_CLAY_BODY_V1]

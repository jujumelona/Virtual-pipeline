## [ART_SOURCE_AND_SEPARATION_V3]
### inochi2d_upper / outfit — 자산·모드·담당 단계 잠금
- 자산 경계: OUTFIT: 실제 옷감·소매·옷깃·밑단·의상에 붙은 디자인 요소만. BODY·얼굴·눈·피부·헤어·독립 장신구 픽셀은 0개. OUTFIT 납품물에는 피부·눈·얼굴·머리카락을 복사하지 않는다. 합성은 previews에서만 가능.
- 구도 경계: Inochi2D 상반신은 머리부터 허리, 양팔·손 포함. 다리 금지. Inochi2D 독립 노드 준비.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. outfit 실제 세분화 판단: OUTFIT: 앞뒤 몸판·좌우 소매·독립 이동하는 칼라/리본/밑단·치맛자락을 필요한 경우 나눈다. 봉제선·무늬는 본래 천에 유지. 감춰진 겹침면 색 복원, 피부·헤어 픽셀 혼입 금지.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

# Inochi2D 상반신 의상 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 보이는 상체 앞·뒷판·카라·양소매·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식·별도 하체 원화를 생성하지 않는다.


## 공식 근거를 이미지 제작에 적용
- 공식 Inochi2D Creator 파츠 원화/PSD: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . 이미지 AI는 실제 의상 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.inochi2d.com/en/latest/creator/nodes/node.html . Inochi Creator의 노드·파츠 계층과 메시 조절은 후속 모델링 단계이다. 이미지 AI가 Inochi 네이티브 리깅을 완료했다는 뜻이 아니다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. Inochi Creator PSD/Nodes 사용법: https://docs.inochi2d.com/en/latest/creator/nodes/node.html .


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / outfit]
**Inochi2D 공식:** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — PSD 가져오기 예시와 중복 그림자 합성 주의. https://docs.inochi2d.com/en/latest/creator/nodes/node.html — Node 자식 Transform/Sorting은 후속 Creator 작업. **의상 작가 실무:** 옷깃·소매·솔기·천의 두께·장력점에서 시작되는 실제 주름과 문양의 연속성. 이 팁의 고정 수치를 기술 규격이라 주장하지 않는다.
**해당 자산:** 사용자가 요청한 의상 한 벌의 실제 몸판·카라·좌우 소매·옷깃 안쪽·앞뒤 천/안감을 필요한 움직임 단위로 추출한다. 전신일 때만 디자인에 실제 있는 치마·바지·신발을 포함한다. 니트·천·가죽 등 사용자 선택 재질의 주름·두께와 고정 문양을 한 스타일로 그린다. 몸 피부·눈·헤어·독립 액세서리를 옷 텍스처에 넣지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_upper/outfit]
[Inochi2D 공식 PSD 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — 의상 파츠의 투명 합성·겹침을 위한 참고. [작가 실무] 목 회전이 가능한 신체 참조를 기준으로 카라 안쪽·뒤옷깃·어깨 아래의 숨은 옷감을 실제 해당 의상에만 추가 작화한다. 신체 목 피부는 의상 ZIP에서 그리지 않는다.
공식 Inochi Creator PSD 가져오기에서는 그림자 레이어가 중복 합성될 수 있음: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . Node 정렬·블렌드·리깅은 후속 Creator 사용자 작업이다.


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/outfit]
**[Inochi2D 공식과 아티스트 작업 구분]** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html 은 가져온 PSD의 그림자 중첩을 설명하는 후속 참고다. 봉제선·장력점의 천 주름, 무늬/망사 연속성, 실제 반투명 소매의 이중 음영 방지는 **요청된 의상의 그림 품질을 위한 조건부 작가 노하우**이지 Creator의 필수 원단/노드/파트 수가 아니다.
[Inochi2D 공식 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html : PSD 가져오기 이후 그림자 레이어들이 중첩되어 원본과 다르게 보일 수 있다. 이미지 AI는 원본과 각 자산의 투명 RGBA/중립 합성을 점검하고, Creator Node/Sorting/실제 블렌드 설정은 후속 사용자가 수행한다.

## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

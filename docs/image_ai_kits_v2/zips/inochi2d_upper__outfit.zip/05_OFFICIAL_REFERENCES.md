# 공식 참고

Inochi2D 공식 문서 https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html 및 예제 https://github.com/Inochi2D/example-models : 시각 참고만.

참고 링크를 실제로 열지 못했다면 봤다고 주장하지 않는다. 원화 제작은 사용자 기준 이미지와 SOURCE_ART_ONLY_V7 계약을 따라 진행한다.

## OUTFIT_CLOTHED_BODY_V1
얼굴을 제외한 몸통·양팔·양손을 실제 의상을 착용한 모습으로 그린다. 의복은 불투명하고 목깃과 소매가 확실하다. 신체를 벗겨낸 원화는 만들지 않는다.


# inochi2d_upper / outfit — Inochi2D 해당 자산 공식 근거

> 00_MASTER_FIRST.md의 완성 원화 우선 계약을 따른다. Inochi Creator 실행/노드/리깅은 이 ZIP의 출력물이 아니다.

## 적용 대상: Inochi2D용 의상 한 벌
[Inochi Creator 공식 첫 모델](https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html)은 PSD에 포함된 그림자/레이어가 불러오기 후 중첩될 수 있음을 보여준다. [공식 Node 자료](https://docs.inochi2d.com/en/latest/creator/nodes/node.html)는 후속 정렬 참고다.
이미지 AI는 **옷깃·소매·안감·실제 있는 하의/고정 장식 등 의상 원화 RGBA**만 출력하며 겹친 투명 명암을 중립 합성으로 확인한다. 신체 피부·얼굴·헤어·독립 소품, Creator 네이티브 파일/리깅은 생성하지 않는다.

각 ZIP은 `00_MASTER_FIRST.md`의 자산·모드 범위를 우선한다. 이 문서에 열거된 파일명/예제는 이 프로젝트 산출 기준이지 공식 엔진의 고정 파츠/이미지 개수 규정이 아니다. 링크는 기법의 출처이며 모델링·PSD 처리 도구 실행 및 외부 다운로드/라이선스 확보를 이미지 생성 AI의 필수 단계로 만들지 않는다.

## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
- 동일 캔버스·앵커에 맞춘 독립 의상 파츠·가림 후면·마스크·PSD를 납품한다. 합성 미리보기의 BODY는 언제나 불투명 단색 베이스 상태다.
## [/MATTE_CLAY_BODY_V1]

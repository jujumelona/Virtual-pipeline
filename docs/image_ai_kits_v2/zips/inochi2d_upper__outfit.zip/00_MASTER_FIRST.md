# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 inochi2d_upper/outfit 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
   단, 특정 기존 캐릭터·BODY와 동일성을 보존해야 하는데 필수 사용자 참조가 없거나, 실제 시각 참고 이미지를 전혀 볼 수 없다면 사유를 정확하게 보고하고 해당 단계만 보류한다. 허위 열람 완료 금지.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** Inochi2D 상반신. 얼굴과 큰 눈 중심의 손그림 애니풍 세밀함, 자연스러운 어깨·양팔·양손, 턱 뒤 목과 가림 표면을 유지한다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**inochi2d_upper/outfit 생성 최상위 기준**: 아래 구형 규칙과 충돌하면 이 규칙을 우선한다.
- 큰 머리, 큰 눈/홍채, 짧고 폭 넓은 얼굴, 둥근 볼, 부드럽고 짧은 U턱, 작은 코·입을 기본으로 한다. **긴/좁은 얼굴과 말상, 뾰족한 V턱, 성숙·실사 모델 인상은 절대 불합격.**
- 정면 얼굴 세로/가로 약 1.10~1.30은 귀여운 스타일의 권장 출발점이며 절대적인 크롭 수치가 아니다. 전신은 프로젝트 6등신, 상반신/바스트업은 큰 머리 존재감을 유지한다.
- 불합격 항목: 머리가 작아 보임, 눈이 작음, 얼굴이 길고 좁음, 뾰족한 턱, 긴 목, 다른 자산 혼입. 눈으로 검사하여 하나라도 발견되면 결과물 납품 금지.

## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_upper/outfit]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 구도: 허리까지 상반신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **inochi2d_upper / outfit** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`collar`, `upper_torso_garment`, `sleeve_L`, `sleeve_R`, `cuff_L`, `cuff_R`, `garment_side_L`, `garment_side_R`, `front_back_overlap`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 의상 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 의상의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 의상 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.

# 최우선 제작 계약: inochi2d_upper / outfit

## [2026-10-13 v5 inochi2d_upper/outfit 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.


## ZIP 고유 작업 범위 잠금: inochi2d_upper / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 보이는 상체 앞·뒷판·카라·양소매·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식·별도 하체 원화를 생성하지 않는다.


**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.



기존 캐릭터와 디자인을 일치시키되 요청받은 **의상** 자산만 납품한다. 다른 카테고리의 새 자산은 추가하지 않는다.



## [필수: 2D 결과 ZIP 레이어 정확성 사전 차단]

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** inochi2d_upper / outfit; OUTFIT — 요청받은 의상 한 종류와 의상에 종속된 단추·프릴·리본. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png.
- 최소 참고 파일 후보: reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: 신체 피부와 눈·목 등 BODY 원화를 의상 속에 합성한 독립 부품으로 납품하지 않는다. 별도 착용 소품은 ACCESSORY의 몫이다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 후속 Colab에서 See-through가 파츠를 분리하고 리깅 단계가 사용한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다.
- 옷깃·소매·안감·등 뒤 겹침을 참고 시점 그림으로 보여준다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. See-through 분리 이후 리깅 시 실제 관절·가림·회전 연결을 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

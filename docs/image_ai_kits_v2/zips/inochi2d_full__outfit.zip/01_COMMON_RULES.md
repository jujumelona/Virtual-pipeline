## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터에서도 의상 자산만 독립 제작한다. 신체·얼굴 원화는 제작하지 않는다.**
이 ZIP은 **inochi2d_full / outfit** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 기존 자료 형식: INX examples and PSD resources (check each file)
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`collar`, `upper_torso_garment`, `sleeve_L`, `sleeve_R`, `cuff_L`, `cuff_R`, `garment_side_L`, `garment_side_R`, `front_back_overlap`, `lower_garment_or_leg_cover_if_requested`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** 기준 신체와 동일한 캔버스·앵커에 의상 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 의상의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** 의상 파츠의 가림·좌우·앞뒤·경계와 기준 몸체의 합성 정합을 검수한다. 기준 신체가 없다면 실제 정합 미검증을 기록한다. 신체·눈 제작을 요구하지 않는다.
- **없는 부위:** 없는 의상 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 해당 자산 원화를 참조, 없으면 의상 자산 원화 생성) → 슬롯 매핑 → 필수 다각도·표정·숨은 면 원화 실제 제작 → 정합 검수 → 원화 파츠 분리·보완 → 실제 PSD·PNG·검증 기록·ZIP.
- **입력이 없는 신규 캐릭터:** 의상 자산만 독립 PSD·PNG·마스크로 제작한다. 기준 몸체가 없으면 공통 캔버스·앵커를 기록하고 정합 미검증을 표시한다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 inochi2d_full/outfit 자산별 제작 규칙]
Inochi2D 전신 의상 ZIP은 사용자 지정 의상 한 벌만 독립 제작한다. 실제 완성 버튜버와 인게임 공식 그림 참고를 열어 본 뒤 품질 기준을 확인한다. 참고 이미지를 열 수 없으면 REFERENCE_NOT_VIEWED로 기록하고 시각 품질 PASS 금지. 기존 BODY·헤어·얼굴·귀를 다시 만들지 않고 정해진 기준 캔버스와 원점/비율에 의상을 정확히 맞춘다. 의상의 옷깃·소매·안감·가려진 면·소재별 실제 주름만 의상 그림에 포함한다. 기준 신체 레이어를 변경하지 않는다. 전후좌우의 형태/옷 길이와 재봉선이 연결되며 실제 파츠 RGBA·알파·합성 미리보기/시각 QA를 제출한다. 실제 Inochi Creator 리깅 또는 VRM 모델 생성 완료로 주장하지 않는다. 무관한 액세서리 및 추가 의상은 만들지 않는다.

# Inochi2D 전신 의상 전용 제작 규칙

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 선택 의상에 실제 존재하는 상체 앞·뒷판·카라·양소매와 하의·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식을 생성하지 않는다. 단, 실제 의상의 하의와 신발은 해당 의상 파츠로 포함할 수 있다.
**그릴 범위:** 전신 캔버스에서 해당 의상의 실제 영역만. 기존 신체 원화의 목·어깨·팔 위치 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 실제 그림 제작
1. 사용자 원본/기준 몸체가 있다면 해당 캐릭터의 색·선화·원점·포즈를 참조하고, **의상만** 완성 원화로 먼저 생성한다.
2. 옷깃 안쪽, 어깨와 소매 아래 안감·겹침 여유를 추가 작화한다. 좌우 소매, 흔들릴 리본·옷자락만 필요한 만큼 분리한다. 사용자가 요청하지 않은 넥타이·리본·장신구나 전신 바지·치마·신발을 강제하지 않는다.
3. 해당 자산만 마스킹·추출해 동일 캔버스의 실제 RGBA PNG로 저장한다. 배경 격자 그림은 알파가 아니다.
4. 움직임/깊이와 가림에 필요한 숨은 **해당 자산의 그림만** underpaint 하고, 원본 보이는 픽셀은 유지한다.
5. 재합성으로 기준 아트와 정합 여부를 확인한다. 다른 자산은 합성 미리보기의 **참고용**으로만 허용하며 실제 파츠 ZIP의 source에 포함하지 않는다.
6. 이 자산에서는 신체를 새로 만들지 않고 기준 BODY의 불투명 중립색 실루엣/마스크를 참조한다. 옷·속옷처럼 보이는 구성은 BODY에 덧그리지 않으며, 요청된 HAIR/OUTFIT/ACCESSORY 파츠만 제작한다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** inochi2d_full / outfit; OUTFIT — 요청받은 의상 한 종류와 의상에 종속된 단추·프릴·리본. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: Inochi2D 전신: 6등신 애니풍 전신과 사지의 연결. Cubism 네이티브 파일은 요구하지 않는다.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png.
- 최소 참고 파일 후보: reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png.
- 위 PNG 목록은 **납품 필수**이고 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 앞/뒤 판·옷깃·목둘레·소매·어깨·팔꿈치·손목·옷 아래 가려진 원단과 안감, 필요한 경우 허리·치맛단·무릎 주변의 실제 천을 작화한다. 가동 부위와 가려지는 속면, 천의 두께·주름 방향이 다각도에서 이어져야 한다. 의상 고유 장식만 의상 파츠로 포함한다.
- Colab 입력 파츠·경로 계약: OUTFIT의 isolated_parts/ 파츠 ID는 outfit/cloth 계열로 시작하도록 적고, 한 파츠의 좌우·깊이 정보를 이름에 명확히 표시한다. 다른 자산의 이름이나 픽셀은 독립 파츠로 포함하지 않는다. layer_order.txt의 경로는 실제 isolated_parts/ PNG와 1:1 매칭한다.
- 자산 소유권 금지: 신체 피부와 눈·목 등 BODY 원화를 의상 속에 합성한 독립 부품으로 납품하지 않는다. 별도 착용 소품은 ACCESSORY의 몫이다.
- 2D ZIP의 실제 납품은 해당 자산의 기준 마스터 원화, 추가 참고 시점 그림, 독립 RGBA 원화 파츠와 마스크, 합성 미리보기, 편집 가능한 레이어 PSD 및 검수표다. 참고 시점 PNG가 자동으로 모션 키폼·메시가 되지는 않는다.
- 2D의 필수 reference_views/ 시점 PNG는 선택사항이 아니다. 정확한 파일명과 경로를 지키고 다각도 원화를 완성한 뒤 파츠를 분리한다..
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

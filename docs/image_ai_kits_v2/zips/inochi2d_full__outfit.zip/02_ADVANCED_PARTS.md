## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** Inochi2D 6등신 전신. 얼굴 표정·양손·발과 독립 관절의 2D 원화를 숙련된 애니 일러스트 수준으로 표현한다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-13 v5 inochi2d_full/outfit 자산별 제작 규칙]



옷 종류를 묻거나 사용자의 설명(원피스/재킷/셔츠/교복/드레스 등)에 따른다. **옷 한 벌의 실제 구조만** 그린다. 몸·헤어·별도 귀걸이/안경 세트는 생성하지 않는다.

|---|---|
| outfit_front.png / outfit_back.png | 앞·뒤 옷감이 깊이가 다른 경우, 팔/목 아래 가린 안감 보완 |
| sleeve_L_upper.png / sleeve_R_upper.png | 어깨부터 팔꿈치까지 별도 움직일 소매 |
| frill_01.png / outfit_ribbon.png | **옷에 부착된** 프릴·리본: 액세서리 ZIP이 아닌 **의상 내부**의 해당 부품 |
| skirt_front.png / skirt_back.png / pants_L.png / pants_R.png | **전신이고 실제 있는 하의만** 제작. 없는 치마/바지를 상상해서 추가하지 않음 |
| belt.png / shoe_L.png / shoe_R.png | 그 의상에 실제 포함될 때만 |



## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / outfit]
사용자가 요청한 의상 한 벌의 실제 몸판·카라·좌우 소매·옷깃 안쪽·앞뒤 천/안감을 필요한 움직임 단위로 추출한다. 전신일 때만 디자인에 실제 있는 치마·바지·신발을 포함한다. 니트·천·가죽 등 사용자 선택 재질의 주름·두께와 고정 문양을 한 스타일로 그린다. 몸 피부·눈·헤어·독립 액세서리를 옷 텍스처에 넣지 않는다.


## [고급 그림자·모근·소재·선폭 | inochi2d_full/outfit]



## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** 실제 입힌 옷의 앞/뒤, 소매 좌우, 옷깃, 따로 흔들리는 리본·밑단과 겨드랑이 안쪽. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: inochi2d_full/outfit; 머리부터 두 발까지 일관된 6등신. 다른 자산을 새로 제작하지 않는다.
- 1) 해당 자산의 마스터를 확정해 의상 재질·무늬·소매와 BODY 앵커을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: outfit.back, outfit.front, sleeve.left, sleeve.right; 실제 존재하는 칼라·리본·밑단만. 의상 패널과 소매·옷깃·안감만 나누며 신체·눈·입·헤어는 그리지 않는다. 다른 자산의 원화를 추가하지 않는다.
- 5) `part_art/_order.txt`에는 앞에서 뒤 순서로 독립 PNG 경로를 나열한다. PSD·마스크·MOC3·리깅은 이미지 AI 작업이 아니다. BODY 전용 눈·입·표정 PNG를 이 ZIP에서 만들지 않는다.
- 6) 이 자산의 원화·BODY 부착점·앞뒤 가림을 정면·3/4·측면 참고와 비교한다. 중립 합성은 `outputs/master.png`와 일치해야 하며 파츠 중복·접합 틈은 불합격이다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png. BODY 전용 입 표정 참고 이미지를 이 ZIP에서 제작하거나 납품하지 않는다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 옷깃·소매·안감·등 뒤 겹침을 참고 시점 그림으로 보여준다.
- **제작 단계 확정:** 이미지 AI는 위에 명시한 독립 파츠의 실제 그림과 다각도 참조를 하나씩 제작한다. PSD 인코딩·메시·키폼·리깅은 별도 단계다. 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] 3/4·측면에는 목·어깨·겨드랑이·소매와 옷깃의 실제 가림·안감을 보여 준다. 기준 BODY 피부·목·얼굴은 의상 독립 파츠 PNG에 함께 그리지 않는다.
- [좌표/참조] 정면·좌우 3/4·양측면 및 상하 자세 비교 원화는 outputs/master.png와 동일한 전체 캔버스 치수·기준 크기로 그린다. 확대 클로즈업은 별도 보조 그림으로만 남긴다. 이미지 AI의 다각도 그림은 PSD2Live/Inochi 실제 키폼에 자동 등록되지 않는다.
- [엔진 확인] Inochi2D는 Inochi Creator의 실제 Part Node·메시·변형·목뿌리 자식 계층을 제작해야 움직인다. 현재 2D PNG/PSD 참조를 Inochi 원생 프로젝트 및 90° 회전 키폼으로 자동 변환하지 못한다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

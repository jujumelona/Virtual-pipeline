# Inochi2D 전신 / 의상만 결과 ZIP
결과: inochi2d_full__outfit__ARTWORK.zip
isolated_parts/outfit_front.png
isolated_parts/outfit_back.png
isolated_parts/sleeve_L_upper.png
isolated_parts/sleeve_R_upper.png
layer_order.txt
previews/overlay_preview.png
파츠는 서로 다른 움직임/깊이에만 분리. 실제 캐릭터에 없는 부위를 강제하지 않으며 02_ADVANCED_PARTS가 세분화 가이드.
RGBA PNG마다 동일 캔버스 원점에 그 부분만 투명 배경으로. layer_order.txt는 뒤→앞 상대 경로만. Inochi 엔진 내부 sorting 정수와 혼동 금지.
최종 미리보기는 개별 PNG 생성 후 합성. HEADPIECE 등 예시 이름은 사용자 요청대로 치환.
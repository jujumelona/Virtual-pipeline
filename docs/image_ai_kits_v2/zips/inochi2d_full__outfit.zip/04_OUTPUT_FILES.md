# Inochi2D 전신 / 의상만 결과 이미지 ZIP
`inochi2d_full__outfit__ARTWORK.zip`
```text
isolated_parts/outfit_front.png
isolated_parts/outfit_back.png
isolated_parts/sleeve_L_upper.png
isolated_parts/sleeve_R_upper.png
layer_order.txt
previews/overlay_preview.png
```
파츠명 예시로 실제 있는 부위만 그린다. headpiece는 사용자가 머리장식을 요청한 경우에만 사용. 02의 고급 개별 움직임에 맞춰 파츠 추가, 동일 원점·투명 RGBA, 마지막 합성, 뒤→앞 목록. **07+09+10의 애니풍 품질·파일 조건 확인 후 최종 ZIP 납품**.

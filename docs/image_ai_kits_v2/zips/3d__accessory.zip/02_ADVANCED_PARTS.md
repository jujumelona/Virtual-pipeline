## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **해당 자산의 고품질 제작 조건:** ACCESSORY 전용. 지정 소품의 소재·윤곽·입체 두께·부착점·그림자·가려진 뒷면을 세련된 애니 원화로 그린다. 원/사각형·SVG 선만으로 구성한 임시 표시물을 완성품으로 제출하지 않으며 신체·의상·헤어를 중복 제작하지 않는다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-13 v5 3d/accessory 적용 최상위 기준]
3D ACCESSORY: 요청한 소품 한 종류만 8방향에서 실제 부착 앵커와 크기·두께·좌우·뒷면을 일관되게 표현한다. 신체·헤어·의상을 복제하거나 새로 생성하지 않는다. 3D 메시 파일/VRM 완성 주장 없이 독립 원화 시트로 납품한다.

# 3D 액세서리만 — 사용자가 지정한 물건 하나의 8방향 턴어라운드


액세서리 종류를 사용자 지시대로 해석한다. **'머리장식'을 요구받으면 머리장식만** 만들고, 안경·귀걸이·왕관·목걸이를 덧붙여 액세서리 세트로 만들지 않는다.

- views/accessory_front.png, views/accessory_back.png, views/accessory_left.png, views/accessory_right.png: 그 물건의 형태·두께·부착 방향·재질·앞뒤 모양을 보여주는 서로 다른 시점 그림.
- previews/turnaround_sheet.png: 앞서 만든 정·후·좌·우 그림을 마지막에 배열한 합성 미리보기.



## [2026-10-13 3D 다각도 전문 작화 노하우 / accessory]
사용자 요청 **액세서리 한 종류**를 실제 정면·후면·좌·우·대각을 포함한 8방향으로 그린다. 그 물건의 부착 고정부·체인/링/프레임·두께·돌출/뒤쪽 면·투명 렌즈 등은 해당 소품에 실제 있을 때만 보여준다. 기준 캐릭터의 귀·코·옷깃·머리카락 등 필요한 앵커를 위치 참조만 하며 인물 전체를 그리지 않는다. 다른 종류 장신구를 세트로 추가하지 않는다.


## [고급 그림자·모근·소재·선폭 | 3d/accessory]

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** 3d / accessory; ACCESSORY — 지정된 부착 소품 한 종류. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): views/accessory_front.png, views/accessory_front_three_quarter_L.png, views/accessory_left.png, views/accessory_back_three_quarter_L.png, views/accessory_back.png, views/accessory_back_three_quarter_R.png, views/accessory_right.png, views/accessory_front_three_quarter_R.png, views/accessory_detail_occlusion.png.
- 최소 참고 파일 후보: views/accessory_front.png, views/accessory_front_three_quarter_L.png, views/accessory_left.png, views/accessory_back_three_quarter_L.png, views/accessory_back.png, views/accessory_back_three_quarter_R.png, views/accessory_right.png, views/accessory_front_three_quarter_R.png, views/accessory_detail_occlusion.png.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: 신체·헤어·의상을 다시 제작하거나 종합 액세서리 세트를 강제로 만들지 않는다.
- 3D의 필수 8방향 원화와 가림 세부 1장은 모두 views/ 폴더의 명시된 정확한 파일명으로 납품한다. reference_views/ 안의 비율·표정 보조 가이드는 필수 턴어라운드를 대체하지 않는다..

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/accessory_front.png, views/accessory_front_three_quarter_L.png 등 8방향 개별 원화와 views/accessory_detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 소품 부착점과 가려진 뒷면을 참고 시점 그림으로 보여준다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] 대각·측면 그림에서 해당 자산의 뒷면, BODY 부착점, 파츠의 실제 앞뒤 순서를 확인한다. 기준 몸체·얼굴 자체를 다시 제작하지 않는다.
- [좌표/참조] 8방향은 각도별 완성 그림이지 움직이는 3D VRM·본·표정 계층 자체가 아니다.
- [엔진 확인] 현재 자동 3D 제작기는 8방향 원화에서 전 방향 메시를 자동 구축하는 것으로 검증되지 않았다. 정면·후면·좌우 참고 이외 대각 시점의 메시·뼈·가림 반영은 추가 구현/검사가 필요하다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [THREE_D_VISUAL_TURNAROUND_CARDS_V1]
# 3D용 실제 8방향 그림 제작 카드: accessory

### 각 시점의 실제 그림을 그리는 방법
**시점 이름만 보고 정면을 옆으로 늘려 다른 시점을 만들지 않는다.** 한 캐릭터의 고정된 실루엣·색·소재·크기·머리 비율을 정한 뒤 시점마다 독립된 한 장의 실제 그림을 그린다. 정면과 등을 단순 수평 반전하지 않는다. 카메라/화면 크기와 기준 발 위치·머리 높이를 유지하며, 모든 그림에서 **같은 캐릭터의 부피 있는 3D 형태**가 보이도록 작화한다.

| 시점별 입력 파일 | 이미지 AI가 보여줘야 하는 형태 | 틀린 결과 |
|---|---|---|
| views/accessory_front.png | 정면의 기준 색·실루엣·중심선, 양쪽 눈/귀·어깨/팔·의상/소품 상대 위치 | 눈/몸 비율이 다른 이후 시점의 원본 |
| views/accessory_front_three_quarter_L.png | 캐릭터 자신의 왼쪽으로 약 45° 돌린 모습. 가까운 면이 넓고 반대쪽은 작아져 가림이 생김 | 정면 얼굴/옷을 평행이동시킨 그림 |
| views/accessory_left.png | 진짜 왼쪽 90°. 코-입-턱, 귀 뒤와 목 앞/뒤선, 어깨/팔의 앞뒤 깊이 확인 | 두 정면 눈을 그대로 그린 측면, 턱과 목이 분리됨 |
| views/accessory_back_three_quarter_L.png | 뒤에서 약 45° 본 몸통·머리 뒤통수·등/모발/뒤 옷 주름의 실제 모양 | 앞면 무늬가 등 뒤에 그대로 남음 |
| views/accessory_back.png | 정확히 뒤쪽에서 본 머리·목·양어깨·옷 뒤/소품 고정부의 완전한 그림 | 정면을 단순 반전하고 얼굴이 뒤통수에 남음 |
| views/accessory_back_three_quarter_R.png | 뒤에서 반대 45°. 좌우 고유 비대칭·머리 뒤 가림 유지 | 왼쪽 뒤 시점을 의미 없이 복사 |
| views/accessory_right.png | 오른쪽 90°. 반대쪽 귀·옆머리·목과 어깨의 연결/가림 설명 | 왼쪽 그림을 뒤집으면서 비대칭 소품까지 뒤집음 |
| views/accessory_front_three_quarter_R.png | 오른쪽 약 45°. 가까운 눈/귀와 먼쪽 눈/귀의 가림이 다른 실제 3D 그림 | 양쪽 3/4을 정면에서 대칭 늘리기 |
| views/accessory_detail_occlusion.png | 이 자산의 중요한 가림·접합을 크게 보여주는 완성 설명 원화 | 잘린 단면만 표시하거나 2D PSD/마스크를 납품 |

**완료 전 반드시 서로 비교:** 머리 상단→턱→귀 아래→목뿌리→양어깨의 연결선, 몸통의 두께, 팔 관절, 동일한 손·소품의 좌우, 등 뒤에 있어야 하는 면. 템플릿이나 실제 참고 이미지를 못 열었다면 열람 완료라고 주장하지 않는다. 이 9장은 3D 제작용 형태 참고일 뿐, 각도를 자동으로 3D 메시/본/스키닝으로 변환했다는 증거는 아니다.

### ACCESSORY 3D 시점별 강조 사항

- 먼저 사용자가 선택한 실제 소품 한 종류만 확정한다. 안경이면 코받침·양 귀로 이어진 안경다리, 귀걸이면 귀의 고정부·움직이는 추, 목걸이면 목 뒤 걸림, 머리핀이면 모근 부착을 보여준다.
- 정면·측면·뒤쪽 8방향에서 **같은 소품이 부착점 중심으로 돌아간 실제 부피**를 유지한다. 앞에서 보이는 면이 뒤쪽에서도 보이면 안 된다.
- 측면에서는 안경다리가 귀 뒤로 들어가는 모습, 귀걸이의 두께, 목걸이의 뒷목 가림 등 실제로 해당하는 관계만 확인한다.
- detail_occlusion은 몸/옷/헤어와 소품의 고정점과 가려진 뒷면을 집중 묘사한다. 소품이 저절로 떠 있거나 8개 각도마다 종류가 바뀌는 결과는 실패다.

## [/THREE_D_VISUAL_TURNAROUND_CARDS_V1]

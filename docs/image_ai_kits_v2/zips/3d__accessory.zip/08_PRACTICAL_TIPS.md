## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 요청된 자산의 독창적인 원화를 새로 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **3d / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 기존 자료 형식: Interactive 3D app/preset; not PSD and not automatically present in ZIP
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** full-body four-view turnaround
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참고 프리셋/공식 실제 그림을 확인한 뒤 새로운 캐릭터 전후좌우 원화를 만든다. 3D 이미지 AI 지시 ZIP은 PSD나 VRM 내보내기를 약속하지 않고 턴어라운드 참조 PNG와 시각 검증을 납품한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# 3D 액세서리 전문 다각도 제작 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / accessory
**유일한 생성 대상:** 지정한 액세서리 한 종류의 앞/뒤/좌우 형상·두께·부착 구조에 대한 참조 그림.
**별도 카테고리 생성 금지:** 여러 소품 세트·얼굴·헤어·신체·의상 원화를 새로 생성하지 않는다. 안경/귀걸이/머리핀 등의 예시 목록을 동시에 모두 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


## 비공식 3D 레퍼런스 작화 노하우
1. 기준 캐릭터의 코·귀·머리카락·의상 등 실제 해당 물건의 앵커 위치만 참고한다. 소품 본체/고정부/연결부의 정면·후면·측면 형상과 두께를 그린다. 체인·프레임·투명 렌즈·고리 등 실제 요청한 물건에 있는 구조만 강조하고 가려진 연결을 설명하는 별도 디테일을 그린다.
2. 사용자가 요청한 하나의 소품인가? 좌/우/뒤 형상이 실제 부착구조·재질·치수에 맞는가? 인물의 다른 자산 원화가 끼어들지 않았는가?
3. 정면 기준 높이·원점·중심축·좌우 비대칭과 빛 방향을 고정하고 후면/좌우 시점마다 깊이와 실제 가려진 면을 새로 그린다.
4. 몸체는 위치·체형·장착점 정합용으로만 참조하고 다른 자산 그림을 추가로 생성하지 않는다. 해당 자산만 그림 납품.
5. 큰 실루엣/색/무늬·접합의 방향별 정합을 먼저 확인한 뒤 얇은 선화·셀 명암·요청된 액세서리 한 종류의 앵커·부착 구조·앞뒤 두께를 검수한다..
6. 끝에서 하나의 turnaround_sheet.png로 비교하되 별도의 네 그림을 실제 파일로 보관한다.

## 비공식 참고
https://virmii.com/blog/tutorial/how-to-make-vtuber-reference-sheet (일반적인 시트 제작 경험), https://www.reddit.com/r/Live2D/comments/12nhr9v/ (좌우 명칭 팁만, 3D 공식 규격 아님).


## [2026-10-13 3D 다각도 전문 작화 노하우 / accessory]
정면을 뒤집어서 측면이라고 제출하지 않는다. 네 그림에서 동일한 부착점·소품 길이/폭/두께·소재색·금속 반사·연결 방향을 맞춘다. 얇은 체인/고리의 앞뒤 겹침과 필요시 렌즈 투명 표현을 실제 도면으로 설명한다. 요청되지 않은 헤어핀·귀걸이·안경 등 추가 금지. 3D 모델·SpringBone·메시/UV/리깅/착용 테스트는 이미지 AI 출력 범위가 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/accessory]
[부착점 4방향 도면] 요청받은 물건 하나의 정면·후면·좌/우 측면에서 고정부의 두께·뒷면과 접합 방향을 별도로 보여준다. 안경이라면 코받침~귀 뒤 다리, 귀걸이라면 귓불 뒤 고정처럼 **요청된 종류의 연결만** 설명한다. 기준 인물 얼굴/눈·피부·의상/헤어는 새로 그리지 않는다.


## [고급 그림자·모근·소재·선폭 | 3d/accessory]
**[소품 고급 4면도]** 주문 소품이 체인·끈처럼 유연한 연결을 실제 가지면 고정부/연결 길이·중립 모양의 그림을 추가 참고로 설명할 수 있다. 금속·유리 등 요청 재질에만 적절한 좁은 하이라이트/투명 표현을 사용한다. 정면을 잘라 후면/측면이라 하지 않고 실제 재질·두께를 새 시점마다 맞춘다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** 3d / accessory; ACCESSORY — 지정된 부착 소품 한 종류. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 3D용 원화 참고: 앞·좌우 3/4·좌우 옆·좌우 뒤 3/4·후면(최소 8개 방향)의 동일 자산 턴어라운드. 2D PSD 파츠가 아닌 형태·재질·뒷면·앵커 참고 그림.
- 최소 참고 파일 후보: views/accessory_front.png, views/accessory_front_three_quarter_L.png, views/accessory_left.png, views/accessory_back_three_quarter_L.png, views/accessory_back.png, views/accessory_back_three_quarter_R.png, views/accessory_right.png, views/accessory_front_three_quarter_R.png, views/accessory_detail_occlusion.png.
- 위 목록은 **최소 작업 기준 후보**이지 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 부착점과 접촉 방향·앞뒤 깊이·고정부·가려지는 뒷면을 실제 원화로 만든다. 좌우 회전시 소품 두께와 고정점이 유지되어야 한다. 필요한 경우 서로 다른 깊이에서 움직이는 소품의 부위만 분리한다. 사용자가 요청한 종류가 머리 장식이 아닐 수 있으므로 실제 소품 형태에 맞춰 뷰를 조정한다.
- 자산 소유권 금지: 신체·헤어·의상을 다시 제작하거나 종합 액세서리 세트를 강제로 만들지 않는다.
- 3D ZIP의 실제 납품은 동일 캐릭터/자산의 다각도 PNG 턴어라운드, 실루엣·재질·부착 앵커 참조, 상세 클로즈업 및 검수표다. PSD 층, 2D 눈 리깅 파츠, VRM 바이너리, Blender 실행 결과를 요구하거나 성공했다고 주장하지 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

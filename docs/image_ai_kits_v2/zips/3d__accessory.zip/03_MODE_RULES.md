## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **3d / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 기존 자료 형식: Interactive 3D app/preset; not PSD and not automatically present in ZIP
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** full-body four-view turnaround
- **입력 요구:** verified_access_to_VRoid_preset_or_licensed_model. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 3d/accessory 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D ACCESSORY: 요청한 소품 한 종류만 4방향에서 실제 부착 앵커와 크기·두께·좌우·뒷면을 일관되게 표현한다. 신체·헤어·의상을 복제하거나 새로 생성하지 않는다. 3D 메시 파일/VRM 완성 주장 없이 독립 원화 시트로 납품한다.

# 3D 액세서리만 다각도 그림 제작 — 2D 파츠 리깅과 구분

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: 3d / accessory
**유일한 생성 대상:** 지정한 액세서리 한 종류의 앞/뒤/좌우 형상·두께·부착 구조에 대한 참조 그림.
**별도 카테고리 생성 금지:** 여러 소품 세트·얼굴·헤어·신체·의상 원화를 새로 생성하지 않는다. 안경/귀걸이/머리핀 등의 예시 목록을 동시에 모두 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


- **views/**: 정면 `views/accessory_front.png`, 후면 `views/accessory_back.png`, 좌측 `views/accessory_left.png`, 우측 `views/accessory_right.png`의 실제 다른 시점 그림을 제작한다. 구체적 경로가 다를 경우 `04_OUTPUT_FILES.md`의 파일명을 우선한다.
- **고유 대상:** 요청 소품 한 종류의 정면·후면·좌측·우측 4면도, 실제 부착점·연결부 디테일. 외형에 없는 가닥·속옷·후드·리본·안경 등 다른 카테고리는 요구하지 않는다.
- **기준 정합:** 기준 캐릭터의 코·귀·머리카락·의상 등 실제 해당 물건의 앵커 위치만 참고한다. 소품 본체/고정부/연결부의 정면·후면·측면 형상과 두께를 그린다. 체인·프레임·투명 렌즈·고리 등 실제 요청한 물건에 있는 구조만 강조하고 가려진 연결을 설명하는 별도 디테일을 그린다.
- **previews/turnaround_sheet.png**는 실제 네 장의 그림을 같은 기준선으로 배열한 비교 결과. 2D 파츠/PSD 파일 대신 3D 자산의 독립적인 네 시점 `views/` 이미지와 실제 `turnaround_sheet.png`를 제출한다.
- 결과는 **참조 그림**이지 3D 메시·VRM·UV·본·리깅·모션 파일이 아니다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / accessory]
**3D 참조도 전용:** 이 ZIP은 모델이나 UV가 아닌 같은 자산의 독립된 정면/후면/좌측/우측 참조 원화를 만든다. 6등신은 신체 ZIP의 디자인 조건이고 헤어/의상/소품에는 같은 몸체 기준선을 정렬하는 데만 사용한다. 실제 3D 모델·Rig·SpringBone·VRM이 완성됐다고 주장하지 않는다. 미러링/크롭·라벨만 바꾼 가짜 측면도 금지.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/accessory]
3D용은 실제 다른 네 방향의 accessory 참조 그림만 생성한다. 기준 6H 신체의 눈·귀·코·목은 소품/헤어/의상 장착 위치를 위한 참고일 뿐 새로 그리지 않는다. 메시·UV·VRM은 이미지 AI 산출물이 아니다.


## [고급 그림자·모근·소재·선폭 | 3d/accessory]
그림으로만 전후좌우 독립된 4면도/세부 참조를 만든다. 2D PNG 레이어·PSD 마스크·Multiply 설정을 요구하지 않고, 재질 하이라이트·선폭·관절 기준선이 같은 물건의 다른 시점에서 일치하는지만 검수한다.

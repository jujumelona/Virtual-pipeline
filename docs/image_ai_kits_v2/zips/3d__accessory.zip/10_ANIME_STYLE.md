# 3D 액세서리 고급 애니 스타일 4면도

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / accessory
**유일한 생성 대상:** 지정한 액세서리 한 종류의 앞/뒤/좌우 형상·두께·부착 구조에 대한 참조 그림.
**별도 카테고리 생성 금지:** 여러 소품 세트·얼굴·헤어·신체·의상 원화를 새로 생성하지 않는다. 안경/귀걸이/머리핀 등의 예시 목록을 동시에 모두 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


기준 캐릭터의 코·귀·머리카락·의상 등 실제 해당 물건의 앵커 위치만 참고한다. 소품 본체/고정부/연결부의 정면·후면·측면 형상과 두께를 그린다. 체인·프레임·투명 렌즈·고리 등 실제 요청한 물건에 있는 구조만 강조하고 가려진 연결을 설명하는 별도 디테일을 그린다. 검정에 가까운 가변 선폭 테이퍼 윤곽과 소재별 얇은 내부선, 2~3톤 셀 셰이딩을 사용한다. 사용자 지정 화풍이 있다면 우선한다. 없는 얼굴·헤어·의상을 기계적으로 덧붙이지 않는다.

영어 이미지 프롬프트: “Professional anime VTuber accessory-only reference artwork, actual independently illustrated front, back, left and right orthographic-style views, consistent dimensions and original design, fine tapered ink outlines, expressive material-specific cel shading, accurate depth and silhouettes; show ONLY the requested accessory, no extra character anatomy or accessory sets.”

VRM/메시/UV/본·리깅 등 3D 네이티브 파일을 그린 것처럼 주장하지 않는다.

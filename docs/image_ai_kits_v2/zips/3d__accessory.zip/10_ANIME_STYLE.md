## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**3d/accessory 제작 우선 규칙:** 하위 구형 얼굴/두상 지시와 충돌하면 이 규칙이 우선한다.
- 3D ACCESSORY는 큰 머리·짧고 둥근 얼굴을 가진 기준 캐릭터의 부착점에 맞춘다. 안경·장식이 얼굴을 길고 좁게 보이게 하거나 두상 대비 크기가 맞지 않으면 불합격. 요청받은 소품만 모델링하고 기준 BODY·HAIR·얼굴·턱을 재생성하지 않는다.
- 공통: 상대적으로 큰 머리, 충분히 큰 눈/홍채, 짧고 넓은 얼굴, 부드러운 U형 턱, 작은 코·입. 긴 좁은 얼굴과 V턱 절대 불합격.
- 정면 얼굴 높이/폭 약 1.10~1.30은 권장 출발점이며 절대 화면 크롭 비율이 아니다. 전신 6등신을 유지한다.
- 정면·후면·좌우 4시점에서 머리 크기·얼굴 윤곽의 일치 여부 확인. 기존 3D BODY 재설계 없이 이 ZIP의 대상 자산만 제작한다.
- 불합격 시 재작업: 작아 보이는 두상, 길고 좁은 얼굴, 뾰족한 턱, 작은 눈, 길어 보이는 목, 자산 범위 혼입. 3D에 2D PSD·PNG 파츠 납품을 강제하지 않는다.

## [2026-10-14 최우선 자산별 제작 규칙: 3d/accessory]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 액세서리만 제작. 부착점·가려진 면 보완. 신체·헤어·의상 재생성 금지.
- 구도: 전신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 실제 PSD·3D 템플릿이 없으면 없다고 알린다. URL 및 그림 도식은 원본 템플릿이 아니다.
- 3D는 정·후·좌·우 4면도. 2D 파츠 PSD 요구 없음.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.


## [2026-10-13 v5 3d/accessory 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D ACCESSORY: 요청한 소품 한 종류만 4방향에서 실제 부착 앵커와 크기·두께·좌우·뒷면을 일관되게 표현한다. 신체·헤어·의상을 복제하거나 새로 생성하지 않는다. 3D 메시 파일/VRM 완성 주장 없이 독립 원화 시트로 납품한다.

# 3D 액세서리 고급 애니 스타일 4면도

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / accessory
**유일한 생성 대상:** 지정한 액세서리 한 종류의 앞/뒤/좌우 형상·두께·부착 구조에 대한 참조 그림.
**별도 카테고리 생성 금지:** 여러 소품 세트·얼굴·헤어·신체·의상 원화를 새로 생성하지 않는다. 안경/귀걸이/머리핀 등의 예시 목록을 동시에 모두 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


기준 캐릭터의 코·귀·머리카락·의상 등 실제 해당 물건의 앵커 위치만 참고한다. 소품 본체/고정부/연결부의 정면·후면·측면 형상과 두께를 그린다. 체인·프레임·투명 렌즈·고리 등 실제 요청한 물건에 있는 구조만 강조하고 가려진 연결을 설명하는 별도 디테일을 그린다. 검정에 가까운 가변 선폭 테이퍼 윤곽과 소재별 얇은 내부선, 2~3톤 셀 셰이딩을 사용한다. 사용자 지정 화풍이 있다면 우선한다. 없는 얼굴·헤어·의상을 기계적으로 덧붙이지 않는다.

영어 이미지 프롬프트: “Professional anime VTuber accessory-only reference artwork, actual independently illustrated front, back, left and right orthographic-style views, consistent dimensions and original design, fine tapered ink outlines, expressive material-specific cel shading, accurate depth and silhouettes; show ONLY the requested accessory, no extra character anatomy or accessory sets.”

VRM/메시/UV/본·리깅 등 3D 네이티브 파일을 그린 것처럼 주장하지 않는다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / accessory]
Professional premium anime VTuber SINGLE ACCESSORY 3D REFERENCE ART, one specified item rendered as four genuinely separately drawn front back left right orthographic-style images with matching physical thickness, actual mounting anchor, surface material and small structural details, refined tapered outlines and cel highlights; no extra accessories or character body, no mesh or VRM.
Original Japanese anime character-art design, dark tapered ink strokes, concise cel shading and correct independent viewpoints.


## [고급 그림자·모근·소재·선폭 | 3d/accessory]
ANIME SINGLE ACCESSORY TURNAROUND REFERENCE ONLY: separately drawn four angles of the requested object's actual shape, thin-connection line weight and realistic stylized material highlights, optional neutral hanging form only when genuinely needed; no full character, added ornaments, modeling UV or VRM.

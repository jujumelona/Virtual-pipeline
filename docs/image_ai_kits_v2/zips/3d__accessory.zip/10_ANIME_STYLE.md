## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **해당 자산의 고품질 제작 조건:** ACCESSORY 전용. 지정 소품의 소재·윤곽·입체 두께·부착점·그림자·가려진 뒷면을 세련된 애니 원화로 그린다. 원/사각형·SVG 선만으로 구성한 임시 표시물을 완성품으로 제출하지 않으며 신체·의상·헤어를 중복 제작하지 않는다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**3d/accessory 제작 우선 규칙:** 하위 구형 얼굴/두상 지시와 충돌하면 이 규칙이 우선한다.
- 3D ACCESSORY는 큰 머리·짧고 둥근 얼굴을 가진 기준 캐릭터의 부착점에 맞춘다. 안경·장식이 얼굴을 길고 좁게 보이게 하거나 두상 대비 크기가 맞지 않으면 불합격. 요청받은 소품만 모델링하고 기준 BODY·HAIR·얼굴·턱을 재생성하지 않는다.
- 공통: 상대적으로 큰 머리, 충분히 큰 눈/홍채, 짧고 넓은 얼굴, 부드러운 U형 턱, 작은 코·입. 긴 좁은 얼굴과 V턱 절대 불합격.
- 정면 얼굴 높이/폭 약 1.10~1.30은 권장 출발점이며 절대 화면 크롭 비율이 아니다. 전신 6등신을 유지한다.
- 정면·후면·좌우 8방향 시점에서 머리 크기·얼굴 윤곽의 일치 여부 확인. 기존 3D BODY 재설계 없이 이 ZIP의 대상 자산만 제작한다.

## [2026-10-14 최우선 자산별 제작 규칙: 3d/accessory]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 액세서리만 제작. 부착점·가려진 면 보완. 신체·헤어·의상 재생성 금지.
- 구도: 전신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.


## [2026-10-13 v5 3d/accessory 적용 최상위 기준]
3D ACCESSORY: 요청한 소품 한 종류만 8방향에서 실제 부착 앵커와 크기·두께·좌우·뒷면을 일관되게 표현한다. 신체·헤어·의상을 복제하거나 새로 생성하지 않는다. 3D 메시 파일/VRM 완성 주장 없이 독립 원화 시트로 납품한다.

# 3D 액세서리 고급 애니 스타일 8방향 턴어라운드

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / accessory
**유일한 생성 대상:** 지정한 액세서리 한 종류의 앞/뒤/좌우 형상·두께·부착 구조에 대한 참조 그림.
**별도 카테고리 생성 금지:** 여러 소품 세트·얼굴·헤어·신체·의상 원화를 새로 생성하지 않는다. 안경/귀걸이/머리핀 등의 예시 목록을 동시에 모두 만들지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


기준 캐릭터의 코·귀·머리카락·의상 등 실제 해당 물건의 앵커 위치만 참고한다. 소품 본체/고정부/연결부의 정면·후면·측면 형상과 두께를 그린다. 체인·프레임·투명 렌즈·고리 등 실제 요청한 물건에 있는 구조만 강조하고 가려진 연결을 설명하는 별도 디테일을 그린다. 검정에 가까운 가변 선폭 테이퍼 윤곽과 소재별 얇은 내부선, 2~3톤 셀 셰이딩을 사용한다. 사용자 지정 화풍이 있다면 우선한다. 없는 얼굴·헤어·의상을 기계적으로 덧붙이지 않는다.

영어 이미지 프롬프트: “Professional anime VTuber accessory-only reference artwork, actual independently illustrated front, back, left and right orthographic-style views, consistent dimensions and original design, fine tapered ink outlines, expressive material-specific cel shading, accurate depth and silhouettes; show ONLY the requested accessory, no extra character anatomy or accessory sets.”



## [2026-10-13 3D 다각도 전문 작화 노하우 / accessory]
Professional premium anime VTuber SINGLE ACCESSORY 3D REFERENCE ART, one specified item rendered as four genuinely separately drawn front back left right orthographic-style images with matching physical thickness, actual mounting anchor, surface material and small structural details, refined tapered outlines and cel highlights; no extra accessories or character body, no mesh or VRM.
Original Japanese anime character-art design, dark tapered ink strokes, concise cel shading and correct independent viewpoints.


## [고급 그림자·모근·소재·선폭 | 3d/accessory]
ANIME SINGLE ACCESSORY TURNAROUND REFERENCE ONLY: separately drawn four angles of the requested object's actual shape, thin-connection line weight and realistic stylized material highlights, optional neutral hanging form only when genuinely needed; no full character, added ornaments, modeling UV or VRM.

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/front.png, views/front_three_quarter_L.png 등 8방향 개별 원화와 views/detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 소품 부착점과 가려진 뒷면을 참고 시점 그림으로 보여준다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

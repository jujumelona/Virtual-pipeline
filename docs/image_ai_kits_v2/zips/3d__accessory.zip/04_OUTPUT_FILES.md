# 3D / 액세서리만 출력
**`3d__accessory__ARTWORK.zip`**
```text
views/accessory_front.png
views/accessory_back.png
views/accessory_left.png
views/accessory_right.png
details/accessory_components.png
previews/turnaround_sheet.png
```
네 방향 모두 동일한 애니 캐릭터/지정 자산의 다른 각도 이미지. 고급 세부 그림은 처음부터 독립 생성. 07+09+10의 작화·선화·셀셰이딩·정합을 반복 점검하여 최종 결과 ZIP 제공.

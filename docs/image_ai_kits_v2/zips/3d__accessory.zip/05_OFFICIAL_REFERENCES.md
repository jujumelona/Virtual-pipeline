# 공식 참고

VRoid Studio https://vroid.com/en/studio : 형태·시점 참고만. VRM 생성은 이미지 AI의 산출 요구가 아니다.

참고 링크를 실제로 열지 못했다면 봤다고 주장하지 않는다. 원화 제작은 사용자 기준 이미지와 SOURCE_ART_ONLY_V7 계약을 따라 진행한다.

## ASSET_ONLY_V1
FACE·OUTFIT을 복제하지 않고 선택한 자산만 그린다.


# live2d_full / outfit — 해당 엔진·자산 공식 근거

> 00_MASTER_FIRST.md의 완성 원화 우선 계약을 따른다. Cubism Editor 실행/리깅은 이 ZIP의 출력물이 아니다.

## 적용 대상: 요청받은 의상 한 벌
[Live2D 공식 일러스트 가공](https://docs.live2d.com/en/cubism-editor-tutorials/psd/)은 옷깃·소매·가디건 등 실제로 따로 움직일 영역만 분리하고 가려진 천을 보완하는 참고자료다. [Clipping 기능](https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/)은 이후 Editor 참고사항이며 이미지 AI가 실행하지 않는다.
실제 납품은 **그 의상의 옷감·카라·소매·실제로 있는 고정 장식/안감**만이다. 얼굴·목 피부·헤어·별도 귀걸이/안경을 그리지 않는다.

각 ZIP은 `00_MASTER_FIRST.md`의 자산·모드 범위를 우선한다. 이 문서에 열거된 파일명/예제는 이 프로젝트 산출 기준이지 공식 엔진의 고정 파츠/이미지 개수 규정이 아니다. 링크는 기법의 출처이며 모델링·PSD 처리 도구 실행 및 외부 다운로드/라이선스 확보를 이미지 생성 AI의 필수 단계로 만들지 않는다.

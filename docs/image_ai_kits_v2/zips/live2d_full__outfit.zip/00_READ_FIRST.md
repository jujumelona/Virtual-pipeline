# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 live2d_full/outfit 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
   단, 특정 기존 캐릭터·BODY와 동일성을 보존해야 하는데 필수 사용자 참조가 없거나, 실제 시각 참고 이미지를 전혀 볼 수 없다면 사유를 정확하게 보고하고 해당 단계만 보류한다. 허위 열람 완료 금지.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** 6등신 전신 애니 원화. 큰 눈과 부드러운 얼굴·균형 잡힌 팔다리, 손가락·관절·발까지 모두 고품질로 그린다. 얼굴 확대 별도 이미지로 눈매 디테일을 보존하고 비례를 재검토한다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_full/outfit]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **OUTFIT만 생성:** 제공된 BODY 좌표에 옷깃·소매·안감·장식·그림자·숨은 옷감을 정렬한다. 터틀넥·민소매·드레스 등 의상 형태는 허용되나 BODY 피부에 절대 합치지 않는다. BODY 신체를 새로 그리지 않는다.
- 프레임: 정수리부터 발끝까지 전체. 자산 소유 범위에만 적용. 전신 캐릭터 기본 디자인은 6등신을 지향하나 크롭에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY 제공 시 얼굴 비율을 변경하지 않는다.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **live2d_full / outfit** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D Haru arm/outfit swap model** — https://www.live2d.com/en/learn/sample/haru/
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.

### 채울 슬롯
`collar`, `upper_torso_garment`, `sleeve_L`, `sleeve_R`, `cuff_L`, `cuff_R`, `garment_side_L`, `garment_side_R`, `front_back_overlap`, `lower_garment_or_leg_cover_if_requested`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 의상 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 의상의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 의상 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.


## [2026-10-13 v5 live2d_full/outfit 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.

# Live2D 전신 의상만 — 고급 이미지 생성 첫 지시

**ZIP 고유 작업 범위 잠금: live2d_full / outfit**
**제작 대상:** 선택한 의상 한 벌의 옷깃·소매·앞뒤 옷감과 실제 있는 치마/바지/신발·고정 장식.
**범위 밖 금지:** 몸·얼굴·피부·헤어·탈착 소품·원본에 없는 하의를 만들지 않는다.

## 제작 순서
1. 기준 캐릭터의 전신 캔버스·원점·선화·색감·정체성을 유지한다. 기준 몸체를 위치 참조로만 사용하고 선택된 의상 원화 한 장만 먼저 완성한다. 신체 그림은 납품 PNG에 포함하지 않는다.
2. 전신 기준 몸체의 어깨·허리·다리 위치를 참조하고 옷 자체만 그린다. 실제 있는 하의·신발만 포함하며 옷깃 안감·소매/옷자락 안쪽·봉제선·주름·2~3톤 셀 명암을 보완한다. 불투명 의복 가림을 유지한다.
3. 실제 독립 움직임이나 깊이의 차이가 있는 의상의 영역만 RGBA PNG로 추출한다. 숨은 부분도 **이 자산만** 후작화하고 다른 종류 픽셀은 혼입하지 않는다. 모든 PNG는 기준 전신 원화의 동일 캔버스·원점·L/R를 유지한다.
5. `09_VISUAL_ART_QUALITY.md`, `10_ANIME_STYLE.md`, `11_OFFICIAL_IMAGE_EXAMPLES.md`를 적용한다. 애니풍 짙은 가변 외곽선·테이퍼·소재별 2~3단 셀 셰이딩을 적용하되 사용자 지정 스타일을 우선하고 실제 보지 못한 공식 이미지는 봤다고 말하지 않는다.
6. `02_ADVANCED_PARTS.md`와 `07_REVIEW_BEFORE_FINAL_ZIP.md`를 확인하여 부족한 의상 그림만 수정/재생성하고 다시 시각검수한다. `00_MASTER_FIRST.md`, `00_DELIVERY_AND_RECHECK.md`의 납품 요건에 따라 실제 `live2d_full__outfit__ARTWORK.zip`을 최종 제공한다.




## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.live2d.com/en/cubism-editor-tutorials/template/
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** 실제 입힌 옷의 앞/뒤, 소매 좌우, 옷깃, 따로 흔들리는 리본·밑단과 겨드랑이 안쪽. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: live2d_full/outfit; 정수리부터 두 발까지 일관된 6등신. 다른 자산을 새로 제작하지 않는다.
- 1) 해당 자산의 디자인 마스터를 그려 정면 전체 실루엣, 원래 배치·좌우·눈/입·색을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: outfit.back, outfit.front, sleeve.left, sleeve.right; 실제 존재하는 칼라·리본·밑단만. 실제 필요한 역할만 추가하되 홍채·흰자·윗속눈썹처럼 독립 움직임/가림이 필요한 역할은 하나로 합치지 않는다. 팔은 상완·전완·손, 옷은 몸에 붙는 뿌리와 흔들리는 부분을 구분한다.
- 5) `part_art/_order.txt`에 **맨 앞에 보이는 파츠부터 맨 뒤 파츠 순서로** 각 경로를 한 줄씩 적는다. PNG 이름과 경로만 기록하며 PSD, 알파 마스크, 3D 메시, MOC3는 만들지 않는다. 열린 입 `mouth.open`, `mouth.tooth.t`, `mouth.tongue`도 개별로 그려 넣되 **중립 미리보기에는 보이지 않게** 한다.
- 6) 같은 자산에서 두 눈의 좌우, 얼굴 윤곽, 목-턱-몸통, 팔꿈치, 머리뿌리/소매 부착점, 좌우 3/4·측면 참조를 교차 확인한다. **전체 중립 합성은 원래 `outputs/master.png`와 같은 캐릭터 한 명**이어야 한다. 입 중복/눈 통째 이동/가림 구멍/부유 손/원래 선화 상실은 실패다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png. BODY는 `expression_refs/mouth_closed.png` / `expression_refs/mouth_open.png`도 첨부하고 입안·치아·혀가 실제로 어떻게 겹치는지 명확히 묘사한다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 옷깃·소매·안감·등 뒤 겹침을 참고 시점 그림으로 보여준다.
- **지침 충돌 해결:** 과거 다른 문서의 '개별 파츠 PNG 금지/완성 PNG 한 장만/파츠는 무조건 Colab에서 전부 분리'는 이 최신 계약으로 대체한다. **이미지 AI는 파츠별 그림까지 직접 생성하지만, PSD 인코딩·메시·키폼·리깅은 절대 생성하지 않는다.** 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

### 실제 대형 이미지 AI 생성 → 고품질 원화 승인 → 다각도 → 분리 (최상위 품질 규칙)
- **작업 순서 강제:** 기존 14개 MD/이미지 참고 실제 열람 → 대상 자산·구도 확정 → 이미지 생성 AI 기능으로 고품질 기준 마스터 원화 직접 생성 → 마스터를 눈으로 보고 합격/재생성 결정 → 해당 캐릭터의 다각도/표정/숨은 면 실제 이미지 추가 생성 → 개별 파츠 채색 보존 분리·PSD/ZIP 조립 → 실제 완성본 시각 검증. 첫 번째 이미지 품질 통과 전에 PSD·파츠 개수 맞추기부터 하지 않는다.
- **이미지 생성 방식:** 마스터와 시점 원화의 **그림 자체를 생성형 이미지 모델로 그린다**. Python/Pillow/cairoSVG/SVG path/ellipse/rectangle/polygon/HTML Canvas/Matplotlib 좌표로 캐릭터의 얼굴·팔·손·헤어·옷을 조합하여 이미지로 출력한 것, 벡터 아이콘/교재용 도형/프록시는 **불합격**이다. 기존 벡터 도형 그림에 그림자·그라데이션만 더해도 불합격이다. 코드·스크립트는 완성도 높은 **실제 생성 원화**를 PSD·마스크·레이어로 가공/검증할 때만 사용한다. 이미지 생성 기능을 못 썼다면 코드로 대체하여 성공이라고 주장하지 않는다.
- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** 6등신 전신 애니 원화. 큰 눈과 부드러운 얼굴·균형 잡힌 팔다리, 손가락·관절·발까지 모두 고품질로 그린다. 얼굴 확대 별도 이미지로 눈매 디테일을 보존하고 비례를 재검토한다.
- **해당 자산의 고품질 제작 조건:** OUTFIT 전용. 지정 의상의 재질/두께/봉제선/주름/안감/깃/소매와 입체 겹침을 숙련된 애니풍으로 새로 그린다. 무늬 없는 직사각형·단색 윤곽 면을 의상으로 가장하지 않고 BODY 피부·눈·얼굴은 납품 파츠에 넣지 않는다.
- **반드시 실제로 비교:** 마스터 원본과 다각도/표정 PNG를 열어 동일 인물·눈매·선 굵기·명암·가림·관절 이음의 일관성을 확인한다. 옆모습은 정면의 미러링/눌러 늘이기가 아니어야 하며, 정면의 분할 이미지를 다른 각도 파일에 복제하는 것은 실패다.
- **결과물:** 완성 마스터는 outputs/master.png, 독립 RGBA 파츠는 isolated_parts/*.png, 실제 가림 순서는 layer_order.txt, 고품질 다각도 원화는 reference_views/에 저장한다. 실제 생성한 원화에서 레이어를 분리하고 세부를 손상시키지 않는다. 편집 가능한 PSD는 고품질 기준 원화와 파츠 분리를 마친 후에 제작한다.
- **반려 기준:** 임시 벡터 도형 사람/투박한 몸통/손가락 없는 손/정면을 압축한 프로필/눈 감김과 입 벌림 원화 누락, 리깅용 목 연결 빈 공간, 이상한 이중 파츠, 낮은 미술 품질, 참조 이미지와 크게 다른 얼굴. 파츠 24개·PNG 9장·PSD 합성 오차 0·ZIP CRC 성공만으로 절대 승인하지 않는다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**live2d_full/outfit 생성 최상위 기준**: 아래 구형 규칙과 충돌하면 이 규칙을 우선한다.
- OUTFIT은 BODY의 큰 머리·둥글고 짧은 얼굴 인상을 유지한다. 과도한 넓은 어깨·소매·칼라로 머리를 작게 보이게 하거나 넥라인 때문에 목이 길어 보이면 실패. 의상 한 벌만 분리, BODY 비율 변경 금지. 터틀넥은 OUTFIT에서만 허용.
- 큰 머리, 큰 눈/홍채, 짧고 폭 넓은 얼굴, 둥근 볼, 부드럽고 짧은 U턱, 작은 코·입을 기본으로 한다. **긴/좁은 얼굴과 말상, 뾰족한 V턱, 성숙·실사 모델 인상은 절대 불합격.**
- 정면 얼굴 세로/가로 약 1.10~1.30은 귀여운 스타일의 권장 출발점이며 절대적인 크롭 수치가 아니다. 전신은 프로젝트 6등신, 상반신/바스트업은 큰 머리 존재감을 유지한다.
- BODY 원본을 제공받았으면 얼굴형·눈 크기·두상·목을 재설계하지 않는다. 2D 원화와 분리 레이어 재합성 이미지 비교.
- 불합격 항목: 머리가 작아 보임, 눈이 작음, 얼굴이 길고 좁음, 뾰족한 턱, 긴 목, 다른 자산 혼입. 눈으로 검사하여 하나라도 발견되면 결과물 납품 금지.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_full/outfit]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **OUTFIT만 생성:** 제공된 BODY 좌표에 옷깃·소매·안감·장식·그림자·숨은 옷감을 정렬한다. 터틀넥·민소매·드레스 등 의상 형태는 허용되나 BODY 피부에 절대 합치지 않는다. BODY 신체를 새로 그리지 않는다.
- 프레임: 정수리부터 발끝까지 전체. 자산 소유 범위에만 적용. 전신 캐릭터 기본 디자인은 6등신을 지향하나 크롭에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY 제공 시 얼굴 비율을 변경하지 않는다.
- 작업절차: 2D는 해당 자산의 완성 원화를 먼저 만든 뒤 필요한 파츠/숨은 면을 분리·보완한다. 실제 다층 PSD·PNG·마스크는 만들고 검증했을 때만 납품 완료로 기록한다.
- 실물 템플릿: 외부 URL이나 비율 도식은 원본 PSD/PNG/3D 템플릿이 아니다. 실제 템플릿 파일이 ZIP에 없으면 없다고 명시한다. 사용자 기준 원화가 있으면 참조한다. 비BODY에 BODY 원본이 없으면 정합 검증 완료를 주장하지 않는다.
- 검증: 원화·미술 품질과 파일 구조를 따로 판정. 비어 있는 파츠나 가려진 영역 미보완, 다른 자산 혼입, 구도 절단은 불합격. 구형 문구로 상반된 지시를 부활시키지 않는다.


## [2026-10-13 v5 live2d_full/outfit 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
OUTFIT: 요청한 옷 한 벌만 별도 제작하고, 기준 BODY에 피부·근육·살접힘을 새로 그리지 않는다. 카라/목깃/소매/옷 주름은 의상 소유 파츠로만 만든다. 기준 BODY와 동일 좌표/캔버스 정합, 움직일 때 필요한 안감/숨은 소매/어깨 이음새, 완성 합성 QA 후 납품. 요청하지 않은 액세서리/신발/다른 옷 강제 금지.

# Live2D 전신 의상 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 실제 의상의 상체 앞·뒷판·카라·양소매와 원본에 있는 하의·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식을 생성하지 않는다. 단, 선택한 의상에 포함된 하의·신발은 의상 파츠로 제작한다.
**그릴 범위:** 전체 캔버스를 기준으로 요청된 의상만. 기존 신체 원화의 목·어깨·팔 위치 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


원단 두께·탄성·솔기를 표현하는 정돈된 테이퍼 선화, 재질별 2~3단 셀 음영과 일관된 주름 방향. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식을 생성하지 않는다. 단, 선택한 의상에 포함된 하의·신발은 의상 파츠로 제작한다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber outfit-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested outfit asset on the reference canvas, no unrelated character parts or props.”

특정 캐릭터의 디자인 복제 금지. 실제 2D 그림까지만, PSD/Cubism 키폼은 사용자가 나중에 처리한다.


## [고급 원화·애니풍 전문 노하우 2026-10-13 / live2d_full / outfit]
Professional anime VTuber FULL LENGTH OUTFIT ONLY, one actual specified garment with authentic collar sleeves seams, actual bottom pieces if present, refined material-specific fabric folds and cel shadows, matching original six-head body canvas; no generated skin hair face unrequested jewelry or shoes.
Crisp tapered outlines, subtle colored inner ink, polished cel shading, consistent original character design.


## [고급 그림자·모근·소재·선폭 | live2d_full/outfit]
Anime VTuber OUTFIT ONLY: user-specified material, tension-driven folds from actual seams and joints, accurate stripe or plaid continuity only if present, believable layered collar and sleeve linings, selective contact lineweight and clean fabric cel shading, check overlaps of optional translucent mesh; no skin, hairstyle, face or separate jewelry.

# Live2D 전신 의상 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 실제 의상의 상체 앞·뒷판·카라·양소매와 원본에 있는 하의·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식을 생성하지 않는다. 단, 선택한 의상에 포함된 하의·신발은 의상 파츠로 제작한다.
**그릴 범위:** 전체 캔버스를 기준으로 요청된 의상만. 기존 신체 원화의 목·어깨·팔 위치 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


원단 두께·탄성·솔기를 표현하는 정돈된 테이퍼 선화, 재질별 2~3단 셀 음영과 일관된 주름 방향. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식을 생성하지 않는다. 단, 선택한 의상에 포함된 하의·신발은 의상 파츠로 제작한다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber outfit-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested outfit asset on the reference canvas, no unrelated character parts or props.”

특정 캐릭터의 디자인 복제 금지. 실제 2D 그림까지만, PSD/Cubism 키폼은 사용자가 나중에 처리한다.


## [고급 원화·애니풍 전문 노하우 2026-10-13 / live2d_full / outfit]
Professional anime VTuber FULL LENGTH OUTFIT ONLY, one actual specified garment with authentic collar sleeves seams, actual bottom pieces if present, refined material-specific fabric folds and cel shadows, matching original six-head body canvas; no generated skin hair face unrequested jewelry or shoes.
Crisp tapered outlines, subtle colored inner ink, polished cel shading, consistent original character design.


## [고급 그림자·모근·소재·선폭 | live2d_full/outfit]
Anime VTuber OUTFIT ONLY: user-specified material, tension-driven folds from actual seams and joints, accurate stripe or plaid continuity only if present, believable layered collar and sleeve linings, selective contact lineweight and clean fabric cel shading, check overlaps of optional translucent mesh; no skin, hairstyle, face or separate jewelry.

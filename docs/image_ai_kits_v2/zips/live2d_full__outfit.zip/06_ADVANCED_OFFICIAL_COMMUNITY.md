# Live2D 전신 의상 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / outfit
**유일한 제작 대상:** 사용자가 선택한 의상 한 벌의 실제 의상의 상체 앞·뒷판·카라·양소매와 원본에 있는 하의·실제로 달린 의상 장식.
**제작 금지:** 새 신체·얼굴·머리카락·귀걸이/목걸이 같은 탈착 장식을 생성하지 않는다. 단, 선택한 의상에 포함된 하의·신발은 의상 파츠로 제작한다.
**그릴 범위:** 전체 캔버스를 기준으로 요청된 의상만. 기존 신체 원화의 목·어깨·팔 위치 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 공식 근거를 이미지 제작에 적용
- 공식 Live2D 파츠 가공: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . 이미지 AI는 실제 의상 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.live2d.com/en/cubism-editor-manual/glue/ . Cubism의 Skinning/Glue/Clipping 등의 기능이 그림 AI가 실제로 ArtMesh나 리깅을 만들었다는 증거는 아니다.
- 옷깃 안쪽, 어깨와 소매 아래 안감·겹침 여유를 추가 작화한다. 좌우 소매, 흔들릴 리본·옷자락만 필요한 만큼 분리한다. 사용자가 요청하지 않은 넥타이·리본·장신구나 전신 바지·치마·신발을 강제하지 않는다.
- 독립 ArtMesh 수나 그림자/하이라이트 PNG 수를 고정하지 않는다. 고정 문양은 본체에, 실제 다른 움직임·앞뒤 순서가 필요한 요소만 나눈다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 미리보기는 실제 파츠를 조립한 그림으로 만들고 기준 몸체는 좌표 참고용으로만 사용한다.
- 커뮤니티 원화 사례: https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ — 개별 작업자 경험이며 공식 필수 조건이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. 공식 PSD 주의사항: https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ .


## [고급 원화·애니풍 전문 노하우 2026-10-13 / live2d_full / outfit]
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ (옷감·카라·리본 선택적 파츠 분리). https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ (후속 Editor 참고).
구별: 6등신·애니풍 채색은 이 프로젝트 디자인 조건이며 Live2D 공식의 필수 비율·톤 수가 아니다. 편집기 리깅/키폼은 이미지 AI 작업이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_full/outfit]
[Live2D 공식 참고] https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 카라·가디건의 움직일 부분은 필요에 따라 분리; 목 자체는 신체 원화. [아티스트 작업 팁] 얼굴과 목 3/4 회전을 참조해 카라 안쪽·뒤칼라와 좌우 목깃에 가려진 옷감을 추가 작화한다.
Live2D/Cubism의 원화 처리 원칙을 참고하되 실제 Cubism 모델·물리·키폼을 이미지 AI에 강제하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_full/outfit]
**[출처 구분]** Live2D 공식은 카라/가디건을 필요에 따라 나누거나 묶을 수 있다고 설명한다: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . **어깨·팔꿈치·허리 등 장력점에서 시작되는 천 주름, 체크무늬/망사의 연결, 반투명 소매 이중 암영 방지**는 전문 일러스트레이터의 미술 설계·검수 기법이며 공식 고정 파츠 구성이나 필수 의상 요소는 아니다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

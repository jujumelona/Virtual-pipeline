# Live2D 전신 / 의상만 결과 그림 ZIP

**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.


> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 기준 원화 먼저 생성 → 2D 원본 분리/3D 참조 확장 → 숨은 부분 보완. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
**`live2d_full__outfit__ARTWORK.zip`**
```text
isolated_parts/outfit_front.png
isolated_parts/outfit_back.png
isolated_parts/sleeve_L_upper.png
isolated_parts/sleeve_R_upper.png
layer_order.txt
previews/overlay_preview.png
```
파일명은 디자인에 실제 있는 부위의 기본 예시. 02에 따라 추가 독립 움직임/깊이 있는 파츠만 원화에서 분리.  모든 PNG는 실제 투명 RGBA·같은 캔버스·원점. `layer_order.txt` 뒤→앞. 실제 파츠를 마지막에 합성.

**07+09+10+11에 따라 실제 애니풍 원화 수준/PNG 요건을 충족할 때만 최종 결과 ZIP을 납품.**

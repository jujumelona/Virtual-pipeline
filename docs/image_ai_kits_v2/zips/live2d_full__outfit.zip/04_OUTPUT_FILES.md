# Live2D 전신 / 의상만 이미지 결과 구조
결과 ZIP: live2d_full__outfit__ARTWORK.zip
isolated_parts/outfit_front.png
isolated_parts/outfit_back.png
isolated_parts/sleeve_L_upper.png
isolated_parts/sleeve_R_upper.png
isolated_parts/skirt_front.png
isolated_parts/skirt_back.png
layer_order.txt
previews/overlay_preview.png
위 파일명은 구조의 예시. 실제 없는 파츠를 만들지 말고 02_ADVANCED_PARTS에 따라 필요한 고급 파츠를 추가하라.
모든 파츠 PNG는 같은 기준 캔버스·원점의 **실제 RGBA 투명 그림**. 시트로 한 번에 생성해도 최종 개별 파일을 각각 납품한다. layer_order.txt에는 뒤→앞 목록만 적는다.
합성 미리보기는 마지막에 실제 파츠로 만들며 합성본을 다시 마스킹하지 않는다. 신체 외 다른 자산은 참조 몸 자체를 다시 만들거나 결과물에 신체 레이어를 섞지 않는다.
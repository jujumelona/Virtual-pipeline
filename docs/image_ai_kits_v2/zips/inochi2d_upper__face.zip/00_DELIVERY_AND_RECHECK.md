# 납품과 재검사

**SOURCE_ART_ONLY_V7 — 이미지 생성 AI 전용.** 이 ZIP에서는 완성 원화와 여러 시점의 참고 원화 PNG만 제작한다. 잘라낸 파츠 PNG, 각 파츠별 재생성, 마스크, 레이어 PSD, 메시, 리깅, MOC3, VRM 완성을 이미지 생성 AI에 절대 요구하지 않는다. **실제 파츠 분리·PSD 생성·리깅은 후속 Colab 노트북의 책임**이며, 노트북의 미구현 기능을 성공으로 표시해서는 안 된다.

허용되는 실제 PNG 파일:

- `outputs/master.png`
- `reference_views/face_front.png`
- `reference_views/head_three_quarter_L.png`
- `reference_views/head_three_quarter_R.png`
- `reference_views/head_profile_L.png`
- `reference_views/head_profile_R.png`
- `reference_views/head_pitch_up.png`
- `reference_views/head_pitch_down.png`
- `reference_views/neck_underpaint.png`
- `reference_views/face_neck_overlap.png`
- `expression_refs/mouth_closed.png`
- `expression_refs/mouth_open.png`

동일 원화를 여러 각도로 이름만 바꿔 납품하지 않는다. 부족한 이미지만 다시 그린다. 최종 ZIP 이름은 `inochi2d_upper__face__ARTWORK.zip`.

## FACE_ONLY_V1
얼굴·눈·귀·코·입·턱·목만 그린다. 몸통·가슴·어깨·팔·손·복부 및 의상은 어떤 참고 이미지에도 그리지 않는다.


## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 독창적인 완성 원화를 처음부터 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **inochi2d_upper / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi Creator official Aka tutorial PSD** — https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
   - 기존 자료 형식: PSD (tutorial cut to head)
   - 실제 활용: Concrete editable head layer and eye/mouth example; DOES NOT include complete arms/torso.
   - 권리 확인: Tutorial source copyright applies; external download only. For full-body parts use a separately licensed reference or original illustration.
- 2. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 기존 자료 형식: INX examples and PSD resources (check each file)
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** upper body through waist/hips with hands
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참조 PSD의 존재는 작화 학습에 도움을 주지만 납품 필수 사용자 첨부물이 아니다. 공개 샘플의 실제 픽셀을 재사용하지 않고 원본 캐릭터를 직접 디자인하며, 완성 마스터에서 편집 가능한 PSD를 만든다. 일러스트 생성/PSD 쓰기 도구가 없으면 그 도구의 한계를 보고한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# Inochi2D 상반신 신체 전문 그림 제작자 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 비공식 실무 — 신체에만 적용
1. 좌우 눈 흰자 뒤를 채우고 홍채/동공/속눈썹의 픽셀 소유권을 분리한다. 열린 입 안쪽과 닫힌 입 선을 동시에 보이지 않게 한다. 턱 뒤 목 피부·좌우 어깨·팔꿈치·손목은 겹침 여유를 둔다. 머리 큰 6등신 기반 애니풍을 유지하면서 실사 골격 음영을 줄인다.
2. 홍채/눈꺼풀/입안 분리, 이중 입 제거, 귀·목·어깨·팔꿈치·손목 hidden fill, 큰 애니 눈과 작은 코·입, 불투명 중립색 도형 프록시 안전 유지.
3. 부위의 양끝/겹침은 납품 파츠 그림 자체 안에서 자연스럽게 이어지게 그린다. 뒷면을 전부 투명 구멍으로 두지 않는다.
4. 독립 움직임이 같은 고정 선화·그림자는 함께 유지하고 실제 다른 움직임/깊이를 가진 그림만 나눈다.
5. 각 파츠 PNG를 밝은 배경과 어두운 배경에서 따로 확대해 알파 프린지·선 잔상·누락된 밑색을 찾는다.
6. 사용자 기준 몸체가 있으면 **참조용으로만** 겹쳐 보고 좌우 L/R은 캐릭터 본인 기준으로 고정한다. 다른 카테고리의 원화·PNG를 만들거나 출력하지 않는다.
7. 작은 방송 화면과 확대 이미지 모두에서 애니풍 명암·선화 가독성을 확인하고 문제가 있으면 실제 그림만 다시 그린다.

## 비공식 참고
https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ ; 정렬·마스킹은 코드로 보조할 수 있지만 기본 도형 SVG/Pillow 그림을 완성 전문 원화로 가장하지 않는다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / body]
큰 홍채·작은 애니풍 코/입·자연스러운 턱과 목, 소재색 내부선/2~3톤 셀 명암을 맞춘다. 입을 하나만 보이게 하며 피부색 가림·홍채 뒤 흰자·턱 뒤 목 underpaint를 확인한다. 손/관절을 조잡한 도형으로 나누지 않는다. 그림자와 피부 하이라이트가 여러 독립 파츠에 복제되어 겹치면 이중 암영이 생기므로 실제 결과에서 수정하고 후속 Inochi Creator의 PSD 그림자 블렌드 조정은 별도 작업으로 구분한다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_upper/body]
[원화 작업/목 회전] 얼굴을 좌우로 돌렸을 때 노출될 **턱 아래 앞목·귀 뒤 옆목·뒷목~어깨/쇄골 피부**를 신체 원화에서 끊김 없이 실제 그린다. 신체 목 파츠 상단을 턱 뒤 **입 높이 부근까지** 덮일 정도로 넉넉히 연장한다. 겉으로 드러난 목을 그만큼 길게 만드는 것이 아니다. 측면에서는 눈을 코 최전면에 붙이지 않고 코받침 뒤/관자놀이 앞에 둔다. 3/4 먼 눈은 정면 가까운 눈 복붙 금지; 코 돌출·귀·턱선과 앞목/뒷목 시작점이 실제 옆얼굴에 맞게 달라져야 한다. 목 안쪽을 마스크 색으로만 메우지 않고 동일한 원화로 보완한다.


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/body]
**[고급 애니풍 신체 원화 작업]** 얼굴 외곽·턱 아래 깊은 겹침은 읽히는 선폭을, 속눈썹 끝·피부색 보조선·입은 필요한 만큼 가는 선을 사용한다. 원본의 검은/채색 선화 취향을 바꾸지 않는다. 분리한 눈·입·목 그림을 단색으로 때우지 말고 원화의 라인·밑색·셀 명암이 파츠 가장자리 안으로 이어지게 새로 그린다. 실제 표정/눈 움직임이 필요한 부위만 선택 분리하며 피부에 머리 모양 그림자를 지워지지 않게 붙이지 않는다.

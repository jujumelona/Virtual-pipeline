## [ART_SOURCE_AND_SEPARATION_V3]
### inochi2d_upper / body — 자산·모드·담당 단계 잠금
- 자산 경계: BODY: 민머리 두상·얼굴 피부·양눈·입·코·귀·목·어깨·몸통 무광 외피·양팔·양손만. 머리카락·패션 의상·장신구 픽셀 0개. BODY 제작 도중 완성 캐릭터 참고 이미지에 보이는 HAIR·OUTFIT·ACCESSORY를 복제하지 않는다. 민머리 완성 BODY만 납품.
- 명시적 생성 제외: BODY에서 머리카락 전부 제외: 앞머리·옆머리·뒷머리·잔머리·묶음머리·포니테일·헤어 장식·머리핀·리본·귀걸이·안경·목걸이·독립 액세서리·패션 의상·옷깃·소매·의복 주름 생성 금지. 민머리 신체 베이스만 만든다. 참조 캐릭터에 머리카락/의상이 보여도 BODY 마스터나 각도·표정 참고 그림에 복사하지 않는다.
- 실물 납품 차단: BODY master 및 정면·3/4·측면·후면 참조에서 머리카락 한 가닥, 헤어핀, 의상 디자인, 독립 장신구가 보이면 CROSS_ASSET_CONTAMINATION: FAIL. 참고 합성본은 별도 previews/로 격리하고 실제 BODY 납품에 섞지 않는다. 실제 눈으로 확인하기 전 PASS 선언 금지; 위반 시 BODY 원화를 수정·재검수.
- 구도 경계: Inochi2D 상반신은 머리부터 허리, 양팔·손 포함. 다리 금지. Inochi2D 독립 노드 준비.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. body 실제 세분화 판단: BODY 필수: 얼굴 바탕(눈·입·귀를 구워 넣지 않음), 귀·눈썹 L/R, 코, 닫힌 입·열린 입안, 목·몸통·상완·전완·손 L/R. 전신만 다리와 발. 양쪽 눈은 각각 eye_L_white, eye_L_iris, eye_L_upper_lash 및 right 대응 세 독립 RGBA 레이어가 필수. 필요할 때 동공·하이라이트·눈꺼풀·아랫속눈썹 추가. eyes라는 한 장짜리 영역·눈 통째 추출·같은 텍스처를 세 파일명으로 복제한 결과는 실패. 홍채 뒤 가려진 흰자까지 실제 픽셀로 보완하고 시선 이동·눈 깜빡임·입 열고 닫기 상태를 각각 합성 검증한다. 실패 시 EYE_MICRO_SPLIT_UNRESOLVED로 차단 후 정밀 마스크 또는 수동 가공. 목 상단은 턱 뒤, 하단은 몸통 아래까지. 어깨·팔꿈치·손목 숨은 면 복원. 얼굴-목-몸통-손 피부색 통일.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

## [FACE_BODY_COLOR_LOCK_V4 / 파츠 원화 생성 강제]
캐릭터 얼굴(홍조·하이라이트·그림자 제외)에서 고른 단 하나의 피부 중간톤 `FACE_SKIN_BASE=#RRGGBB`를 먼저 확정하고, BODY 마스터·각도·표정 참고 원화 생성 요청에는 **실제 HEX 값**과 마스터 참조를 함께 전달한다. 얼굴·귀·두피·목·어깨·몸통 커버의 보이는 기본색·양쪽 상완·전완·양손·손가락·모든 RGB 가림 뒤 연장 픽셀은 같은 베이스색으로 작화한다. 보이는 몸통은 불투명한 무광 비해부학적 가림형 커버로 남기되 **커버의 기본색을 얼굴색과 다르게(회색/보라/라벤더) 만들지 않는다**. 실제 의상 또는 별도 수영복 레이어의 디자인색은 피부가 아니므로 임의로 피부색으로 바꾸지 않는다. 이미 존재하는 보라색 BODY 원화는 정면 마스터 단계에서 얼굴색에 맞게 다시 채색한 뒤 파츠를 자른다. 마스크는 별도 알파 데이터이며 RGB를 회색/흰색으로 덮어 틈을 감추지 않는다. 정면·3/4·측면·고개 상하 모든 뷰에서 동일한 팔레트를 사용한다. 얼굴↔목↔몸통↔상완↔전완↔손의 각 연결부를 **합성 이미지로 확인**, 베이스색이 분리되면 `COLOR_CONTINUITY_FAIL` 처리하고 기준 원화를 보정하고 후속 분리 파츠를 재추출·검수할 때까지 해당 단계의 완료를 선언하지 않는다.
## [/FACE_BODY_COLOR_LOCK_V4]

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **inochi2d_upper / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi Creator official Aka tutorial PSD** — https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
   - 실제 활용: Concrete editable head layer and eye/mouth example; DOES NOT include complete arms/torso.
   - 권리 확인: Tutorial source copyright applies; external download only. For full-body parts use a separately licensed reference or original illustration.
- 2. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`

- **구도:** upper body through waist/hips with hands
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 원화가 우선이다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.

# Inochi2D 상반신 신체 전문 그림 제작자 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.


## 비공식 실무 — 신체에만 적용
4. 독립 움직임이 같은 고정 선화·그림자는 함께 유지하고 실제 다른 움직임/깊이를 가진 그림만 나눈다.
6. 사용자 기준 몸체가 있으면 **참조용으로만** 겹쳐 보고 좌우 L/R은 캐릭터 본인 기준으로 고정한다. 다른 카테고리의 원화·PNG를 만들거나 출력하지 않는다.
7. 작은 방송 화면과 확대 이미지 모두에서 애니풍 명암·선화 가독성을 확인하고 문제가 있으면 실제 그림만 다시 그린다.

## 비공식 참고
https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ ; 정렬·마스킹은 코드로 보조할 수 있지만 기본 도형 SVG/Pillow 그림을 완성 전문 원화로 가장하지 않는다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / body]


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_upper/body]


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/body]



## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 외피 베이스색은 반드시 얼굴 피부의 `FACE_SKIN_BASE` 하나로 정한다. 회색·보라·라벤더 등 얼굴과 다른 색을 금지한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [BROADCAST_HANDS_BODY_COLOR_V1]
### 방송용 손·목·소매 접합 실무 순서
**범위 우선순위:** 이 지침은 같은 ZIP의 오래된 '가슴 위까지만', '손이 보일 때만 손' 같은 조건보다 우선한다. BODY 원본의 양손 누락은 허용하지 않는다. 작업 자산 소유권·2D/3D 형식 규칙은 유지한다.
### 상반신 BODY: 실제로 무엇을 완성하고 어떻게 합성할지

- **전체 범위:** 정수리부터 윗배/허리 위와 양손 끝까지의 자연스러운 몸통·양어깨·양팔·양손을 전부 생성한다. 하단·좌우 캔버스 가장자리는 손가락을 자르지 않고 움직임을 위한 여백을 둔다.
- **양손 원화 필수(분리 PNG는 후속):** 손목에서 멈추지 않고 왼손·오른손 각각 손바닥, 엄지, 검지·중지·약지·새끼손가락의 **끝까지 완전한 그림**을 만든다. 양쪽 상완·전완·손은 후속 전문 분리 단계가 각각 독립 RGBA PNG로 추출하고 가려진 접합면을 보정한다. 화면 뒤로 숨기는 것을 '손 생성 완료'라고 기록하지 않는다.
- **방송 기본 자세:** T/A자 팔벌림이 아니라 어깨 힘을 뺀 자연스러운 자세에서 팔꿈치를 편안하게 굽혀 양손을 윗배·몸통 옆쪽 가까이에 배치한다. 두 손을 몸 앞에 둬도 좋으나 얼굴을 가리지 않는다. 좌우 팔 길이·손목 방향·엄지 위치가 실제 같은 사람이어야 한다.
- **마스킹 색 구분:** 색으로 가려진 면을 메우는 BODY 보정용 원화/언더페인트의 **RGB는 주변의 실제 BODY에 보이는 픽셀과 동일하게** 한다. 목·얼굴 아래 피부는 해당 목/얼굴 피부색을, 어깨·몸통 찰흙형 외피의 뒤받침은 실제 외피 베이스색을, 팔꿈치·손목 안쪽은 각각 이어지는 팔/손의 지정색을 사용한다. 몸통 커버·목·팔·손 베이스색이 다르면 마스터부터 수정하여 얼굴과 반드시 동일하게 통일한다. 다만 별도 의복 레이어는 예외다. **임의의 회색·검정·흰색·반창고색으로 틈을 덮지 않는다.** 가장자리는 기존 원화의 셀 명암/선폭을 그대로 이어 그리되 가려지는 단면에 검은 절단선을 새로 긋지 않는다.
- **알파/클리핑 마스크는 다른 것:** 투명도·가림을 정의하는 알파/클리핑 마스크는 채색 피부가 아니다. 마스크 채널은 투명도 데이터로 유지한다. '몸색과 같게'라는 규칙을 알파 채널이나 별도의 회색조 클리핑 마스크에 적용해 불투명으로 덮으면 안 된다. 실제 같은 BODY 색상으로 칠하는 대상은 **보정용 RGB 그림**뿐이다.
- **턱·목·어깨 OFF/ON:** face와 hair를 가린 뒤 part_art/neck.png를 열었을 때 목 위쪽은 턱 양옆 뒤·귀 아래 뒤까지 실제 피부색으로 채워져 있어야 한다. torso를 숨기면 목 아랫단이 가슴 윗면/어깨 아래로 이어져야 한다. 모두 켰을 때 목과 턱 및 어깨 접합에 투명 삼각형이나 검정 이중 테두리가 없고, 옆모습에서 귀 아래→턱 뒤→목 앞·뒷선→어깨로 실제 연속 연결되어야 한다. 3/4/측면 참고 그림만 예쁘게 있고 실제 neck.png가 잘려 있으면 불합격이다.
- **팔 파츠 그림 경계:** 어깨 소켓 안쪽까지 arm.left/right.upper를 실제 외피/피부색으로 연장하고, 팔꿈치 뒤까지 arm.left/right.forearm 윗단을 연장하며, 손목의 숨은 시작부분을 hand.left/right에 실제 손색으로 채운다. 상완→전완→손을 한 번씩 켜고 끄며 색상·선화·가림 순서·자연스러운 길이를 확인한다. 손의 각 다섯 손가락은 만화풍 단순화는 허용하나 벙어리장갑 실루엣·추가 손가락·손가락 잘림은 금지한다.
- **방송 화면 대조:** 원본 전체(양손·윗배 포함)와 방송용 확대 화면(얼굴·목·어깨 위주)을 **별도 미리보기**로 본다. 방송 확대 미리보기에 손이 일부 안 보이더라도 원본·파츠 폴더에서는 완전한 양손을 유지한다. 확대 화면은 컷/카메라 설정이며 손 삭제·프레임 수정 지시가 아니다.
- 실제 2D 검수: (1) 중립 파츠 전체 ON, (2) face/hair OFF 상태에서 neck의 턱 뒤 연장 확인, (3) torso OFF에서 neck 아랫단과 팔 어깨 윗단 확인, (4) forearm OFF+hand ON에서 숨은 손목 그림 확인, (5) 다시 전부 켜 정면·3/4·측면에서 틈 없는 합성을 비교한다. 색이 다른 접합부는 각 원본 BODY 지정 RGB를 복원한다.
## [/BROADCAST_HANDS_BODY_COLOR_V1]

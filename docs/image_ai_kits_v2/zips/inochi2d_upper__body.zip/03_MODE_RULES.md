## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**inochi2d_upper/body 생성 최상위 기준**: 아래 구형 규칙과 충돌하면 이 규칙을 우선한다.
- BODY에서 크고 둥근 머리, 가로폭 넓고 세로 짧은 얼굴, 부드럽고 짧은 U형 턱, 자연스러운 볼, 큰 눈과 홍채를 실제 완성 원화에 구현한다. 길고 좁은 말상·V형 뾰족한 턱·긴 코 밑·긴 목·작은 눈·머리보다 지나치게 넓은 어깨 금지. 민머리 윗두피만 커서 눈이 작아 보이는 것도 실패. 전신은 6등신. 실제 피부의 갈비뼈/쇄골/배꼽/근육 표현 과장 금지. BODY 상의/터틀넥/보디슈트 금지, 최소 가림은 분리.
- 큰 머리, 큰 눈/홍채, 짧고 폭 넓은 얼굴, 둥근 볼, 부드럽고 짧은 U턱, 작은 코·입을 기본으로 한다. **긴/좁은 얼굴과 말상, 뾰족한 V턱, 성숙·실사 모델 인상은 절대 불합격.**
- 정면 얼굴 세로/가로 약 1.10~1.30은 귀여운 스타일의 권장 출발점이며 절대적인 크롭 수치가 아니다. 전신은 프로젝트 6등신, 상반신/바스트업은 큰 머리 존재감을 유지한다.
- BODY 원본을 제공받았으면 얼굴형·눈 크기·두상·목을 재설계하지 않는다. 2D 원화와 분리 레이어 재합성 이미지 비교.
- 불합격 항목: 머리가 작아 보임, 눈이 작음, 얼굴이 길고 좁음, 뾰족한 턱, 긴 목, 다른 자산 혼입. 눈으로 검사하여 하나라도 발견되면 결과물 납품 금지.

## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_upper/body]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 신체와 얼굴만. 큰 눈/홍채·둥근 두상·단순한 애니풍 피부. 근육·늑골·배꼽·쇄골 과장 금지. 목 덮는 상의·터틀넥·보디슈트 금지. 최소 면적 무지 가림만 별도 파츠. 팔과 손 포함. 헤어·의상·소품 불포함.
- 구도: 허리까지 상반신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 실제 PSD·3D 템플릿이 없으면 없다고 알린다. URL 및 그림 도식은 원본 템플릿이 아니다.
- 2D 완성 원화 먼저, 움직임별 분리와 가려진 면 보완, 실제 파일 산출 시에만 납품 완료.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 요청된 자산의 독창적인 원화를 새로 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **inochi2d_upper / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi Creator official Aka tutorial PSD** — https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
   - 기존 자료 형식: PSD (tutorial cut to head)
   - 실제 활용: Concrete editable head layer and eye/mouth example; DOES NOT include complete arms/torso.
   - 권리 확인: Tutorial source copyright applies; external download only. For full-body parts use a separately licensed reference or original illustration.
- 2. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 기존 자료 형식: INX examples and PSD resources (check each file)
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** upper body through waist/hips with hands
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참조 PSD의 존재는 도움이 되지만 납품 필수 사용자 첨부물이 아니다. 공개 샘플 캐릭터의 실제 픽셀을 재사용하지 않고 원본 애니 캐릭터를 직접 디자인하며 완성 마스터에서 편집 가능한 다층 PSD·파츠 PNG·마스크를 만든다. 일러스트 생성/PSD 쓰기 도구가 없으면 그 도구의 한계를 보고한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 inochi2d_upper/body 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
BODY 피부는 도형 프록시가 아니라 실제 완성된 애니풍 채색 원화로 제작한다. 갈비뼈·배꼽·쇄골 등의 상세 해부학 선을 억제한다. 가림은 별도 최소 무지 파츠이며 상의는 OUTFIT에서만 제작한다.

# Inochi2D 상반신 / 신체만의 2D 제작·납품 범위

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


- **프레임:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 머리·얼굴·다리 등은 신체의 외형이나 위치를 판단하기 위한 기준이지 다른 자산 그림을 만들라는 뜻이 아니다.
- **실제 출력:** 얼굴·눈·입·목·상체·양팔·손. 없는 디자인과 독립 움직임이 불필요한 부분은 만들지 않는다.
- 같은 캔버스·좌표·기준 신체/캐릭터 배율을 유지하는 **투명 RGBA PNG**. `isolated_parts/`에는 이 자산의 픽셀만 포함한다.
- `layer_order.txt`는 실제 생성된 해당 자산 PNG 파일명만 캐릭터 본인 기준 L/R·뒤→앞 순으로 기록한다.
- `previews/composite_preview.png`는 실제 파츠를 합성한다. 기준 몸체가 보이는 별도 overlay는 위치 확인용일 뿐 납품 파츠에 신체를 포함시킨 증거가 아니다.
- Inochi Creator의 Node/메시/파라미터/물리·동작 제작은 이미지 AI 출력 계약 밖이다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / body]
상반신은 사용자의 6등신 캐릭터 디자인의 상대 머리·어깨 비례를 참고하여 **보이는 신체/자산만 처음부터 원화**로 그린다. 골반·다리·발의 생성은 강제하지 않는다. 다른 자산은 같은 기준 몸체 캔버스에 맞추되 새 신체 원화를 만들지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_upper/body]
Inochi2D 상반신은 실제 보이는 신체/헤어/옷/소품만. 6등신 기반 상대 비례 참고, 하체·바스트업 별도 화면 점유율 강제 금지.


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/body]
2D 상반신 원화만 만든다. Inochi Creator에서 PSD를 가져올 때 그림자 레이어가 겹칠 수 있어 원화의 중복 그림자·알파를 중립 합성으로 비교하되 노드/Sorting 설정을 실행하거나 인증하라는 뜻이 아니다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** inochi2d_upper / body; BODY — 눈·얼굴·귀·입·목·어깨·관절·손, 전신이면 다리와 발. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: Inochi2D 상반신: 동일 캐릭터의 머리·목·양팔·손·상반신. Cubism 네이티브 파일은 요구하지 않는다.
- 최소 참고 파일 후보: reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png.
- 위 목록은 **최소 작업 기준 후보**이지 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 눈 흰자/홍채/윗아랫눈꺼풀과 속눈썹·눈썹·시선 상태, 정확히 한 개의 입의 열림/닫힘, 턱 뒤에서 입 높이 부근까지 숨겨진 목 피부, 목 아래 몸통, 어깨/팔꿈치/손목의 접합부와 실제 손가락을 필요 수만큼 별도로 그린다. 3/4 먼 눈·코·턱·귀는 정면을 눌러 만든 것이 아닌 새로운 형태로 작화한다.
- 자산 소유권 금지: HAIR·교체 OUTFIT·ACCESSORY를 BODY 완성 자산에 섞지 않는다. 회색 도형, 실사 인체, 길고 좁은 얼굴, 끊긴 목, 두 입, 손 없는 바스트업은 실패다.
- 2D ZIP의 실제 납품은 해당 자산의 기준 마스터 원화, 추가 참고 시점 그림, 독립 RGBA 원화 파츠와 마스크, 합성 미리보기, 편집 가능한 레이어 PSD 및 검수표다. 참고 시점 PNG가 자동으로 모션 키폼·메시가 되지는 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]


## [2026-10-13 v5 inochi2d_upper/body 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
BODY: 얼굴/표정 원화는 짧고 둥근 U형 턱, 둥근 볼, 작은 애니 귀의 내부선 1~2개, 과한 정수리·긴 목 방지. 눈은 크게 하되 홍채색을 기본 분홍/노랑으로 고정하지 않고 사용자 지정값 또는 캐릭터 팔레트로 결정한다. 몸통은 **AI 생성 그림이 아니라** 불투명 중립색 단색 2D 도형 프록시로 만든다. BODY에 속옷·옷·튜브탑·쇄골/가슴/근육/겨드랑이 살접힘/의복 압박 주름이 있으면 FAIL. 별도 코드로 몸체를 만든 뒤 얼굴과 동일 캔버스에서 조립; 코드 실행과 합성 증거 없으면 납품 중단. Inochi Creator 실제 리깅 완료로 표시하지 않는다. 이 ZIP은 상반신 신체 범위로 한정한다.
Inochi2D 공식 자료 https://docs.inochi2d.com/ 와 애니 버튜버 실제 샘플 https://www.live2d.com/en/learn/sample/ 를 *이미지로* 볼 것. Cubism 기능을 Inochi에 요구하지 않음.

# Inochi2D 상반신 신체에만 적용하는 공식 원화 시각 사례

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


- 아래 Live2D 공개 캐릭터 샘플은 **화풍·선화·명암·완성도만 참고**한다. 샘플 전체 캐릭터를 다시 그리거나 body 이외의 신체·헤어·의상을 제작하라는 뜻이 아니다.
- 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스. 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.
- 공식 예시 이미지는 ZIP에 동봉하지 않았다. 열람 불가면 보았다고 주장하지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

화풍 참고용 Live2D 갤러리: https://www.live2d.com/en/learn/sample/ ; **Inochi2D 실제 원화/노드는 별도 엔진**: https://docs.inochi2d.com/en/latest/creator/nodes/node.html . 샘플 외형은 복제하지 않는다.

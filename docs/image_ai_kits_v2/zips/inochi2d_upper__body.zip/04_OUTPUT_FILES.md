# Inochi2D 상반신 / 신체만 결과 그림 ZIP

**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.


> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 기준 원화 먼저 생성 → 2D 원본 분리/3D 참조 확장 → 숨은 부분 보완. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
**`inochi2d_upper__body__ARTWORK.zip`**
```text
isolated_parts/face_skin.png
isolated_parts/nose.png
isolated_parts/ear_L.png
isolated_parts/ear_R.png
isolated_parts/brow_L.png
isolated_parts/brow_R.png
isolated_parts/eye_L_white.png
isolated_parts/eye_L_iris.png
isolated_parts/eye_L_upper_lash.png
isolated_parts/eye_L_lower_lash.png
isolated_parts/eye_R_white.png
isolated_parts/eye_R_iris.png
isolated_parts/eye_R_upper_lash.png
isolated_parts/eye_R_lower_lash.png
isolated_parts/mouth_upper.png
isolated_parts/mouth_lower.png
isolated_parts/mouth_inside.png
isolated_parts/neck.png
isolated_parts/torso.png
isolated_parts/arm_L_upper.png
isolated_parts/arm_L_forearm.png
isolated_parts/hand_L.png
isolated_parts/arm_R_upper.png
isolated_parts/arm_R_forearm.png
isolated_parts/hand_R.png
layer_order.txt
previews/composite_preview.png
```
파일명은 디자인에 실제 있는 부위의 기본 예시. 02에 따라 추가 독립 움직임/깊이 있는 파츠만 원화에서 분리.  모든 PNG는 실제 투명 RGBA·같은 캔버스·원점. `layer_order.txt` 뒤→앞. 실제 파츠를 마지막에 합성.

**07+09+10+11에 따라 실제 애니풍 원화 수준/PNG 요건을 충족할 때만 최종 결과 ZIP을 납품.**


## 7가지 결함을 막기 위한 신체 참조·상태 이미지

아래 파일은 기존 파츠 납품에 **추가**한다. 이름만 있는 플레이스홀더·정면 복사·이미지 미생성은 납품으로 인정하지 않는다.

```text
reference_views/head_front.png
reference_views/head_three_quarter_L.png
reference_views/head_three_quarter_R.png
reference_views/head_profile_L.png
reference_views/head_profile_R.png
previews/mouth_closed.png
previews/mouth_open.png
previews/neck_overlap.png
```

`mouth_closed`는 닫힌 입 한 개만, `mouth_open`은 열린 입 한 개만 합성한 이미지여야 한다. `neck_overlap`에서는 얼굴/몸통 가림을 걷었을 때 목 피부의 실제 연장 그림이 드러나야 한다. **측면 참조 이미지는 Cubism의 측면 키폼을 자동으로 생성하지 않는다.** 후속 Editor 작업을 위한 실제 추가 원화다.

## 실제 6등신 디자인·큰 눈 확인용 참고 원화
`reference_views/body_six_heads_guide.png` — 머리카락을 제외한 정수리~턱 높이 1, 전신 6등신(머리1/상체2/하체3) 구획선·그 캐릭터의 큰 눈을 함께 보여주는 실제 비례 가이드. **상반신 결과에서도 참고 가이드는 전신**이지만 납품할 독립 파츠는 상반신 범위만이다. 7등신 실사 모델에 해당하는 인상을 금지. 이 이미지는 파츠 입력 대신 **작화 기준 참고**이므로 `layer_order.txt`에는 넣지 않는다.

`reference_views/face_large_anime_eyes.png` — 얼굴을 확대한 애니 눈·큰 홍채·아이라인·눈매 참조. 실사 작은 눈/작은 홍채 금지. `eye_L_*` 및 `eye_R_*`의 실제 합성본과 일치하며, 원화의 눈 비례가 실사로 줄어들지 않아야 한다.

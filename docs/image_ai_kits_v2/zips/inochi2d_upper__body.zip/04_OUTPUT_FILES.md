# Inochi2D 상반신 / 신체만 최종 PNG 결과 ZIP

`inochi2d_upper__body__ARTWORK.zip`
```text
inochi2d_upper__body__ARTWORK.zip
  isolated_parts/face_skin.png
  isolated_parts/nose.png
  isolated_parts/ear_L.png
  isolated_parts/ear_R.png
  isolated_parts/brow_L.png
  isolated_parts/brow_R.png
  isolated_parts/eye_L_white.png
  isolated_parts/eye_L_iris.png
  isolated_parts/eye_L_upper_lash.png
  isolated_parts/eye_L_lower_lash.png
  isolated_parts/eye_R_white.png
  isolated_parts/eye_R_iris.png
  isolated_parts/eye_R_upper_lash.png
  isolated_parts/eye_R_lower_lash.png
  isolated_parts/mouth_upper.png
  isolated_parts/mouth_lower.png
  isolated_parts/mouth_inside.png
  isolated_parts/neck.png
  isolated_parts/torso.png
  isolated_parts/arm_L_upper.png
  isolated_parts/arm_L_forearm.png
  isolated_parts/hand_L.png
  isolated_parts/arm_R_upper.png
  isolated_parts/arm_R_forearm.png
  isolated_parts/hand_R.png
  layer_order.txt
  previews/composite_preview.png
```
파츠명 예시이며 실제 없는 물체/부위는 추가하지 않는다. 단, 고급 별도 움직임·가림·깊이가 필요한 그림은 처음부터 개별적으로 완성한다. 각각 **같은 캔버스와 기준 원점의 진짜 투명 RGBA PNG**. `layer_order.txt`에는 실제 그림 뒤→앞 순서를 기록하고 마지막에 PNG 자체로 합성 미리보기 작성. 액세서리 파일명은 사용자가 지정한 그 물건(예: 안경이면 accessory_glasses_main)에 맞춘다.

**`07_REVIEW_BEFORE_FINAL_ZIP.md` + `09_VISUAL_ART_QUALITY.md`에서 미술 수준·신체 비율·명암·선화·숨은 원화·정렬 조건을 만족한 경우에만 최종 결과 ZIP 제공.**

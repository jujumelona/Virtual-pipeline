# Inochi2D 상반신 / 신체만 이미지 납품 구조
결과 ZIP: inochi2d_upper__body__ARTWORK.zip
isolated_parts/face_skin.png
isolated_parts/nose.png
isolated_parts/brow_L.png
isolated_parts/brow_R.png
isolated_parts/eye_L_white.png
isolated_parts/eye_L_iris.png
isolated_parts/eye_L_upper_lash.png
isolated_parts/eye_R_white.png
isolated_parts/eye_R_iris.png
isolated_parts/eye_R_upper_lash.png
isolated_parts/mouth_upper.png
isolated_parts/mouth_lower.png
isolated_parts/mouth_inside.png
isolated_parts/neck.png
isolated_parts/torso.png
isolated_parts/arm_L_upper.png
isolated_parts/arm_L_forearm.png
isolated_parts/hand_L.png
isolated_parts/arm_R_upper.png
isolated_parts/arm_R_forearm.png
isolated_parts/hand_R.png
layer_order.txt
previews/composite_preview.png
명칭은 실제 있는 구성만 사용하며 02의 고급 파츠 필요 시 추가한다. 액세서리 자리 이름 HEADPIECE는 요청 제품 이름으로 바꾼다.
각 PNG는 동일 캔버스/원점의 실제 투명 RGBA, 각 움직임 부위만 포함. 시트는 생성 호출에 활용 가능하나 최종 별도 PNG 필수.
뒤→앞 목록만 쓰고 Inochi 엔진의 노드 sorting 숫자를 이미지 AI가 예측해 작성하게 하지 않는다. 합성은 완성된 파츠를 마지막에 사용한다.
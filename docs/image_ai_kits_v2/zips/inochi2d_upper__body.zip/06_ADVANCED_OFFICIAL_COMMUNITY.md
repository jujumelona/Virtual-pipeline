# Inochi2D 상반신 신체 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 공식 근거를 이미지 제작에 적용
- 공식 Inochi2D Creator 파츠 원화/PSD: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . 이미지 AI는 실제 신체 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . Inochi Creator의 노드·파츠 계층과 메시 조절은 후속 모델링 단계이다. 이미지 AI가 Inochi 네이티브 리깅을 완료했다는 뜻이 아니다.
- 좌우 눈 흰자 뒤를 채우고 홍채/동공/속눈썹의 픽셀 소유권을 분리한다. 열린 입 안쪽과 닫힌 입 선을 동시에 보이지 않게 한다. 턱 뒤 목 피부·좌우 어깨·팔꿈치·손목은 겹침 여유를 둔다. 머리 큰 6등신 기반 애니풍을 유지하면서 실사 골격 음영을 줄인다.
- 독립 ArtMesh 수나 그림자/하이라이트 PNG 수를 고정하지 않는다. 고정 문양은 본체에, 실제 다른 움직임·앞뒤 순서가 필요한 요소만 나눈다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 미리보기는 실제 파츠를 조립한 그림으로 만들고 기준 몸체는 좌표 참고용으로만 사용한다.
- 커뮤니티 원화 사례: https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ — 개별 작업자 경험이며 공식 필수 조건이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. Inochi Creator PSD/Nodes 사용법: https://docs.inochi2d.com/en/latest/creator/nodes/node.html .

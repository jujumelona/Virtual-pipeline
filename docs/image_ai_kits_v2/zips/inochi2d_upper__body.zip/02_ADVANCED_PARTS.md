## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** Inochi2D 상반신. 얼굴과 큰 눈 중심의 손그림 애니풍 세밀함, 자연스러운 어깨·양팔·양손, 턱 뒤 목과 가림 표면을 유지한다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-13 v5 inochi2d_upper/body 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
도형 CPU 예시: `from PIL import Image,ImageDraw; im=Image.new('RGBA',(1024,1536),(0,0,0,0)); d=ImageDraw.Draw(im); d.rectangle((444,700,580,980),fill=(193,197,203,255)); d.polygon([(444,850),(340,925),(170,1100),(170,1535),(854,1535),(854,1100),(684,925),(580,850)],fill=(193,197,203,255)); im.save('BODY_flat_proxy.png')`. 얼굴 캔버스와 스케일에 맞춰 보정.


## [최우선·강제] 정확히 6등신 / 큰 애니풍 눈 / 원화 기준

- **전신은 정확히 6등신.** 머리카락을 뺀 정수리~턱 두상 높이를 1로 하고 정수리~발바닥의 키를 **6배**로 설계. 비례 구획의 출발점은 머리 1 : 상체 2 : 하체 3. **6등신에서 벗어난 실사 체형·임의 등신 선택·자동 조정 금지.** 상반신은 6등신 전신 디자인의 머리/목/어깨 비율만 참조한 뒤, 보이는 상반신만 처음부터 원화로 그린다. 전신 가이드를 따로 그려 크롭할 필요는 없다. 고정은 이 프로젝트의 디자인 조건이지 모든 VTuber 캐릭터가 무조건 6등신이라는 일반 법칙이 아니다.
- **눈은 크고 또렷한 애니풍.** 실제 사람 눈에 비해 두 눈의 가로·세로 크기를 충분히 크게 디자인하고 **홍채도 크며 하이라이트·눈꼬리·진한 테이퍼 윗속눈썹이 얼굴의 시선을 지배**한다. 작은 실사 눈, 작은 홍채, 피부와 한 덩어리인 실사 안와/눈꺼풀, 근거 없는 일률적인 눈 폭 퍼센트 제한 **모두 금지**. 애니 참고 그림과 큰 눈 인상을 시각 비교하며 캐릭터 정체성을 유지한다.
- **입·코는 눈보다 작다.** 코는 작은 점/선/얕은 셀 음영, 중립 입은 작고 얇은 애니 선/면. 현실적인 코뼈·콧구멍, 도톰한 실사 입술·주름은 금지. 입은 한 위치의 **하나**; 닫힘/열림은 대체 상태이고 입안·혀·치아는 열린 입 내부만 표현.
- **마네킹형 캐릭터 신체.** 헤어·의상을 나중에 입힐 둥글고 단정한 6등신 불투명 도형 베이스. 갈비뼈·복근·흉근·정교한 쇄골/힘줄·실사 피부 그라데이션 금지. 귀는 간결한 애니 귀 외곽과 최소 안쪽 음영, 목은 자연스럽게 연결하고 몸통·가슴·배는 해부학 음영 없는 불투명 단색 도형.
- **회전 준비.** 턱 아래 목의 숨은 피부를 몸통 아래까지 충분히 연장해 겹치게 그린다. 정면 캐릭터를 비틀거나 대칭 복사한 것을 측면으로 주장하지 않는다. 같은 큰 눈 비율의 좌우 3/4·측면 참조를 **실제로** 추가 작화한다. 6등신 전신 가이드와 측면에서도 동일한 캐릭터일 것.
- **참고 자료:** 6등신 작화 기본 비례 https://atam-academy.com/blog/49102/ ; 공식 Live2D 애니 얼굴·눈/디포머 원화 예제 https://www.live2d.com/en/learn/sample/momose-hiyori/ . 특정 기존 캐릭터를 복제하지 않는다.


**신체 범위:** 얼굴·눈·눈썹·코·입·귀·목·몸통·양팔·손, 전신이면 골반·양다리·발. 사용자에게 헤어/의상/액세서리를 함께 제공하는 세트가 아니다.



|---|---|
| face_skin.png | 이마·양쪽 볼·턱·눈/입 아래의 피부. 눈·입을 겹쳐 그리지 않음 |
| ear_L.png / ear_R.png | 독립 움직임/가림이 있는 귀, 머리카락 아래 드러날 피부 보강 |
| nose.png | 얼굴 피부와 별도 그림인 코/코 그림자; 캐릭터 스타일에 맞춤 |
| brow_L.png / brow_R.png | 각 눈썹 |
| eye_L_white.png / eye_R_white.png | 홍채가 움직여도 드러날 전체 흰자 영역 |
| eye_L_pupil.png / eye_R_pupil.png | 필요할 때 완성 원화에서 동공을 추출 |
| eye_L_upper_lash.png / eye_R_upper_lash.png | 눈 깜빡임용 윗속눈썹 |
| eye_L_lower_lash.png / eye_R_lower_lash.png | 별도 표정 움직임이 있는 아랫속눈썹 |
| eye_L_corner.png / eye_R_corner.png | 눈꼬리 구조가 실제로 독립 변형할 때 추가 |
| eye_L_lid.png / eye_R_lid.png | 눈꺼풀 피부가 움직이며 새로 보일 때 |
| eye_L_highlight.png / eye_R_highlight.png | 별도 조절될 경우만 하이라이트 |
| mouth_upper.png / mouth_lower.png | 위/아래 입술 및 경계 피부 |
| mouth_inside.png | 크고 온전히 그려진 입안. 닫으면 입술 아래로 가려짐 |
| mouth_tongue.png / mouth_upper_teeth.png | 실제 입 열림·표정에서 필요한 경우에만 독립 원화 |

### 몸통·관절 (신체 내부)

|---|---|
| neck.png | 턱 아래에서 고개를 돌려도 끊기지 않도록 숨은 목 부분 충분히 |
| torso.png | 어깨와 팔 아래 몸통. **불투명 실제 애니풍 BODY 피부 베이스 상태**를 포함 |
| arm_L_upper.png / arm_R_upper.png | 어깨·팔꿈치 연결부 겹침을 그려 둠 |
| arm_L_forearm.png / arm_R_forearm.png | 팔꿈치·손목 연장과 손목 접합 고려 |
| hand_L.png / hand_R.png | 실제 손가락 형태; 독립 손가락 포즈가 필요할 때만 세분화 |
| pelvis.png / thigh_L.png / thigh_R.png | **전신에서만**, 골반/양 허벅지 |
| shin_L.png / shin_R.png / foot_L.png / foot_R.png | **전신에서만**, 무릎·발목·발 부분 |


### 실제 생성 순서

완성된 기준 원화 → 얼굴 피부·목·몸통·어깨·팔·전신 하체 → **눈 흰자/홍채/동공/속눈썹/눈꺼풀·눈썹과 코·입술/입안/혀**를 원본에서 추출·가림 보완 → 모든 실제 PNG를 원래 위치에 놓고 **마지막에 합성**.

완성 캐릭터 원화에서 눈·입을 추출하고, 보이지 않았던 영역만 추가 작화한다.

## 긴급 품질 계약: 애니풍 마네킹 신체, 실사 인체 금지

신체만 제작하는 작업은 해부학 교과서나 실제 사람 상반신을 그리는 일이 아니다. 헤어·의상·장식이 추후 장착되는 **고품질 애니풍 2D 버추얼 캐릭터 원화**를 만든다.

1. 눈에 비해 지나치게 작은 머리·성인 실사 모델 체형·사실적인 긴 몸통/어깨·큰 근육/갈비뼈/가슴 근육/복근/명치/과도한 해부학 표현·섬세한 피부 그라데이션을 절대 채택하지 않는다. 얼굴 피부만 캐릭터 스타일대로 채색하고, 가슴·복부 BODY 프록시는 추가 음영 없이 단색으로 유지한다. 이 프로젝트에서는 전신 6등신(머리1/상체2/하체3)을 반드시 유지한다.
2. 귀는 단순화된 애니풍 귀. 실물 귀 연골·안쪽 주름과 움푹 파인 실사 음영을 재현하지 않는다. 검정에 가까운 가변 테이퍼 선화, 2~3톤 셀 셰이딩, 눈/코/턱과 통일.
3. 기준 합성에 **입 하나만 보인다.** `mouth_close`와 `mouth_open`은 두 입이 아니라 한 위치의 서로 대체되는 상태. 열림 시 닫힌 입선이 남아 이중으로 보이면 해당 그림·레이어 설계를 고친다. `mouth_inside`가 닫힌 입 상태에서 새어나오지 않게 한다.
4. 턱과 몸통을 크게 겹치게 하는 식의 임시 가림이 아닌, 목 상하·양 측면 및 턱 밑 숨은 피부를 실제로 연장해 그린다. 고개 좌우 회전·기울기 때문에 목이 절단된 투명 경계로 드러나지 않게 한다.



## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / body]


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_upper/body]


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/body]

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** inochi2d_upper / body; BODY — 눈·얼굴·귀·입·목·어깨·관절·손, 전신이면 다리와 발. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png.
- 최소 참고 파일 후보: reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 눈 흰자/홍채/윗아랫눈꺼풀과 속눈썹·눈썹·시선 상태, 정확히 한 개의 입의 열림/닫힘, 턱 뒤에서 입 높이 부근까지 숨겨진 목 피부, 목 아래 몸통, 어깨/팔꿈치/손목의 접합부와 실제 손가락을 필요 수만큼 별도로 그린다. 3/4 먼 눈·코·턱·귀는 정면을 눌러 만든 것이 아닌 새로운 형태로 작화한다.
- 자산 소유권 금지: HAIR·교체 OUTFIT·ACCESSORY를 BODY 완성 자산에 섞지 않는다. 회색 도형, 실사 인체, 길고 좁은 얼굴, 끊긴 목, 두 입, 손 없는 바스트업은 실패다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 회색/살구색/중립 파스텔색 등의 균일한 불투명 색 면을 허용한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 2D 후속 Colab에서 See-through가 파츠를 분리하고 PSD2Live가 리깅을 수행한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다. - BODY의 입은 닫힘/벌림을 각각 실제로 그린 expression_refs/mouth_closed.png 및 expression_refs/mouth_open.png도 생성한다. 열린 입에는 입안의 어두운 공간·윗니·혀가 실제로 구별되게 보이고, 다른 얼굴과 위치·선화·색조가 일치해야 한다. 이 둘은 상태별 완성 참고 원화이며 PSD 레이어/마스크가 아니다.
- 목·턱·좌우 어깨·상완·전완·손의 실루엣을 시점마다 정합되게 그린다. 단색 무광 찰흙형 비해부학 BODY를 유지한다. neck_underpaint와 body_joint_overlaps는 **부품이 아니라 목·턱·몸통·어깨의 가림·연결을 설명하는 완성 참고 그림**이다. 정면·좌우 3/4·측면에서 턱 아래 목과 귀 뒤, 목-어깨 접점을 보여준다. 정면 그림을 늘이거나 머리만 좌우 이동해 옆모습으로 속이지 않는다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

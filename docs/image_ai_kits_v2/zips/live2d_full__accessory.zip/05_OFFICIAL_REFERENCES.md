# live2d_full / accessory — 해당 엔진·자산 공식 근거

> 00_MASTER_FIRST.md의 완성 원화 우선 계약을 따른다. Cubism Editor 실행/리깅은 이 ZIP의 출력물이 아니다.

## 적용 대상: 실제 주문된 액세서리 한 종류
[Live2D 공식 일러스트 가공](https://docs.live2d.com/en/cubism-editor-tutorials/psd/)의 필요한 부위만 분리하고 가린 부분을 보완하는 일반 원칙을 해당 소품에만 적용한다. [Parts 기능](https://docs.live2d.com/en/cubism-editor-manual/edit-parts/)은 후속 정리 참고사항이고 이미지 AI에 Editor 작업을 요구하지 않는다.
실제 납품은 **요청한 물건 하나의 본체·부착 고정부·그 물건에 실제 있는 움직이는 부속**만이다. 안경·귀걸이·헤드셋 예시는 자동 생성 목록이 아니며 인물의 눈·귀·얼굴·헤어를 다시 그리지 않는다.

각 ZIP은 `00_MASTER_FIRST.md`의 자산·모드 범위를 우선한다. 이 문서에 열거된 파일명/예제는 이 프로젝트 산출 기준이지 공식 엔진의 고정 파츠/이미지 개수 규정이 아니다. 링크는 기법의 출처이며 모델링·PSD 처리 도구 실행 및 외부 다운로드/라이선스 확보를 이미지 생성 AI의 필수 단계로 만들지 않는다.

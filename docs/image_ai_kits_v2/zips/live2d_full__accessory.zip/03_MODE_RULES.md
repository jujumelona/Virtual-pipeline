## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_full/accessory]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **ACCESSORY만 생성:** 요청한 장식/부착점/겹침과 필요한 숨은 면만. BODY·얼굴·헤어·의상 전체를 재생성하지 않는다.
- 프레임: 정수리부터 발끝까지 전체. 자산 소유 범위에만 적용. 전신 캐릭터 기본 디자인은 6등신을 지향하나 크롭에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY 제공 시 얼굴 비율을 변경하지 않는다.
- 작업절차: 2D는 해당 자산의 완성 원화를 먼저 만든 뒤 필요한 파츠/숨은 면을 분리·보완한다. 실제 다층 PSD·PNG·마스크는 만들고 검증했을 때만 납품 완료로 기록한다.
- 실물 템플릿: 외부 URL이나 비율 도식은 원본 PSD/PNG/3D 템플릿이 아니다. 실제 템플릿 파일이 ZIP에 없으면 없다고 명시한다. 사용자 기준 원화가 있으면 참조한다. 비BODY에 BODY 원본이 없으면 정합 검증 완료를 주장하지 않는다.
- 검증: 원화·미술 품질과 파일 구조를 따로 판정. 비어 있는 파츠나 가려진 영역 미보완, 다른 자산 혼입, 구도 절단은 불합격. 구형 문구로 상반된 지시를 부활시키지 않는다.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 독창적인 완성 원화를 처음부터 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **live2d_full / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** complete six-head design through feet
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참조 PSD의 존재는 도움이 되지만 납품 필수 사용자 첨부물이 아니다. 공개 샘플 캐릭터의 실제 픽셀을 재사용하지 않고 원본 애니 캐릭터를 직접 디자인하며 완성 마스터에서 편집 가능한 다층 PSD·파츠 PNG·마스크를 만든다. 일러스트 생성/PSD 쓰기 도구가 없으면 그 도구의 한계를 보고한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 live2d_full/accessory 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
ACCESSORY: 요청한 소품 한 종류만 제작, 기준 BODY/HAIR/OUTFIT는 정합을 위한 참조이므로 생성하지 않는다. 부착 앵커·앞/뒤·좌/우·투명 알파 및 얇은 부분 가림, 캔버스/원점 동일성, 합성 미리보기 실제 검수. 소품 예시를 실제 디자인에 강제하지 않는다.

# Live2D 전신 / 액세서리만의 2D 제작·납품 범위

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: live2d_full / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
**그릴 범위:** 전체 캔버스를 기준으로 요청된 액세서리 한 종류만. 기존 몸체·헤어·옷의 장착 위치 좌표만 참조. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


- **프레임:** 전체 캔버스를 기준으로 요청된 액세서리 한 종류만. 머리·얼굴·다리 등은 액세서리의 외형이나 위치를 판단하기 위한 기준이지 다른 자산 그림을 만들라는 뜻이 아니다.
- **실제 출력:** 지정한 소품 한 종류의 본체·필요 연결부·실제 뒷면. 없는 디자인과 독립 움직임이 불필요한 부분은 만들지 않는다.
- 같은 캔버스·좌표·기준 신체/캐릭터 배율을 유지하는 **투명 RGBA PNG**. `isolated_parts/`에는 이 자산의 픽셀만 포함한다.
- `layer_order.txt`는 실제 생성된 해당 자산 PNG 파일명만 캐릭터 본인 기준 L/R·뒤→앞 순으로 기록한다.
- `previews/composite_preview.png`는 실제 파츠를 합성한다. 기준 몸체가 보이는 별도 overlay는 위치 확인용일 뿐 납품 파츠에 신체를 포함시킨 증거가 아니다.
- Live2D Cubism의 ArtMesh/Deformer/키폼/물리/모션/PSD·MOC3 제작은 이미지 AI 출력 계약 밖이다.


## [고급 원화·애니풍 전문 노하우 2026-10-13 / live2d_full / accessory]
정수리~턱 H 대비 전신 6H인 기준 신체는 **이미 주어진 정합 참조**이며 이 accessory ZIP에서 새로 그리지 않는다. 다른 자산은 같은 6등신 기준 캐릭터의 캔버스/원점/앵커에 정렬하지만 **인체 전체를 재생성하지 않는다**. 전신 프레임이라고 없는 묶음머리·치마/바지·신발·귀걸이를 새로 넣지 않는다. 6H 수치는 Live2D 기술적 의무가 아닌 사용자 디자인 조건이다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_full/accessory]
전신 신체는 정수리~턱 H 대비 전체 6H라는 이 프로젝트 디자인 계약을 따른다. 헤어·의상·소품은 그 몸체 원점/실루엣에만 맞추고 신체를 새로 그리지 않는다. 신체의 눈/목 파츠를 이 자산에 추가하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_full/accessory]
전신 신체는 프로젝트의 6등신 설계를 보존한다. 관절·소매·의상 무늬·긴 머리카락의 끝이 실제 있는 구간에서만 연속적인지 확인한다. 타 자산이 신체 전체를 새로 만들지 않는다.

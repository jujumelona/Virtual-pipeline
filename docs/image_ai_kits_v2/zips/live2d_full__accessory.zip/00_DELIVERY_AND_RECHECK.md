# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 live2d_full/accessory 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
   단, 특정 기존 캐릭터·BODY와 동일성을 보존해야 하는데 필수 사용자 참조가 없거나, 실제 시각 참고 이미지를 전혀 볼 수 없다면 사유를 정확하게 보고하고 해당 단계만 보류한다. 허위 열람 완료 금지.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** 6등신 전신 애니 원화. 큰 눈과 부드러운 얼굴·균형 잡힌 팔다리, 손가락·관절·발까지 모두 고품질로 그린다. 얼굴 확대 별도 이미지로 눈매 디테일을 보존하고 비례를 재검토한다.
- **해당 자산의 고품질 제작 조건:** ACCESSORY 전용. 지정 소품의 소재·윤곽·입체 두께·부착점·그림자·가려진 뒷면을 세련된 애니 원화로 그린다. 원/사각형·SVG 선만으로 구성한 임시 표시물을 완성품으로 제출하지 않으며 신체·의상·헤어를 중복 제작하지 않는다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-13 v5 live2d_full/accessory 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
ACCESSORY: 요청한 소품 한 종류만 제작, 기준 BODY/HAIR/OUTFIT는 정합을 위한 참조이므로 생성하지 않는다. 부착 앵커·앞/뒤·좌/우·투명 알파 및 얇은 부분 가림, 캔버스/원점 동일성, 합성 미리보기 실제 검수. 소품 예시를 실제 디자인에 강제하지 않는다.

# 반드시 실제 결과 ZIP까지 제작하고 반복 점검하기

**목표 산출물:** `live2d_full__accessory__ARTWORK.zip`. 이 안내 ZIP을 전달받은 AI는 설명·계획·중간 미리보기만으로 종료하지 않고, 실제 작품 생성과 결과 ZIP 작성을 끝까지 시도한다. 사용자에게 이미 디자인 요구가 있으면 같은 질문을 반복하지 않는다.

## 작업 실행

4. **2차 파일/합성 점검:** 수정된 PNG를 다시 열어 투명도·크기·원점·가림·파일명·실제 합성 일관성을 살펴본다. 3D 참조 이미지라면 전후좌우 디자인 정합과 미리보기 실제 배열을 확인한다.
6. 요청에 해당하는 그림 파일과 미리보기가 준비되면 즉시 `live2d_full__accessory__ARTWORK.zip` 압축을 생성하고, 가능한 경우 **다시 열어 파일 수·이름·열림·이미지 데이터 존재 여부**를 확인한다. 누락·손상 시 고쳐서 새 ZIP으로 다시 압축한다.
7. 최종 답변에는 **실제 만들어진 ZIP 파일을 열 수 있는 링크**를 제공한다. 결과 파일이 있는데 설명만 하고 끝내거나, 그림 시트만 주고 ZIP 작성 단계를 생략하지 않는다.

## 일시적 오류 대응

- 동일 방법이 계속 실패하면 사용할 수 있는 다른 이미지 편집·파일 작성 경로로 진행한다. **OpenArt 등 외부 서비스 연결을 필수 단계로 넣지 않는다.**
- 불필요한 확인 질문·계획 문서·형식적 인증·가짜 ZIP·빈 ZIP은 결과물 대체가 아니다.
- 실제 이용 가능한 이미지 생성/파일 작성 도구가 전혀 없거나 작업 실행이 기술적으로 불가능하다면 완료 또는 ZIP 제공을 **허위로 주장하지 말고 정확한 장애를 알린다**. 지침만으로 없는 도구를 실행하거나 서비스 중단을 막을 수는 없다.



## [필수: 2D 결과 ZIP 레이어 정확성 사전 차단]
최종 결과 ZIP을 작성한 **다음** `04_OUTPUT_FILES.md` Python 검증 코드를 임시 폴더에 저장해 납품할 실제 ZIP을 검사한다. 불합격이면 PNG·명칭·순서를 실제 수정→재압축→재검사한다. 검사 실행 불가 또는 FAIL 상태면 완료라고 선언하지 않는다. 구조 통과와 별도로 원화·합성 미술 검수를 계속한다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** live2d_full / accessory; ACCESSORY — 지정된 부착 소품 한 종류. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 전신: 6등신 스타일의 정수리~발끝, 손·무릎·발목·발 모두 일관성 유지.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 최소 참고 파일 후보: reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: 신체·헤어·의상을 다시 제작하거나 종합 액세서리 세트를 강제로 만들지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 후속 Colab에서 See-through가 파츠를 분리하고 리깅 단계가 사용한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다.
- 소품 부착점과 가려진 뒷면을 참고 시점 그림으로 보여준다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. See-through 분리 이후 리깅 시 실제 관절·가림·회전 연결을 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** 6등신 전신 애니 원화. 큰 눈과 부드러운 얼굴·균형 잡힌 팔다리, 손가락·관절·발까지 모두 고품질로 그린다. 얼굴 확대 별도 이미지로 눈매 디테일을 보존하고 비례를 재검토한다.
- **해당 자산의 고품질 제작 조건:** ACCESSORY 전용. 지정 소품의 소재·윤곽·입체 두께·부착점·그림자·가려진 뒷면을 세련된 애니 원화로 그린다. 원/사각형·SVG 선만으로 구성한 임시 표시물을 완성품으로 제출하지 않으며 신체·의상·헤어를 중복 제작하지 않는다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-13 v5 live2d_full/accessory 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
ACCESSORY: 요청한 소품 한 종류만 제작, 기준 BODY/HAIR/OUTFIT는 정합을 위한 참조이므로 생성하지 않는다. 부착 앵커·앞/뒤·좌/우·투명 알파 및 얇은 부분 가림, 캔버스/원점 동일성, 합성 미리보기 실제 검수. 소품 예시를 실제 디자인에 강제하지 않는다.

# Live2D 전신 액세서리 독립 원화 품질 조건

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_full / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.


- 스타일: 작은 소품에도 분명한 실루엣·소재와 광택, 정확한 부착 구조·가변 선폭·깔끔한 투명 알파.
- 제작 범위: **사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만**. 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
- 원화는 숙련 애니 일러스트레이터의 실물 레이어처럼 선폭 강약·테이퍼·소재별 명암·가림과 실루엣을 유지한다. SVG/Pillow/Matplotlib 도형 인형이나 단순 색면을 실제 완성 이미지로 제출하지 않는다.
- 샘플 https://www.live2d.com/en/learn/sample/ 는 화풍·완성도만 참고한다. 특정 기존 캐릭터 외형을 복제하거나 예시 캐릭터의 옷/헤어/얼굴을 덧그리지 않는다.
- 필요한 그림을 직접 생성·검토하지 못하면 완료를 주장하지 않는다. 최종 ZIP은 해당 자산의 실제 원화·PNG·미리보기로 구성한다.


## [고급 원화·애니풍 전문 노하우 2026-10-13 / live2d_full / accessory]
단일 요청 소품 / 실제 앵커·방향·크기·앞뒤 관계 / 얇은 연결과 알파 / 다른 장식 종류 및 기준 몸체 픽셀 없음.


## [고급 그림자·모근·소재·선폭 | live2d_full/accessory]
**[소품의 고급 완성도]** 부착점과 얇은 연결의 선폭 위계, 실제 재질의 반사와 투명 경계, 축소 시 인식되는 실루엣을 확인한다. 리본·체인·고리·렌즈는 요청한 물건에 존재할 때만 필요한 품질 항목이다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** live2d_full / accessory; ACCESSORY — 지정된 부착 소품 한 종류. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 전신: 6등신 스타일의 정수리~발끝, 손·무릎·발목·발 모두 일관성 유지.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 최소 참고 파일 후보: reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: 신체·헤어·의상을 다시 제작하거나 종합 액세서리 세트를 강제로 만들지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 후속 Colab에서 See-through가 파츠를 분리하고 리깅 단계가 사용한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다.
- 소품 부착점과 가려진 뒷면을 참고 시점 그림으로 보여준다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. See-through 분리 이후 리깅 시 실제 관절·가림·회전 연결을 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

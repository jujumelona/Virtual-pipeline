## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **inochi2d_full / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 기존 자료 형식: INX examples and PSD resources (check each file)
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** complete six-head design through feet
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 inochi2d_full/accessory 적용 최상위 기준]
실제 고품질 애니풍 버튜버 원화 이미지를 열어 시각 비교하고 REFERENCE_NOT_VIEWED인 경우 품질 PASS 금지. 사용자 불합격 사진은 긍정 예시가 아니다. Inochi2D 전신 ACCESSORY는 지정한 액세서리 **한 종류만** 정면/좌우 부착 관계가 일치하도록 만든다. 기준 BODY의 얼굴형·귀·눈·헤어·의상·몸통을 다시 생성하지 않는다. 기준 캐릭터 동일 캔버스·원점·스케일·앵커·알파·가림 순서를 실제 합성 PNG에서 확인한다. Inochi Creator 실제 리깅·노드 적용 완료 주장 금지.

# Inochi2D 전신 / 액세서리만의 2D 제작·납품 범위

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
**그릴 범위:** 전신 캔버스에서 해당 액세서리의 실제 영역만. 기존 몸체·헤어·옷의 장착 위치 좌표만 참조. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


- **프레임:** 전신 캔버스에서 해당 액세서리의 실제 영역만. 머리·얼굴·다리 등은 액세서리의 외형이나 위치를 판단하기 위한 기준이지 다른 자산 그림을 만들라는 뜻이 아니다.
- **실제 출력:** 지정한 소품 한 종류의 본체·필요 연결부·실제 뒷면. 없는 디자인과 독립 움직임이 불필요한 부분은 만들지 않는다.
- 같은 캔버스·좌표·기준 신체/캐릭터 배율을 유지하는 **투명 RGBA PNG**. `isolated_parts/`에는 이 자산의 픽셀만 포함한다.
- `layer_order.txt`는 실제 생성된 해당 자산 PNG 파일명만 캐릭터 본인 기준 L/R·뒤→앞 순으로 기록한다.
- `previews/composite_preview.png`는 실제 파츠를 합성한다. 기준 몸체가 보이는 별도 overlay는 위치 확인용일 뿐 납품 파츠에 신체를 포함시킨 증거가 아니다.
- Inochi Creator의 Node/메시/파라미터/물리·동작 제작은 이미지 AI 출력 계약 밖이다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / accessory]
이미 제공된 신체의 6H 전신 비율은 **기준 좌표로만 참고**하며 이 accessory ZIP에서 새 신체를 그리지 않는다. 헤어·의상·액세서리는 그 몸체의 실제 원점·장착 위치에 맞추는 것이지 6등신 몸체를 새로 그리는 것이 아니다. 의상 하의·신발·묶음머리 등은 실제 디자인에 있을 때만.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_full/accessory]
Inochi2D 전신 신체는 6H 디자인 계약, 다른 자산은 기준 몸체 좌표에 맞추고 신체를 신규 생성하지 않는다. 신체의 눈/목 파츠를 이 자산에 추가하지 않는다.


## [고급 그림자·모근·소재·선폭 | inochi2d_full/accessory]
전신 신체의 6등신·파츠 접합을 유지한다. Inochi2D 합성에서 겹친 투명 음영/소재/소품이 원본보다 짙어지는 위험을 원화 단계에서 점검하고 실제 Creator 편집은 후속 사용자 작업으로 둔다.

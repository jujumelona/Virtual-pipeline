# 참고 이미지 자료

Inochi2D 공식 문서 https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html 및 예제 https://github.com/Inochi2D/example-models : 시각 참고만.

예제 캐릭터의 디자인 자체를 베끼지 않는다. Inochi2D 전신에서 필요한 ACCESSORY 단일 소품 원화만 제작한다. 출력 경로는 04_OUTPUT_FILES.md의 실제 PNG 목록과 일치해야 한다.

## ASSET_ONLY_V1
FACE·OUTFIT을 복제하지 않고 선택한 자산만 그린다.


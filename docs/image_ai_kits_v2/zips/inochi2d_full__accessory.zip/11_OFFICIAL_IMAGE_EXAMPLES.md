
## [2026-10-13 v5 inochi2d_full/accessory 적용 최상위 기준]
실제 고품질 애니풍 버튜버 원화 이미지를 열어 시각 비교하고 REFERENCE_NOT_VIEWED인 경우 품질 PASS 금지. 사용자 불합격 사진은 긍정 예시가 아니다. Inochi2D 전신 ACCESSORY는 지정한 액세서리 **한 종류만** 정면/좌우 부착 관계가 일치하도록 만든다. 기준 BODY의 얼굴형·귀·눈·헤어·의상·몸통을 다시 생성하지 않는다. 기준 캐릭터 동일 캔버스·원점·스케일·앵커·알파·가림 순서를 실제 합성 PNG에서 확인한다. Inochi Creator 실제 리깅·노드 적용 완료 주장 금지.
공식 참고 https://docs.inochi2d.com/ , 실제 버튜버 이미지 https://www.live2d.com/en/learn/sample/ 를 직접 열어 비교한다.

# Inochi2D 전신 액세서리에만 적용하는 공식 원화 시각 사례

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
**그릴 범위:** 전신 캔버스에서 해당 액세서리의 실제 영역만. 기존 몸체·헤어·옷의 장착 위치 좌표만 참조. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


- 아래 Live2D 공개 캐릭터 샘플은 **화풍·선화·명암·완성도만 참고**한다. 샘플 전체 캐릭터를 다시 그리거나 accessory 이외의 신체·헤어·의상을 제작하라는 뜻이 아니다.
- 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만. 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
- 공식 예시 이미지는 ZIP에 동봉하지 않았다. 열람 불가면 보았다고 주장하지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

화풍 참고용 Live2D 갤러리: https://www.live2d.com/en/learn/sample/ ; **Inochi2D 실제 원화/노드는 별도 엔진**: https://docs.inochi2d.com/en/latest/creator/nodes/node.html . 샘플 외형은 복제하지 않는다.

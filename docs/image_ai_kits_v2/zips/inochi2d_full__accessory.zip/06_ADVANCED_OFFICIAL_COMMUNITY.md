## [ART_SOURCE_AND_SEPARATION_V3]
### inochi2d_full / accessory — 자산·모드·담당 단계 잠금
- 자산 경계: ACCESSORY: 지정된 단일 장신구만. BODY·얼굴·눈·피부·헤어·의복 픽셀과 요청하지 않은 다른 장신구는 0개. ACCESSORY 납품물에는 피부·헤어·의복을 복사하지 않는다. 요청 소품 한 종류만.
- 명시적 생성 제외: ACCESSORY에서는 요청된 한 종류의 장신구만. 머리카락·얼굴·눈·피부·몸통·손·의상·요청되지 않은 기타 장식 생성 금지. 장착 위치의 기준 BODY/HAIR/OUTFIT 원화는 참조일 뿐 픽셀 납품 금지.
- 실물 납품 차단: ACCESSORY master/납품 PNG에 머리카락·피부·얼굴·의상 또는 요청되지 않은 추가 소품이 있으면 CROSS_ASSET_CONTAMINATION: FAIL. 기준 캐릭터 합성은 별도 previews/에서만 허용.
- 구도 경계: Inochi2D 전신은 머리부터 발끝까지, 양팔·손·양다리·발 포함. Inochi2D 독립 노드 준비.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. accessory 실제 세분화 판단: ACCESSORY: 실제 요청된 한 장신구의 운동/가림 단위로 분리. 고정 머리핀은 한 레이어 허용, 좌우 귀걸이·안경 다리·움직이는 리본 날개는 별도. 붙어 있는 신체·헤어·옷 픽셀 혼입 금지.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

## [GPT_ARTWORK_SEGMENTER_HANDOFF_V5]
### inochi2d_full / accessory — GPT 마스터 원화에서 실제 분리 AI까지
**최상위 역할 계약. 이 ZIP은 GPT의 원화 생성 지시서이지 GPT에게 PSD·파츠 분리를 시키는 지시서가 아니다.** 모든 14개 MD의 기존 `part_art/`, `_order.txt`, `isolated_parts/`, PSD, 알파, 개별 눈·목 세분화, 합성 검수 지시는 **별도 후속 분리 엔진의 출력/검사 명세**로 해석한다. 이미지 생성 AI가 그 파일을 생성했다고 주장해서는 안 된다.
1. GPT는 `outputs/master.png` **실제 정면 원화 PNG 1장**(RGB 또는 진짜 RGBA)을 생성한다. 콜라주, 부품을 떨어뜨려 배치한 시트, 가짜 투명 PNG, 기존 이미지와 다른 인물로 그린 설정화는 불합격이다.
2. 다음은 투명 파츠가 아닌, 같은 캐릭터의 다른 시점/숨은 부분 참고 원화이다. **각각 별도의 실제 PNG**로 그린다.
  - `reference_views/accessory_front.png`
  - `reference_views/accessory_three_quarter_L.png`
  - `reference_views/accessory_three_quarter_R.png`
  - `reference_views/accessory_profile_L.png`
  - `reference_views/accessory_profile_R.png`
  - `reference_views/accessory_back.png`
  - `reference_views/accessory_attachment_anchor.png`
  - `reference_views/accessory_occlusion.png`
3. 마스터와 front/three_quarter/profile/pitch 참고는 **동일한 원본 캔버스 가로·세로 픽셀 크기, 인물 스케일·중심좌표**를 유지한다. 뷰 이름을 바꾸거나 정면을 복제해 다른 시점으로 위장하지 않는다.
4. **모드 구도:** Inochi2D 전신, 정수리~발끝, 양손·발 포함.
5. **자산 경계:** 사용자가 요청한 한 종류 소품만. 기준 몸체의 부착 위치에 정렬하되 신체/얼굴/머리/의상을 복제하지 않는다.
6. **See-through 분리를 고려한 원화:** 한 이미지에 한 시점·한 캐릭터, 흰색/단순 단색 배경, 선명한 애니 셀 셰이딩/파츠 윤곽·깔끔한 경계; 글자·워터마크·장식 배경·눈 위의 불필요한 손/머리카락 겹침·과도한 발광 금지. 구분을 위해 머리·팔을 물리적으로 잘라 떼어 놓거나 전체 원화 품질을 저하시키지 않는다.
- 현재 자산 외의 BODY/얼굴/눈/의상/장신구 픽셀을 결과 이미지에 합치지 않는다. 원래 캐릭터는 위치·색·디자인 참조로만 사용한다.
7. **GPT 결과물:** `inochi2d_full__accessory__ARTWORK.zip`에 `outputs/master.png`, 위 `reference_views/*.png` 및 BODY에서 `expression_refs/*.png`만 저장한다. `manifest.json`, `layer_order.txt`, `part_art/_order.txt`, `part_art/*.png`, `isolated_parts/`, PSD, MOC3 등 분리/리깅 파일은 생성하지 않는다. 원화 ZIP 납품과 Live2D 완료를 혼동하지 않는다.
8. **후속 파이프라인:** `tools/vts_source_only_pack.py`가 실물 마스터·뷰의 PNG 형식/중복/크기 등을 확인한다. 이후 See-through V3/NF4로 분리 PSD 후보를 만들고, 관찰된 파츠를 공식 좌우/깊이 세분화 또는 SAM 정밀 마스크로 필요 시 개선한다. Qwen-Image-Layered는 기존 런타임에서 해당 자산에 **실제로 연결된 경우에만** 추가 RGBA 분해에 사용한다. Qwen은 텍스트만으로 L/R 홍채·흰자·속눈썹 레이어를 정확히 지정하는 기능을 보장하지 않는다.
9. **후속 검수:** 원본 보이는 RGB 보존, 실제 알파, 가려진 부분 복원, PSD 순서/캔버스 좌표, 좌우 눈 흰자·홍채·속눈썹, 턱-목-몸통·팔-손 접합, 마스터 중립 합성 일치와 변형을 검사한다. 불합격 부위는 분리 작업에서만 재시도/인페인팅하고 GPT가 파츠 시트를 대신 그리게 하지 않는다. 결과 PSD는 Cubism/Inochi2D 모델 리깅/방송 동작 성공을 뜻하지 않는다.
10. 위에 적힌 PNG를 실제 제작할 수 없으면 그 누락을 명확히 보고한다. 분리 엔진 오류는 GPT 원화 생성 완료와 별도로 보고한다.
## [/GPT_ARTWORK_SEGMENTER_HANDOFF_V5]

## [MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
### inochi2d_full / accessory — 24개 자산별 실제 분리 경로
**V5의 GPT 원화 역할을 유지한 채, 후속 분리 AI가 무엇을 어떻게 나눌지 정하는 최신 자산 전용 기준.** 모드·자산을 서로 바꿔 처리하면 실패다.
- 작업 범위: Inochi2D 전신: 머리~양발까지. 하체·관절 세분화 필요, Inochi 네이티브 리깅은 별도.
- 대상 경계: 사용자가 요청한 장식 단 한 종류만. 소품 유형을 모르거나 여러 후보가 섞이면 임의로 headwear 등으로 결정하지 않고 품목 확인/수정 필요.
- **See-through V3의 실제 기본 태그 중 이 자산 관련 항목:** headwear, earwear, eyewear, neckwear, tail, wings, objects. 23개 태그 이외의 파츠 명칭을 모델이 직접 출력한다고 간주하지 않는다.
- **실제 후속 세부 분리·검수 대상:** 사용자가 요청한 한 종류 소품의 독립 본체, 부착점, 다른 파츠 뒤 가려지는 뒷면, 실제 움직임이 필요한 세부
- **V3만으로 불가능/불충분:** headwear/earwear/eyewear/neckwear/tail/wings/objects 중 실제 요청 품목에 해당하는 것만 유효하다. 클래스만으로 정확한 장식 본체·고정점·내부 움직임 파츠를 인증할 수 없다.
- **어떤 엔진이 실제 수행:** 실행 경로: 독립 자산 PNG의 진짜 알파가 있으면 보존; 아니면 단색 배경에서 실물 전경 마스크를 검사해 추출 → 독립 자산 PSD 1개 후보 → 별도 세부 분리·가림 면 보정 필요. **이 자산만 있는 PNG에는 See-through V3 전체 캐릭터용 head crop을 실행하지 않는다.** V3의 의미 태그는 캐릭터 전체 PSD가 별도로 제공된 경우의 참고 카테고리일 뿐이다.
- **완성 조건:** 이미지 생성 GPT가 한 장짜리 가짜 파츠 시트를 만들면 실패. See-through 결과 PSD만 생성되거나 레이어 이름/개수만 맞으면 **분리 성공 아님**. 실제 움직일 파츠의 서로 다른 원본 RGB/알파/레이어/가려진 면이 검증돼야 한다. 실패 항목은 해당 파츠만 정밀 분리·인페인팅하여 재검사하고, 전체 원화를 매번 재생성하지 않는다.
- 3D HAIR/OUTFIT처럼 제작 엔진이 없는 경우 또는 독립 2D 자산의 세부 분리가 남아 있으면 `NOT_YET_RIG_READY`로 명시한다. 중간 PSD를 완성된 방송 모델로 제출 금지.
- 경로 규정의 코드 기준: `tools/vts_segmentation_profiles.py`. Live2D/Inochi2D 실행은 `notebooks/VTuber_Finished_AI_ZIP_All_Modes.ipynb`의 모드/자산 선택을 따른다.
## [/MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
# Inochi2D 전신 액세서리 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.


## 공식 근거를 이미지 제작에 적용
- 공식 Inochi2D Creator 파츠 원화/PSD: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . 이미지 AI는 실제 액세서리 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.inochi2d.com/en/latest/creator/nodes/node.html . Inochi Creator의 노드·파츠 계층과 메시 조절은 후속 모델링 단계이다. 이미지 AI가 Inochi 네이티브 리깅을 완료했다는 뜻이 아니다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. Inochi Creator PSD/Nodes 사용법: https://docs.inochi2d.com/en/latest/creator/nodes/node.html .


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / accessory]
**Inochi2D 공식:** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — PSD 가져오기 예시와 중복 그림자 합성 주의. https://docs.inochi2d.com/en/latest/creator/nodes/node.html — Node 자식 Transform/Sorting은 후속 Creator 작업. **소품 작가 실무:** 실제 주문된 한 물건의 앵커·두께·금속/유리 등 해당 소재의 반사·가림·알파. 이 팁의 고정 수치를 기술 규격이라 주장하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_full/accessory]
[Inochi2D 공식 PSD 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — 개별 소품 원화의 배치와 투명 그림 겹침 참고. [개인 작가] https://tips.clip-studio.com/en-us/articles/8014 — 귀·코·관자놀이의 측면 관계를 **요청한 소품 한 종류의 고정점** 확인에만 사용한다. 피부/눈/목 파츠를 생성하지 않는다.
공식 Inochi Creator PSD 가져오기에서는 그림자 레이어가 중복 합성될 수 있음: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . Node 정렬·블렌드·리깅은 후속 Creator 사용자 작업이다.


## [고급 그림자·모근·소재·선폭 | inochi2d_full/accessory]
**[Inochi2D 공식과 작가 작업 구분]** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html 은 독립 원화 파츠 합성의 참고다. 실제 요청한 체인·끈의 선택적 중립 자세, 가는 금속 윤곽/렌즈 투명 알파 경계 검수는 아티스트용 권고이며 모든 액세서리의 직선화·고정 파츠 수를 요구하지 않는다.
[Inochi2D 공식 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html : PSD 가져오기 이후 그림자 레이어들이 중첩되어 원본과 다르게 보일 수 있다. 이미지 AI는 원본과 각 자산의 투명 RGBA/중립 합성을 점검하고, Creator Node/Sorting/실제 블렌드 설정은 후속 사용자가 수행한다.

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

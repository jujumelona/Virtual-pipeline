# Inochi2D 전신 액세서리 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
**그릴 범위:** 전신 캔버스에서 해당 액세서리의 실제 영역만. 기존 몸체·헤어·옷의 장착 위치 좌표만 참조. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 공식 근거를 이미지 제작에 적용
- 공식 Inochi2D Creator 파츠 원화/PSD: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . 이미지 AI는 실제 액세서리 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.inochi2d.com/en/latest/creator/nodes/node.html . Inochi Creator의 노드·파츠 계층과 메시 조절은 후속 모델링 단계이다. 이미지 AI가 Inochi 네이티브 리깅을 완료했다는 뜻이 아니다.
- 지정 물건의 실제 앵커를 코·귀·머리카락·카라 중 맞는 위치에서 참조한다. 고정부와 흔들릴 부분만 분리하며 프레임·체인·렌즈 등 얇은 알파 영역과 좌우/앞뒤 관계를 정밀하게 보존한다.
- 독립 원화 파츠 수나 그림자/하이라이트 PNG 수를 고정하지 않는다. 고정 문양은 본체에, 실제 다른 움직임·앞뒤 순서가 필요한 요소만 나눈다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 미리보기는 실제 파츠를 조립한 그림으로 만들고 기준 몸체는 좌표 참고용으로만 사용한다.
- 개별 아티스트의 작업 경험은 Inochi2D의 고정 파츠 수나 Cubism 작업 절차를 요구하는 공식 규격이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. Inochi Creator PSD/Nodes 사용법: https://docs.inochi2d.com/en/latest/creator/nodes/node.html .


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / accessory]
**Inochi2D 공식:** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — PSD 가져오기 예시와 중복 그림자 합성 주의. https://docs.inochi2d.com/en/latest/creator/nodes/node.html — Node 자식 Transform/Sorting은 후속 Creator 작업. **소품 작가 실무:** 실제 주문된 한 물건의 앵커·두께·금속/유리 등 해당 소재의 반사·가림·알파. 이 팁의 고정 수치를 기술 규격이라 주장하지 않는다.
**해당 자산:** 사용자가 실제 선택한 액세서리 한 종류의 고정 앵커(코·귀·모근·옷깃·손목 등)와 실제 움직이는 부속 및 숨은 면을 분리한다. 안경/귀걸이/헤드셋/머리핀 등의 목록은 선택지일 뿐 전체 세트를 의미하지 않는다. 프레임·얇은 연결·투명 렌즈·금속 링은 원래 물건에 있을 때만 만든다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_full/accessory]
[Inochi2D 공식 PSD 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — 개별 소품 원화의 배치와 투명 그림 겹침 참고. [개인 작가] https://tips.clip-studio.com/en-us/articles/8014 — 귀·코·관자놀이의 측면 관계를 **요청한 소품 한 종류의 고정점** 확인에만 사용한다. 피부/눈/목 파츠를 생성하지 않는다.
공식 Inochi Creator PSD 가져오기에서는 그림자 레이어가 중복 합성될 수 있음: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . Node 정렬·블렌드·리깅은 후속 Creator 사용자 작업이다.


## [고급 그림자·모근·소재·선폭 | inochi2d_full/accessory]
**[Inochi2D 공식과 작가 작업 구분]** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html 은 독립 원화 파츠 합성의 참고다. 실제 요청한 체인·끈의 선택적 중립 자세, 가는 금속 윤곽/렌즈 투명 알파 경계 검수는 아티스트용 권고이며 모든 액세서리의 직선화·고정 파츠 수를 요구하지 않는다.
[Inochi2D 공식 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html : PSD 가져오기 이후 그림자 레이어들이 중첩되어 원본과 다르게 보일 수 있다. 이미지 AI는 원본과 각 자산의 투명 RGBA/중립 합성을 점검하고, Creator Node/Sorting/실제 블렌드 설정은 후속 사용자가 수행한다.

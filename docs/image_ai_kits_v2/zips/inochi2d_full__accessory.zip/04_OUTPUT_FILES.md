# Inochi2D 전신 / 액세서리만 결과 이미지 ZIP

> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 기준 원화 먼저 생성 → 2D 원본 분리/3D 참조 확장 → 숨은 부분 보완. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
`inochi2d_full__accessory__ARTWORK.zip`
```text
isolated_parts/accessory_headpiece_main.png
layer_order.txt
previews/overlay_preview.png
```
파츠명 예시로 실제 있는 부위만 그린다. headpiece는 사용자가 머리장식을 요청한 경우에만 사용. 02의 고급 개별 움직임에 맞춰 파츠 추가, 동일 원점·투명 RGBA, 마지막 합성, 뒤→앞 목록. **07+09+10의 애니풍 품질·파일 조건 확인 후 최종 ZIP 납품**.

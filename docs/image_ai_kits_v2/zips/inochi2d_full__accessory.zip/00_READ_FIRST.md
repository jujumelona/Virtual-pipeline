## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_full/accessory]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 액세서리만 제작. 부착점·가려진 면 보완. 신체·헤어·의상 재생성 금지.
- 구도: 전신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 실제 PSD·3D 템플릿이 없으면 없다고 알린다. URL 및 그림 도식은 원본 템플릿이 아니다.
- 2D 완성 원화 먼저, 움직임별 분리와 가려진 면 보완, 실제 파일 산출 시에만 납품 완료.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.

# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 inochi2d_full/accessory 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지가 **제공된 경우** 실제 이미지를 확인한다. 신규 캐릭터의 경우 사용자 PSD·원화가 없어도 정상이며, 실제 접근 가능한 공개 원화 및 파츠 구조 자료를 참고한다.
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 접근 불가능한 외부 참고 링크는 `unavailable` 상태·원인으로 기록하고 실제 열 수 있는 적절한 다른 공개 그림을 조사해 대체한다. 참고용 외부 PSD 하나를 못 열었다는 이유로 사용자에게 BODY PSD 첨부를 요구하거나 신규 캐릭터 제작을 중단하지 않는다.
   단, 특정 기존 캐릭터·BODY와 동일성을 보존해야 하는데 필수 사용자 참조가 없거나, 실제 시각 참고 이미지를 전혀 볼 수 없다면 사유를 정확하게 보고하고 해당 단계만 보류한다. 허위 열람 완료 금지.
7. 제공된 필수 사용자 자료와 실제 열람 가능한 충분한 참고 이미지의 검토·누락 기록 및 충돌 해결을 마친 뒤 새 캐릭터 원화 한 장 제작. 공개 예제의 캐릭터 픽셀·모양을 그대로 복제하지 않는다. 실제 PSD는 완성 원화에서 파츠 분리·레이어 작성하여 최종 납품한다.
   그 원화의 품질 확인 후 파츠 분리/PSD 제작/합성·최종 ZIP 검수로 진행한다.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 독창적인 완성 원화를 처음부터 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **inochi2d_full / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 기존 자료 형식: INX examples and PSD resources (check each file)
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** complete six-head design through feet
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참조 PSD의 존재는 도움이 되지만 납품 필수 사용자 첨부물이 아니다. 공개 샘플 캐릭터의 실제 픽셀을 재사용하지 않고 원본 애니 캐릭터를 직접 디자인하며 완성 마스터에서 편집 가능한 다층 PSD·파츠 PNG·마스크를 만든다. 일러스트 생성/PSD 쓰기 도구가 없으면 그 도구의 한계를 보고한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 inochi2d_full/accessory 적용 최상위 기준]
실제 고품질 애니풍 버튜버 원화 이미지를 열어 시각 비교하고 REFERENCE_NOT_VIEWED인 경우 품질 PASS 금지. 사용자 불합격 사진은 긍정 예시가 아니다. Inochi2D 전신 ACCESSORY는 지정한 액세서리 **한 종류만** 정면/좌우 부착 관계가 일치하도록 만든다. 기준 BODY의 얼굴형·귀·눈·헤어·의상·몸통을 다시 생성하지 않는다. 기준 캐릭터 동일 캔버스·원점·스케일·앵커·알파·가림 순서를 실제 합성 PNG에서 확인한다. Inochi Creator 실제 리깅·노드 적용 완료 주장 금지.

# Inochi2D 전신 액세서리 전용 — 고품질 첫 원화 지시

**ZIP 고유 작업 범위 잠금: inochi2d_full / accessory**
**제작 대상:** 사용자가 지정한 한 가지 소품의 실제 부착부·본체·필요한 가동 부품.
**범위 외 금지:** 여러 장식 세트·몸·얼굴·헤어·의상·손·발을 새로 그리지 않는다.

## 제작 순서
1. 사용자 기준 전신 캐릭터 원화의 캔버스·원점·색감·선화·좌우를 유지한다. 기준 신체는 위치 참조용으로만 사용하고, 이 ZIP의 액세서리 자체를 한 장의 완성 원화로 먼저 그린다. 참조 신체를 결과 그림에 포함하지 않는다.
2. 기준 전신의 귀·코·머리카락·옷깃 등 해당 장착 위치만 참조한다. 선택된 물건의 고리·체인·프레임·반투명 렌즈 등 실제 있는 부분만 그림으로 제작해 위치·L/R·알파를 맞춘다.
3. 이 액세서리에 실제 존재하고 다른 움직임·깊이·가림이 필요한 부분만 RGBA PNG로 마스킹·추출한다. 가려진 해당 자산 면만 별도로 그려 보완하며 원래 보이는 픽셀을 보존한다.
4. `isolated_parts/`의 투명 PNG는 모두 같은 전체 캔버스/원점이다. `layer_order.txt`에 실제 PNG만 뒤→앞 순으로 기재하고 최종 PNG 합성 미리보기와 원본을 비교한다. 참조 몸체 overlay는 별도 비교용이다.
5. `09_VISUAL_ART_QUALITY.md`·`10_ANIME_STYLE.md`·`11_OFFICIAL_IMAGE_EXAMPLES.md`를 활용하여 애니풍 가변 외곽선·테이퍼·소재별 2~3톤 셀 명암을 정교하게 구현한다. 사용자 지정 스타일 우선, 열람하지 못한 공식 예시는 직접 봤다고 말하지 않는다.
6. `00_MASTER_FIRST.md`, `02_ADVANCED_PARTS.md`, `07_REVIEW_BEFORE_FINAL_ZIP.md`로 오염·누락 파츠를 반복 점검하고 결함만 수정/재생성한다. `00_DELIVERY_AND_RECHECK.md`에 따라 실제 `inochi2d_full__accessory__ARTWORK.zip`을 최종 제작해 제공한다.

**금지:** 이 이미지 AI 지시로 Inochi Creator Node/메시/리깅/키폼/모션·네이티브 내보내기, Live2D Cubism PSD/MOC3 제작, VRM/3D 메시 생성을 완료했다고 주장하지 않는다.

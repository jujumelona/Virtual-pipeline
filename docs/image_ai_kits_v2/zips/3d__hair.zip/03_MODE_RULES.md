## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **3d / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 기존 자료 형식: Interactive 3D app/preset; not PSD and not automatically present in ZIP
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** full-body four-view turnaround
- **입력 요구:** verified_access_to_VRoid_preset_or_licensed_model. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 3d/hair 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D HAIR: 요청한 헤어스타일 하나만 전면/후면/좌/우의 실제 서로 다른 참조 시트로 만든다. 동일한 기준 신체/머리의 형상·높이·얼굴/귀 앵커를 참조하되 신체 원화를 새로 제작하지 않는다. 앞머리·옆머리·뒤머리·모근·가림·헤어 볼륨을 각 뷰에서 정합하고 헤어 장식/의상을 임의 추가하지 않는다.

# 3D 헤어만 다각도 그림 제작 — 2D 파츠 리깅과 구분

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: 3d / hair
**유일한 생성 대상:** 사용자가 정한 헤어스타일 한 종류의 앞/뒤/좌/우 형상과 가닥·모근의 다각도 참조 그림.
**별도 카테고리 생성 금지:** 얼굴·눈·코·입·몸·옷·다른 머리장식이나 액세서리 세트는 새로 그리지 않는다. 몸체 참고는 최종 헤어 뷰에 합치지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


- **views/**: 정면 `views/hair_front.png`, 후면 `views/hair_back.png`, 좌측 `views/hair_left.png`, 우측 `views/hair_right.png`의 실제 다른 시점 그림을 제작한다. 구체적 경로가 다를 경우 `04_OUTPUT_FILES.md`의 파일명을 우선한다.
- **고유 대상:** 정면·후면·좌측·우측 헤어 4면도, 실제 필요한 모근/가닥 구조 참고. 외형에 없는 가닥·속옷·후드·리본·안경 등 다른 카테고리는 요구하지 않는다.
- **기준 정합:** 정면 앞머리 분할·좌우 옆머리·측면 두께·뒤통수 볼륨·가려진 모근·실제 있는 묶음 형태를 각 시점에서 따로 그린다. 전면을 단순 좌우 뒤집어 측면으로 사용하지 않는다. 눈/귀는 부착 위치와 크기 비교에만 참조한다. 애니 헤어의 자연스러운 테이퍼·잔가닥·재질별 하이라이트와 2~3톤 셀 명암을 유지한다.
- **previews/turnaround_sheet.png**는 실제 네 장의 그림을 같은 기준선으로 배열한 비교 결과. 2D 파츠/PSD 파일 대신 3D 자산의 독립적인 네 시점 `views/` 이미지와 실제 `turnaround_sheet.png`를 제출한다.
- 결과는 **참조 그림**이지 3D 메시·VRM·UV·본·리깅·모션 파일이 아니다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / hair]
**3D 참조도 전용:** 이 ZIP은 모델이나 UV가 아닌 같은 자산의 독립된 정면/후면/좌측/우측 참조 원화를 만든다. 6등신은 신체 ZIP의 디자인 조건이고 헤어/의상/소품에는 같은 몸체 기준선을 정렬하는 데만 사용한다. 실제 3D 모델·Rig·SpringBone·VRM이 완성됐다고 주장하지 않는다. 미러링/크롭·라벨만 바꾼 가짜 측면도 금지.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/hair]
3D용은 실제 다른 네 방향의 hair 참조 그림만 생성한다. 기준 6H 신체의 눈·귀·코·목은 소품/헤어/의상 장착 위치를 위한 참고일 뿐 새로 그리지 않는다. 메시·UV·VRM은 이미지 AI 산출물이 아니다.


## [고급 그림자·모근·소재·선폭 | 3d/hair]
그림으로만 전후좌우 독립된 4면도/세부 참조를 만든다. 2D PNG 레이어·PSD 마스크·Multiply 설정을 요구하지 않고, 재질 하이라이트·선폭·관절 기준선이 같은 물건의 다른 시점에서 일치하는지만 검수한다.

# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 3d/hair 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지·예시와 참고 이미지를 **모두 실제 비전으로 연다.**
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 자료 접근이 안 되거나 참고 그림이 보이지 않으면 **생성 중단** 후
   확인할 수 없는 항목을 구체적으로 보고하고 원본 이미지 첨부를 요청한다.
   허위 열람 완료나 임의 참고 그림 대체 금지.
7. 모든 자료가 실제 확인되고 충돌이 해결된 뒤에만 완성 원화 한 장 제작.
   그 원화의 품질 확인 후 파츠 분리/PSD 제작/합성·최종 ZIP 검수로 진행한다.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **3d / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 기존 자료 형식: Interactive 3D app/preset; not PSD and not automatically present in ZIP
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** full-body four-view turnaround
- **입력 요구:** verified_access_to_VRoid_preset_or_licensed_model. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 3d/hair 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D HAIR: 요청한 헤어스타일 하나만 전면/후면/좌/우의 실제 서로 다른 참조 시트로 만든다. 동일한 기준 신체/머리의 형상·높이·얼굴/귀 앵커를 참조하되 신체 원화를 새로 제작하지 않는다. 앞머리·옆머리·뒤머리·모근·가림·헤어 볼륨을 각 뷰에서 정합하고 헤어 장식/의상을 임의 추가하지 않는다.

# 3D 헤어만 — 전후좌우 고급 참조 원화 시작 지시

**ZIP 고유 작업 범위 잠금: 3d / hair**
**그리는 대상:** 요청된 한 헤어스타일의 앞·옆·뒤 가닥·뿌리·볼륨에 대한 실제 전후좌우 4면도.
**다른 자산 금지:** 얼굴·눈·홍채·코·입·몸·옷·독립 장신구의 새 그림을 만들지 않는다.

## 실제 4면도 제작
1. 사용자 지정 헤어 하나의 정면 원화를 먼저 완성한다. 참조 신체·얼굴·옷은 좌표·디자인 정합 확인용이며 납품 그림에 들어가면 안 된다. 사용자 원본의 색·선화·비율·비대칭을 유지한다.
2. 기준 캐릭터의 머리 실루엣·귀·목 위치를 참고하되 참조 몸체는 납품 헤어 4면도에 포함하지 않는다. 머리뿌리·뒤통수 깊이·옆가닥·테이퍼를 네 방향에서 별도로 그린다. 정면 미러·크롭으로 측면을 대체하지 않는다.
3. 정면·후면·좌측면·우측면에서 **이 자산만** 별도로 실제 그림을 생성한다. 정면 크롭·반전·뒤집기·파일명 교체를 측면이라고 제출하지 않는다. 장착 좌표는 기준 신체와 비교하되 기준 신체 픽셀을 복제하지 않는다.
4. `04_OUTPUT_FILES.md`에 지정한 `views/`의 실제 PNG 4장과 필요한 이 자산의 `details/`만 저장한다. 네 장을 같은 크기·기준선·광원·원점에 배열한 `previews/turnaround_sheet.png`를 만든다.
5. `09_VISUAL_ART_QUALITY.md`·`10_ANIME_STYLE.md`·`11_OFFICIAL_IMAGE_EXAMPLES.md`의 애니풍 짙은 가변 외곽선·테이퍼·2~3톤 셀 셰이딩과 캐릭터 고유 디자인을 적용한다. 원격 공식 이미지를 실제 열지 못했으면 봤다고 주장하지 않는다.
6. `00_MASTER_FIRST.md`, `02_ADVANCED_PARTS.md`, `07_REVIEW_BEFORE_FINAL_ZIP.md`로 실제 방향별 형태·가림·부착점의 오류를 찾아 수정·재생성하고 다시 검토한다. `00_DELIVERY_AND_RECHECK.md`에 따라 `3d__hair__ARTWORK.zip`을 최종 제공한다.

**금지:** 그림 외 실제 3D 메시·본·UV·VRM/GLB/FBX·SpringBone·리깅·모션·회전 테스트·PSD/MOC3를 이미지 AI가 실행했다고 주장하지 않는다. 그림이 없으면 완료라고 말하지 않는다.

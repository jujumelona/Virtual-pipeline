## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 독창적인 완성 원화를 처음부터 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **3d / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 기존 자료 형식: Interactive 3D app/preset; not PSD and not automatically present in ZIP
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** full-body four-view turnaround
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참고 프리셋/공식 실제 그림을 확인한 뒤 새로운 캐릭터 전후좌우 원화를 만든다. 3D 이미지 AI 지시 ZIP은 PSD나 VRM 내보내기를 약속하지 않고 턴어라운드 참조 PNG와 시각 검증을 납품한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# 3D 헤어 전문 다각도 제작 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / hair
**유일한 생성 대상:** 사용자가 정한 헤어스타일 한 종류의 앞/뒤/좌/우 형상과 가닥·모근의 다각도 참조 그림.
**별도 카테고리 생성 금지:** 얼굴·눈·코·입·몸·옷·다른 머리장식이나 액세서리 세트는 새로 그리지 않는다. 몸체 참고는 최종 헤어 뷰에 합치지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


## 비공식 3D 레퍼런스 작화 노하우
1. 정면 앞머리 분할·좌우 옆머리·측면 두께·뒤통수 볼륨·가려진 모근·실제 있는 묶음 형태를 각 시점에서 따로 그린다. 전면을 단순 좌우 뒤집어 측면으로 사용하지 않는다. 눈/귀는 부착 위치와 크기 비교에만 참조한다. 애니 헤어의 자연스러운 테이퍼·잔가닥·재질별 하이라이트와 2~3톤 셀 명암을 유지한다.
2. 앞/뒤/좌/우 가닥 흐름·볼륨·모근 위치가 동일 스타일인가? 측면이 미러/크롭이 아닌 깊이 표현인가? 얼굴·몸통 픽셀을 납품하지 않았는가?
3. 정면 기준 높이·원점·중심축·좌우 비대칭과 빛 방향을 고정하고 후면/좌우 시점마다 깊이와 실제 가려진 면을 새로 그린다.
4. 몸체는 위치·체형·장착점 정합용으로만 참조하고 다른 자산 그림을 추가로 생성하지 않는다. 해당 자산만 그림 납품.
5. 큰 실루엣/색/무늬·접합의 방향별 정합을 먼저 확인한 뒤 얇은 선화·셀 명암·해당 헤어의 모근 연결·앞뒤 가닥 층·측면 볼륨을 검수한다..
6. 끝에서 하나의 turnaround_sheet.png로 비교하되 별도의 네 그림을 실제 파일로 보관한다.

## 비공식 참고
https://virmii.com/blog/tutorial/how-to-make-vtuber-reference-sheet (일반적인 시트 제작 경험), https://www.reddit.com/r/Live2D/comments/12nhr9v/ (좌우 명칭 팁만, 3D 공식 규격 아님).


## [2026-10-13 3D 다각도 전문 작화 노하우 / hair]
먼저 정면 실루엣과 후면 모근/부피를 정의하고 옆면에서 실제 머리 두께·머리끝 길이와 겹침을 따로 그린다. 정면을 늘이거나 미러링해서 측면이라고 제공하지 않는다. 가닥 흐름·테이퍼·재질 하이라이트가 전후좌우 같은 머리에서 발생한 것처럼 이어져야 한다. 헤어 메시/커브/VRM과 Hair Physics를 만든 것은 아니며 필요한 상세도는 모근·가닥/실제 묶음으로 한정한다.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/hair]
[4방향 헤어/목 뒤 공간] 정면 모근·측면 귀 앞뒤 가닥·후면 뒷머리 볼륨과 목 위 가닥의 실제 길이/두께가 전후좌우 모두 같은 헤어스타일을 이루어야 한다. 뒷목 피부를 헤어 ZIP에 그리지 않고 머리카락만 해당 머리 중심에 정합한다. 정면 그림을 미러링해 측면도라고 내지 않는다.


## [고급 그림자·모근·소재·선폭 | 3d/hair]
**[전후좌우 머리카락 그림]** 정면 두상의 실제 모근과 머리 덩어리 형태를 기준 삼아 후면/양 측면의 크기·실루엣·굴곡/테이퍼/재질 반사를 독립 작화한다. 가닥 뿌리/속머리 음영을 그리지만 얼굴 위의 이동형 그림자 독립 PSD 레이어를 요구하거나 신체 피부를 생성하지 않는다.

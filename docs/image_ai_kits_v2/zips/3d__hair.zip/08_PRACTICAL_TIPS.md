## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **3d / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 헤어 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 헤어의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **없는 부위:** 없는 헤어 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 해당 자산 원화를 참조, 없으면 헤어 자산 원화 생성) → 슬롯 매핑 → 필수 8방향 원화·가림 세부 1장 실제 제작 → 시점 간 디자인 정합·시각 검수 → 3D 참고 PNG·검증 기록·ZIP.
- **입력이 없는 신규 캐릭터:** 헤어 자산 8방향 참조 PNG 및 가림 세부 1장을 제작한다. 네이티브 VRM 완성은 약속하지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.

# 3D 헤어 전문 다각도 제작 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / hair
**유일한 생성 대상:** 사용자가 정한 헤어스타일 한 종류의 앞/뒤/좌/우 형상과 가닥·모근의 다각도 참조 그림.
**별도 카테고리 생성 금지:** 얼굴·눈·코·입·몸·옷·다른 머리장식이나 액세서리 세트는 새로 그리지 않는다. 몸체 참고는 최종 헤어 뷰에 합치지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


## 비공식 3D 레퍼런스 작화 노하우
2. 앞/뒤/좌/우 가닥 흐름·볼륨·모근 위치가 동일 스타일인가? 측면이 미러/크롭이 아닌 깊이 표현인가? 얼굴·몸통 픽셀을 납품하지 않았는가?
3. 정면 기준 높이·원점·중심축·좌우 비대칭과 빛 방향을 고정하고 후면/좌우 시점마다 깊이와 실제 가려진 면을 새로 그린다.
4. 몸체는 위치·체형·장착점 정합용으로만 참조하고 다른 자산 그림을 추가로 생성하지 않는다. 해당 자산만 그림 납품.
5. 큰 실루엣/색/무늬·접합의 방향별 정합을 먼저 확인한 뒤 얇은 선화·셀 명암·해당 헤어의 모근 연결·앞뒤 가닥 층·측면 볼륨을 검수한다..
6. 끝에서 하나의 turnaround_sheet.png로 비교하되 별도의 네 그림을 실제 파일로 보관한다.

## 비공식 참고
https://virmii.com/blog/tutorial/how-to-make-vtuber-reference-sheet (일반적인 시트 제작 경험), https://www.reddit.com/r/Live2D/comments/12nhr9v/ (좌우 명칭 팁만, 3D 공식 규격 아님).


## [2026-10-13 3D 다각도 전문 작화 노하우 / hair]
먼저 정면 실루엣과 후면 모근/부피를 정의하고 옆면에서 실제 머리 두께·머리끝 길이와 겹침을 따로 그린다. 정면을 늘이거나 미러링해서 측면이라고 제공하지 않는다. 가닥 흐름·테이퍼·재질 하이라이트가 전후좌우 같은 머리에서 발생한 것처럼 이어져야 한다. 헤어 메시/커브/VRM과 Hair Physics를 만든 것은 아니며 필요한 상세도는 모근·가닥/실제 묶음으로 한정한다.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/hair]
[8방향 헤어/목 뒤 공간] 정면 모근·측면 귀 앞뒤 가닥·후면 뒷머리 볼륨과 목 위 가닥의 실제 길이/두께가 전후좌우 모두 같은 헤어스타일을 이루어야 한다. 뒷목 피부를 헤어 ZIP에 그리지 않고 머리카락만 해당 머리 중심에 정합한다. 정면 그림을 미러링해 측면도라고 내지 않는다.


## [고급 그림자·모근·소재·선폭 | 3d/hair]

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** 3d / hair; HAIR — 요청받은 헤어스타일 한 종류의 가닥·후두부·머리뿌리·그림자. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): views/hair_front.png, views/hair_front_three_quarter_L.png, views/hair_left.png, views/hair_back_three_quarter_L.png, views/hair_back.png, views/hair_back_three_quarter_R.png, views/hair_right.png, views/hair_front_three_quarter_R.png, views/hair_detail_occlusion.png.
- 최소 참고 파일 후보: views/hair_front.png, views/hair_front_three_quarter_L.png, views/hair_left.png, views/hair_back_three_quarter_L.png, views/hair_back.png, views/hair_back_three_quarter_R.png, views/hair_right.png, views/hair_front_three_quarter_R.png, views/hair_detail_occlusion.png.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 앞머리/옆머리/뒷머리/아호게 등 독립적으로 움직일 실제 묶음만 생성한다. 앞머리 아래 이마를 머리카락으로 새로 그리면 안 되며, 귀 앞뒤와 정수리·후두부의 숨은 가닥·뿌리·끝의 실제 픽셀을 추가한다. 좌우 프로필 및 후면에서 머리카락 질량·뿌리 방향·가닥 겹침을 정합시킨다.
- 3D의 필수 8방향 원화와 가림 세부 1장은 모두 views/ 폴더의 명시된 정확한 파일명으로 납품한다. reference_views/ 안의 비율·표정 보조 가이드는 필수 턴어라운드를 대체하지 않는다..

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/front.png, views/front_three_quarter_L.png 등 8방향 개별 원화와 views/detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 모발의 뒷면·모근 및 두상 각도 관계를 참고 원화로 명확하게 그린다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

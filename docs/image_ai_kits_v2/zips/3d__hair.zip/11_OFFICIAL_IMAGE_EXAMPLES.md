# 참고 이미지 자료

VRoid Studio https://vroid.com/en/studio : 형태·시점 참고만. VRM 생성은 이미지 AI의 산출 요구가 아니다.

예제 캐릭터의 디자인 자체를 베끼지 않는다. 3D VRM 참조도에서 필요한 HAIR 헤어 원화만 제작한다. 출력 경로는 04_OUTPUT_FILES.md의 실제 PNG 목록과 일치해야 한다.

## ASSET_ONLY_V1
FACE·OUTFIT을 복제하지 않고 선택한 자산만 그린다.


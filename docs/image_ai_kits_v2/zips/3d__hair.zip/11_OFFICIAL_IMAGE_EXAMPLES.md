
## [2026-10-13 v5 3d/hair 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D HAIR: 요청한 헤어스타일 하나만 전면/후면/좌/우의 실제 서로 다른 참조 시트로 만든다. 동일한 기준 신체/머리의 형상·높이·얼굴/귀 앵커를 참조하되 신체 원화를 새로 제작하지 않는다. 앞머리·옆머리·뒤머리·모근·가림·헤어 볼륨을 각 뷰에서 정합하고 헤어 장식/의상을 임의 추가하지 않는다.
3D 관련 공식 참조: https://vrm.dev/en/vrm/how_to_make_vrm/convert_from_humanoid_model/ ; 애니 스타일 실제 시각 참고 https://www.live2d.com/en/learn/sample/ . 외형 복제 금지.

# 3D 헤어 시각 참고 링크 — 다른 자산 생성 근거가 아님

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / hair
**유일한 생성 대상:** 사용자가 정한 헤어스타일 한 종류의 앞/뒤/좌/우 형상과 가닥·모근의 다각도 참조 그림.
**별도 카테고리 생성 금지:** 얼굴·눈·코·입·몸·옷·다른 머리장식이나 액세서리 세트는 새로 그리지 않는다. 몸체 참고는 최종 헤어 뷰에 합치지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


아래 Live2D 캐릭터 샘플은 **애니풍 선화/셀 명암의 미술적 수준만** 참고한다. 이 ZIP은 헤어만 제작하며 샘플 전체 캐릭터를 재생성하지 않는다. 얼굴·눈·코·입·몸·옷·다른 머리장식이나 액세서리 세트는 새로 그리지 않는다. 몸체 참고는 최종 헤어 뷰에 합치지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

공식 시각 샘플: https://www.live2d.com/en/learn/sample/ ; 3D 참고 체계: https://vrm.dev/en/vrm1/humanoid/ ; Blender 참고: https://docs.blender.org/manual/en/latest/modeling/meshes/uv/unwrapping/introduction.html . 외부 그림 자체는 ZIP에 복제하지 않았고 직접 열지 못하면 봤다고 주장하지 않는다.

# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 3d/hair 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지·예시와 참고 이미지를 **모두 실제 비전으로 연다.**
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 자료 접근이 안 되거나 참고 그림이 보이지 않으면 **생성 중단** 후
   확인할 수 없는 항목을 구체적으로 보고하고 원본 이미지 첨부를 요청한다.
   허위 열람 완료나 임의 참고 그림 대체 금지.
7. 모든 자료가 실제 확인되고 충돌이 해결된 뒤에만 완성 원화 한 장 제작.
   그 원화의 품질 확인 후 파츠 분리/PSD 제작/합성·최종 ZIP 검수로 진행한다.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**


## [2026-10-13 v5 3d/hair 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D HAIR: 요청한 헤어스타일 하나만 전면/후면/좌/우의 실제 서로 다른 참조 시트로 만든다. 동일한 기준 신체/머리의 형상·높이·얼굴/귀 앵커를 참조하되 신체 원화를 새로 제작하지 않는다. 앞머리·옆머리·뒤머리·모근·가림·헤어 볼륨을 각 뷰에서 정합하고 헤어 장식/의상을 임의 추가하지 않는다.
3D 관련 공식 참조: https://vrm.dev/en/vrm/how_to_make_vrm/convert_from_humanoid_model/ ; 애니 스타일 실제 시각 참고 https://www.live2d.com/en/learn/sample/ . 외형 복제 금지.

# 3D 헤어 시각 참고 링크 — 다른 자산 생성 근거가 아님

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / hair
**유일한 생성 대상:** 사용자가 정한 헤어스타일 한 종류의 앞/뒤/좌/우 형상과 가닥·모근의 다각도 참조 그림.
**별도 카테고리 생성 금지:** 얼굴·눈·코·입·몸·옷·다른 머리장식이나 액세서리 세트는 새로 그리지 않는다. 몸체 참고는 최종 헤어 뷰에 합치지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


아래 Live2D 캐릭터 샘플은 **애니풍 선화/셀 명암의 미술적 수준만** 참고한다. 이 ZIP은 헤어만 제작하며 샘플 전체 캐릭터를 재생성하지 않는다. 얼굴·눈·코·입·몸·옷·다른 머리장식이나 액세서리 세트는 새로 그리지 않는다. 몸체 참고는 최종 헤어 뷰에 합치지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

공식 시각 샘플: https://www.live2d.com/en/learn/sample/ ; 3D 참고 체계: https://vrm.dev/en/vrm1/humanoid/ ; Blender 참고: https://docs.blender.org/manual/en/latest/modeling/meshes/uv/unwrapping/introduction.html . 외부 그림 자체는 ZIP에 복제하지 않았고 직접 열지 못하면 봤다고 주장하지 않는다.

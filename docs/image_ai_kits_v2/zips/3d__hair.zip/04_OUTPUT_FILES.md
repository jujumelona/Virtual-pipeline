# 3D / 헤어만 최종 그림 납품 ZIP

최종 결과 **`3d__hair__ARTWORK.zip`**

```text
3d__hair__ARTWORK.zip
  views/hair_front.png
  views/hair_back.png
  views/hair_left.png
  views/hair_right.png
  details/hairline_roots.png
  details/hair_strands.png
  previews/turnaround_sheet.png
```

`views/` 4장은 **동일한 실제 물건/캐릭터를 각기 다른 방향에서 생성한 그림**이다. 얼굴·눈·코·입 등 `details/` 그림은 실제 필요한 상세 원화를 **처음부터 별도로** 그리고 전신 확대 크롭으로 대신하지 않는다. 선택 자산에 실제 없는 파츠는 강제하지 않으며 무관한 신체·헤어·액세서리 세트를 생성하지 않는다.

마지막 턴어라운드는 완성 `views/`를 같은 높이·비율의 참고판에 배열해 만든다. **07의 반복 시각·파일 점검에서 적용 가능한 모든 이미지 요구를 충족한 경우에만 최종 결과 ZIP을 제공한다.** 3D 모델 생성/검증을 주장하지 않는다.

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-13 v5 3d/hair 적용 최상위 기준]
3D HAIR: 요청한 헤어스타일 하나만 전면/후면/좌/우의 실제 서로 다른 참조 시트로 만든다. 동일한 기준 신체/머리의 형상·높이·얼굴/귀 앵커를 참조하되 신체 원화를 새로 제작하지 않는다. 앞머리·옆머리·뒤머리·모근·가림·헤어 볼륨을 각 뷰에서 정합하고 헤어 장식/의상을 임의 추가하지 않는다.

# 3D 헤어만 — 요청 헤어스타일의 다각도 상세 그림


기준 캐릭터의 두상/얼굴 이미지를 참고하여 **사용자가 지정한 헤어스타일 하나만** 만든다. 새 몸, 새 의상, 장신구 묶음을 만들지 않는다.

- views/hair_front.png, views/hair_back.png, views/hair_left.png, views/hair_right.png: 같은 헤어의 각 방향 모양·볼륨·헤어라인·가림 깊이를 새 그림으로 각각 만든다.
- details/hairline_roots.png: 이마·옆머리·뒤통수의 머리 뿌리 위치, 부위가 가려져도 연결되는 원화.
- details/hair_strands.png: 앞머리 묶음, 길게 움직이는 가닥/아호게/트윈테일/땋은 머리 등 **사용자 스타일에 실제 있는 요소만** 세부 그림으로.
- previews/turnaround_sheet.png: 위 실제 생성 이미지들을 이용해 마지막에 만드는 다각도 미리보기.

3D 도구가 헤어 메시·커브·SpringBone을 이미 구현했다고 주장하지 않는다. 이미지 AI는 형상과 구조를 설명하는 그림을 제작한다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / hair]
요청된 헤어스타일 **앞·뒤·좌·우 8방향 턴어라운드만** 독립 작화한다. 이마 헤어라인·정수리 모근·좌우 옆가닥·귀 앞뒤 머리 깊이·뒷머리 볼륨과 실제 긴 가닥이 모든 시점에서 하나의 머리 형태로 이어져야 한다. 사용자 기준 몸체의 머리 중심·높이·두상 크기를 참조하되 얼굴·피부·옷은 헤어 이미지 결과에 붙이지 않는다. 없는 포니테일/머리핀 생성 금지.


## [고급 그림자·모근·소재·선폭 | 3d/hair]
**[3D 헤어 시트]** 정면 모근·옆머리·후면 머리 덩어리를 8방향 시점에서 같은 두상 곡면에 붙는 하나의 헤어스타일로 그린다. 옆머리가 턱/볼에서 자라 보이지 않도록 실제 모근의 뒤쪽 연결을 보여준다. 헤어의 재질 하이라이트와 앞뒤 깊이는 8방향 턴어라운드의 색면/선화로만 표현하고 2D용 그림자 레이어를 요구하지 않는다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** 3d / hair; HAIR — 요청받은 헤어스타일 한 종류의 가닥·후두부·머리뿌리·그림자. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): views/hair_front.png, views/hair_front_three_quarter_L.png, views/hair_left.png, views/hair_back_three_quarter_L.png, views/hair_back.png, views/hair_back_three_quarter_R.png, views/hair_right.png, views/hair_front_three_quarter_R.png, views/hair_detail_occlusion.png.
- 최소 참고 파일 후보: views/hair_front.png, views/hair_front_three_quarter_L.png, views/hair_left.png, views/hair_back_three_quarter_L.png, views/hair_back.png, views/hair_back_three_quarter_R.png, views/hair_right.png, views/hair_front_three_quarter_R.png, views/hair_detail_occlusion.png.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 앞머리/옆머리/뒷머리/아호게 등 독립적으로 움직일 실제 묶음만 생성한다. 앞머리 아래 이마를 머리카락으로 새로 그리면 안 되며, 귀 앞뒤와 정수리·후두부의 숨은 가닥·뿌리·끝의 실제 픽셀을 추가한다. 좌우 프로필 및 후면에서 머리카락 질량·뿌리 방향·가닥 겹침을 정합시킨다.
- 3D의 필수 8방향 원화와 가림 세부 1장은 모두 views/ 폴더의 명시된 정확한 파일명으로 납품한다. reference_views/ 안의 비율·표정 보조 가이드는 필수 턴어라운드를 대체하지 않는다..

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/hair_front.png, views/hair_front_three_quarter_L.png 등 8방향 개별 원화와 views/hair_detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 모발의 뒷면·모근 및 두상 각도 관계를 참고 원화로 명확하게 그린다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

# inochi2d_full / body — Inochi2D 해당 자산 공식 근거

> 00_MASTER_FIRST.md의 완성 원화 우선 계약을 따른다. Inochi Creator 실행/노드/리깅은 이 ZIP의 출력물이 아니다.

## 적용 대상: Inochi2D용 신체 원화만
[Inochi Creator 공식 첫 모델](https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html)은 가져온 그림의 파츠 계층과 그림자 중첩 문제를 설명한다. [공식 Node 문서](https://docs.inochi2d.com/en/latest/creator/nodes/node.html)는 후속 상대 정렬의 참고자료다.
이미지 AI는 **선택된 화면 범위 신체 원화, 눈·입·목의 실제 필요한 RGBA 파츠와 합성 미리보기**만 준비한다. Inochi Creator 노드/Sorting/메시/리깅을 수행했다고 주장하지 않는다. 신체 이외의 헤어·패션 의상·소품을 만들지 않는다.

각 ZIP은 `00_MASTER_FIRST.md`의 자산·모드 범위를 우선한다. 이 문서에 열거된 파일명/예제는 이 프로젝트 산출 기준이지 공식 엔진의 고정 파츠/이미지 개수 규정이 아니다. 링크는 기법의 출처이며 모델링·PSD 처리 도구 실행 및 외부 다운로드/라이선스 확보를 이미지 생성 AI의 필수 단계로 만들지 않는다.

# Inochi2D 전신 신체 고급 원화 노하우 — 공식과 비공식 구분

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손·골반·양다리·발과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.
**그릴 범위:** 전신 캔버스에서 머리·상체·양팔·손·골반·양다리·발. 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 공식 근거를 이미지 제작에 적용
- 공식 Inochi2D Creator 파츠 원화/PSD: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . 이미지 AI는 실제 신체 **원화·마스킹·가려진 해당 자산 면**을 제작한다.
- 자산 특화 참고: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . Inochi Creator의 노드·파츠 계층과 메시 조절은 후속 모델링 단계이다. 이미지 AI가 Inochi 네이티브 리깅을 완료했다는 뜻이 아니다.
- 좌우 눈 흰자 뒤를 채우고 홍채/동공/속눈썹의 픽셀 소유권을 분리한다. 열린 입 안쪽과 닫힌 입 선을 동시에 보이지 않게 한다. 턱 뒤 목 피부·좌우 어깨·팔꿈치·손목·무릎·발목은 겹침 여유를 둔다. 머리 큰 6등신 기반 애니풍을 유지하면서 실사 골격 음영을 줄인다.
- 독립 원화 파츠 수나 그림자/하이라이트 PNG 수를 고정하지 않는다. 고정 문양은 본체에, 실제 다른 움직임·앞뒤 순서가 필요한 요소만 나눈다.

## 비공식 제작자 실무
- 숨은 면까지 그림을 연장하고, 개별 RGBA 알파 테두리를 흰색/어두운 배경 모두에서 확인한다.
- 미리보기는 실제 파츠를 조립한 그림으로 만들고 기준 몸체는 좌표 참고용으로만 사용한다.
- 개별 아티스트의 작업 경험은 Inochi2D의 고정 파츠 수나 Cubism 작업 절차를 요구하는 공식 규격이 아니다.
- 공식 및 커뮤니티 링크를 직접 열람하지 못했으면 실제 봤다고 주장하지 않는다. Inochi Creator PSD/Nodes 사용법: https://docs.inochi2d.com/en/latest/creator/nodes/node.html .


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / body]
**Inochi2D 공식:** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — PSD 가져오기 예시와 중복 그림자 합성 주의. https://docs.inochi2d.com/en/latest/creator/nodes/node.html — Node 자식 Transform/Sorting은 후속 Creator 작업. **개인 작가 참고:** https://tips.clip-studio.com/en-us/articles/7379 (캐릭터 얼굴 비율의 스타일별 조정), https://tips.clip-studio.com/en-us/articles/5958 (헤어 덩어리 작화). 이 팁의 고정 수치를 기술 규격이라 주장하지 않는다.
**해당 자산:** 신체만의 애니풍 큰 눈·홍채·눈꺼풀·속눈썹·흰자·입 위아래선/입안·귀·목/어깨를 필요한 움직임 단위로 분리한다. 가려진 흰자·입안·턱 뒤 목·귀 뒤·관절 안쪽 피부를 동일 선화·채색으로 보완한다. 전신 신체에서만 무릎·발목·발까지 다루고 상반신에서 하체는 요구하지 않는다. 신체는 세부 윤곽 없는 중립색 프록시/마스크로 덮는다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_full/body]
[Inochi2D 공식 PSD 가이드] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html — 이미지 원화의 독립 파츠와 그림자 겹침에 관한 후속 가져오기 참고. **눈·입·목 피부를 턱·머리에 가리지 않는 범위까지 여유롭게 보완하는 것**은 원화 작가의 작업 원칙이며 Inochi Creator의 고정 규격은 아니다. [개인 작가 CLIP STUDIO TIPS] https://tips.clip-studio.com/ko-kr/articles/11807 , https://tips.clip-studio.com/ko-kr/articles/6599 , https://tips.clip-studio.com/en-us/articles/8014 — 애니 눈·측면 코·귀의 작화 참고. 눈 수치는 실측 업계 평균이 아닌 프로젝트 추천값이다.
공식 Inochi Creator PSD 가져오기에서는 그림자 레이어가 중복 합성될 수 있음: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html . Node 정렬·블렌드·리깅은 후속 Creator 사용자 작업이다.


## [고급 그림자·모근·소재·선폭 | inochi2d_full/body]
**[Inochi2D 공식과 작업 경험 구분]** https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html 은 PSD 파츠·중복 음영의 후속 가져오기 참고다. 눈꼬리 속눈썹·흰자·입안의 숨은 픽셀을 보완하는 것은 애니 원화의 작업 원칙이다. 피부 고정 그림자와 별도로 이동해야 할 헤어 투사 그림자 소유권 분리는 **선택적 미술 설계**이지 Inochi의 고정 노드/파츠 수 규정이 아니다.
[Inochi2D 공식 예제] https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html : PSD 가져오기 이후 그림자 레이어들이 중첩되어 원본과 다르게 보일 수 있다. 이미지 AI는 원본과 각 자산의 투명 RGBA/중립 합성을 점검하고, Creator Node/Sorting/실제 블렌드 설정은 후속 사용자가 수행한다.

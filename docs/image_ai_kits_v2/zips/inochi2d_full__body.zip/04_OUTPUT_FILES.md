# Inochi2D 전신 / 신체만 결과 이미지 ZIP

**`inochi2d_full__body__ARTWORK.zip`**
```text
inochi2d_full__body__ARTWORK.zip
  isolated_parts/face_skin.png
  isolated_parts/nose.png
  isolated_parts/ear_L.png
  isolated_parts/ear_R.png
  isolated_parts/brow_L.png
  isolated_parts/brow_R.png
  isolated_parts/eye_L_white.png
  isolated_parts/eye_L_iris.png
  isolated_parts/eye_L_upper_lash.png
  isolated_parts/eye_L_lower_lash.png
  isolated_parts/eye_R_white.png
  isolated_parts/eye_R_iris.png
  isolated_parts/eye_R_upper_lash.png
  isolated_parts/eye_R_lower_lash.png
  isolated_parts/mouth_upper.png
  isolated_parts/mouth_lower.png
  isolated_parts/mouth_inside.png
  isolated_parts/neck.png
  isolated_parts/torso.png
  isolated_parts/arm_L_upper.png
  isolated_parts/arm_L_forearm.png
  isolated_parts/hand_L.png
  isolated_parts/arm_R_upper.png
  isolated_parts/arm_R_forearm.png
  isolated_parts/hand_R.png
  isolated_parts/pelvis.png
  isolated_parts/thigh_L.png
  isolated_parts/thigh_R.png
  isolated_parts/shin_L.png
  isolated_parts/shin_R.png
  isolated_parts/foot_L.png
  isolated_parts/foot_R.png
  layer_order.txt
  previews/composite_preview.png
```

예시는 **실제 디자인에 필요한 부위의 이름 예시**로, 없는 파츠를 숫자 맞추기 위해 만들지 않는다. 02·06·08에서 독립 움직임·깊이·가림이 다른 파츠가 추가로 필요하면 **처음부터 별도 원화로 생성**한다.

모든 2D 파츠는 해당 부위만 포함한 **같은 캔버스·원점의 RGBA 투명 PNG**. `layer_order.txt`는 실제 생성된 PNG 상대경로를 뒤→앞으로 중복·누락 없이. 미리보기는 실제 PNG 생성 뒤에 합성한다. 

**07의 반복 시각·파일 점검에서 모든 적용 가능한 요건을 만족하면 그때만 최종 ZIP을 납품**한다. Inochi 모델/PSD·리깅·모션 검증·가짜 인증 파일을 만들지 않는다.

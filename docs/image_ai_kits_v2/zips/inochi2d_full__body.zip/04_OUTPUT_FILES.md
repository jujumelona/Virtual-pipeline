# Inochi2D 전신 / 신체만 결과 ZIP
결과: inochi2d_full__body__ARTWORK.zip
isolated_parts/face_skin.png
isolated_parts/nose.png
isolated_parts/ear_L.png
isolated_parts/ear_R.png
isolated_parts/brow_L.png
isolated_parts/brow_R.png
isolated_parts/eye_L_white.png
isolated_parts/eye_L_iris.png
isolated_parts/eye_L_upper_lash.png
isolated_parts/eye_R_white.png
isolated_parts/eye_R_iris.png
isolated_parts/eye_R_upper_lash.png
isolated_parts/mouth_upper.png
isolated_parts/mouth_lower.png
isolated_parts/mouth_inside.png
isolated_parts/neck.png
isolated_parts/torso.png
isolated_parts/arm_L_upper.png
isolated_parts/arm_L_forearm.png
isolated_parts/hand_L.png
isolated_parts/arm_R_upper.png
isolated_parts/arm_R_forearm.png
isolated_parts/hand_R.png
isolated_parts/pelvis.png
isolated_parts/thigh_L.png
isolated_parts/thigh_R.png
isolated_parts/shin_L.png
isolated_parts/shin_R.png
isolated_parts/foot_L.png
isolated_parts/foot_R.png
layer_order.txt
previews/composite_preview.png
파츠는 서로 다른 움직임/깊이에만 분리. 실제 캐릭터에 없는 부위를 강제하지 않으며 02_ADVANCED_PARTS가 세분화 가이드.
RGBA PNG마다 동일 캔버스 원점에 그 부분만 투명 배경으로. layer_order.txt는 뒤→앞 상대 경로만. Inochi 엔진 내부 sorting 정수와 혼동 금지.
최종 미리보기는 개별 PNG 생성 후 합성. HEADPIECE 등 예시 이름은 사용자 요청대로 치환.
# Inochi2D 전신 / 신체만 결과 이미지 ZIP

**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.


> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 해당 2D 자산의 고품질 완성 기준 원화 먼저 생성 → 같은 캔버스에서 실제 RGBA 파츠만 분리 → 해당 자산의 숨은 면 추가 작화. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
`inochi2d_full__body__ARTWORK.zip`
```text
isolated_parts/face_skin.png
isolated_parts/nose.png
isolated_parts/ear_L.png
isolated_parts/ear_R.png
isolated_parts/brow_L.png
isolated_parts/brow_R.png
isolated_parts/eye_L_white.png
isolated_parts/eye_L_iris.png
isolated_parts/eye_L_upper_lash.png
isolated_parts/eye_L_lower_lash.png
isolated_parts/eye_R_white.png
isolated_parts/eye_R_iris.png
isolated_parts/eye_R_upper_lash.png
isolated_parts/eye_R_lower_lash.png
isolated_parts/mouth_upper.png
isolated_parts/mouth_lower.png
isolated_parts/mouth_inside.png
isolated_parts/neck.png
isolated_parts/torso.png
isolated_parts/arm_L_upper.png
isolated_parts/arm_L_forearm.png
isolated_parts/hand_L.png
isolated_parts/arm_R_upper.png
isolated_parts/arm_R_forearm.png
isolated_parts/hand_R.png
isolated_parts/pelvis.png
isolated_parts/thigh_L.png
isolated_parts/thigh_R.png
isolated_parts/shin_L.png
isolated_parts/shin_R.png
isolated_parts/foot_L.png
isolated_parts/foot_R.png
layer_order.txt
previews/composite_preview.png
```
파츠명 예시로 실제 있는 부위만 그린다. headpiece는 사용자가 머리장식을 요청한 경우에만 사용. 02의 고급 개별 움직임에 맞춰 파츠 추가, 동일 원점·투명 RGBA, 마지막 합성, 뒤→앞 목록. **07+09+10의 애니풍 품질·파일 조건 확인 후 최종 ZIP 납품**.


## 7가지 결함을 막기 위한 신체 참조·상태 이미지

아래 파일은 기존 파츠 납품에 **추가**한다. 이름만 있는 플레이스홀더·정면 복사·이미지 미생성은 납품으로 인정하지 않는다.

```text
reference_views/head_front.png
reference_views/head_three_quarter_L.png
reference_views/head_three_quarter_R.png
reference_views/head_profile_L.png
reference_views/head_profile_R.png
previews/mouth_closed.png
previews/mouth_open.png
previews/neck_overlap.png
```

`mouth_closed`는 닫힌 입 한 개만, `mouth_open`은 열린 입 한 개만 합성한 이미지여야 한다. `neck_overlap`에서는 얼굴/몸통 가림을 걷었을 때 목 피부의 실제 연장 그림이 드러나야 한다. **측면 참조 이미지는 Cubism의 측면 키폼을 자동으로 생성하지 않는다.** 후속 Editor 작업을 위한 실제 추가 원화다.

## 실제 6등신 디자인·큰 눈 확인용 참고 원화
`reference_views/body_six_heads_guide.png` — 머리카락을 제외한 정수리~턱 높이 1, 전신 6등신(머리1/상체2/하체3) 구획선·그 캐릭터의 큰 눈을 함께 보여주는 실제 비례 가이드. 이 ZIP의 납품 범위는 전신 신체이므로 전신 참고 가이드는 실제 전신 파츠의 배치와 일치해야 한다. 7등신 실사 모델에 해당하는 인상을 금지. 이 이미지는 파츠 입력 대신 **작화 기준 참고**이므로 `layer_order.txt`에는 넣지 않는다.

`reference_views/face_large_anime_eyes.png` — 얼굴을 확대한 애니 눈·큰 홍채·아이라인·눈매 참조. 실사 작은 눈/작은 홍채 금지. `eye_L_*` 및 `eye_R_*`의 실제 합성본과 일치하며, 원화의 눈 비례가 실사로 줄어들지 않아야 한다.

**에디션 유의:** 신체 베이스는 Cubism FREE 또는 PRO 중 사용자가 선택한 에디션으로 처리한다. **신체만이라는 이유로 PRO를 강제하지 않는다.** 이미지 AI는 에디션을 임의로 변경하지 않는다.


## ZIP 고유 작업 범위 잠금: inochi2d_full / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손·골반·양다리·발과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.
**그릴 범위:** 전신 캔버스에서 머리·상체·양팔·손·골반·양다리·발. 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 

실제 디자인에 포함된 해당 body 파츠만 isolated_parts/에 납품한다. 몸체와 얼굴은 기준 좌표 참조 전용이며 다른 자산을 재제작하지 않는다.


## [필수: 2D 결과 ZIP 레이어 정확성 사전 차단]
# 2D 제작 AI 최종 ZIP: 레이어 순서·실제 PNG 일치 필수 계약

이 규칙은 Live2D/Inochi2D 2D 지시 ZIP에만 적용한다. 3D에는 적용하지 않는다.
외부 AI가 작성하는 결과 원화 ZIP을 검사하는 규칙이지 지시서 ZIP 자체의 레이어 목록은 아니다.

1. 고품질 기준 원화 `outputs/master.png`를 먼저 만든 다음, 해당 자산의 실제 움직이는 파츠만 분리·숨은 면을 보완한다. 파일명은 각 파츠 원화를 내보낼 때 확정한다. 27개 등 정해진 숫자를 맞추지 않는다.
2. 실제 PNG를 만들 때 작성한 **파츠 계획표**에 `part_id / 정확한 상대 경로 / 화면 뒤→앞 순서`를 기록한다. 파츠를 삭제·추가·이름 변경하면 계획표와 실파일을 함께 갱신하고 순서를 다시 사람이 판단한다.
3. 최종 결과 ZIP의 경로는 `outputs/master.png`, `isolated_parts/<part_id>.png`, `layer_order.txt`를 같은 루트에 놓는다. ZIP 내 한 개 최상위 폴더 안에 모두 넣는 방식도 가능하지만 두 구조를 섞지 않는다.
4. `layer_order.txt`는 **실제 존재하는 독립 PNG 각각을 정확히 한 번**, `isolated_parts/eye_L_iris.png` 같은 **루트 기준 상대 경로**로 한 줄씩 기록한다. ZIP 파일 전체 경로, `./` 접두, 대소문자 다른 이름, 디렉터리 접두를 쓰지 않는다. 순서는 ZIP 내부 저장 순서/알파벳순이 아니라 시각적으로 결정한 **뒤→앞 순서**다.
5. `previews/`, `reference_views/`, `outputs/` 내 PNG는 `layer_order.txt`에 포함하지 않는다. `isolated_parts/` 안의 실제 PNG는 누락·중복·미등록이 하나도 없어야 한다. 결과 ZIP에 `manifest.json`을 별도 생성하지 않는다 (단순 2D 형식).
6. 모든 파츠 PNG는 기준 원화와 동일한 **픽셀 크기·원점**, 실제 RGBA 알파, 의미 있는 불투명 픽셀과 일부 투명 픽셀을 갖는다. 부위가 삭제됐는데도 미리보기만 남거나, 시트 PNG만 남기는 납품은 금지한다.
7. **최종 ZIP을 완성한 뒤** 이 ZIP의 `04_OUTPUT_FILES.md`에 포함된 Python 검증 코드를 별도 검사 파일에 복사하여 **실제 결과 ZIP**을 대상으로 실행한다. 파일을 고친 경우 압축·검사를 다시 수행한다. 오류 하나라도 있으면 납품하지 말고 문제가 된 PNG/순서를 수정한다.
8. 코드 검증은 경로·개수·형식만 검증한다. 고급 원화 품질·목 회전용 언더페인트·전후 가림·알파 테두리·합성 비교는 별도로 시각 검수한다. 실제 실행하지 않았는데 PASS라고 쓰지 않는다.

**우회 금지:** 검사 통과를 위해 존재하는 PNG를 몰래 버리거나 임의로 `layer_order.txt`를 알파벳 정렬하거나, 비어 있는 가짜 PNG를 생성하거나, 중간 PNG 구조 검사의 PASS를 최종 납품으로 오인하지 않는다. Live2D/Inochi2D 최종 결과 원화 ZIP에는 실제 편집 가능한 다층 PSD와 각 파츠의 알파 마스크가 필수이며, Cubism/Inochi Creator 네이티브 리깅 및 모션 자동 완성은 요구하지 않는다.

### 반드시 실행하는 결과 ZIP 검증
아래 코드를 작업 임시 폴더의 `validate_artwork_zip.py`로 저장해 **최종 압축 이후** `python validate_artwork_zip.py inochi2d_full__body__ARTWORK.zip pro`를 실행한다. PRO일 경우 마지막 인자를 `pro`로 설정한다. `PASS`가 안 나오면 수정·재압축하며, 실제 실행할 수 없으면 완료라고 하지 않는다. 이 검사 코드는 납품 그림 ZIP에 포함하지 않는다.

```python
"""Fail-closed structural validator for externally generated 2D artwork ZIPs.

Run: python validate_artwork_zip.py artwork.zip [free|pro]
This checks files and pixels, not whether the artwork is aesthetically correct.
"""
from collections import Counter
from io import BytesIO
from pathlib import Path
import re
import sys
from zipfile import ZipFile

from PIL import Image

_PART_ID = re.compile(r"[A-Za-z][A-Za-z0-9_-]*(?:\.[A-Za-z][A-Za-z0-9_-]*)*\Z")


def validate(path: str | Path, edition: str = "pro", *, final_live2d_body: bool = False) -> None:
    if edition not in ("free", "pro"):
        raise ValueError("edition must be free or pro")
    with ZipFile(path) as archive:
        members = [m for m in archive.infolist() if not m.is_dir()]
        filenames = [m.filename for m in members]
        if len(filenames) != len(set(filenames)):
            raise ValueError("ZIP contains duplicate member paths")
        if not members or len(members) > 500:
            raise ValueError("ZIP empty or too many files")
        if sum(m.file_size for m in members) > 650 * 1024 * 1024:
            raise ValueError("ZIP uncompressed size limit exceeded")
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC verification failed")
        order_paths = [n for n in filenames
                       if n == "layer_order.txt"
                       or (n.endswith("/layer_order.txt") and n.count("/") == 1)]
        if len(order_paths) != 1:
            raise ValueError("One root or single-parent layer_order.txt required")
        prefix = order_paths[0][:-len("layer_order.txt")]
        if any(not name.startswith(prefix) for name in filenames):
            raise ValueError("Mixed root and wrapped folders: choose one layout")
        if prefix + "manifest.json" in filenames:
            raise ValueError("Do not include manifest.json in simple image-only ZIP")
        if final_live2d_body:
            # This stricter gate is for actual hand-off, not intermediate PNG sprite packs.
            # Do not mistake a correctly composited flat proxy for finished VTuber art.
            if any(n.rsplit("/", 1)[-1].lower() == "body_flat_proxy.png"
                   for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: flat BODY proxy is not completed torso art")
            if not any(n.lower().endswith(".psd") for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: layered PSD is missing")
            if not any(n.startswith(prefix + "alpha_masks/") and n.endswith(".png")
                       for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: per-part alpha masks are missing")
            if not any(n.startswith(prefix + "inputs/") for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: original input is missing")
            if not any(n.endswith(".json") for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: layer/validation JSON is missing")
            if not any(n.startswith(prefix + "previews/") for n in filenames):
                raise ValueError("FINAL_ARTWORK_REJECTED: visual comparison previews missing")
            # Art quality remains subject to visual review; this code cannot certify it.
        master_name = prefix + "outputs/master.png"
        if master_name not in filenames:
            raise ValueError("Missing outputs/master.png")
        names = [n.strip() for n in archive.read(order_paths[0]).decode("utf-8-sig").splitlines()
                 if n.strip() and not n.lstrip().startswith("#")]
        counts = Counter(names)
        dupes = sorted(n for n, count in counts.items() if count != 1)
        isolated = [n[len(prefix):] for n in filenames
                    if n.startswith(prefix + "isolated_parts/")]
        invalid = sorted(n for n in isolated
                         if not n.startswith("isolated_parts/")
                         or not n.endswith(".png")
                         or not _PART_ID.fullmatch(n[len("isolated_parts/"):-4]))
        if invalid:
            raise ValueError(f"Invalid isolated sprite paths: {invalid}")
        actual = set(isolated)
        listed = set(names)
        missing = sorted(listed - actual)
        unlisted = sorted(actual - listed)
        if dupes or missing or unlisted:
            raise ValueError(
                f"layer_order mismatch: duplicate={dupes}; "
                f"listed_but_missing_png={missing}; "
                f"png_not_in_layer_order={unlisted}"
            )
        if not (1 if edition == "pro" else 2) <= len(names) <= (500 if edition == "pro" else 100):
            raise ValueError(f"Invalid part count for {edition}: {len(names)}")
        for name in names:
            if (not name.startswith("isolated_parts/") or not name.endswith(".png")
                    or not _PART_ID.fullmatch(name[len("isolated_parts/"):-4])):
                raise ValueError(f"Invalid sprite path: {name!r}")
        with Image.open(BytesIO(archive.read(master_name))) as master:
            if master.format != "PNG" or master.mode not in ("RGB", "RGBA"):
                raise ValueError("Master must be RGB/RGBA PNG")
            size = master.size
        if min(size) < 256 or size[0] * size[1] > 32_000_000:
            raise ValueError("Invalid master size")
        for name in names:
            with Image.open(BytesIO(archive.read(prefix + name))) as im:
                if im.format != "PNG" or im.mode != "RGBA" or im.size != size:
                    raise ValueError(f"PNG mode/canvas mismatch: {name}: {im.mode} {im.size} != {size}")
                alpha = im.getchannel("A")
                if alpha.getbbox() is None or alpha.getextrema()[0] == 255:
                    raise ValueError(f"Empty or fully opaque sprite: {name}")
        print(f"PASS: {len(names)} unique RGBA sprites match layer_order.txt and master canvas {size}")


if __name__ == "__main__":
    args = sys.argv[1:]
    production = "--final-live2d-body" in args
    args = [arg for arg in args if arg != "--final-live2d-body"]
    if len(args) not in (1, 2):
        raise SystemExit("Usage: python validate_artwork_zip.py ARTWORK.zip [free|pro] [--final-live2d-body]")
    validate(args[0], args[1] if len(args) == 2 else "pro", final_live2d_body=production)
```

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** inochi2d_full / body; BODY — 눈·얼굴·귀·입·목·어깨·관절·손, 전신이면 다리와 발. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: Inochi2D 전신: 6등신 애니풍 전신과 사지의 연결. Cubism 네이티브 파일은 요구하지 않는다.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png.
- 최소 참고 파일 후보: reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png.
- 위 PNG 목록은 **납품 필수**이고 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 눈 흰자/홍채/윗아랫눈꺼풀과 속눈썹·눈썹·시선 상태, 정확히 한 개의 입의 열림/닫힘, 턱 뒤에서 입 높이 부근까지 숨겨진 목 피부, 목 아래 몸통, 어깨/팔꿈치/손목의 접합부와 실제 손가락을 필요 수만큼 별도로 그린다. 3/4 먼 눈·코·턱·귀는 정면을 눌러 만든 것이 아닌 새로운 형태로 작화한다.
- Colab 입력 파츠·경로 계약: 2D 독립 파츠 이름은 계층/해부학 기준으로 face 또는 head, neck, torso 또는 body, eye_L/eye_R, arm_L/arm_R, hand_L/hand_R 등을 실제 부위별로 부여한다. 기본 수영복의 상·하의는 removable_neutral_modesty_band_upper 및 removable_neutral_modesty_band_lower로 각각 분리하고 두 레이어를 켠 상태로 마스터와 미리보기를 만든다. isolated_parts/*.png와 layer_order.txt는 모두 실제 파일로 맞춘다.
- 자산 소유권 금지: HAIR·교체 OUTFIT·ACCESSORY를 BODY 완성 자산에 섞지 않는다. 회색 도형, 실사 인체, 길고 좁은 얼굴, 끊긴 목, 두 입, 손 없는 바스트업은 실패다.
- 2D ZIP의 실제 납품은 해당 자산의 기준 마스터 원화, 추가 참고 시점 그림, 독립 RGBA 원화 파츠와 마스크, 합성 미리보기, 편집 가능한 레이어 PSD 및 검수표다. 참고 시점 PNG가 자동으로 모션 키폼·메시가 되지는 않는다.
- 기존 MD에서 reference_views/를 '필요한 경우만' 또는 선택 사항으로 표현했더라도 위 지정 시점 파일은 최종 ZIP에서 필수다. 파일명 대소문자/확장자/경로를 변경하지 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]



## [FACE_BODY_COLOR_LOCK_V4 / 파츠 원화 생성 강제]
캐릭터 얼굴(홍조·하이라이트·그림자 제외)에서 고른 단 하나의 피부 중간톤 `FACE_SKIN_BASE=#RRGGBB`를 먼저 확정하고, 매 이미지 생성 요청에 **실제 HEX 값**과 마스터 참조를 함께 전달한다. 얼굴·귀·두피·목·어깨·몸통 커버의 보이는 기본색·양쪽 상완·전완·양손·손가락·모든 RGB 가림 뒤 연장 픽셀은 같은 베이스색으로 작화한다. 보이는 몸통은 불투명한 무광 비해부학적 가림형 커버로 남기되 **커버의 기본색을 얼굴색과 다르게(회색/보라/라벤더) 만들지 않는다**. 실제 의상 또는 별도 수영복 레이어의 디자인색은 피부가 아니므로 임의로 피부색으로 바꾸지 않는다. 이미 존재하는 보라색 BODY 원화는 정면 마스터 단계에서 얼굴색에 맞게 다시 채색한 뒤 파츠를 자른다. 마스크는 별도 알파 데이터이며 RGB를 회색/흰색으로 덮어 틈을 감추지 않는다. 정면·3/4·측면·고개 상하 모든 뷰에서 동일한 팔레트를 사용한다. 얼굴↔목↔몸통↔상완↔전완↔손의 각 연결부를 **합성 이미지로 확인**, 베이스색이 분리되면 `COLOR_CONTINUITY_FAIL` 처리하고 잘못된 신체 파츠를 재생성할 때까지 납품하지 않는다.
## [/FACE_BODY_COLOR_LOCK_V4]

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **inochi2d_full / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.
- 2. **Inochi Creator official Aka tutorial PSD** — https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
   - 실제 활용: Concrete editable head layer and eye/mouth example; DOES NOT include complete arms/torso.
   - 권리 확인: Tutorial source copyright applies; external download only. For full-body parts use a separately licensed reference or original illustration.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`, `hip`, `thigh_L`, `thigh_R`, `calf_L`, `calf_R`, `foot_L`, `foot_R`

- **구도:** complete six-head design through feet
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 원화가 우선이다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.

# Inochi2D 전신 신체 전문 그림 제작자 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손·골반·양다리·발과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.


## 비공식 실무 — 신체에만 적용
4. 독립 움직임이 같은 고정 선화·그림자는 함께 유지하고 실제 다른 움직임/깊이를 가진 그림만 나눈다.
6. 사용자 기준 몸체가 있으면 **참조용으로만** 겹쳐 보고 좌우 L/R은 캐릭터 본인 기준으로 고정한다. 다른 카테고리의 원화·PNG를 만들거나 출력하지 않는다.
7. 작은 방송 화면과 확대 이미지 모두에서 애니풍 명암·선화 가독성을 확인하고 문제가 있으면 실제 그림만 다시 그린다.

## 비공식 참고
https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ ; 정렬·마스킹은 코드로 보조할 수 있지만 기본 도형 SVG/Pillow 그림을 완성 전문 원화로 가장하지 않는다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / body]


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_full/body]


## [고급 그림자·모근·소재·선폭 | inochi2d_full/body]



## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 외피 베이스색은 반드시 얼굴 피부의 `FACE_SKIN_BASE` 하나로 정한다. 회색·보라·라벤더 등 얼굴과 다른 색을 금지한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** 해당 플랫폼 실제 PSD 템플릿의 레이어·가림 계층, 눈-흰자/홍채/윗속눈썹, 입-닫힌선/입안/윗니/혀, 얼굴/귀/목, 좌우 상완/전완/손. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: inochi2d_full/body; 머리부터 두 발까지 일관된 6등신. 다른 자산을 새로 제작하지 않는다.
- 1) 해당 자산의 마스터를 확정하고 얼굴·눈·입·목·몸통·팔과 색상을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: face, ear.left, ear.right, eye.left.white, eye.left.iris, eye.left.upper.lash, eye.right.white, eye.right.iris, eye.right.upper.lash, eyebrow.left, eyebrow.right, nose, mouth.close, mouth.open, mouth.tooth.t, mouth.tongue, neck, torso, arm.left.upper, arm.left.forearm, hand.left, arm.right.upper, arm.right.forearm, hand.right, pelvis, thigh.left, thigh.right, shin.left, shin.right, foot.left, foot.right. 눈 흰자·홍채·윗속눈썹, 닫힌 입·입안·윗니·혀, 양쪽 상완·전완·손을 각각 그린다. 다른 자산 소유의 파츠를 새로 만들지 않는다.
- 5) `part_art/_order.txt`에 앞에서 뒤로 개별 PNG 파일 경로를 기록한다. PSD·마스크·메시·리깅은 이미지 AI가 만들지 않는다. 열린 입안·치아·혀 파츠는 따로 그리되 중립 합성에는 표시하지 않는다.
- 6) 양쪽 눈·목·어깨·팔·손목의 연결과 가림을 정면·3/4·측면 참고와 비교한다. 중립 합성은 `outputs/master.png`와 동일한 원화여야 한다. 파츠 중복·틈·떠 있는 원화는 반려한다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png. BODY는 `expression_refs/mouth_closed.png` 및 `expression_refs/mouth_open.png`도 서로 다르게 그린 완성 표정 참고 원화로 납품한다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 목·턱·좌우 어깨·상완·전완·손의 실루엣을 시점마다 정합되게 그린다. 단색 무광 찰흙형 비해부학 BODY를 유지한다. neck_underpaint와 body_joint_overlaps는 **부품이 아니라 목·턱·몸통·어깨의 가림·연결을 설명하는 완성 참고 그림**이다. 정면·좌우 3/4·측면에서 턱 아래 목과 귀 뒤, 목-어깨 접점을 보여준다. 정면 그림을 늘이거나 머리만 좌우 이동해 옆모습으로 속이지 않는다.
- **제작 단계 확정:** 이미지 AI는 위에 명시한 독립 파츠의 실제 그림과 다각도 참조를 하나씩 제작한다. PSD 인코딩·메시·키폼·리깅은 별도 단계다. 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] part_art/neck.png는 턱 아래 잘린 얇은 조각이 아니어야 한다. 정면에서 턱 뒤 피부를 입 높이 가까이까지 위쪽으로 실제 그려 두고, 아래는 part_art/torso.png의 상부와 실질적인 알파 교집합을 만들어 놓는다. 얼굴 아래·목·몸통이 알파로 단순히 접하는 선은 실패다. head_three_quarter_L/R는 약 45°, head_profile_L/R는 실제 90° 형태 참고다. 각각 코·입·턱·귀·목뿌리·양어깨가 한 그림 안에서 연결되고 좌우 반전 복제로 대체하지 않는다. head_pitch_up/down에서 턱 아래 목의 드러남/가림을 실제로 바꾼다. neck_underpaint와 body_joint_overlaps 참고 그림을 따로 그리는 것만으로는 실제 part_art/neck.png의 가려진 픽셀이 생기지 않는다.
- [좌표/참조] 정면·좌우 3/4·양측면 및 상하 자세 비교 원화는 outputs/master.png와 동일한 전체 캔버스 치수·기준 크기로 그린다. 확대 클로즈업은 별도 보조 그림으로만 남긴다. 이미지 AI의 다각도 그림은 PSD2Live/Inochi 실제 키폼에 자동 등록되지 않는다.
- [엔진 확인] Inochi2D는 Inochi Creator의 실제 Part Node·메시·변형·목뿌리 자식 계층을 제작해야 움직인다. 현재 2D PNG/PSD 참조를 Inochi 원생 프로젝트 및 90° 회전 키폼으로 자동 변환하지 못한다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [BROADCAST_HANDS_BODY_COLOR_V1]
### 방송용 손·목·소매 접합 실무 순서
**범위 우선순위:** 이 지침은 같은 ZIP의 오래된 '가슴 위까지만', '손이 보일 때만 손' 같은 조건보다 우선한다. BODY 원본의 양손 누락은 허용하지 않는다. 작업 자산 소유권·2D/3D 형식 규칙은 유지한다.
### 전신 BODY: 실제로 무엇을 완성하고 어떻게 합성할지

- **전체 범위:** 정수리에서 양발 끝까지의 자연스러운 몸통·양어깨·양팔·양손을 전부 생성한다. 하단·좌우 캔버스 가장자리는 손가락을 자르지 않고 움직임을 위한 여백을 둔다.
- **양손 전체 필수:** 손목에서 멈추지 않고 왼손·오른손 각각 손바닥, 엄지, 검지·중지·약지·새끼손가락의 **끝까지 완전한 그림**을 만든다. 양쪽 상완·전완·손은 각각 독립 RGBA PNG다. 화면 뒤로 숨기는 것을 '손 생성 완료'라고 기록하지 않는다.
- **방송 기본 자세:** T/A자 팔벌림이 아니라 어깨 힘을 뺀 자연스러운 자세에서 팔꿈치를 편안하게 굽혀 양손을 윗배·몸통 옆쪽 가까이에 배치한다. 두 손을 몸 앞에 둬도 좋으나 얼굴을 가리지 않는다. 좌우 팔 길이·손목 방향·엄지 위치가 실제 같은 사람이어야 한다.
- **마스킹 색 구분:** 색으로 가려진 면을 메우는 BODY 보정용 원화/언더페인트의 **RGB는 주변의 실제 BODY에 보이는 픽셀과 동일하게** 한다. 목·얼굴 아래 피부는 해당 목/얼굴 피부색을, 어깨·몸통 찰흙형 외피의 뒤받침은 실제 외피 베이스색을, 팔꿈치·손목 안쪽은 각각 이어지는 팔/손의 지정색을 사용한다. 몸통 커버·목·팔·손 베이스색이 다르면 마스터부터 수정하여 얼굴과 반드시 동일하게 통일한다. 다만 별도 의복 레이어는 예외다. **임의의 회색·검정·흰색·반창고색으로 틈을 덮지 않는다.** 가장자리는 기존 원화의 셀 명암/선폭을 그대로 이어 그리되 가려지는 단면에 검은 절단선을 새로 긋지 않는다.
- **알파/클리핑 마스크는 다른 것:** 투명도·가림을 정의하는 알파/클리핑 마스크는 채색 피부가 아니다. 마스크 채널은 투명도 데이터로 유지한다. '몸색과 같게'라는 규칙을 알파 채널이나 별도의 회색조 클리핑 마스크에 적용해 불투명으로 덮으면 안 된다. 실제 같은 BODY 색상으로 칠하는 대상은 **보정용 RGB 그림**뿐이다.
- **턱·목·어깨 OFF/ON:** face와 hair를 가린 뒤 part_art/neck.png를 열었을 때 목 위쪽은 턱 양옆 뒤·귀 아래 뒤까지 실제 피부색으로 채워져 있어야 한다. torso를 숨기면 목 아랫단이 가슴 윗면/어깨 아래로 이어져야 한다. 모두 켰을 때 목과 턱 및 어깨 접합에 투명 삼각형이나 검정 이중 테두리가 없고, 옆모습에서 귀 아래→턱 뒤→목 앞·뒷선→어깨로 실제 연속 연결되어야 한다. 3/4/측면 참고 그림만 예쁘게 있고 실제 neck.png가 잘려 있으면 불합격이다.
- **팔 파츠 그림 경계:** 어깨 소켓 안쪽까지 arm.left/right.upper를 실제 외피/피부색으로 연장하고, 팔꿈치 뒤까지 arm.left/right.forearm 윗단을 연장하며, 손목의 숨은 시작부분을 hand.left/right에 실제 손색으로 채운다. 상완→전완→손을 한 번씩 켜고 끄며 색상·선화·가림 순서·자연스러운 길이를 확인한다. 손의 각 다섯 손가락은 만화풍 단순화는 허용하나 벙어리장갑 실루엣·추가 손가락·손가락 잘림은 금지한다.
- **방송 화면 대조:** 원본 전체(양손·윗배 포함)와 방송용 확대 화면(얼굴·목·어깨 위주)을 **별도 미리보기**로 본다. 방송 확대 미리보기에 손이 일부 안 보이더라도 원본·파츠 폴더에서는 완전한 양손을 유지한다. 확대 화면은 컷/카메라 설정이며 손 삭제·프레임 수정 지시가 아니다.
- 실제 2D 검수: (1) 중립 파츠 전체 ON, (2) face/hair OFF 상태에서 neck의 턱 뒤 연장 확인, (3) torso OFF에서 neck 아랫단과 팔 어깨 윗단 확인, (4) forearm OFF+hand ON에서 숨은 손목 그림 확인, (5) 다시 전부 켜 정면·3/4·측면에서 틈 없는 합성을 비교한다. 색이 다른 접합부는 각 원본 BODY 지정 RGB를 복원한다.
## [/BROADCAST_HANDS_BODY_COLOR_V1]

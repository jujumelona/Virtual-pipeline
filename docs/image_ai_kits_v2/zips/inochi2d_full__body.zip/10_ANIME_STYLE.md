
## [2026-10-13 v5 inochi2d_full/body 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
BODY: 얼굴/표정 원화는 짧고 둥근 U형 턱, 둥근 볼, 작은 애니 귀의 내부선 1~2개, 과한 정수리·긴 목 방지. 눈은 크게 하되 홍채색을 기본 분홍/노랑으로 고정하지 않고 사용자 지정값 또는 캐릭터 팔레트로 결정한다. 몸통은 **AI 생성 그림이 아니라** 불투명 중립색 단색 2D 도형 프록시로 만든다. BODY에 속옷·옷·튜브탑·쇄골/가슴/근육/겨드랑이 살접힘/의복 압박 주름이 있으면 FAIL. 별도 코드로 몸체를 만든 뒤 얼굴과 동일 캔버스에서 조립; 코드 실행과 합성 증거 없으면 납품 중단. Inochi Creator 실제 리깅 완료로 표시하지 않는다. 이 ZIP은 프로젝트 전신 6등신 기준을 적용하지만 얼굴과 몸통 도형 제작은 분리한다.

# Inochi2D 전신 신체 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손·골반·양다리·발과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.
**그릴 범위:** 전신 캔버스에서 머리·상체·양팔·손·골반·양다리·발. 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


큰 홍채·깊이 있는 속눈썹·작은 코와 입·부드러운 턱·매끈한 셀 피부. 사실적인 갈비뼈/복근/흉근·성인 실사 비례는 금지. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber body-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested body asset on the reference canvas, no unrelated character parts or props.”

특정 캐릭터의 디자인 복제 금지. 실제 2D 그림까지만, PSD/Inochi Creator 키폼은 사용자가 나중에 처리한다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / body]
High-end Japanese anime Inochi2D BODY ARTWORK ONLY, expressive layered large irises, defined lashes, compact mouth and nose, coherent neck shoulder and actually visible limb connections, modest opaque basewear and clean transparent separated pixels, no redraw of hairstyles fashion costume or accessories.
Tapered, refined anime ink lines and material-aware cel shadows; keep the user's exact original design. No native Creator modeling output.


## [고급 그림자·모근·소재·선폭 | inochi2d_full/body]
Anime VTuber BODY ONLY: preserve the existing eye shape and facial identity, tapered eyelash and mouth linework, delicate colored interior contours and clean skin cel-shadows, no baked-in moving hair-cast shadow on the permanent face skin, no duplicated facial linework, no hairstyle/clothing/accessory generation.

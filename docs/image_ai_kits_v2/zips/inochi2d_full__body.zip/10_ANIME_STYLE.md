## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**inochi2d_full/body 생성 최상위 기준**: 아래 구형 규칙과 충돌하면 이 규칙을 우선한다.
- BODY에서 크고 둥근 머리, 가로폭 넓고 세로 짧은 얼굴, 부드럽고 짧은 U형 턱, 자연스러운 볼, 큰 눈과 홍채를 실제 완성 원화에 구현한다. 길고 좁은 말상·V형 뾰족한 턱·긴 코 밑·긴 목·작은 눈·머리보다 지나치게 넓은 어깨 금지. 민머리 윗두피만 커서 눈이 작아 보이는 것도 실패. 전신은 6등신. 실제 피부의 갈비뼈/쇄골/배꼽/근육 표현 과장 금지. BODY 상의/터틀넥/보디슈트 금지, 최소 가림은 분리.
- 큰 머리, 큰 눈/홍채, 짧고 폭 넓은 얼굴, 둥근 볼, 부드럽고 짧은 U턱, 작은 코·입을 기본으로 한다. **긴/좁은 얼굴과 말상, 뾰족한 V턱, 성숙·실사 모델 인상은 절대 불합격.**
- 정면 얼굴 세로/가로 약 1.10~1.30은 귀여운 스타일의 권장 출발점이며 절대적인 크롭 수치가 아니다. 전신은 프로젝트 6등신, 상반신/바스트업은 큰 머리 존재감을 유지한다.
- BODY 원본을 제공받았으면 얼굴형·눈 크기·두상·목을 재설계하지 않는다. 2D 원화와 분리 레이어 재합성 이미지 비교.
- 불합격 항목: 머리가 작아 보임, 눈이 작음, 얼굴이 길고 좁음, 뾰족한 턱, 긴 목, 다른 자산 혼입. 눈으로 검사하여 하나라도 발견되면 결과물 납품 금지.

## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_full/body]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 신체와 얼굴만. 큰 눈/홍채·둥근 두상·단순한 애니풍 피부. 근육·늑골·배꼽·쇄골 과장 금지. 목 덮는 상의·터틀넥·보디슈트 금지. 최소 면적 무지 가림만 별도 파츠. 팔과 손 포함. 헤어·의상·소품 불포함.
- 구도: 전신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 실제 PSD·3D 템플릿이 없으면 없다고 알린다. URL 및 그림 도식은 원본 템플릿이 아니다.
- 2D 완성 원화 먼저, 움직임별 분리와 가려진 면 보완, 실제 파일 산출 시에만 납품 완료.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.


## [2026-10-13 v5 inochi2d_full/body 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
BODY 피부는 도형 프록시가 아니라 실제 완성된 애니풍 채색 원화로 제작한다. 갈비뼈·배꼽·쇄골 등의 상세 해부학 선을 억제한다. 가림은 별도 최소 무지 파츠이며 상의는 OUTFIT에서만 제작한다.

# Inochi2D 전신 신체 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_full / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손·골반·양다리·발과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.
**그릴 범위:** 전신 캔버스에서 머리·상체·양팔·손·골반·양다리·발. 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


큰 홍채·깊이 있는 속눈썹·작은 코와 입·부드러운 턱·매끈한 셀 피부. 사실적인 갈비뼈/복근/흉근·성인 실사 비례는 금지. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리를 추가로 그리지 않는다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber body-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested body asset on the reference canvas, no unrelated character parts or props.”

특정 캐릭터의 디자인 복제 금지. 실제 2D 그림까지만, PSD/Inochi Creator 키폼은 사용자가 나중에 처리한다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_full / body]
High-end Japanese anime Inochi2D BODY ARTWORK ONLY, expressive layered large irises, defined lashes, compact mouth and nose, coherent neck shoulder and actually visible limb connections, modest opaque basewear and clean transparent separated pixels, no redraw of hairstyles fashion costume or accessories.
Tapered, refined anime ink lines and material-aware cel shadows; keep the user's exact original design. No native Creator modeling output.


## [고급 그림자·모근·소재·선폭 | inochi2d_full/body]
Anime VTuber BODY ONLY: preserve the existing eye shape and facial identity, tapered eyelash and mouth linework, delicate colored interior contours and clean skin cel-shadows, no baked-in moving hair-cast shadow on the permanent face skin, no duplicated facial linework, no hairstyle/clothing/accessory generation.

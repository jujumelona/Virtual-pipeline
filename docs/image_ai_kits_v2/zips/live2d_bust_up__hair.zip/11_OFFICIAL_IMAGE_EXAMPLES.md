# 공식 원화 이미지 예시(원격 링크)

00_MASTER_FIRST.md 참고. 원격 이미지 권한·가용성 보장 없음. 공식 원화 자체는 ZIP에 복사하지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

이 그림의 개별 캐릭터 외형을 복제하지 않는다. 실제 보지 못했으면 확인했다고 주장하지 않는다.
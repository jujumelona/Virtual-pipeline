# Live2D 바스트업 hair 공식·제작자 팁

공식 Live2D 일러스트 가공 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 앞머리·옆머리·뒷머리와 가림 보완. 공식 Skinning https://docs.live2d.com/en/cubism-editor-manual/skinning/ — 흔들림 리깅은 Editor 사용자 단계. 비공식 Live2D 커뮤니티 https://www.reddit.com/r/Live2D/ — 실제 흔들릴 가닥 중심으로 분할하는 실무 조언.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / hair]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 앞/옆/뒤 헤어의 실제 분리 및 가려진 뿌리 보완. **CLIP STUDIO TIPS 개인 작가:** https://tips.clip-studio.com/en-us/articles/5958 , https://tips.clip-studio.com/en-us/articles/6072 — 모근/실루엣→묶음→가닥 설계 조언. 사용자 헤어스타일을 대체할 표준형을 강제하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/hair]
**[Live2D 공식]** https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 앞머리/옆머리/뒷머리 분리와 원화에서 가려진 뿌리 추가 작화. **[개인 작가]** https://tips.clip-studio.com/en-us/articles/8014 — 정면과 측면의 실루엣을 별도로 검토하는 방법. 바스트업 기준 몸체의 확정된 얼굴 중심 구도와 눈 디자인는 **신체/구도에만 쓰는 선택적 기준**, 헤어 자체의 파츠 폭/길이 비율이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/hair]
**[공식과 아티스트 경험 구별]** 공식 Live2D 파츠 분리/숨은 머리뿌리 보완: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . **볼에서 자란 것처럼 보이는 잘못된 옆머리 뿌리, 머리 이동과 따로 노는 앞머리 투사 그림자, 반사광의 흐름·단선 문제**는 실제 작화 품질을 위한 아티스트 검수 항목이지 공식 파츠 개수·그림자 생성 의무가 아니다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

배 위까지 이어진 BODY의 원점·스케일을 참조하여 헤어만 제작하고 얼굴/신체는 재작화하지 않는다.

## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 후속 Colab에서 See-through가 파츠를 분리하고 리깅 단계가 사용한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다.
- 모발의 뒷면·모근 및 두상 각도 관계를 참고 원화로 명확하게 그린다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. See-through 분리 이후 리깅 시 실제 관절·가림·회전 연결을 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

# Live2D 바스트업 hair 공식·제작자 팁

공식 Live2D 일러스트 가공 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 앞머리·옆머리·뒷머리와 가림 보완. 공식 Skinning https://docs.live2d.com/en/cubism-editor-manual/skinning/ — 흔들림 리깅은 Editor 사용자 단계. 비공식 Live2D 커뮤니티 https://www.reddit.com/r/Live2D/ — 실제 흔들릴 가닥 중심으로 분할하는 실무 조언.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.
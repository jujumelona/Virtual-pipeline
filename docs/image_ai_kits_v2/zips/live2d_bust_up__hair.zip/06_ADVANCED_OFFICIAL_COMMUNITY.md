# 공식·비공식 원화 기법

00_MASTER_FIRST.md 우선. 공식: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 겹침·클리핑을 고려한 Live2D 원화 준비. 눈·입·목·어깨의 움직일 여유를 실제 파츠로 둔다.

## 비공식

https://www.reddit.com/r/Live2D/ — 원화 분리 실무 경험을 참고하되 규격으로 단정하지 않는다. 방송 화면에서 큰 얼굴과 표정 전달을 우선하고 실제 2D 미술로 정합 확인한다.
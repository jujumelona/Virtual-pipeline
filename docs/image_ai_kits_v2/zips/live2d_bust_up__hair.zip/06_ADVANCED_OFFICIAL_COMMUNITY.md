# 공식·비공식 원화 기법

00_MASTER_FIRST.md 우선. 공식: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 겹침·클리핑을 고려한 Live2D 원화 준비. 눈·입·목·어깨의 움직일 여유를 실제 파츠로 둔다.

## 비공식

https://www.reddit.com/r/Live2D/ — 원화 분리 실무 경험을 참고하되 규격으로 단정하지 않는다. 방송 화면에서 큰 얼굴과 표정 전달을 우선하고 실제 2D 미술로 정합 확인한다.

## 2026 공식 제작 노하우 (원화 단계에 적용)

공식 원화 가공 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 머리카락 앞·옆·뒤 분리, 눈의 위/아래 속눈썹·흰자·홍채 분리, 눈 뒤 흰자와 앞머리 뒤 얼굴 피부 보완. 입은 상하 윤곽과 입안을 나누며 피부색 가림으로 입안의 삐져나옴을 줄인다. 얼굴 윤곽은 둥근 입체감을 고려한다. 목은 턱 뒤로 넉넉히 연장하며 공식 예시는 입 높이까지도 제시한다.

공식 소재 분리 https://docs.live2d.com/en/cubism-editor-manual/divide-the-material/ — 수정용 PSD와 Cubism 가져오기용 PSD를 분리해 관리한다. 전자는 비파괴 원본·레이어 마스크·보완 그림을 유지하고, 후자는 움직임 단위별로 합쳐진 실제 RGBA 픽셀 레이어를 사용한다.

공식 PSD https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ — Cubism에 가져갈 PSD는 RGB·8bit/channel·PSD 형식, sRGB 권장. 중복 레이어명, 가져오기 PSD에 남은 레이어 마스크, 선화/색칠의 불필요한 분리 등을 점검한다.

공식 파라미터 https://docs.live2d.com/en/cubism-editor-manual/standard-parameter-list/ 및 대각선 https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ — Angle X/Y/Z, 눈·입 등은 나중에 Editor에서 키폼을 만들어야 한다. 이미지 AI는 회전에 필요한 옆얼굴/귀/목/머리카락/의복 가림 그림만 준비한다. 완전 측면·90도 회전 원화를 무조건 요구하지 않는다.

공식 FREE 비교 https://www.live2d.com/ko/cubism/comparison/ — 무료판 텍스처 2048px 1장, ArtMesh 100개, 파라미터 30개, Blend Shape 파라미터 3개, 디포머 50개, Parts 30개, ArtPath 3개. 이는 Editor 모델 리소스 제한이지 원본 PSD 보조 레이어 수를 임의로 잘라내야 하는 요구가 아니다.

제작 사례 Live2dTree https://live2dtree.com/tutorial — 방송에서 얼굴을 크게 보여주므로 얼굴 파츠를 더 세밀하게 분리하고 중앙 배치·대칭 가이드·머리/목 가림 영역을 보완. 예시 3000×5000 캔버스는 해당 제작자의 사례일 뿐 의무 규격은 아니다.

커뮤니티 https://www.reddit.com/r/Live2D/comments/vc93ns/ — 움직이지 않는 선화·기본색·그림자는 해당 파츠와 합치고, 위치가 달라지는 그림자와 하이라이트만 별도 분리하는 실무 조언.
커뮤니티 https://www.reddit.com/r/Live2D/comments/15wts96/ — 3/4 회전 시 멀리 있는 눈을 원근상 좁게 보이도록 설계하고 대각선에서 눈/머리카락이 틀어지는지 확인.
커뮤니티 https://www.reddit.com/r/Live2D/comments/1ed8w4c/ — 옷깃·리본처럼 좌우 독립 움직임이 필요한 것은 분리하고, 모든 표정에 눈과 입 전체를 중복 그리지 않는다.

원화 제작 AI에게 Photoshop/Cubism Editor 플러그인 설치, 네이티브 리깅, ArtMesh/키폼/물리, moc3 또는 cmo3 파일 생성을 요구하지 않는다. 실제 GPU 및 Editor 실행 없이 품질과 움직임을 통과 판정하지 않는다. 실사 비율이나 나체 기본 몸체 대신 애니풍 큰 얼굴·홍채와 불투명 옷/속옷 또는 안전한 마스킹을 사용한다. 마스킹 아래의 노출 신체를 복원하라고 요구하지 않는다.

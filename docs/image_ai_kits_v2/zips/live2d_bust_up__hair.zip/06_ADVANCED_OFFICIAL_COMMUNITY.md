# Live2D 바스트업 hair 공식·제작자 팁

공식 Live2D 일러스트 가공 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 앞머리·옆머리·뒷머리와 가림 보완. 공식 Skinning https://docs.live2d.com/en/cubism-editor-manual/skinning/ — 흔들림 리깅은 Editor 사용자 단계. 비공식 Live2D 커뮤니티 https://www.reddit.com/r/Live2D/ — 실제 흔들릴 가닥 중심으로 분할하는 실무 조언.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / hair]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 앞/옆/뒤 헤어의 실제 분리 및 가려진 뿌리 보완. **CLIP STUDIO TIPS 개인 작가:** https://tips.clip-studio.com/en-us/articles/5958 , https://tips.clip-studio.com/en-us/articles/6072 — 모근/실루엣→묶음→가닥 설계 조언. 사용자 헤어스타일을 대체할 표준형을 강제하지 않는다.
**공통 주의:** Live2D/Cubism 공식은 원화 분리·편집기 구현을 설명하지만, '정확한 6등신', '홍채 가로폭 몇 %', '2~3톤만 허용'을 기술 규격으로 요구하지 않는다. Cubism Editor의 키폼·클리핑·Skinning은 이미지 AI의 자동 납품 대상이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/hair]
**[Live2D 공식]** https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 앞머리/옆머리/뒷머리 분리와 원화에서 가려진 뿌리 추가 작화. **[개인 작가]** https://tips.clip-studio.com/en-us/articles/8014 — 정면과 측면의 실루엣을 별도로 검토하는 방법. 바스트업 기준 몸체의 확정된 얼굴 중심 구도와 눈 디자인는 **신체/구도에만 쓰는 선택적 기준**, 헤어 자체의 파츠 폭/길이 비율이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/hair]
**[공식과 아티스트 경험 구별]** 공식 Live2D 파츠 분리/숨은 머리뿌리 보완: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . **볼에서 자란 것처럼 보이는 잘못된 옆머리 뿌리, 머리 이동과 따로 노는 앞머리 투사 그림자, 반사광의 흐름·단선 문제**는 실제 작화 품질을 위한 아티스트 검수 항목이지 공식 파츠 개수·그림자 생성 의무가 아니다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
배 위까지 이어진 BODY의 원점·스케일을 참조하여 헤어만 제작하고 얼굴/신체는 재작화하지 않는다.
실제 다층 PSD, 같은 캔버스 투명 RGBA PNG와 파츠별 알파 마스크, 원본 입력과 원본 PSD(있다면), 원본-결과 및 PRO BODY 정합 미리보기, 레이어 좌표/순서·검증·분할 JSON, 사용자 제작·시각검수·Cubism 안내 MD는 최종 필수. PSD와 마스크가 없으면 중간 PNG 검사 PASS여도 최종 납품 불가. BODY 최종 납품에 --final-live2d-body를 사용한다. HAIR/OUTFIT/ACCESSORY도 PSD·마스크 필수. 실제 이미지/Editor 확인 없이 미술·리깅 품질 PASS 금지.

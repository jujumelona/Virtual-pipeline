# Live2D 바스트업 hair 공식·제작자 팁

공식 Live2D 일러스트 가공 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 앞머리·옆머리·뒷머리와 가림 보완. 공식 Skinning https://docs.live2d.com/en/cubism-editor-manual/skinning/ — 흔들림 리깅은 Editor 사용자 단계. 비공식 Live2D 커뮤니티 https://www.reddit.com/r/Live2D/ — 실제 흔들릴 가닥 중심으로 분할하는 실무 조언.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / hair]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 앞/옆/뒤 헤어의 실제 분리 및 가려진 뿌리 보완. **CLIP STUDIO TIPS 개인 작가:** https://tips.clip-studio.com/en-us/articles/5958 , https://tips.clip-studio.com/en-us/articles/6072 — 모근/실루엣→묶음→가닥 설계 조언. 사용자 헤어스타일을 대체할 표준형을 강제하지 않는다.
**공통 주의:** Live2D/Cubism 공식은 원화 분리·편집기 구현을 설명하지만, '정확한 6등신', '홍채 가로폭 몇 %', '2~3톤만 허용'을 기술 규격으로 요구하지 않는다. Cubism Editor의 키폼·클리핑·Skinning은 이미지 AI의 자동 납품 대상이 아니다.

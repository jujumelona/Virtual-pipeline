# Live2D 방송용 바스트업 헤어 애니풍 기준

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / hair
**실제 제작:** 사용자가 요청한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥 원화만.
**금지:** 신체·얼굴·눈·입·피부·옷·독립 머리장식을 새로 생성하지 않는다.
**구도:** 방송용 바스트업은 머리 높이 1 : 보이는 목·어깨·상체 약 1~2의 레이아웃 기준이며, 헤어·의상·액세서리 ZIP에서는 제공된 기준 몸체를 새로 그리지 않고 해당 자산만 완성한다.


- 대상: 사용자가 요청한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥 원화만. 신체·얼굴·눈·입·피부·옷·독립 머리장식을 새로 생성하지 않는다.
- 애니풍: 검정에 가까운 짙은 가변 굵기 선화와 가늘어지는 테이퍼, 깔끔한 소재별 내부선, 2~3톤 셀 명암·높은 디자인 일관성.
- 이 자산의 미술적 특징: 헤어 실루엣·뿌리 연결·가닥 끝의 테이퍼·알파 프린지·머릿결 2~3톤 셀 명암·얼굴의 시야 방해 없음.
- 기준 캐릭터의 눈매·머리/얼굴 비율은 **참조를 통한 크기·정체성 맞춤**이며 신체와 얼굴 이외 자산을 새로 생성하는 요구가 아니다.
- 머리 1높이에 화면에 보이는 상체 1~2높이라는 구도 기준만 적용한다. 전신의 하체/다리/발을 강제하지 않는다.

영어 이미지 프롬프트: “Professional premium anime VTuber bust-up hair-only artwork, variable-weight tapered dark linework, detailed consistent 2-3 tone cel shading, faithful original character aesthetics, isolated requested hair art on matching full canvas, no extra character parts or props.”


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / hair]
### 이 ZIP에만 적용할 애니풍 프롬프트
Polished anime VTuber BUST-UP HAIR ONLY, authentic requested hairstyle, large pleasing crown silhouette, organic front side back tufts and hidden roots, tapered hair strands and subtle material-aware highlights, clean dark ink with delicate inner lines and cel shadows, exact original character head alignment, transparent asset only; no face, eyes, body, clothing or decorative hairpins unless explicitly requested.
**소유 픽셀:** 캐릭터 기준 이미지의 다른 범주는 좌표/컬러 참조일 뿐 새 그림 산출 대상이 아니다.

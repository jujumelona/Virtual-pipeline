## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**live2d_bust_up/hair 전용 생성 최우선 규칙.** 이 조항보다 아래의 구형 구도·얼굴형 설명이 충돌하면 이 조항을 우선한다.
- HAIR는 기존 BODY의 크고 둥근 머리와 짧고 넓은 얼굴 인상을 유지. 앞·옆머리가 얼굴을 길고 좁게 만들거나 정수리·관자 볼륨을 축소해 머리가 작아 보이면 불합격. 실제 지정된 헤어스타일의 실루엣과 모근만 제작. 기준 얼굴·귀·눈·턱·목을 다시 그리지 않는다.
- 공통 스타일: 귀여운 애니/VTuber, 머리가 상대적으로 크게 보이고, **짧고 폭이 있는 얼굴·부드럽고 짧은 U형 턱·큰 눈과 홍채·작은 코와 입**. 긴/좁은 얼굴, 말상, 길게 내려온 뾰족한 턱, 현실/성숙 모델 인상은 절대 불합격.
- 정면 얼굴 높이/폭(귀 제외) 약 1.10~1.30은 스타일 **출발 참고값**이며 신체/프레임 전체 비율은 강제하지 않는다. 전신은 프로젝트의 6등신 유지, 바스트업·상반신은 실사형으로 머리를 축소하지 않는다.
- 실물 기준 BODY가 제공되면 원본 두상/얼굴을 바꾸지 않는다. 2D는 완성 원화·파트 재합성에서 기준 얼굴과 실제 시각 비교한다.
- **검수 필수:** 머리 크기, 얼굴의 넓고 짧은 윤곽, 둥근 턱끝, 눈/홍채 크기, 자연스러운 목·어깨 비율, 기준 캐릭터 동일성, 다른 자산 혼입 여부. 긴 얼굴처럼 보이게 만드는 옆머리와 작아 보이는 두상 발견 시 불합격.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_bust_up/hair]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **HAIR만 생성:** 제공된 BODY의 두상/두피/귀/얼굴 기준점에 맞춘 앞·옆·뒷머리와 실제 가려진 모근. 신체·눈·입·의상·소품을 새로 생성하지 않는다.
- 프레임: 정수리부터 상복부/허리 위 및 양손까지 방송용 바스트업. 자산 소유 범위에만 적용. 전신 캐릭터의 기본 디자인은 6등신을 지향하나 크롭 프레임에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 극단적 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY가 제공되면 얼굴 비율을 변경하지 않는다.
- 작업절차: 2D는 해당 자산의 완성 원화를 먼저 만들고 필요 파츠/숨은 면을 분리·보완한다. 실제 다층 PSD·PNG·마스크는 만들고 검증했을 때만 납품 완료로 기록한다.
- 실물 템플릿 계약: 외부 URL이나 비율 도식은 원본 PSD/PNG/3D 템플릿이 아니다. 실제 템플릿 파일이 ZIP에 없으면 없다고 명시한다. 사용자 기준 원화가 있으면 해당 이미지를 참조한다. 비BODY 자산에 BODY 원본이 없으면 정합 검증을 완료했다고 주장하지 않는다.
- 검증: 원화·그림 품질과 파일 구조를 따로 판정. 비어 있는 파츠나 가려진 영역 미보완, 다른 자산 혼입, 구도 절단은 불합격. 구형 문구로 상반된 지시를 부활시키지 않는다.


## [2026-10-13 v5 live2d_bust_up/hair 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.
HAIR: 사용자 지정 헤어스타일 한 종류만, BODY의 얼굴·눈·귀·목·몸통을 다시 그리지 않는다. 헤어 모근·옆머리·귀 앞/뒤 가림·후면 숨은 가닥·좌우 의미·투명 RGBA를 확인하고 원본 BODY와 동일 캔버스/좌표로 맞춘다. 의상·머리장식 임의 추가 금지.

# Live2D 방송용 바스트업 헤어 애니풍 기준

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / hair
**실제 제작:** 사용자가 요청한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥 원화만.
**금지:** 신체·얼굴·눈·입·피부·옷·독립 머리장식을 새로 생성하지 않는다.


- 대상: 사용자가 요청한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥 원화만. 신체·얼굴·눈·입·피부·옷·독립 머리장식을 새로 생성하지 않는다.
- 애니풍: 검정에 가까운 짙은 가변 굵기 선화와 가늘어지는 테이퍼, 깔끔한 소재별 내부선, 2~3톤 셀 명암·높은 디자인 일관성.
- 이 자산의 미술적 특징: 헤어 실루엣·뿌리 연결·가닥 끝의 테이퍼·알파 프린지·머릿결 2~3톤 셀 명암·얼굴의 시야 방해 없음.
- 기준 캐릭터의 눈매·머리/얼굴 비율은 **참조를 통한 크기·정체성 맞춤**이며 신체와 얼굴 이외 자산을 새로 생성하는 요구가 아니다.

영어 이미지 프롬프트: “Professional premium anime VTuber bust-up hair-only artwork, variable-weight tapered dark linework, detailed consistent 2-3 tone cel shading, faithful original character aesthetics, isolated requested hair art on matching full canvas, no extra character parts or props.”


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / hair]
### 이 ZIP에만 적용할 애니풍 프롬프트
Polished anime VTuber BUST-UP HAIR ONLY, authentic requested hairstyle, large pleasing crown silhouette, organic front side back tufts and hidden roots, tapered hair strands and subtle material-aware highlights, clean dark ink with delicate inner lines and cel shadows, exact original character head alignment, transparent asset only; no face, eyes, body, clothing or decorative hairpins unless explicitly requested.
**소유 픽셀:** 캐릭터 기준 이미지의 다른 범주는 좌표/컬러 참조일 뿐 새 그림 산출 대상이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/hair]
Anime VTuber HAIR ONLY: authentic scalp-rooted silhouette, layered front side and back tufts, tapered fine ink at the strand tips, depth-aware cel shadows and flowing highlights; only if needed provide a hair-owned cast-shadow layer instead of baking hair shadows into face skin, never add eyes, ears, outfit or ornamental hairpins.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | hair]
Exact same FACE-FIRST close-bust-up reference canvas and head anchor, generate only the user-chosen hair artwork, with believable volume and natural root-to-tip flow, high-end clean anime ink and stylized cel highlights; keep underlying face large and readable but no face/eye/neck/body pixels in exported hair PNG.

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
배 위까지 이어진 BODY의 원점·스케일을 참조하여 헤어만 제작하고 얼굴/신체는 재작화하지 않는다.
HAIR 자산의 최종 산출은 해당 자산의 완성 원화와 실제 독립 PNG/숨은 면 보완, 같은 캔버스의 미리보기·레이어 순서·검증 기록, 실제 제작한 다층 PSD 및 필요 마스크를 포함한다. BODY 전용 최종 납품 옵션과 눈/피부 파츠 생성 조건을 이 자산에 강제하지 않는다. 미작성 산출물을 제작 완료로 표기하지 않는다.
HAIR ONLY aligned to existing full upper-body canvas.

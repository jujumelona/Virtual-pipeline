## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **live2d_bust_up / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 헤어 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 헤어의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 헤어 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.

# Live2D 바스트업 hair 고유 실무 노하우

1. 방송 화면의 머리 실루엣·정수리 볼륨을 살리되 눈·입과 표정을 충분히 보이게 한다.
2. 앞머리·좌우 옆머리·뒷머리의 깊이를 정하고 실제 흔들릴 가닥만 세분화한다. 머리카락 숫자 채우기가 목적이 아니다.
3. 가려진 머리카락 뿌리·귀 앞뒤·목 뒤 머리 부분을 별도 underpaint 하되 얼굴 피부는 재제작하지 않는다.
5. 존재하지 않는 포니테일·트윈테일·아호게를 강제하거나 별도 액세서리 ZIP의 머리핀을 중복 제작하지 않는다.
6. 기존 신체의 **원본 기준 원화**와 정확히 같은 캔버스·원점·배율·머리 중심을 사용하여 가닥 알파 프린지·머리 뿌리 끊김을 재합성 검수한다.


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / hair]
### 작업 순서·아티스트 실전 노하우
1. **실루엣 → 모근/흐름 → 큰 가닥 → 작은 가닥 → 재질별 하이라이트** 순서로 헤어 완성 원화를 먼저 설계한다.
2. 각 가닥은 뿌리에서 끝으로 얇아지는 테이퍼와 서로 다른 굴곡을 갖는다. 정수리를 단색 헬멧처럼, 잔가닥을 빗살처럼 균일하게 만들지 않는다.
3. 귀 앞뒤·앞머리 아래·뒷머리 뒤의 숨은 머리카락을 실제로 연장하여 흔들림 뒤 투명 구멍을 막는다. **피부나 귀 자체를 재생성하지 않는다.**
5. 원본 기준 몸체의 머리 중심·원점·배율을 유지해 밝고 어두운 배경, 방송 크기에서 알파·선화·눈 가림을 재검토한다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/hair]


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/hair]

배 위까지 이어진 BODY의 원점·스케일을 참조하여 헤어만 제작하고 얼굴/신체는 재작화하지 않는다.



## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.live2d.com/en/cubism-editor-tutorials/template/
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** Live2D 원화 가공 예제의 앞머리·옆머리 좌우·뒷머리·개별 흔들리는 긴 가닥과 가려진 모근. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: live2d_bust_up/hair; 얼굴 크게, 목·양어깨·양팔·양손·상복부까지. 다른 자산을 새로 제작하지 않는다.
- 1) 이 자산의 디자인 마스터를 확정하고 머리카락 형태·색상과 BODY 기준 앵커을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: hair.back, hair.front, hair.side.left, hair.side.right; 실제 움직이는 추가 가닥만. 앞·뒤·좌우 옆머리와 실제 움직이는 가닥만 만들고 다른 신체·옷을 제작하지 않는다. 다른 자산에 속한 파츠를 추가하거나 누락을 이름만으로 통과시키지 않는다.
- 5) `part_art/_order.txt`에는 앞에서 뒤로 각 개별 PNG 경로를 한 줄씩 쓴다. PSD·마스크·MOC3·리깅은 제작하지 않는다. BODY 전용 눈·입·대체 표정 PNG를 이 자산에서 새로 만들지 않는다.
- 6) 해당 자산의 형태·장착 앵커·앞뒤 가림을 정면·3/4·측면 참조와 대조하고, 중립 파츠 합성이 `outputs/master.png`와 일치해야 한다. 접합 틈·중복·부유 파츠는 반려한다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png. BODY용 입 표정 그림은 이 자산에서 새로 그리거나 납품하지 않는다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 모발의 뒷면·모근 및 두상 각도 관계를 참고 원화로 명확하게 그린다.
- **제작 단계 확정:** 이미지 AI는 위에 명시한 독립 파츠의 실제 그림과 다각도 참조를 하나씩 제작한다. PSD 인코딩·메시·키폼·리깅은 별도 단계다. 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

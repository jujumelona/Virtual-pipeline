## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **live2d_bust_up / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 기존 자료 형식: PSD
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** head to upper abdomen/waist with complete shoulders arms and hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# Live2D 바스트업 hair 고유 실무 노하우

1. 방송 화면의 머리 실루엣·정수리 볼륨을 살리되 눈·입과 표정을 충분히 보이게 한다.
2. 앞머리·좌우 옆머리·뒷머리의 깊이를 정하고 실제 흔들릴 가닥만 세분화한다. 머리카락 숫자 채우기가 목적이 아니다.
3. 가려진 머리카락 뿌리·귀 앞뒤·목 뒤 머리 부분을 별도 underpaint 하되 얼굴 피부는 재제작하지 않는다.
4. 머릿결 흐름과 테이퍼 끝, 움직이는 하이라이트/고정 명암을 구분한다. 고정 명암은 파츠에 합쳐도 된다.
5. 존재하지 않는 포니테일·트윈테일·아호게를 강제하거나 별도 액세서리 ZIP의 머리핀을 중복 제작하지 않는다.
6. 기존 신체의 **원본 기준 원화**와 정확히 같은 캔버스·원점·배율·머리 중심을 사용하여 가닥 알파 프린지·머리 뿌리 끊김을 재합성 검수한다.

공통 작업: 실제 원본 기준 원화의 동일 캔버스·원점·스케일을 보존하고 투명 PNG를 원래 순서로 재합성합니다. 다른 자산 원화를 새로 만들거나 리깅 결과를 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / hair]
### 작업 순서·아티스트 실전 노하우
1. **실루엣 → 모근/흐름 → 큰 가닥 → 작은 가닥 → 재질별 하이라이트** 순서로 헤어 완성 원화를 먼저 설계한다.
2. 각 가닥은 뿌리에서 끝으로 얇아지는 테이퍼와 서로 다른 굴곡을 갖는다. 정수리를 단색 헬멧처럼, 잔가닥을 빗살처럼 균일하게 만들지 않는다.
3. 귀 앞뒤·앞머리 아래·뒷머리 뒤의 숨은 머리카락을 실제로 연장하여 흔들림 뒤 투명 구멍을 막는다. **피부나 귀 자체를 재생성하지 않는다.**
4. 광택이 실제 가닥에 고정되면 함께 두고, 독립적으로 변할 경우에만 분리한다. 2~3톤 셀 명암을 기본으로 하되 색상 단계 수가 고정 기술 규격은 아니다.
5. 원본 기준 몸체의 머리 중심·원점·배율을 유지해 밝고 어두운 배경, 방송 크기에서 알파·선화·눈 가림을 재검토한다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/hair]
**옆얼굴에 맞춘 모발 접합:** 턱·귀·뒷목의 기준 위치를 참조로만 읽고, 귀 앞쪽 가닥/귀 뒤쪽 가닥/뒷머리 뿌리를 실제 다른 깊이로 설계한다. 머리 회전을 상정하면 앞머리 뒤 이마 주변, 귀 뒤 뿌리, 뒷통수~목 뒤에 숨겨진 **머리카락 픽셀**이 드러난다. 그 영역만 연장한다. 측면 가닥의 두상 위 볼륨은 사용자 헤어스타일을 유지하고, 피부·귀·목 파츠는 절대 재생성하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/hair]
**[헤어 뿌리·캐스트 그림자]** 머리뿌리의 출발점→큰 가닥의 표면 굴곡→작은 갈래의 테이퍼를 같은 방향으로 설계한다. 얼굴 위 앞머리 그림자가 필요하면 헤어 자산에만 속하는 별도의 그림자 후보를 원본 좌표에서 제작하되, **움직임/합성 구조에 필요할 때만** 추가한다. 그림자를 원본 피부에도 그리고 독립 그림자에도 그리는 중복을 금지한다. 헤어 하이라이트는 가닥 흐름과 머리 곡면을 따라 가게 하고, 실제 함께 움직이는 고정 명암은 무리하게 독립 레이어로 나누지 않는다.

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
배 위까지 이어진 BODY의 원점·스케일을 참조하여 헤어만 제작하고 얼굴/신체는 재작화하지 않는다.
실제 다층 PSD, 같은 캔버스 투명 RGBA PNG와 파츠별 알파 마스크, 원본 입력과 원본 PSD(있다면), 원본-결과 및 PRO BODY 정합 미리보기, 레이어 좌표/순서·검증·분할 JSON, 사용자 제작·시각검수·Cubism 안내 MD는 최종 필수. PSD와 마스크가 없으면 중간 PNG 검사 PASS여도 최종 납품 불가. BODY 최종 납품에 --final-live2d-body를 사용한다. HAIR/OUTFIT/ACCESSORY도 PSD·마스크 필수. 실제 이미지/Editor 확인 없이 미술·리깅 품질 PASS 금지.

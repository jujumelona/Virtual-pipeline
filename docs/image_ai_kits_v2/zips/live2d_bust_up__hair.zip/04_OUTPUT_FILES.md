# 헤어만 납품 파일 구조

00_MASTER_FIRST.md에 따라 실제 그림 제작. live2d_bust_up__hair__ARTWORK.zip
outputs/master.png — 최종 바스트업 기준 원화
outputs/master_original.png — 원본 저장
isolated_parts/ — 실제 RGBA PNG 파츠
layer_order.txt — 레이어 순서와 L/R
previews/composite_preview.png — 재합성 원화 비교
previews/reference_bust_up.png — 머리~가슴 윗부분 구도 비교
reference_views/ — 회전 보조(필요한 경우만)
README.md — 수작업 보완 및 실제 납품 범위

원화가 없는 그림·가짜 PSD·moc3·cmo3는 제출하지 않는다. 이 이미지 AI 지시서에서 Cubism PRO 설치·리깅을 요구하지 않는다.

## ZIP 고유 작업 범위 잠금: live2d_bust_up / hair
**실제 제작:** 사용자가 요청한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥 원화만.
**금지:** 신체·얼굴·눈·입·피부·옷·독립 머리장식을 새로 생성하지 않는다.
**구도:** 방송용 바스트업은 머리 높이 1 : 보이는 목·어깨·상체 약 1~2의 레이아웃 기준이며, 헤어·의상·액세서리 ZIP에서는 제공된 기준 몸체를 새로 그리지 않고 해당 자산만 완성한다.

`outputs/master.png`는 이 ZIP의 헤어 원화만, `isolated_parts/`는 헤어의 RGBA PNG만 의미한다. 기준 몸체가 들어간 화면은 위치 확인용 preview로 구분한다. 다른 카테고리 픽셀을 파츠로 납품하지 않는다.

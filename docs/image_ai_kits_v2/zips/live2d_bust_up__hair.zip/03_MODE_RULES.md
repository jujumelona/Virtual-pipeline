## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**live2d_bust_up/hair 전용 생성 최우선 규칙.** 이 조항보다 아래의 구형 구도·얼굴형 설명이 충돌하면 이 조항을 우선한다.
- HAIR는 기존 BODY의 크고 둥근 머리와 짧고 넓은 얼굴 인상을 유지. 앞·옆머리가 얼굴을 길고 좁게 만들거나 정수리·관자 볼륨을 축소해 머리가 작아 보이면 불합격. 실제 지정된 헤어스타일의 실루엣과 모근만 제작. 기준 얼굴·귀·눈·턱·목을 다시 그리지 않는다.
- 공통 스타일: 귀여운 애니/VTuber, 머리가 상대적으로 크게 보이고, **짧고 폭이 있는 얼굴·부드럽고 짧은 U형 턱·큰 눈과 홍채·작은 코와 입**. 긴/좁은 얼굴, 말상, 길게 내려온 뾰족한 턱, 현실/성숙 모델 인상은 절대 불합격.
- 정면 얼굴 높이/폭(귀 제외) 약 1.10~1.30은 스타일 **출발 참고값**이며 신체/프레임 전체 비율은 강제하지 않는다. 전신은 프로젝트의 6등신 유지, 바스트업·상반신은 실사형으로 머리를 축소하지 않는다.
- 실물 기준 BODY가 제공되면 원본 두상/얼굴을 바꾸지 않는다. 2D는 완성 원화·파트 재합성에서 기준 얼굴과 실제 시각 비교한다.
- **검수 필수:** 머리 크기, 얼굴의 넓고 짧은 윤곽, 둥근 턱끝, 눈/홍채 크기, 자연스러운 목·어깨 비율, 기준 캐릭터 동일성, 다른 자산 혼입 여부. 긴 얼굴처럼 보이게 만드는 옆머리와 작아 보이는 두상 발견 시 불합격.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_bust_up/hair]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **HAIR만 생성:** 제공된 BODY의 두상/두피/귀/얼굴 기준점에 맞춘 앞·옆·뒷머리와 실제 가려진 모근. 신체·눈·입·의상·소품을 새로 생성하지 않는다.
- 프레임: 정수리부터 상복부/허리 위 및 양손까지 방송용 바스트업. 자산 소유 범위에만 적용. 전신 캐릭터의 기본 디자인은 6등신을 지향하나 크롭 프레임에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 극단적 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY가 제공되면 얼굴 비율을 변경하지 않는다.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **live2d_bust_up / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 헤어 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 헤어의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 헤어 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.


## [2026-10-13 v5 live2d_bust_up/hair 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.
HAIR: 사용자 지정 헤어스타일 한 종류만, BODY의 얼굴·눈·귀·목·몸통을 다시 그리지 않는다. 헤어 모근·옆머리·귀 앞/뒤 가림·후면 숨은 가닥·좌우 의미·투명 RGBA를 확인하고 원본 BODY와 동일 캔버스/좌표로 맞춘다. 의상·머리장식 임의 추가 금지.

# Live2D 바스트업 헤어 고유 제작·납품 모드

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / hair
**실제 제작:** 사용자가 요청한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥 원화만.
**금지:** 신체·얼굴·눈·입·피부·옷·독립 머리장식을 새로 생성하지 않는다.


- 전신 6등신 원화를 잘라 사용하는 구도가 아니라 처음부터 방송에 보이는 영역을 디자인한다. 헤어/의상/액세서리만의 경우 **기준 몸체는 합성 preview에만 참조**하고 생성하지 않는다.
- 그림으로 제작할 대상은 사용자가 요청한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥 원화만. 신체·얼굴·눈·입·피부·옷·독립 머리장식을 새로 생성하지 않는다.


## 바스트업 프레이밍 — 이 자산만 적용
- **골반·다리·발을 포함한 하체 그림은 바스트업에서 제작/납품하지 않는다.** 이 ZIP은 기준 캐릭터가 아니라 선택된 자산 한 종류만 실제 그림으로 만든다.


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / hair]
### 바스트업 고유 구도(기술 강제가 아닌 프로젝트 설계)


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/hair]
**구도 동기화만:** 기준 신체의 방송 바스트업 프레임을 그대로 따르며 새로 머리 비율/눈 크기를 결정하거나 신체 원화를 생성하지 않는다. H와 머리 프레임 크기는 참조 캐릭터의 이미 확정된 값이다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/hair]
방송용 가슴 위 프레임에서 해당 자산의 축소 가독성과 기준 얼굴·표정의 조화를 검수하되 화면 바깥 하체 제작을 강제하지 않는다. 스타일·원화가 지정되면 그 디자인을 우선하고, 잘려 있는 부위는 추측해 늘리지 않는다.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | hair]

배 위까지 이어진 BODY의 원점·스케일을 참조하여 헤어만 제작하고 얼굴/신체는 재작화하지 않는다.
기준 신체 참조 — 해당 자산만 독립 제작한다.
사용자가 요구한 배 위까지의 완성된 방송 상체, 양어깨·상완·전완·손·가림부와 헤어·의상·소품 기준 BODY 정합을 실제 원화로 확인한다.



## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.live2d.com/en/cubism-editor-tutorials/template/
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** Live2D 원화 가공 예제의 앞머리·옆머리 좌우·뒷머리·개별 흔들리는 긴 가닥과 가려진 모근. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: live2d_bust_up/hair; 얼굴 크게, 목·양어깨·양팔·양손·상복부까지. 다른 자산을 새로 제작하지 않는다.
- 1) 이 자산의 디자인 마스터를 확정하고 머리카락 형태·색상과 BODY 기준 앵커을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: hair.back, hair.front, hair.side.left, hair.side.right; 실제 움직이는 추가 가닥만. 앞·뒤·좌우 옆머리와 실제 움직이는 가닥만 만들고 다른 신체·옷을 제작하지 않는다. 다른 자산에 속한 파츠를 추가하거나 누락을 이름만으로 통과시키지 않는다.
- 5) `part_art/_order.txt`에는 앞에서 뒤로 각 개별 PNG 경로를 한 줄씩 쓴다. PSD·마스크·MOC3·리깅은 제작하지 않는다. BODY 전용 눈·입·대체 표정 PNG를 이 자산에서 새로 만들지 않는다.
- 6) 해당 자산의 형태·장착 앵커·앞뒤 가림을 정면·3/4·측면 참조와 대조하고, 중립 파츠 합성이 `outputs/master.png`와 일치해야 한다. 접합 틈·중복·부유 파츠는 반려한다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png. BODY용 입 표정 그림은 이 자산에서 새로 그리거나 납품하지 않는다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 모발의 뒷면·모근 및 두상 각도 관계를 참고 원화로 명확하게 그린다.
- **제작 단계 확정:** 이미지 AI는 위에 명시한 독립 파츠의 실제 그림과 다각도 참조를 하나씩 제작한다. PSD 인코딩·메시·키폼·리깅은 별도 단계다. 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] 3/4·측면에는 앞/뒤/옆머리의 진짜 깊이, 귀 뒤 모근과 목 뒤 실제 가닥을 그린다. BODY의 귀·눈·목은 앵커 참고이며 헤어 파츠 PNG에 복사하지 않는다.
- [좌표/참조] 정면·좌우 3/4·양측면 및 상하 자세 비교 원화는 outputs/master.png와 동일한 전체 캔버스 치수·기준 크기로 그린다. 확대 클로즈업은 별도 보조 그림으로만 남긴다. 이미지 AI의 다각도 그림은 PSD2Live/Inochi 실제 키폼에 자동 등록되지 않는다.
- [엔진 확인] PSD2Live 기본 머리 ParamAngleX 범위는 -45..+45°, ParamAngleY는 -30..+30°다. 실제 -90/+90° 옆모습 PNG는 자동으로 키폼이 되지 않는다. 실제 MOC3 극한 각도 렌더링과 턱·목·귀·헤어 가림을 확인할 때까지 90° 가능이라고 보고하지 않는다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

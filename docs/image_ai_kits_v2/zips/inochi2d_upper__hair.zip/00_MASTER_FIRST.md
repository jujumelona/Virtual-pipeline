# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**[실제 원화 작화 방식: 02_ADVANCED_PARTS.md의 EXPLICIT_DRAWING_STEPS_V1을 반드시 먼저 열어 따르며, 07_REVIEW_BEFORE_FINAL_ZIP.md의 REAL_VISUAL_REVIEW_V1로 실제 그림을 비교한다.]**

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 inochi2d_upper/hair 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지가 **제공된 경우** 실제 이미지를 확인한다. 신규 캐릭터의 경우 사용자 PSD·원화가 없어도 정상이며, 실제 접근 가능한 공개 원화 및 파츠 구조 자료를 참고한다.
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 접근 불가능한 외부 참고 링크는 `unavailable` 상태·원인으로 기록하고 실제 열 수 있는 적절한 다른 공개 그림을 조사해 대체한다. 참고용 외부 PSD 하나를 못 열었다는 이유로 사용자에게 BODY PSD 첨부를 요구하거나 신규 캐릭터 제작을 중단하지 않는다.
   단, 특정 기존 캐릭터·BODY와 동일성을 보존해야 하는데 필수 사용자 참조가 없거나, 실제 시각 참고 이미지를 전혀 볼 수 없다면 사유를 정확하게 보고하고 해당 단계만 보류한다. 허위 열람 완료 금지.
7. 필수 사용자 자료·실제 시각 참고·템플릿 슬롯 검토 및 충돌 해결 후 기준 캐릭터 디자인을 확정한다. 공개 예제 캐릭터의 픽셀·외형을 그대로 복제하지 않는다.
실제 템플릿 슬롯·마스터·직전 승인 파츠를 보고 앞·뒷머리·양옆머리·움직이는 모발 가닥을 하나씩 독립 RGBA PNG로 그린다. 다른 자산을 그리지 않고 `part_art/_order.txt`와 함께 납품한다. PSD·마스크·리깅은 Colab 단계다.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** Inochi2D 상반신. 얼굴과 큰 눈 중심의 손그림 애니풍 세밀함, 자연스러운 어깨·양팔·양손, 턱 뒤 목과 가림 표면을 유지한다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**inochi2d_upper/hair 생성 최상위 기준**: 아래 구형 규칙과 충돌하면 이 규칙을 우선한다.
- HAIR는 기준 BODY의 큰 두상과 짧고 둥근 얼굴을 변경하지 않는다. 정수리·양옆의 헤어 볼륨이 머리를 작게 보이게 하거나 옆머리가 얼굴을 좁고 길게 만들면 실패. 눈/턱/피부 재생성 금지; 요청받은 모발만.
- 큰 머리, 큰 눈/홍채, 짧고 폭 넓은 얼굴, 둥근 볼, 부드럽고 짧은 U턱, 작은 코·입을 기본으로 한다. **긴/좁은 얼굴과 말상, 뾰족한 V턱, 성숙·실사 모델 인상은 절대 불합격.**
- 정면 얼굴 세로/가로 약 1.10~1.30은 귀여운 스타일의 권장 출발점이며 절대적인 크롭 수치가 아니다. 전신은 프로젝트 6등신, 상반신/바스트업은 큰 머리 존재감을 유지한다.
- 불합격 항목: 머리가 작아 보임, 눈이 작음, 얼굴이 길고 좁음, 뾰족한 턱, 긴 목, 다른 자산 혼입. 눈으로 검사하여 하나라도 발견되면 결과물 납품 금지.

## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_upper/hair]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 헤어만 제작. 기준 신체/눈/얼굴 재생성 금지. 두피·가닥·모근의 숨은 면 보완.
- 구도: 허리까지 상반신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **inochi2d_upper / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi Creator official Aka tutorial PSD** — https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
   - 실제 활용: Concrete editable head layer and eye/mouth example; DOES NOT include complete arms/torso.
   - 권리 확인: Tutorial source copyright applies; external download only. For full-body parts use a separately licensed reference or original illustration.
- 2. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 헤어 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 헤어의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 헤어 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.

# 최우선 제작 계약: inochi2d_upper / hair

## [2026-10-13 v5 inochi2d_upper/hair 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.


## ZIP 고유 작업 범위 잠금: inochi2d_upper / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.


**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.



기존 캐릭터와 디자인을 일치시키되 요청받은 **헤어** 자산만 납품한다. 다른 카테고리의 새 자산은 추가하지 않는다.



## [필수: 2D 결과 ZIP 레이어 정확성 사전 차단]



## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** Live2D 원화 가공 예제의 앞머리·옆머리 좌우·뒷머리·개별 흔들리는 긴 가닥과 가려진 모근. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: inochi2d_upper/hair; 두상부터 상반신·양손까지. 다른 자산을 새로 제작하지 않는다.
- 1) 해당 자산의 마스터를 확정하고 헤어의 실루엣·색상과 BODY 부착 위치을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: hair.back, hair.front, hair.side.left, hair.side.right; 실제 움직이는 추가 가닥만. 앞뒤·좌우 모발과 움직이는 가닥만 만들고 눈·입·피부·의상은 제작하지 않는다. 다른 자산 소유의 파츠를 새로 만들지 않는다.
- 5) `part_art/_order.txt`에 앞에서 뒤로 개별 PNG 파일 경로를 기록한다. PSD·마스크·메시·리깅은 이미지 AI가 만들지 않는다. BODY 눈·입이나 대체 표정 파츠는 이 자산에서 만들지 않는다.
- 6) 이 자산의 형태·BODY 앵커·앞뒤 가림을 정면·3/4·측면 참고와 비교한다. 중립 합성은 `outputs/master.png`와 동일한 원화여야 한다. 파츠 중복·틈·떠 있는 원화는 반려한다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png. BODY 전용 입 표정 원화는 이 자산 ZIP에서 새로 그리거나 납품하지 않는다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 모발의 뒷면·모근 및 두상 각도 관계를 참고 원화로 명확하게 그린다.
- **제작 단계 확정:** 이미지 AI는 위에 명시한 독립 파츠의 실제 그림과 다각도 참조를 하나씩 제작한다. PSD 인코딩·메시·키폼·리깅은 별도 단계다. 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] 3/4·측면에는 앞/뒤/옆머리의 진짜 깊이, 귀 뒤 모근과 목 뒤 실제 가닥을 그린다. BODY의 귀·눈·목은 앵커 참고이며 헤어 파츠 PNG에 복사하지 않는다.
- [좌표/참조] 정면·좌우 3/4·양측면 및 상하 자세 비교 원화는 outputs/master.png와 동일한 전체 캔버스 치수·기준 크기로 그린다. 확대 클로즈업은 별도 보조 그림으로만 남긴다. 이미지 AI의 다각도 그림은 PSD2Live/Inochi 실제 키폼에 자동 등록되지 않는다.
- [엔진 확인] Inochi2D는 Inochi Creator의 실제 Part Node·메시·변형·목뿌리 자식 계층을 제작해야 움직인다. 현재 2D PNG/PSD 참조를 Inochi 원생 프로젝트 및 90° 회전 키폼으로 자동 변환하지 못한다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

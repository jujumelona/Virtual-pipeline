# inochi2d_upper / hair — Inochi2D 해당 자산 공식 근거

> 00_MASTER_FIRST.md의 완성 원화 우선 계약을 따른다. Inochi Creator 실행/노드/리깅은 이 ZIP의 출력물이 아니다.

## 적용 대상: Inochi2D용 헤어 한 종류
[Inochi Creator 공식 첫 모델](https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html)은 가져올 PSD 일러스트 파츠와 그림자 합성의 주의점을 안내한다. [공식 Node 문서](https://docs.inochi2d.com/en/latest/creator/nodes/node.html)는 모델링 후 노드와 앞뒤 정렬의 참고다.
이미지 AI는 **실제 헤어 원화와 모근·앞·옆·뒤 헤어 RGBA**만 출력한다. 얼굴·눈·귀·목 피부·의상 제작과 Creator Node/메시/리깅 작업은 이 ZIP의 대상이 아니다.

각 ZIP은 `00_MASTER_FIRST.md`의 자산·모드 범위를 우선한다. 이 문서에 열거된 파일명/예제는 이 프로젝트 산출 기준이지 공식 엔진의 고정 파츠/이미지 개수 규정이 아니다. 링크는 기법의 출처이며 모델링·PSD 처리 도구 실행 및 외부 다운로드/라이선스 확보를 이미지 생성 AI의 필수 단계로 만들지 않는다.

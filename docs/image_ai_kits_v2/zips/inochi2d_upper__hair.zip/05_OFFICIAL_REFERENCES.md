# inochi2d_upper / hair — Inochi2D 해당 자산 공식 근거


## 적용 대상: Inochi2D용 헤어 한 종류
[Inochi Creator 공식 첫 모델](https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html)은 가져올 PSD 일러스트 파츠와 그림자 합성의 주의점을 안내한다. [공식 Node 문서](https://docs.inochi2d.com/en/latest/creator/nodes/node.html)는 모델링 후 노드와 앞뒤 정렬의 참고다.


## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 후속 Colab에서 See-through가 파츠를 분리하고 리깅 단계가 사용한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다.
- 모발의 뒷면·모근 및 두상 각도 관계를 참고 원화로 명확하게 그린다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. See-through 분리 이후 리깅 시 실제 관절·가림·회전 연결을 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [SAFE_GENERATION_STAGE_V3]
이 ZIP은 HAIR만 독립적으로 생성한다. 머리카락만 제작하고 신체·피부·BODY 원화는 새로 그리지 않는다. 다른 자산은 정렬 참조로만 사용한다. 이미지 생성기에는 해당 자산의 긍정적 디자인 설명과 해당 모드의 시점·캔버스 계약만 전달하고, 전체 14개 MD를 프롬프트로 복사하지 않는다. 분리/PSD/리깅은 후속 단계이며 안전 정책을 우회하지 않는다.
## [/SAFE_GENERATION_STAGE_V3]

## [ART_SOURCE_AND_SEPARATION_V3]
### inochi2d_upper / hair — 자산·모드·담당 단계 잠금
- 자산 경계: HAIR: 앞머리·좌우 옆머리·뒷머리 및 필요한 독립 모발만. BODY·얼굴·눈·손·의상·액세서리 그림은 기준 참조이며 출력에는 0개. HAIR 납품물에는 눈·얼굴·신체 색을 복사하지 않는다. 전체 캐릭터 합성은 previews에서만 가능.
- 명시적 생성 제외: HAIR에서는 머리카락만. 얼굴 피부·눈·홍채·흰자·속눈썹·코·입·귀·목·어깨·팔·손·몸통·의상·헤어 장식/액세서리 픽셀 생성 금지. 기준 BODY는 참조이고 헤어 PNG에 합치지 않는다.
- 실물 납품 차단: HAIR master/납품 PNG에 눈·얼굴·피부·의복·머리장식이 있으면 CROSS_ASSET_CONTAMINATION: FAIL. 기준 캐릭터 합성은 별도 previews/에서만 허용.
- 구도 경계: Inochi2D 상반신은 머리부터 허리, 양팔·손 포함. 다리 금지. Inochi2D 독립 노드 준비.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. hair 실제 세분화 판단: HAIR: 앞머리·뒷머리·좌우 옆머리·독립으로 흔들리는 가닥과 묶음머리만 필요한 만큼 분리. 숨은 뿌리/뒷모발을 보완. 전체 머리카락 한 장 coarse 마스크는 파츠 분리 성공이 아니다.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

## [GPT_ARTWORK_SEGMENTER_HANDOFF_V5]
### inochi2d_upper / hair — GPT 마스터 원화에서 실제 분리 AI까지
**최상위 역할 계약. 이 ZIP은 GPT의 원화 생성 지시서이지 GPT에게 PSD·파츠 분리를 시키는 지시서가 아니다.** 모든 14개 MD의 기존 `part_art/`, `_order.txt`, `isolated_parts/`, PSD, 알파, 개별 눈·목 세분화, 합성 검수 지시는 **별도 후속 분리 엔진의 출력/검사 명세**로 해석한다. 이미지 생성 AI가 그 파일을 생성했다고 주장해서는 안 된다.
1. GPT는 `outputs/master.png` **실제 정면 원화 PNG 1장**(RGB 또는 진짜 RGBA)을 생성한다. 콜라주, 부품을 떨어뜨려 배치한 시트, 가짜 투명 PNG, 기존 이미지와 다른 인물로 그린 설정화는 불합격이다.
2. 다음은 투명 파츠가 아닌, 같은 캐릭터의 다른 시점/숨은 부분 참고 원화이다. **각각 별도의 실제 PNG**로 그린다.
  - `reference_views/hair_front.png`
  - `reference_views/hair_three_quarter_L.png`
  - `reference_views/hair_three_quarter_R.png`
  - `reference_views/hair_profile_L.png`
  - `reference_views/hair_profile_R.png`
  - `reference_views/hair_back.png`
  - `reference_views/hair_underlayers.png`
  - `reference_views/hair_motion_clearance.png`
3. 마스터와 front/three_quarter/profile/pitch 참고는 **동일한 원본 캔버스 가로·세로 픽셀 크기, 인물 스케일·중심좌표**를 유지한다. 뷰 이름을 바꾸거나 정면을 복제해 다른 시점으로 위장하지 않는다.
4. **모드 구도:** Inochi2D 상반신, 머리~허리, 양팔·손 포함. 다리·발 없음.
5. **자산 경계:** 기존 BODY 참조에 위치를 맞추는 앞·옆·뒤 머리카락만. 기준 몸체·얼굴·눈·옷·별개 장신구 픽셀 제외.
6. **See-through 분리를 고려한 원화:** 한 이미지에 한 시점·한 캐릭터, 흰색/단순 단색 배경, 선명한 애니 셀 셰이딩/파츠 윤곽·깔끔한 경계; 글자·워터마크·장식 배경·눈 위의 불필요한 손/머리카락 겹침·과도한 발광 금지. 구분을 위해 머리·팔을 물리적으로 잘라 떼어 놓거나 전체 원화 품질을 저하시키지 않는다.
- 현재 자산 외의 BODY/얼굴/눈/의상/장신구 픽셀을 결과 이미지에 합치지 않는다. 원래 캐릭터는 위치·색·디자인 참조로만 사용한다.
7. **GPT 결과물:** `inochi2d_upper__hair__ARTWORK.zip`에 `outputs/master.png`, 위 `reference_views/*.png` 및 BODY에서 `expression_refs/*.png`만 저장한다. `manifest.json`, `layer_order.txt`, `part_art/_order.txt`, `part_art/*.png`, `isolated_parts/`, PSD, MOC3 등 분리/리깅 파일은 생성하지 않는다. 원화 ZIP 납품과 Live2D 완료를 혼동하지 않는다.
8. **후속 파이프라인:** `tools/vts_source_only_pack.py`가 실물 마스터·뷰의 PNG 형식/중복/크기 등을 확인한다. 이후 See-through V3/NF4로 분리 PSD 후보를 만들고, 관찰된 파츠를 공식 좌우/깊이 세분화 또는 SAM 정밀 마스크로 필요 시 개선한다. Qwen-Image-Layered는 기존 런타임에서 해당 자산에 **실제로 연결된 경우에만** 추가 RGBA 분해에 사용한다. Qwen은 텍스트만으로 L/R 홍채·흰자·속눈썹 레이어를 정확히 지정하는 기능을 보장하지 않는다.
9. **후속 검수:** 원본 보이는 RGB 보존, 실제 알파, 가려진 부분 복원, PSD 순서/캔버스 좌표, 좌우 눈 흰자·홍채·속눈썹, 턱-목-몸통·팔-손 접합, 마스터 중립 합성 일치와 변형을 검사한다. 불합격 부위는 분리 작업에서만 재시도/인페인팅하고 GPT가 파츠 시트를 대신 그리게 하지 않는다. 결과 PSD는 Cubism/Inochi2D 모델 리깅/방송 동작 성공을 뜻하지 않는다.
10. 위에 적힌 PNG를 실제 제작할 수 없으면 그 누락을 명확히 보고한다. 분리 엔진 오류는 GPT 원화 생성 완료와 별도로 보고한다.
## [/GPT_ARTWORK_SEGMENTER_HANDOFF_V5]

## [MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
### inochi2d_upper / hair — 24개 자산별 실제 분리 경로
**V5의 GPT 원화 역할을 유지한 채, 후속 분리 AI가 무엇을 어떻게 나눌지 정하는 최신 자산 전용 기준.** 모드·자산을 서로 바꿔 처리하면 실패다.
- 작업 범위: Inochi2D 상반신: 머리~허리, 팔·손 포함. Cubism 파라미터/ArtMesh로 납품하는 것이 아니라 Inochi용 PSD/노드 후처리.
- 대상 경계: 외부 기준 BODY는 위치 참조 전용. 원화에는 머리카락만 두고 얼굴/눈/몸통 픽셀을 섞지 않는다.
- **See-through V3의 실제 기본 태그 중 이 자산 관련 항목:** front hair, back hair. 23개 태그 이외의 파츠 명칭을 모델이 직접 출력한다고 간주하지 않는다.
- **실제 후속 세부 분리·검수 대상:** 앞머리, 옆머리 좌/우, 뒷머리, 머리카락 뿌리의 숨은 면과 움직임 단위
- **V3만으로 불가능/불충분:** 앞/뒤 머리카락은 V3 태그가 있지만 옆머리 좌/우·개별 술·뿌리 숨은 면의 전용 태그는 없다.
- **어떤 엔진이 실제 수행:** 실행 경로: 독립 자산 PNG의 진짜 알파가 있으면 보존; 아니면 단색 배경에서 실물 전경 마스크를 검사해 추출 → 독립 자산 PSD 1개 후보 → 별도 세부 분리·가림 면 보정 필요. **이 자산만 있는 PNG에는 See-through V3 전체 캐릭터용 head crop을 실행하지 않는다.** V3의 의미 태그는 캐릭터 전체 PSD가 별도로 제공된 경우의 참고 카테고리일 뿐이다.
- **완성 조건:** 이미지 생성 GPT가 한 장짜리 가짜 파츠 시트를 만들면 실패. See-through 결과 PSD만 생성되거나 레이어 이름/개수만 맞으면 **분리 성공 아님**. 실제 움직일 파츠의 서로 다른 원본 RGB/알파/레이어/가려진 면이 검증돼야 한다. 실패 항목은 해당 파츠만 정밀 분리·인페인팅하여 재검사하고, 전체 원화를 매번 재생성하지 않는다.
- 3D HAIR/OUTFIT처럼 제작 엔진이 없는 경우 또는 독립 2D 자산의 세부 분리가 남아 있으면 `NOT_YET_RIG_READY`로 명시한다. 중간 PSD를 완성된 방송 모델로 제출 금지.
- 경로 규정의 코드 기준: `tools/vts_segmentation_profiles.py`. Live2D/Inochi2D 실행은 `notebooks/VTuber_Finished_AI_ZIP_All_Modes.ipynb`의 모드/자산 선택을 따른다.
## [/MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 모근·앞옆뒷머리·묶음·흔들릴 가닥의 선폭·채색·연결과 다른 자산 픽셀 혼입을 실제 시각 확인. 예시의 완성 캐릭터 눈·몸을 그대로 복사하지 않는다.
- **모드별 실제 구도:** Inochi2D 상반신: 머리부터 허리 부근까지, 양팔·양손. 골반 아래 다리·발·전신 생성 금지. HAIR: 앞머리·좌우 옆머리·뒷머리 및 필요한 독립 모발만. BODY·얼굴·눈·손·의상·액세서리 그림은 기준 참조이며 출력에는 0개.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 모근·앞옆뒷머리·묶음·흔들릴 가닥의 선폭·채색·연결과 다른 자산 픽셀 혼입을 실제 시각 확인. 증거 없으면 ART_QUALITY_UNVERIFIED.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**inochi2d_upper/hair 생성 최상위 기준**: 아래 구형 규칙과 충돌하면 이 규칙을 우선한다.
- HAIR는 기준 BODY의 큰 두상과 짧고 둥근 얼굴을 변경하지 않는다. 정수리·양옆의 헤어 볼륨이 머리를 작게 보이게 하거나 옆머리가 얼굴을 좁고 길게 만들면 실패. 눈/턱/피부 재생성 금지; 요청받은 모발만.
- 큰 머리, 큰 눈/홍채, 짧고 폭 넓은 얼굴, 둥근 볼, 부드럽고 짧은 U턱, 작은 코·입을 기본으로 한다. **긴/좁은 얼굴과 말상, 뾰족한 V턱, 성숙·실사 모델 인상은 절대 불합격.**
- 정면 얼굴 세로/가로 약 1.10~1.30은 귀여운 스타일의 권장 출발점이며 절대적인 크롭 수치가 아니다. 전신은 프로젝트 6등신, 상반신/바스트업은 큰 머리 존재감을 유지한다.
- 불합격 항목: 머리가 작아 보임, 눈이 작음, 얼굴이 길고 좁음, 뾰족한 턱, 긴 목, 다른 자산 혼입. 눈으로 검사하여 하나라도 발견되면 결과물 납품 금지.

## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_upper/hair]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 헤어만 제작. 기준 신체/눈/얼굴 재생성 금지. 두피·가닥·모근의 숨은 면 보완.
- 구도: 허리까지 상반신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.


## [2026-10-13 v5 inochi2d_upper/hair 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.

# Inochi2D 상반신 헤어 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.



이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber hair-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested hair asset on the reference canvas, no unrelated character parts or props.”



## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / hair]
Premium Japanese anime Inochi2D HAIR ONLY, authentic requested hairstyle, root-directed front side and back tufts, elegant crown volume and tapered strands, material-dependent cel highlights with nonduplicated shadow pixels, clean independent RGBA hair textures; no face, outfit, skin or ornamental items.
Tapered, refined anime ink lines and material-aware cel shadows; keep the user's exact original design. No native Creator modeling output.


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/hair]
Anime VTuber HAIR ONLY: authentic scalp-rooted silhouette, layered front side and back tufts, tapered fine ink at the strand tips, depth-aware cel shadows and flowing highlights; only if needed provide a hair-owned cast-shadow layer instead of baking hair shadows into face skin, never add eyes, ears, outfit or ornamental hairpins.

## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

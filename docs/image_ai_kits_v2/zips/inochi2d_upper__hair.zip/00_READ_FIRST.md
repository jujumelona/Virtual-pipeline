# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 inochi2d_upper/hair 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지가 **제공된 경우** 실제 이미지를 확인한다. 신규 캐릭터의 경우 사용자 PSD·원화가 없어도 정상이며, 실제 접근 가능한 공개 원화 및 파츠 구조 자료를 참고한다.
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 접근 불가능한 외부 참고 링크는 `unavailable` 상태·원인으로 기록하고 실제 열 수 있는 적절한 다른 공개 그림을 조사해 대체한다. 참고용 외부 PSD 하나를 못 열었다는 이유로 사용자에게 BODY PSD 첨부를 요구하거나 신규 캐릭터 제작을 중단하지 않는다.
   단, 특정 기존 캐릭터·BODY와 동일성을 보존해야 하는데 필수 사용자 참조가 없거나, 실제 시각 참고 이미지를 전혀 볼 수 없다면 사유를 정확하게 보고하고 해당 단계만 보류한다. 허위 열람 완료 금지.
7. 제공된 필수 사용자 자료와 실제 열람 가능한 충분한 참고 이미지의 검토·누락 기록 및 충돌 해결을 마친 뒤 새 캐릭터 원화 한 장 제작. 공개 예제의 캐릭터 픽셀·모양을 그대로 복제하지 않는다. 실제 PSD는 완성 원화에서 파츠 분리·레이어 작성하여 최종 납품한다.
   그 원화의 품질 확인 후 파츠 분리/PSD 제작/합성·최종 ZIP 검수로 진행한다.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_upper/hair]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 헤어만 제작. 기준 신체/눈/얼굴 재생성 금지. 두피·가닥·모근의 숨은 면 보완.
- 구도: 허리까지 상반신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 실제 PSD·3D 템플릿이 없으면 없다고 알린다. URL 및 그림 도식은 원본 템플릿이 아니다.
- 2D 완성 원화 먼저, 움직임별 분리와 가려진 면 보완, 실제 파일 산출 시에만 납품 완료.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터에서도 헤어 자산만 독립 제작한다. 신체·얼굴 원화는 제작하지 않는다.**
이 ZIP은 **inochi2d_upper / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi Creator official Aka tutorial PSD** — https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
   - 기존 자료 형식: PSD (tutorial cut to head)
   - 실제 활용: Concrete editable head layer and eye/mouth example; DOES NOT include complete arms/torso.
   - 권리 확인: Tutorial source copyright applies; external download only. For full-body parts use a separately licensed reference or original illustration.
- 2. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 기존 자료 형식: INX examples and PSD resources (check each file)
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** 기준 신체와 동일한 캔버스·앵커에 헤어 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 헤어의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** 헤어 파츠의 가림·좌우·앞뒤·경계와 기준 몸체의 합성 정합을 검수한다. 기준 신체가 없다면 실제 정합 미검증을 기록한다. 신체·눈 제작을 요구하지 않는다.
- **없는 부위:** 없는 헤어 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 해당 자산 원화를 참조, 없으면 헤어 자산 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 모드에 맞는 실물 PSD 또는 참조 PNG·검증 기록·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 헤어 자산만 독립 PSD·PNG·마스크로 제작한다. 기준 몸체가 없으면 공통 캔버스·앵커를 기록하고 정합 미검증을 표시한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 inochi2d_upper/hair 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
HAIR: 지정된 머리 하나만 독립 파츠 제작. BODY·귀·눈·목·의상을 새로 생성하지 않고 동일 캔버스/원점/스케일을 따르며 모근/이마/귀 뒤 숨은 가닥과 좌우 앞뒤 레이어, 알파/단정한 선화를 검수. 특정 헤어스타일·고정 눈색·장식 강제 금지. Inochi2D 노드/정렬은 후속 Creator 작업이다.

# Inochi2D 상반신 헤어 전용 — 첫 실행 원화 지시

**ZIP 고유 작업 범위 잠금: inochi2d_upper / hair**
**제작하는 것:** 사용자가 요청한 헤어스타일 하나의 앞머리·좌우 옆머리·뒷머리·실제 필요한 가닥.
**제작하지 않는 것:** 신체·얼굴·피부·눈·입·옷·독립 장식을 추가 생성하지 않는다.

## 실행 계약
1. 사용자 제공 캐릭터 원화·기준 신체의 색·선화·원점·크기를 보존한다. 몸체는 좌표·정체성의 참조로만 쓰고 헤어만의 고급 완성 원화를 먼저 그린다. 참조 얼굴·몸체를 결과 PNG에 포함하지 않는다.
2. 기준 머리 중심·귀·목 위치만 참조한다. 앞머리와 가려진 모근·귀 뒤·목 뒤의 헤어만 보완한다. 끝이 가늘어지는 테이퍼 선화와 2~3톤 셀 명암, 실제 흔들릴 가닥만 분리한다.
3. 이 헤어에 속하는 실제 독립 움직임/깊이의 차이가 있는 부위만 투명 RGBA PNG로 추출하고 해당 자산의 가려진 면만 추가 작화한다. `isolated_parts/`를 동일 캔버스·원점·캐릭터 본인 L/R로 맞춘다.
4. 실제 PNG 파일명의 뒤→앞 순서를 `layer_order.txt`에 기록하고 해당 PNG를 재합성해 `previews/`의 원화 비교를 생성한다. 기준 몸체가 있는 overlay는 정합 참고용이지 실제 파츠가 아니다.
5. `09_VISUAL_ART_QUALITY.md`, `10_ANIME_STYLE.md`, `11_OFFICIAL_IMAGE_EXAMPLES.md`의 애니풍 외곽선·테이퍼·재질별 셀 명암과 실제 사용자 화풍을 준수한다. 샘플 그림 링크를 열 수 없으면 봤다고 주장하지 않는다.
6. `00_MASTER_FIRST.md`, `02_ADVANCED_PARTS.md`, `07_REVIEW_BEFORE_FINAL_ZIP.md`의 **이 자산 검사만** 적용해 결함을 수정/재생성하고 다시 확인한다. `00_DELIVERY_AND_RECHECK.md`에 따라 실제 `inochi2d_upper__hair__ARTWORK.zip`을 최종 납품한다.

이 파일은 Inochi2D 원화 제작 지시다. Inochi Creator 노드/메시/리깅·키폼·모션/내보내기나 Live2D Cubism·PSD·MOC3를 이미지 AI가 자동 수행했다고 주장하지 않는다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** inochi2d_upper / hair; HAIR — 요청받은 헤어스타일 한 종류의 가닥·후두부·머리뿌리·그림자. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: Inochi2D 상반신: 동일 캐릭터의 머리·목·양팔·손·상반신. Cubism 네이티브 파일은 요구하지 않는다.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png.
- 최소 참고 파일 후보: reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png.
- 위 PNG 목록은 **납품 필수**이고 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 앞머리/옆머리/뒷머리/아호게 등 독립적으로 움직일 실제 묶음만 생성한다. 앞머리 아래 이마를 머리카락으로 새로 그리면 안 되며, 귀 앞뒤와 정수리·후두부의 숨은 가닥·뿌리·끝의 실제 픽셀을 추가한다. 좌우 프로필 및 후면에서 머리카락 질량·뿌리 방향·가닥 겹침을 정합시킨다.
- Colab 입력 파츠·경로 계약: HAIR의 isolated_parts/ 파츠 ID는 hair 계열로 시작하도록 적고, 한 파츠의 좌우·깊이 정보를 이름에 명확히 표시한다. 다른 자산의 이름이나 픽셀은 독립 파츠로 포함하지 않는다. layer_order.txt의 경로는 실제 isolated_parts/ PNG와 1:1 매칭한다.
- 자산 소유권 금지: BODY의 눈·피부·목·손, OUTFIT, ACCESSORY를 새 완성 자산으로 그리거나 PSD 파츠에 혼입하지 않는다.
- 2D ZIP의 실제 납품은 해당 자산의 기준 마스터 원화, 추가 참고 시점 그림, 독립 RGBA 원화 파츠와 마스크, 합성 미리보기, 편집 가능한 레이어 PSD 및 검수표다. 참고 시점 PNG가 자동으로 모션 키폼·메시가 되지는 않는다.
- 기존 MD에서 reference_views/를 '필요한 경우만' 또는 선택 사항으로 표현했더라도 위 지정 시점 파일은 최종 ZIP에서 필수다. 파일명 대소문자/확장자/경로를 변경하지 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [ART_SOURCE_AND_SEPARATION_V3]
### inochi2d_upper / hair — 자산·모드·담당 단계 잠금
- 자산 경계: HAIR: 앞머리·좌우 옆머리·뒷머리 및 필요한 독립 모발만. BODY·얼굴·눈·손·의상·액세서리 그림은 기준 참조이며 출력에는 0개. HAIR 납품물에는 눈·얼굴·신체 색을 복사하지 않는다. 전체 캐릭터 합성은 previews에서만 가능.
- 명시적 생성 제외: HAIR에서는 머리카락만. 얼굴 피부·눈·홍채·흰자·속눈썹·코·입·귀·목·어깨·팔·손·몸통·의상·헤어 장식/액세서리 픽셀 생성 금지. 기준 BODY는 참조이고 헤어 PNG에 합치지 않는다.
- 실물 납품 차단: HAIR master/납품 PNG에 눈·얼굴·피부·의복·머리장식이 있으면 CROSS_ASSET_CONTAMINATION: FAIL. 기준 캐릭터 합성은 별도 previews/에서만 허용.
- 구도 경계: Inochi2D 상반신은 머리부터 허리, 양팔·손 포함. 다리 금지. Inochi2D 독립 노드 준비.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. hair 실제 세분화 판단: HAIR: 앞머리·뒷머리·좌우 옆머리·독립으로 흔들리는 가닥과 묶음머리만 필요한 만큼 분리. 숨은 뿌리/뒷모발을 보완. 전체 머리카락 한 장 coarse 마스크는 파츠 분리 성공이 아니다.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**[실제 원화 작화 방식: 02_ADVANCED_PARTS.md의 EXPLICIT_DRAWING_STEPS_V1을 반드시 먼저 열어 따르며, 07_REVIEW_BEFORE_FINAL_ZIP.md의 REAL_VISUAL_REVIEW_V1로 실제 그림을 비교한다.]**

## [REVIEW_VISUAL_TASK_CARDS_V1]
**그림 생성 전:** 02_ADVANCED_PARTS.md의 [SINGLE_PART_VISUAL_TASK_CARDS_V1]에서 이번 파츠 하나의 템플릿 실제 그림·형태·뒤에 숨은 픽셀·고정점·앞뒤 가림·실패 예시를 확인한다. 목록의 이름만 듣고 생성한 그림은 불합격이다.
## [/REVIEW_VISUAL_TASK_CARDS_V1]

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 inochi2d_upper/hair 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지가 **제공된 경우** 실제 이미지를 확인한다. 신규 캐릭터의 경우 사용자 PSD·원화가 없어도 정상이며, 실제 접근 가능한 공개 원화 및 파츠 구조 자료를 참고한다.
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 접근 불가능한 외부 참고 링크는 `unavailable` 상태·원인으로 기록하고 실제 열 수 있는 적절한 다른 공개 그림을 조사해 대체한다. 참고용 외부 PSD 하나를 못 열었다는 이유로 사용자에게 BODY PSD 첨부를 요구하거나 신규 캐릭터 제작을 중단하지 않는다.
   단, 특정 기존 캐릭터·BODY와 동일성을 보존해야 하는데 필수 사용자 참조가 없거나, 실제 시각 참고 이미지를 전혀 볼 수 없다면 사유를 정확하게 보고하고 해당 단계만 보류한다. 허위 열람 완료 금지.
7. 필수 사용자 자료·실제 시각 참고·템플릿 슬롯 검토 및 충돌 해결 후 기준 캐릭터 디자인을 확정한다. 공개 예제 캐릭터의 픽셀·외형을 그대로 복제하지 않는다.
이미지 생성 AI는 현재 자산의 고품질 마스터 한 장 및 각도·가림 참고 그림을 먼저 만든다. 원본의 세부 픽셀을 보존한 독립 RGBA PNG는 후속 전문 분리 단계에서 추출·숨은 면 보정 후 검증한다. 파츠 순서 파일은 분리 단계만 작성하고 PSD·리깅은 그 이후 작업이다.
**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 모근·앞옆뒷머리·묶음·흔들릴 가닥의 선폭·채색·연결과 다른 자산 픽셀 혼입을 실제 시각 확인. 예시의 완성 캐릭터 눈·몸을 그대로 복사하지 않는다.
- **모드별 실제 구도:** Inochi2D 상반신: 머리부터 허리 부근까지, 양팔·양손. 골반 아래 다리·발·전신 생성 금지. HAIR: 앞머리·좌우 옆머리·뒷머리 및 필요한 독립 모발만. BODY·얼굴·눈·손·의상·액세서리 그림은 기준 참조이며 출력에는 0개.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 모근·앞옆뒷머리·묶음·흔들릴 가닥의 선폭·채색·연결과 다른 자산 픽셀 혼입을 실제 시각 확인. 증거 없으면 ART_QUALITY_UNVERIFIED.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_upper/hair]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 헤어만 제작. 기준 신체/눈/얼굴 재생성 금지. 두피·가닥·모근의 숨은 면 보완.
- 구도: 허리까지 상반신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **inochi2d_upper / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi Creator official Aka tutorial PSD** — https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
   - 실제 활용: Concrete editable head layer and eye/mouth example; DOES NOT include complete arms/torso.
   - 권리 확인: Tutorial source copyright applies; external download only. For full-body parts use a separately licensed reference or original illustration.
- 2. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 헤어 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 헤어의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 헤어 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.


## [2026-10-13 v5 inochi2d_upper/hair 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.

# Inochi2D 상반신 헤어 전용 — 첫 실행 원화 지시

**ZIP 고유 작업 범위 잠금: inochi2d_upper / hair**
**제작하는 것:** 사용자가 요청한 헤어스타일 하나의 앞머리·좌우 옆머리·뒷머리·실제 필요한 가닥.
**제작하지 않는 것:** 신체·얼굴·피부·눈·입·옷·독립 장식을 추가 생성하지 않는다.

## 실행 계약
1. 사용자 제공 캐릭터 원화·기준 신체의 색·선화·원점·크기를 보존한다. 몸체는 좌표·정체성의 참조로만 쓰고 헤어만의 고급 완성 원화를 먼저 그린다. 참조 얼굴·몸체를 결과 PNG에 포함하지 않는다.
5. `09_VISUAL_ART_QUALITY.md`, `10_ANIME_STYLE.md`, `11_OFFICIAL_IMAGE_EXAMPLES.md`의 애니풍 외곽선·테이퍼·재질별 셀 명암과 실제 사용자 화풍을 준수한다. 샘플 그림 링크를 열 수 없으면 봤다고 주장하지 않는다.
6. `00_MASTER_FIRST.md`, `02_ADVANCED_PARTS.md`, `07_REVIEW_BEFORE_FINAL_ZIP.md`의 **이 자산 검사만** 적용해 결함을 수정/재생성하고 다시 확인한다. `00_DELIVERY_AND_RECHECK.md`에 따라 실제 `inochi2d_upper__hair__ARTWORK.zip`을 최종 납품한다.




## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [BROADCAST_HANDS_BODY_COLOR_V1]
### 이미지 생성 시작 전에 반드시 정할 원화 캔버스
**범위 우선순위:** 이 지침은 같은 ZIP의 오래된 '가슴 위까지만', '손이 보일 때만 손' 같은 조건보다 우선한다. BODY 원본의 양손 누락은 허용하지 않는다. 작업 자산 소유권·2D/3D 형식 규칙은 유지한다.
- 첫 생성 이전에 정수리·목·양어깨·두 손목·양손 열 손가락 끝과 아래/좌우 여백이 들어가는 캔버스를 확정한다. BODY 참조가 없으면 기준 디자인 마스터부터 완성한다. 눈으로 보지 않고 손을 추정했다는 완료 보고 금지.
### 상반신 HAIR: BODY 양손·목 보존과 자산별 정확한 정렬

- 기준 BODY는 해당 모드의 실제 프레임을 사용한다. BODY 양손은 손가락 끝까지 완성된 참조여야 하며, 상반신이라 손과 손목·어깨를 잘라서는 안 된다.
- **현재 ZIP은 HAIR만 생성한다.** 기준 BODY의 양손·팔·목과 윗배는 위치 및 가림 참조로만 사용한다. BODY의 피부/클레이 RGB 픽셀을 현재 자산의 독립 산출물에 복사하거나, BODY 손이 잘린 상태로 둔 채 의상·머리카락·장식으로 숨기지 않는다. 모근·귀 뒤·뒷머리·목 뒤에 실제 모발을 잇되 neck.png의 피부색을 헤어 원화에 그리지 않는다. 머리카락이 턱/목 연결 결함을 가리기 위한 가짜 검은 면이 되면 실패다. 2D는 실제 독립 자산 PNG만 납품하고, BODY 원화는 참고 합성으로만 사용한다.
- **보정색:** 가림에 감춰지는 BODY 피부/무광 외피를 임의 회색 면으로 교체하지 않는다. 보이는 BODY RGB와 연속된 원래 색을 유지하도록 참고하되, 현재 자산의 숨은 픽셀은 현재 자산 고유의 재질색으로 그린다. 별도의 알파/클리핑 마스크를 몸색 RGB로 채워 버리지 않는다.
## [/BROADCAST_HANDS_BODY_COLOR_V1]

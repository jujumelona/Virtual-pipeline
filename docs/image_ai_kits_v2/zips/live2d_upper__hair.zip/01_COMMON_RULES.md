## [ART_SOURCE_AND_SEPARATION_V3]
### live2d_upper / hair — 자산·모드·담당 단계 잠금
- 자산 경계: HAIR: 앞머리·좌우 옆머리·뒷머리 및 필요한 독립 모발만. BODY·얼굴·눈·손·의상·액세서리 그림은 기준 참조이며 출력에는 0개. HAIR 납품물에는 눈·얼굴·신체 색을 복사하지 않는다. 전체 캐릭터 합성은 previews에서만 가능.
- 구도 경계: 상반신은 머리부터 허리 부근, 양팔·양손 끝까지. 다리·발 금지.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. hair 실제 세분화 판단: HAIR: 앞머리·뒷머리·좌우 옆머리·독립으로 흔들리는 가닥과 묶음머리만 필요한 만큼 분리. 숨은 뿌리/뒷모발을 보완. 전체 머리카락 한 장 coarse 마스크는 파츠 분리 성공이 아니다.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **live2d_upper / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 헤어 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 헤어의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 헤어 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.


## [2026-10-13 v5 live2d_upper/hair 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.

# Live2D 상반신 헤어 전용 제작 규칙

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.


## 실제 그림 제작
1. 사용자 원본/기준 몸체가 있다면 해당 캐릭터의 색·선화·원점·포즈를 참조하고, **헤어만** 완성 원화로 먼저 생성한다.
4. 움직임/깊이와 가림에 필요한 숨은 **해당 자산의 그림만** underpaint 하고, 원본 보이는 픽셀은 유지한다.



## [MATTE_CLAY_BODY_V1]
### HAIR — 찰흙형 BODY 위에 헤어만 제작
- BODY는 가슴·복부 해부학 상세 없이 **불투명 무광 단색 찰흙형 상체 베이스**를 사용한다. HAIR은 이미 존재하는 몸체/목/어깨/얼굴 비율을 변경하거나 재생성하지 않는다.
- 헤어의 선·가닥·음영 품질은 사용자 디자인과 애니 원화 기준을 그대로 지킨다. BODY의 단색 정책을 머리카락까지 단색 도형으로 강제하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [BROADCAST_HANDS_BODY_COLOR_V1]
### 공통 몸색·손끝·프레임 계약
**범위 우선순위:** 이 지침은 같은 ZIP의 오래된 '가슴 위까지만', '손이 보일 때만 손' 같은 조건보다 우선한다. BODY 원본의 양손 누락은 허용하지 않는다. 작업 자산 소유권·2D/3D 형식 규칙은 유지한다.
### 상반신 HAIR: BODY 양손·목 보존과 자산별 정확한 정렬

- 기준 BODY는 해당 모드의 실제 프레임을 사용한다. BODY 양손은 손가락 끝까지 완성된 참조여야 하며, 상반신이라 손과 손목·어깨를 잘라서는 안 된다.
- **현재 ZIP은 HAIR만 생성한다.** 기준 BODY의 양손·팔·목과 윗배는 위치 및 가림 참조로만 사용한다. BODY의 피부/클레이 RGB 픽셀을 현재 자산의 독립 산출물에 복사하거나, BODY 손이 잘린 상태로 둔 채 의상·머리카락·장식으로 숨기지 않는다. 모근·귀 뒤·뒷머리·목 뒤에 실제 모발을 잇되 neck.png의 피부색을 헤어 원화에 그리지 않는다. 머리카락이 턱/목 연결 결함을 가리기 위한 가짜 검은 면이 되면 실패다. 2D는 실제 독립 자산 PNG만 납품하고, BODY 원화는 참고 합성으로만 사용한다.
- **보정색:** 가림에 감춰지는 BODY 피부/무광 외피를 임의 회색 면으로 교체하지 않는다. 보이는 BODY RGB와 연속된 원래 색을 유지하도록 참고하되, 현재 자산의 숨은 픽셀은 현재 자산 고유의 재질색으로 그린다. 별도의 알파/클리핑 마스크를 몸색 RGB로 채워 버리지 않는다.
## [/BROADCAST_HANDS_BODY_COLOR_V1]

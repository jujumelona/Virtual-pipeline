## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **live2d_upper / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 기존 자료 형식: PSD
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** upper body through waist/hips with hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 live2d_upper/hair 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
HAIR: 요청한 헤어스타일만; BODY의 얼굴/귀/눈/목/몸통을 재생성하지 않는다. 동일 캔버스·원점·스케일 참조, 모근/뒤통수와 귀 앞뒤 겹침, 실제 필요한 숨은 가닥/후면 underpaint, 왼쪽/오른쪽 파츠와 알파 경계 검수. 머리 장식과 의상은 임의 추가 금지.

# Live2D 상반신 / 헤어만의 2D 제작·납품 범위

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


- **프레임:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 머리·얼굴·다리 등은 헤어의 외형이나 위치를 판단하기 위한 기준이지 다른 자산 그림을 만들라는 뜻이 아니다.
- **실제 출력:** 앞·옆 L/R·뒤 헤어와 필요 가닥. 없는 디자인과 독립 움직임이 불필요한 부분은 만들지 않는다.
- 같은 캔버스·좌표·기준 신체/캐릭터 배율을 유지하는 **투명 RGBA PNG**. `isolated_parts/`에는 이 자산의 픽셀만 포함한다.
- `layer_order.txt`는 실제 생성된 해당 자산 PNG 파일명만 캐릭터 본인 기준 L/R·뒤→앞 순으로 기록한다.
- `previews/composite_preview.png`는 실제 파츠를 합성한다. 기준 몸체가 보이는 별도 overlay는 위치 확인용일 뿐 납품 파츠에 신체를 포함시킨 증거가 아니다.
- Live2D Cubism의 ArtMesh/Deformer/키폼/물리/모션/PSD·MOC3 제작은 이미지 AI 출력 계약 밖이다.


## [2026-10-13 원화·애니풍 심화: live2d_upper/hair]
이미 완성된 기준 신체의 머리·어깨 비례와 원점을 참조하고 **hair 자산 원화만 처음부터 제작**한다. 전신을 완성한 뒤 자르는 것이 납품 필수가 아니다. 신체는 실제 보이는 머리·목·어깨·팔과 상체만, 다른 자산은 같은 기준 몸체의 캔버스/원점에 해당 부분만 작업한다. 이 비율은 Cubism 공식 제한이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_upper/hair]
상반신의 상대 두상·어깨 비율은 6등신 전신 설정을 참고하되 하체를 그리지 않는다. 바스트업 전용 화면 점유율 수치를 강제하지 않는다. 신체의 눈/목 파츠를 이 자산에 추가하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_upper/hair]
어깨·상완·소매·실제 헤어 끝의 화면 안 가시성, 피부·머리·옷 사이 접합을 우선한다. 하체나 프레임 밖 의상/소품은 필요조건이 아니다.

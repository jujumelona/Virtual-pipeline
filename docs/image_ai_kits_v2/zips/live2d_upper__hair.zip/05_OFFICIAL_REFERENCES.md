# live2d_upper / hair — 해당 엔진·자산 공식 근거

> 00_MASTER_FIRST.md의 완성 원화 우선 계약을 따른다. Cubism Editor 실행/리깅은 이 ZIP의 출력물이 아니다.

## 적용 대상: 요청받은 헤어스타일 한 종류
[Live2D 공식 일러스트 가공](https://docs.live2d.com/en/cubism-editor-tutorials/psd/)은 앞·옆·뒤 헤어가 가려지는 영역을 보완하고 필요한 움직임 단위로 분리할 수 있음을 설명한다. [Skinning 기능](https://docs.live2d.com/en/cubism-editor-manual/skinning/)은 후속 모델링에서 긴 가닥을 다루는 방법이며 이미지 AI가 실행하지 않는다.
실제 납품은 **해당 헤어 원화·모근과 실제 필요한 헤어 파츠·재합성 미리보기**만이다. 피부·눈·귀·의상·소품을 새로 생성하지 않는다.

각 ZIP은 `00_MASTER_FIRST.md`의 자산·모드 범위를 우선한다. 이 문서에 열거된 파일명/예제는 이 프로젝트 산출 기준이지 공식 엔진의 고정 파츠/이미지 개수 규정이 아니다. 링크는 기법의 출처이며 모델링·PSD 처리 도구 실행 및 외부 다운로드/라이선스 확보를 이미지 생성 AI의 필수 단계로 만들지 않는다.

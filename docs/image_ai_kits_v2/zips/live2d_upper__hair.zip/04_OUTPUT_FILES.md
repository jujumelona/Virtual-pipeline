# Live2D 상반신 / 헤어만 결과 이미지 ZIP
결과 이름: live2d_upper__hair__ARTWORK.zip
PNG 예시(캐릭터에 실제 있는 부위만, 고급 파츠 추가는 02 지침 참조):
isolated_parts/hair_back_base.png
isolated_parts/hair_front_center.png
isolated_parts/hair_side_L.png
isolated_parts/hair_side_R.png
layer_order.txt
previews/overlay_preview.png
모든 2D 파츠 PNG는 진짜 RGBA 투명·같은 기준 캔버스와 원점. 동작이 다르면 처음부터 독립 이미지로 그린다.
layer_order.txt는 실제 있는 부품 파일명들을 뒤→앞으로 한 줄씩. 프리뷰는 마지막에 생성된 PNG를 합성해서 만든다.
액세서리 파일명 HEADPIECE 등은 요청된 실제 물건 명칭으로 치환한다. 꺾쇠괄호나 다른 자리표시자를 문자 그대로 파일명으로 쓰지 않는다.
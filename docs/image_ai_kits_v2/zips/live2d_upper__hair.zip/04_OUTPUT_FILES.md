# Live2D 상반신 / 헤어만 실제 이미지 결과 ZIP

결과: live2d_upper__hair__ARTWORK.zip
isolated_parts/hair_back_base.png
isolated_parts/hair_front_center.png
isolated_parts/hair_side_L.png
isolated_parts/hair_side_R.png
layer_order.txt
previews/overlay_preview.png

세부 파츠 명칭은 02_ADVANCED_PARTS.md에서 필요에 따라 추가한다. 없는 부위는 만들지 않는다. 눈·입 등은 신체 범주 내부 파츠다.
각 PNG는 투명 RGBA, 같은 크기의 기준 캔버스와 원점, 해당 부위만 그린다. layer_order.txt는 실제 PNG를 뒤→앞으로 나열한다. 생성한 파츠를 마지막에 합성한다.
사용자가 요청하지 않은 별도 신체/헤어/의상/액세서리 세트는 추가하지 않는다. PSD/리깅/키폼/모션 테스트는 요구하지 않는다.
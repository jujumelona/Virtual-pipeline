## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터에서도 헤어 자산만 독립 제작한다. 신체·얼굴 원화는 제작하지 않는다.**
이 ZIP은 **live2d_upper / hair** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 기존 자료 형식: PSD
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.

### 채울 슬롯
`hair_back`, `hair_root`, `hair_left`, `hair_right`, `hair_front`, `occlusion_ears`, `occlusion_neck`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** 기준 신체와 동일한 캔버스·앵커에 헤어 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 헤어의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** 헤어 파츠의 가림·좌우·앞뒤·경계와 기준 몸체의 합성 정합을 검수한다. 기준 신체가 없다면 실제 정합 미검증을 기록한다. 신체·눈 제작을 요구하지 않는다.
- **없는 부위:** 없는 헤어 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 해당 자산 원화를 참조, 없으면 헤어 자산 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 모드에 맞는 실물 PSD 또는 참조 PNG·검증 기록·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 헤어 자산만 독립 PSD·PNG·마스크로 제작한다. 기준 몸체가 없으면 공통 캔버스·앵커를 기록하고 정합 미검증을 표시한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# Live2D 상반신 헤어 전문 그림 제작자 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / hair
**유일한 제작 대상:** 지정한 헤어스타일 한 종류의 앞머리·좌우 옆머리·뒷머리·실제 있는 잔가닥.
**제작 금지:** 얼굴·홍채·피부·눈·입·신체·옷·별도 액세서리를 파츠로 새로 그리지 않는다. 없는 포니테일이나 장식도 추가하지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기존 기준 몸체의 머리 중심·귀·얼굴 좌표를 참조만 함. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 비공식 실무 — 헤어에만 적용
1. 큰 머리 실루엣과 정수리 볼륨, 머리카락 뿌리·귀 앞뒤·목 뒤 가림을 넉넉히 보완한다. 개별 흔들림이 필요한 가닥만 분리하고 고정 명암은 합친다. 테이퍼 끝과 아호게 등은 실제 디자인에 있는 것만 적용한다.
2. 앞·옆·뒤 모근과 가림, 가닥 알파/테이퍼, 눈과 입을 가리지 않는 방송 가독성, 없는 묶음머리 강제 없음, 얼굴 픽셀 혼입 없음.
3. 부위의 양끝/겹침은 납품 파츠 그림 자체 안에서 자연스럽게 이어지게 그린다. 뒷면을 전부 투명 구멍으로 두지 않는다.
4. 독립 움직임이 같은 고정 선화·그림자는 함께 유지하고 실제 다른 움직임/깊이를 가진 그림만 나눈다.
5. 각 파츠 PNG를 밝은 배경과 어두운 배경에서 따로 확대해 알파 프린지·선 잔상·누락된 밑색을 찾는다.
6. 사용자 기준 몸체가 있으면 **참조용으로만** 겹쳐 보고 좌우 L/R은 캐릭터 본인 기준으로 고정한다. 다른 카테고리의 원화·PNG를 만들거나 출력하지 않는다.
7. 작은 방송 화면과 확대 이미지 모두에서 애니풍 명암·선화 가독성을 확인하고 문제가 있으면 실제 그림만 다시 그린다.

## 비공식 참고
https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ ; 정렬·마스킹은 코드로 보조할 수 있지만 기본 도형 SVG/Pillow 그림을 완성 전문 원화로 가장하지 않는다.


## [2026-10-13 원화·애니풍 심화: live2d_upper/hair]
실루엣 → 큰 묶음 → 중간 가닥 → 테이퍼 끝·재질 하이라이트 순서로 세련된 애니풍을 설계한다. 반듯한 단색 헬멧·균일한 빗살 선을 피하고 겹침 뿌리를 같은 색으로 이어 그린다. 움직이지 않는 하이라이트/명암은 무리하게 분리하지 않는다. 기준 몸체 원점·머리 중심/좌우/알파 프린지를 밝은·어두운 배경에서 검토한다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_upper/hair]
[헤어/두상 회전] 정수리 모근에서 귀 앞·귀 뒤와 뒷머리의 가닥이 실제 어떤 깊이로 내려오는지 설계하고, 앞머리에 가려진 **머리카락 뿌리와 옆·뒷머리 안쪽만** 보완한다. 3/4 옆얼굴에서 가닥이 이마·귀·목 뒤로 휘어지는 모양을 원본 헤어스타일과 일치시킨다. 눈·귀·피부·목을 헤어 PNG로 만들지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_upper/hair]
**[헤어 뿌리·캐스트 그림자]** 머리뿌리의 출발점→큰 가닥의 표면 굴곡→작은 갈래의 테이퍼를 같은 방향으로 설계한다. 얼굴 위 앞머리 그림자가 필요하면 헤어 자산에만 속하는 별도의 그림자 후보를 원본 좌표에서 제작하되, **움직임/합성 구조에 필요할 때만** 추가한다. 그림자를 원본 피부에도 그리고 독립 그림자에도 그리는 중복을 금지한다. 헤어 하이라이트는 가닥 흐름과 머리 곡면을 따라 가게 하고, 실제 함께 움직이는 고정 명암은 무리하게 독립 레이어로 나누지 않는다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** live2d_upper / hair; HAIR — 요청받은 헤어스타일 한 종류의 가닥·후두부·머리뿌리·그림자. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 상반신: 두상부터 허리/상반신 지정 끝까지. 하체를 강제로 만들지 않는다.
- 최소 참고 파일 후보: reference_views/hair_front.png, reference_views/hair_three_quarter_L.png, reference_views/hair_three_quarter_R.png, reference_views/hair_profile_L.png, reference_views/hair_profile_R.png, reference_views/hair_back.png, reference_views/hair_underlayers.png, reference_views/hair_motion_clearance.png.
- 위 목록은 **최소 작업 기준 후보**이지 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 앞머리/옆머리/뒷머리/아호게 등 독립적으로 움직일 실제 묶음만 생성한다. 앞머리 아래 이마를 머리카락으로 새로 그리면 안 되며, 귀 앞뒤와 정수리·후두부의 숨은 가닥·뿌리·끝의 실제 픽셀을 추가한다. 좌우 프로필 및 후면에서 머리카락 질량·뿌리 방향·가닥 겹침을 정합시킨다.
- 자산 소유권 금지: BODY의 눈·피부·목·손, OUTFIT, ACCESSORY를 새 완성 자산으로 그리거나 PSD 파츠에 혼입하지 않는다.
- 2D ZIP의 실제 납품은 해당 자산의 기준 마스터 원화, 추가 참고 시점 그림, 독립 RGBA 원화 파츠와 마스크, 합성 미리보기, 편집 가능한 레이어 PSD 및 검수표다. 참고 시점 PNG가 자동으로 모션 키폼·메시가 되지는 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

# Live2D 바스트업 액세서리 전용 시각 참고

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / accessory
**실제 제작:** 사용자가 지정한 한 종류의 액세서리 본체·부착 고정부·필요한 움직임 부품만.
**금지:** 신체·헤어·의상·얼굴·눈·입을 새로 만들지 않는다. 안경/귀걸이/목걸이/헤드셋을 모두 묶은 세트를 만들지 않는다.
**구도:** 기존 기준 신체의 얼굴 중심 근접 바스트업을 그대로 유지하면서 이 ZIP의 accessory 한 자산만 실제 제작한다. 신체·눈·얼굴·목 피부나 전신 비율은 재설계하지 않는다.


아래 공식 Live2D 전체 캐릭터 샘플은 **애니풍 선화·작화 수준을 참고할 목적만** 있고, 액세서리 외의 얼굴/옷/머리/악세서리를 추가로 그리라는 명령은 아니다. 신체·헤어·의상·얼굴·눈·입을 새로 만들지 않는다. 안경/귀걸이/목걸이/헤드셋을 모두 묶은 세트를 만들지 않는다.

[공식 Tsumiki 전신 샘플 — 선화만 참고](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
[공식 Izumi 전신 샘플 — 채색만 참고](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

공식 샘플: https://www.live2d.com/en/learn/sample/ . 원본 파일을 ZIP에 복제하지 않았으며 열람 불가면 보았다고 주장하지 않는다.

**전신 샘플은 화풍 참고만:** 샘플 이미지는 근접 바스트업 구도나 눈/얼굴 비율의 정답 사진이 아니다. 전신·상체 중심 포즈를 모방하지 않고 얼굴 위주의 현재 ZIP 지침과 사용자 캐릭터 외형을 우선한다.

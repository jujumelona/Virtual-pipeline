# Live2D 바스트업 accessory 공식·제작자 팁

공식 원화 분리 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 소품 독립 파츠. 공식 Clipping https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ 및 Skinning https://docs.live2d.com/en/cubism-editor-manual/skinning/ — 리깅은 Cubism Editor 사용자 작업. 비공식 Live2D 커뮤니티 https://www.reddit.com/r/Live2D/ — 실제 부착과 흔들림을 고려한 소품 작업 팁.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / accessory]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식 파츠 원화:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 독립 움직임과 가림 면의 일반 원칙. **공식 Clipping/Skinning(후속 Editor):** https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ , https://docs.live2d.com/en/cubism-editor-manual/skinning/ . 소품 종류와 파츠 개수를 정하는 공식 강제 목록은 아니다.
**공통 주의:** Live2D/Cubism 공식은 원화 분리·편집기 구현을 설명하지만, '정확한 6등신', '홍채 가로폭 몇 %', '2~3톤만 허용'을 기술 규격으로 요구하지 않는다. Cubism Editor의 키폼·클리핑·Skinning은 이미지 AI의 자동 납품 대상이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/accessory]
**[Live2D 공식]** https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 가려진 파츠와 분리 필요성의 일반 원칙. **[개인 작가]** https://tips.clip-studio.com/en-us/articles/8014 — 측면 얼굴과 귀/코의 위치 관계. 코·귀·안경다리는 안경을 실제 요청했을 때만 참고한다. 눈 크기 추천값은 소품 설계 규격이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/accessory]
**[공식·실무 구분]** Live2D 공식의 필요한 범위만 분리/숨은 면 보완: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . **체인·끈의 중립 형태로 과도한 원근 찌그러짐 방지, 얇은 금속·유리/투명 알파 경계 검수**는 아티스트용 조건부 권고다. 공식적으로 모든 액세서리를 직선/고정 개수로 제작하라는 규정은 없다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

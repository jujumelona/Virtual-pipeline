## [ART_SOURCE_AND_SEPARATION_V3]
### live2d_bust_up / accessory — 자산·모드·담당 단계 잠금
- 자산 경계: 액세서리 전용. 실제 주문된 장신구 한 종류만. 고정부·좌우 부착점·움직이는 날개와 가려진 부분만. 헤어·옷·신체 픽셀과 임의 장신구 세트 금지.
- 구도 경계: 바스트업은 얼굴과 큰 눈이 화면 중심, 머리부터 상복부, 양어깨·상완·전완·양손 끝까지. 골반·다리 금지.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. accessory 실제 세분화 판단: ACCESSORY: 실제 요청된 한 장신구의 운동/가림 단위로 분리. 고정 머리핀은 한 레이어 허용, 좌우 귀걸이·안경 다리·움직이는 리본 날개는 별도. 붙어 있는 신체·헤어·옷 픽셀 혼입 금지.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

# Live2D 바스트업 accessory 공식·제작자 팁

공식 원화 분리 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 소품 독립 파츠. 공식 Clipping https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ 및 Skinning https://docs.live2d.com/en/cubism-editor-manual/skinning/ — 리깅은 Cubism Editor 사용자 작업. 비공식 Live2D 커뮤니티 https://www.reddit.com/r/Live2D/ — 실제 부착과 흔들림을 고려한 소품 작업 팁.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / accessory]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식 파츠 원화:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 독립 움직임과 가림 면의 일반 원칙. **공식 Clipping/Skinning(후속 Editor):** https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ , https://docs.live2d.com/en/cubism-editor-manual/skinning/ . 소품 종류와 파츠 개수를 정하는 공식 강제 목록은 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/accessory]
**[Live2D 공식]** https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 가려진 파츠와 분리 필요성의 일반 원칙. **[개인 작가]** https://tips.clip-studio.com/en-us/articles/8014 — 측면 얼굴과 귀/코의 위치 관계. 코·귀·안경다리는 안경을 실제 요청했을 때만 참고한다. 눈 크기 추천값은 소품 설계 규격이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/accessory]
**[공식·실무 구분]** Live2D 공식의 필요한 범위만 분리/숨은 면 보완: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . **체인·끈의 중립 형태로 과도한 원근 찌그러짐 방지, 얇은 금속·유리/투명 알파 경계 검수**는 아티스트용 조건부 권고다. 공식적으로 모든 액세서리를 직선/고정 개수로 제작하라는 규정은 없다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

기준 BODY와 동일 캔버스의 실제 부착점에 요청한 소품만 제작한다.

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

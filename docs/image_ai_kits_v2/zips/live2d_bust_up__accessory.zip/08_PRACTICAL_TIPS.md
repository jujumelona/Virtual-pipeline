## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **live2d_bust_up / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 액세서리 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 액세서리의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 액세서리 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.

# Live2D 바스트업 accessory 고유 실무 노하우

1. 사용자가 명시한 액세서리 한 종류만 제작한다. 예시에 나온 모든 소품을 한 번에 추가하지 않는다.
2. 실제 **원본 기준 원화**에서 부착 앵커를 찾는다. 안경=코·귀, 귀걸이=귀, 머리핀=머리카락처럼 그 종류에 해당할 때만 적용한다.
4. 얇은 체인·프레임, 반투명 렌즈, 금속 반사광의 알파 경계·앞뒤 가림을 확대해 검수한다.
5. 소품 뒤에 필요한 가려진 면을 보완하되 얼굴·눈·입·헤어를 다시 생성하지 않는다.
6. 같은 캔버스에 재합성하여 물체가 떠 보이지 않는지, 너무 크거나 눈·입을 가리지 않는지 작은 방송 크기에서도 확인한다.


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / accessory]
### 작업 순서·아티스트 실전 노하우
1. 캐릭터 기준 원화에서 코·귀·앞머리·옷깃 중 해당 소품의 부착 앵커를 정확히 선택한다. 임의 장식 세트 생성은 금지한다.
2. 고정부는 안정적, 흔들리는 본체는 실제 길이와 접점이 보이도록 그린다. 체인/안경다리/얇은 링이 한두 픽셀로 끊기지 않게 한다.
3. 투명 렌즈 등은 사용자 요구 재질에 있을 때만. 반투명 알파·프린지를 밝은/어두운 배경에서 둘 다 확인한다.
4. 원본 기준 신체에 겹쳐 부착이 떠 있지 않은지, 앞뒤 L/R이 뒤집히지 않았는지, 방송 크기에서 표정을 가리지 않는지 본다.
5. 소품 PNG만 납품한다. 인접 얼굴/헤어/의상은 합성 미리보기에만 이용하고 실제 산출 픽셀에 섞지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/accessory]
**측면에서의 부착 검수:** 안경이 요청됐다면 정면 코받침→측면 안경다리→귀 뒤의 연결이 부유하지 않게, 귀걸이라면 귓불 앵커와 좌우 가림이 틀어지지 않게, 헤어핀이면 그 디자인의 실제 가닥 뿌리에 고정되게 그린다. **이는 조건부 예시이고 함께 생성할 목록이 아니다.** 고개를 돌렸을 때 물건의 앞뒤 순서·폭·두께가 달라질 것을 참고로 표시하되 피부·귀·헤어·얼굴은 새 그림으로 만들지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/accessory]
**[소품 소재·선폭·가림]** 원본 디자인의 고정부와 연결점은 읽히는 선폭으로, 체인·안경 프레임 같은 얇은 선은 축소 후 끊기지 않도록 유의한다. 체인/리본처럼 움직일 수 있는 부분은 실제 요청되었고 변형이 예정된 경우에만 중립 자세 참고를 제공한다. 금속은 좁고 대비 큰 반사, 렌즈는 진짜 투명 알파, 다른 재질은 각 소재에 맞춘다. 밝고 어두운 배경에서 알파/두께를 검수하되 눈·귀·신체를 새로 그리지 않는다.

기준 BODY와 동일 캔버스의 실제 부착점에 요청한 소품만 제작한다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** live2d_bust_up / accessory; ACCESSORY — 지정된 부착 소품 한 종류. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 방송용 바스트업: 얼굴·목·양어깨·양팔·양손·상복부가 빠지지 않게. 전신·하체 이미지 생성은 납품 필수 아님.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 최소 참고 파일 후보: reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: 신체·헤어·의상을 다시 제작하거나 종합 액세서리 세트를 강제로 만들지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 후속 Colab에서 See-through가 파츠를 분리하고 리깅 단계가 사용한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다.
- 소품 부착점과 가려진 뒷면을 참고 시점 그림으로 보여준다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. See-through 분리 이후 리깅 시 실제 관절·가림·회전 연결을 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

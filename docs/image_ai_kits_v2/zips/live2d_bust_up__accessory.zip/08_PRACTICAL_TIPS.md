## [SAFE_GENERATION_STAGE_V3]
이 ZIP은 ACCESSORY만 독립적으로 생성한다. 사용자가 지정한 단일 액세서리만 제작하고 신체·피부·BODY 원화는 새로 그리지 않는다. 다른 자산은 정렬 참조로만 사용한다. 이미지 생성기에는 해당 자산의 긍정적 디자인 설명과 해당 모드의 시점·캔버스 계약만 전달하고, 전체 14개 MD를 프롬프트로 복사하지 않는다. 분리/PSD/리깅은 후속 단계이며 안전 정책을 우회하지 않는다.
## [/SAFE_GENERATION_STAGE_V3]

## [ART_SOURCE_AND_SEPARATION_V3]
### live2d_bust_up / accessory — 자산·모드·담당 단계 잠금
- 자산 경계: ACCESSORY: 지정된 단일 장신구만. BODY·얼굴·눈·피부·헤어·의복 픽셀과 요청하지 않은 다른 장신구는 0개. ACCESSORY 납품물에는 피부·헤어·의복을 복사하지 않는다. 요청 소품 한 종류만.
- 명시적 생성 제외: ACCESSORY에서는 요청된 한 종류의 장신구만. 머리카락·얼굴·눈·피부·몸통·손·의상·요청되지 않은 기타 장식 생성 금지. 장착 위치의 기준 BODY/HAIR/OUTFIT 원화는 참조일 뿐 픽셀 납품 금지.
- 실물 납품 차단: ACCESSORY master/납품 PNG에 머리카락·피부·얼굴·의상 또는 요청되지 않은 추가 소품이 있으면 CROSS_ASSET_CONTAMINATION: FAIL. 기준 캐릭터 합성은 별도 previews/에서만 허용.
- 구도 경계: 바스트업은 얼굴과 큰 눈이 화면 중심, 머리부터 상복부, 양어깨·상완·전완·양손 끝까지. 골반·다리 금지.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. accessory 실제 세분화 판단: ACCESSORY: 실제 요청된 한 장신구의 운동/가림 단위로 분리. 고정 머리핀은 한 레이어 허용, 좌우 귀걸이·안경 다리·움직이는 리본 날개는 별도. 붙어 있는 신체·헤어·옷 픽셀 혼입 금지.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

## [GPT_ARTWORK_SEGMENTER_HANDOFF_V5]
### live2d_bust_up / accessory — GPT 마스터 원화에서 실제 분리 AI까지
**최상위 역할 계약. 이 ZIP은 GPT의 원화 생성 지시서이지 GPT에게 PSD·파츠 분리를 시키는 지시서가 아니다.** 모든 14개 MD의 기존 `part_art/`, `_order.txt`, `isolated_parts/`, PSD, 알파, 개별 눈·목 세분화, 합성 검수 지시는 **별도 후속 분리 엔진의 출력/검사 명세**로 해석한다. 이미지 생성 AI가 그 파일을 생성했다고 주장해서는 안 된다.
1. GPT는 `outputs/master.png` **실제 정면 원화 PNG 1장**(RGB 또는 진짜 RGBA)을 생성한다. 콜라주, 부품을 떨어뜨려 배치한 시트, 가짜 투명 PNG, 기존 이미지와 다른 인물로 그린 설정화는 불합격이다.
2. 다음은 투명 파츠가 아닌, 같은 캐릭터의 다른 시점/숨은 부분 참고 원화이다. **각각 별도의 실제 PNG**로 그린다.
  - `reference_views/accessory_front.png`
  - `reference_views/accessory_three_quarter_L.png`
  - `reference_views/accessory_three_quarter_R.png`
  - `reference_views/accessory_profile_L.png`
  - `reference_views/accessory_profile_R.png`
  - `reference_views/accessory_back.png`
  - `reference_views/accessory_attachment_anchor.png`
  - `reference_views/accessory_occlusion.png`
3. 마스터와 front/three_quarter/profile/pitch 참고는 **동일한 원본 캔버스 가로·세로 픽셀 크기, 인물 스케일·중심좌표**를 유지한다. 뷰 이름을 바꾸거나 정면을 복제해 다른 시점으로 위장하지 않는다.
4. **모드 구도:** 머리와 눈이 큰 방송용 바스트업. 상복부·양팔·양손가락 끝까지 포함. 골반·다리·발 없음.
5. **자산 경계:** 사용자가 요청한 한 종류 소품만. 기준 몸체의 부착 위치에 정렬하되 신체/얼굴/머리/의상을 복제하지 않는다.
6. **See-through 분리를 고려한 원화:** 한 이미지에 한 시점·한 캐릭터, 흰색/단순 단색 배경, 선명한 애니 셀 셰이딩/파츠 윤곽·깔끔한 경계; 글자·워터마크·장식 배경·눈 위의 불필요한 손/머리카락 겹침·과도한 발광 금지. 구분을 위해 머리·팔을 물리적으로 잘라 떼어 놓거나 전체 원화 품질을 저하시키지 않는다.
- 현재 자산 외의 BODY/얼굴/눈/의상/장신구 픽셀을 결과 이미지에 합치지 않는다. 원래 캐릭터는 위치·색·디자인 참조로만 사용한다.
7. **GPT 결과물:** `live2d_bust_up__accessory__ARTWORK.zip`에 `outputs/master.png`, 위 `reference_views/*.png` 및 BODY에서 `expression_refs/*.png`만 저장한다. `manifest.json`, `layer_order.txt`, `part_art/_order.txt`, `part_art/*.png`, `isolated_parts/`, PSD, MOC3 등 분리/리깅 파일은 생성하지 않는다. 원화 ZIP 납품과 Live2D 완료를 혼동하지 않는다.
8. **후속 파이프라인:** `tools/vts_source_only_pack.py`가 실물 마스터·뷰의 PNG 형식/중복/크기 등을 확인한다. 이후 See-through V3/NF4로 분리 PSD 후보를 만들고, 관찰된 파츠를 공식 좌우/깊이 세분화 또는 SAM 정밀 마스크로 필요 시 개선한다. Qwen-Image-Layered는 기존 런타임에서 해당 자산에 **실제로 연결된 경우에만** 추가 RGBA 분해에 사용한다. Qwen은 텍스트만으로 L/R 홍채·흰자·속눈썹 레이어를 정확히 지정하는 기능을 보장하지 않는다.
9. **후속 검수:** 원본 보이는 RGB 보존, 실제 알파, 가려진 부분 복원, PSD 순서/캔버스 좌표, 좌우 눈 흰자·홍채·속눈썹, 턱-목-몸통·팔-손 접합, 마스터 중립 합성 일치와 변형을 검사한다. 불합격 부위는 분리 작업에서만 재시도/인페인팅하고 GPT가 파츠 시트를 대신 그리게 하지 않는다. 결과 PSD는 Cubism/Inochi2D 모델 리깅/방송 동작 성공을 뜻하지 않는다.
10. 위에 적힌 PNG를 실제 제작할 수 없으면 그 누락을 명확히 보고한다. 분리 엔진 오류는 GPT 원화 생성 완료와 별도로 보고한다.
## [/GPT_ARTWORK_SEGMENTER_HANDOFF_V5]

## [MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
### live2d_bust_up / accessory — 24개 자산별 실제 분리 경로
**V5의 GPT 원화 역할을 유지한 채, 후속 분리 AI가 무엇을 어떻게 나눌지 정하는 최신 자산 전용 기준.** 모드·자산을 서로 바꿔 처리하면 실패다.
- 작업 범위: Live2D 방송용 바스트업: 큰 두상, 머리~상복부, 양팔과 양손가락 끝. 다리·발·골반 파츠 금지.
- 대상 경계: 사용자가 요청한 장식 단 한 종류만. 소품 유형을 모르거나 여러 후보가 섞이면 임의로 headwear 등으로 결정하지 않고 품목 확인/수정 필요.
- **See-through V3의 실제 기본 태그 중 이 자산 관련 항목:** headwear, earwear, eyewear, neckwear, tail, wings, objects. 23개 태그 이외의 파츠 명칭을 모델이 직접 출력한다고 간주하지 않는다.
- **실제 후속 세부 분리·검수 대상:** 사용자가 요청한 한 종류 소품의 독립 본체, 부착점, 다른 파츠 뒤 가려지는 뒷면, 실제 움직임이 필요한 세부
- **V3만으로 불가능/불충분:** headwear/earwear/eyewear/neckwear/tail/wings/objects 중 실제 요청 품목에 해당하는 것만 유효하다. 클래스만으로 정확한 장식 본체·고정점·내부 움직임 파츠를 인증할 수 없다.
- **어떤 엔진이 실제 수행:** 실행 경로: 독립 자산 PNG의 진짜 알파가 있으면 보존; 아니면 단색 배경에서 실물 전경 마스크를 검사해 추출 → 독립 자산 PSD 1개 후보 → 별도 세부 분리·가림 면 보정 필요. **이 자산만 있는 PNG에는 See-through V3 전체 캐릭터용 head crop을 실행하지 않는다.** V3의 의미 태그는 캐릭터 전체 PSD가 별도로 제공된 경우의 참고 카테고리일 뿐이다.
- **완성 조건:** 이미지 생성 GPT가 한 장짜리 가짜 파츠 시트를 만들면 실패. See-through 결과 PSD만 생성되거나 레이어 이름/개수만 맞으면 **분리 성공 아님**. 실제 움직일 파츠의 서로 다른 원본 RGB/알파/레이어/가려진 면이 검증돼야 한다. 실패 항목은 해당 파츠만 정밀 분리·인페인팅하여 재검사하고, 전체 원화를 매번 재생성하지 않는다.
- 3D HAIR/OUTFIT처럼 제작 엔진이 없는 경우 또는 독립 2D 자산의 세부 분리가 남아 있으면 `NOT_YET_RIG_READY`로 명시한다. 중간 PSD를 완성된 방송 모델로 제출 금지.
- 경로 규정의 코드 기준: `tools/vts_segmentation_profiles.py`. Live2D/Inochi2D 실행은 `notebooks/VTuber_Finished_AI_ZIP_All_Modes.ipynb`의 모드/자산 선택을 따른다.
## [/MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **live2d_bust_up / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 액세서리 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 액세서리의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 액세서리 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.

# Live2D 바스트업 accessory 고유 실무 노하우

1. 사용자가 명시한 액세서리 한 종류만 제작한다. 예시에 나온 모든 소품을 한 번에 추가하지 않는다.
2. 실제 **원본 기준 원화**에서 부착 앵커를 찾는다. 안경=코·귀, 귀걸이=귀, 머리핀=머리카락처럼 그 종류에 해당할 때만 적용한다.
4. 얇은 체인·프레임, 반투명 렌즈, 금속 반사광의 알파 경계·앞뒤 가림을 확대해 검수한다.
5. 소품 뒤에 필요한 가려진 면을 보완하되 얼굴·눈·입·헤어를 다시 생성하지 않는다.
6. 같은 캔버스에 재합성하여 물체가 떠 보이지 않는지, 너무 크거나 눈·입을 가리지 않는지 작은 방송 크기에서도 확인한다.


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / accessory]
### 작업 순서·아티스트 실전 노하우
1. 캐릭터 기준 원화에서 코·귀·앞머리·옷깃 중 해당 소품의 부착 앵커를 정확히 선택한다. 임의 장식 세트 생성은 금지한다.
2. 고정부는 안정적, 흔들리는 본체는 실제 길이와 접점이 보이도록 그린다. 체인/안경다리/얇은 링이 한두 픽셀로 끊기지 않게 한다.
3. 투명 렌즈 등은 사용자 요구 재질에 있을 때만. 반투명 알파·프린지를 밝은/어두운 배경에서 둘 다 확인한다.
4. 원본 기준 신체에 겹쳐 부착이 떠 있지 않은지, 앞뒤 L/R이 뒤집히지 않았는지, 방송 크기에서 표정을 가리지 않는지 본다.
5. 소품 PNG만 납품한다. 인접 얼굴/헤어/의상은 합성 미리보기에만 이용하고 실제 산출 픽셀에 섞지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/accessory]
**측면에서의 부착 검수:** 안경이 요청됐다면 정면 코받침→측면 안경다리→귀 뒤의 연결이 부유하지 않게, 귀걸이라면 귓불 앵커와 좌우 가림이 틀어지지 않게, 헤어핀이면 그 디자인의 실제 가닥 뿌리에 고정되게 그린다. **이는 조건부 예시이고 함께 생성할 목록이 아니다.** 고개를 돌렸을 때 물건의 앞뒤 순서·폭·두께가 달라질 것을 참고로 표시하되 피부·귀·헤어·얼굴은 새 그림으로 만들지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/accessory]
**[소품 소재·선폭·가림]** 원본 디자인의 고정부와 연결점은 읽히는 선폭으로, 체인·안경 프레임 같은 얇은 선은 축소 후 끊기지 않도록 유의한다. 체인/리본처럼 움직일 수 있는 부분은 실제 요청되었고 변형이 예정된 경우에만 중립 자세 참고를 제공한다. 금속은 좁고 대비 큰 반사, 렌즈는 진짜 투명 알파, 다른 재질은 각 소재에 맞춘다. 밝고 어두운 배경에서 알파/두께를 검수하되 눈·귀·신체를 새로 그리지 않는다.

기준 BODY와 동일 캔버스의 실제 부착점에 요청한 소품만 제작한다.



## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [BROADCAST_HANDS_BODY_COLOR_V1]
### 방송용 손·목·소매 접합 실무 순서
**범위 우선순위:** 이 지침은 같은 ZIP의 오래된 '가슴 위까지만', '손이 보일 때만 손' 같은 조건보다 우선한다. 바스트업의 원본에는 양손 끝까지 무조건 포함한다. 작업 자산 소유권·2D/3D 형식 규칙은 유지한다.
### 바스트업 ACCESSORY: BODY 양손·목 보존과 자산별 정확한 정렬

- **바스트업 위치 참고 범위:** 기준 BODY 원화에서 정수리·양어깨·상완·전완·양손 열 손가락 끝·윗배 및 작업 여백까지 눈으로 확인한다. HAIR/OUTFIT/ACCESSORY에서는 손을 새로 생성하지 않는다. 기존 BODY의 손과 목을 가리지 않는 현재 자산의 그림만 동일 캔버스 좌표에 납품한다.
- **현재 ZIP은 ACCESSORY만 생성한다.** 기준 BODY의 양손·팔·목과 윗배는 위치 및 가림 참조로만 사용한다. BODY의 피부/클레이 RGB 픽셀을 현재 자산의 독립 산출물에 복사하거나, BODY 손이 잘린 상태로 둔 채 의상·머리카락·장식으로 숨기지 않는다. 안경·귀걸이·목걸이·머리핀 등 요청한 한 종류의 부착점만 그린다. 목·귀·손 피부를 장식색으로 덮거나 BODY 색의 임시 도형으로 바꾸지 않는다. 2D는 실제 독립 자산 PNG만 납품하고, BODY 원화는 참고 합성으로만 사용한다.
- **보정색:** 가림에 감춰지는 BODY 피부/무광 외피를 임의 회색 면으로 교체하지 않는다. 보이는 BODY RGB와 연속된 원래 색을 유지하도록 참고하되, 현재 자산의 숨은 픽셀은 현재 자산 고유의 재질색으로 그린다. 별도의 알파/클리핑 마스크를 몸색 RGB로 채워 버리지 않는다.
- 현재 자산의 부분별 ON/OFF를 BODY 참조 합성 위에서 검토한다. BODY의 neck·arm·hand를 현재 자산 파일에 복제하지 않는다. 소매/옷깃·머리카락·소품이 가리는 면은 현재 소재의 실제 색으로 완성한다.
## [/BROADCAST_HANDS_BODY_COLOR_V1]

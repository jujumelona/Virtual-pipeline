## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **live2d_bust_up / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 기존 자료 형식: PSD
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.
- 2. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** head to upper abdomen/waist with complete shoulders arms and hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# Live2D 바스트업 accessory 고유 실무 노하우

1. 사용자가 명시한 액세서리 한 종류만 제작한다. 예시에 나온 모든 소품을 한 번에 추가하지 않는다.
2. 실제 **원본 기준 원화**에서 부착 앵커를 찾는다. 안경=코·귀, 귀걸이=귀, 머리핀=머리카락처럼 그 종류에 해당할 때만 적용한다.
3. 고정부·실제 흔들릴 본체만 실용적으로 분리하고 무의미한 작은 조각 수를 늘리지 않는다.
4. 얇은 체인·프레임, 반투명 렌즈, 금속 반사광의 알파 경계·앞뒤 가림을 확대해 검수한다.
5. 소품 뒤에 필요한 가려진 면을 보완하되 얼굴·눈·입·헤어를 다시 생성하지 않는다.
6. 같은 캔버스에 재합성하여 물체가 떠 보이지 않는지, 너무 크거나 눈·입을 가리지 않는지 작은 방송 크기에서도 확인한다.

공통 작업: 실제 원본 기준 원화의 동일 캔버스·원점·스케일을 보존하고 투명 PNG를 원래 순서로 재합성합니다. 다른 자산 원화를 새로 만들거나 리깅 결과를 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / accessory]
### 작업 순서·아티스트 실전 노하우
1. 캐릭터 기준 원화에서 코·귀·앞머리·옷깃 중 해당 소품의 부착 앵커를 정확히 선택한다. 임의 장식 세트 생성은 금지한다.
2. 고정부는 안정적, 흔들리는 본체는 실제 길이와 접점이 보이도록 그린다. 체인/안경다리/얇은 링이 한두 픽셀로 끊기지 않게 한다.
3. 투명 렌즈 등은 사용자 요구 재질에 있을 때만. 반투명 알파·프린지를 밝은/어두운 배경에서 둘 다 확인한다.
4. 원본 기준 신체에 겹쳐 부착이 떠 있지 않은지, 앞뒤 L/R이 뒤집히지 않았는지, 방송 크기에서 표정을 가리지 않는지 본다.
5. 소품 PNG만 납품한다. 인접 얼굴/헤어/의상은 합성 미리보기에만 이용하고 실제 산출 픽셀에 섞지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/accessory]
**측면에서의 부착 검수:** 안경이 요청됐다면 정면 코받침→측면 안경다리→귀 뒤의 연결이 부유하지 않게, 귀걸이라면 귓불 앵커와 좌우 가림이 틀어지지 않게, 헤어핀이면 그 디자인의 실제 가닥 뿌리에 고정되게 그린다. **이는 조건부 예시이고 함께 생성할 목록이 아니다.** 고개를 돌렸을 때 물건의 앞뒤 순서·폭·두께가 달라질 것을 참고로 표시하되 피부·귀·헤어·얼굴은 새 그림으로 만들지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/accessory]
**[소품 소재·선폭·가림]** 원본 디자인의 고정부와 연결점은 읽히는 선폭으로, 체인·안경 프레임 같은 얇은 선은 축소 후 끊기지 않도록 유의한다. 체인/리본처럼 움직일 수 있는 부분은 실제 요청되었고 변형이 예정된 경우에만 중립 자세 참고를 제공한다. 금속은 좁고 대비 큰 반사, 렌즈는 진짜 투명 알파, 다른 재질은 각 소재에 맞춘다. 밝고 어두운 배경에서 알파/두께를 검수하되 눈·귀·신체를 새로 그리지 않는다.

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
기준 BODY와 동일 캔버스의 실제 부착점에 요청한 소품만 제작한다.
실제 다층 PSD, 같은 캔버스 투명 RGBA PNG와 파츠별 알파 마스크, 원본 입력과 원본 PSD(있다면), 원본-결과 및 PRO BODY 정합 미리보기, 레이어 좌표/순서·검증·분할 JSON, 사용자 제작·시각검수·Cubism 안내 MD는 최종 필수. PSD와 마스크가 없으면 중간 PNG 검사 PASS여도 최종 납품 불가. BODY 최종 납품에 --final-live2d-body를 사용한다. HAIR/OUTFIT/ACCESSORY도 PSD·마스크 필수. 실제 이미지/Editor 확인 없이 미술·리깅 품질 PASS 금지.

## [ART_SOURCE_AND_SEPARATION_V3]
### live2d_bust_up / accessory — 자산·모드·담당 단계 잠금
- 자산 경계: ACCESSORY: 지정된 단일 장신구만. BODY·얼굴·눈·피부·헤어·의복 픽셀과 요청하지 않은 다른 장신구는 0개. ACCESSORY 납품물에는 피부·헤어·의복을 복사하지 않는다. 요청 소품 한 종류만.
- 구도 경계: 바스트업은 얼굴과 큰 눈이 화면 중심, 머리부터 상복부, 양어깨·상완·전완·양손 끝까지. 골반·다리 금지.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. accessory 실제 세분화 판단: ACCESSORY: 실제 요청된 한 장신구의 운동/가림 단위로 분리. 고정 머리핀은 한 레이어 허용, 좌우 귀걸이·안경 다리·움직이는 리본 날개는 별도. 붙어 있는 신체·헤어·옷 픽셀 혼입 금지.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 선택 장신구의 형태·재질·부착점·후면·크기와 다른 자산 픽셀 혼입을 실제 시각 확인. 예시의 완성 캐릭터 눈·몸을 그대로 복사하지 않는다.
- **모드별 실제 구도:** 방송용 바스트업: 머리·얼굴을 크게, 아래쪽은 상복부와 양손 손가락 끝까지만. 골반·허벅지·무릎·발·전신 그림 생성 금지. ACCESSORY: 지정된 단일 장신구만. BODY·얼굴·눈·피부·헤어·의복 픽셀과 요청하지 않은 다른 장신구는 0개.
- **해당 자산의 고품질 제작 조건:** ACCESSORY 전용. 지정 소품의 소재·윤곽·입체 두께·부착점·그림자·가려진 뒷면을 세련된 애니 원화로 그린다. 원/사각형·SVG 선만으로 구성한 임시 표시물을 완성품으로 제출하지 않으며 신체·의상·헤어를 중복 제작하지 않는다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선택 장신구의 형태·재질·부착점·후면·크기와 다른 자산 픽셀 혼입을 실제 시각 확인. 증거 없으면 ART_QUALITY_UNVERIFIED.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**live2d_bust_up/accessory 전용 생성 최우선 규칙.** 이 조항보다 아래의 구형 구도·얼굴형 설명이 충돌하면 이 조항을 우선한다.
- ACCESSORY는 기존 BODY/HAIR의 큰 머리·짧고 둥근 얼굴 인상을 보존. 머리장식·안경·귀걸이 등 요청한 소품이 두상에 비해 지나치게 크거나 작고, 얼굴을 길고 좁게 보이게 하면 불합격. 기존 얼굴·눈·턱·귀·모근 앵커만 참조하고 재생성하지 않는다. 요청 소품 하나만.
- 공통 스타일: 귀여운 애니/VTuber, 머리가 상대적으로 크게 보이고, **짧고 폭이 있는 얼굴·부드럽고 짧은 U형 턱·큰 눈과 홍채·작은 코와 입**. 긴/좁은 얼굴, 말상, 길게 내려온 뾰족한 턱, 현실/성숙 모델 인상은 절대 불합격.
- 기준 얼굴 비율(참조만): 승인된 두상·귀·머리·몸체는 부착 위치 참조다. 오직 지정된 장신구만 원화로 그린다. 신체 6등신/머리 크기는 해당 자산 그림의 생성 명령이 아니다.
- 실물 기준 BODY가 제공되면 원본 두상/얼굴을 바꾸지 않는다. 2D는 완성 원화·파트 재합성에서 기준 얼굴과 실제 시각 비교한다.
- **검수 필수:** 머리 크기, 얼굴의 넓고 짧은 윤곽, 둥근 턱끝, 눈/홍채 크기, 자연스러운 목·어깨 비율, 기준 캐릭터 동일성, 다른 자산 혼입 여부. 머리·얼굴을 왜곡하는 소품 비율 발견 시 불합격.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_bust_up/accessory]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **ACCESSORY만 생성:** 요청한 장식/부착점/겹침과 필요한 숨은 면만. BODY·얼굴·헤어·의상 전체를 재생성하지 않는다.
- 프레임: 방송용 바스트업: 머리·얼굴을 크게, 아래쪽은 상복부와 양손 손가락 끝까지만. 골반·허벅지·무릎·발·전신 그림 생성 금지. ACCESSORY: 지정된 단일 장신구만. BODY·얼굴·눈·피부·헤어·의복 픽셀과 요청하지 않은 다른 장신구는 0개.
- 기준 얼굴 정합(참조만): 승인된 두상·귀·머리·몸체는 부착 위치 참조다. 오직 지정된 장신구만 원화로 그린다. 얼굴·눈 자체는 이 ZIP의 제작 항목이 아니다.


## [2026-10-13 v5 live2d_bust_up/accessory 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.

# Live2D 방송용 바스트업 액세서리 애니풍 기준

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / accessory
**실제 제작:** 사용자가 지정한 한 종류의 액세서리 본체·부착 고정부·필요한 움직임 부품만.
**금지:** 신체·헤어·의상·얼굴·눈·입을 새로 만들지 않는다. 안경/귀걸이/목걸이/헤드셋을 모두 묶은 세트를 만들지 않는다.


- 대상: 사용자가 지정한 한 종류의 액세서리 본체·부착 고정부·필요한 움직임 부품만. 신체·헤어·의상·얼굴·눈·입을 새로 만들지 않는다. 안경/귀걸이/목걸이/헤드셋을 모두 묶은 세트를 만들지 않는다.
- 애니풍: 검정에 가까운 짙은 가변 굵기 선화와 가늘어지는 테이퍼, 깔끔한 소재별 내부선, 2~3톤 셀 명암·높은 디자인 일관성.
- 이 자산의 미술적 특징: 지정한 한 물건의 부착 앵커·좌우 깊이·연결부 강도·투명 알파/금속 재질·방송 크기에서 표정 가림 없음.
- 기준 캐릭터의 눈매·머리/얼굴 비율은 **참조를 통한 크기·정체성 맞춤**이며 신체와 얼굴 이외 자산을 새로 생성하는 요구가 아니다.

영어 이미지 프롬프트: “Professional premium anime VTuber bust-up accessory-only artwork, variable-weight tapered dark linework, detailed consistent 2-3 tone cel shading, faithful original character aesthetics, isolated requested accessory art on matching full canvas, no extra character parts or props.”


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / accessory]
### 이 ZIP에만 적용할 애니풍 프롬프트
Premium anime VTuber BUST-UP ACCESSORY ONLY, exactly one requested item, precise attachment to reference character, stable mounting hardware and optional authentic dangling parts, clean antialiased fine ink and material-specific subtle reflections, correct transparent alpha and L/R depth, visually readable at stream thumbnail size, no extra ornaments, no body hair clothing or face redraw.
**소유 픽셀:** 캐릭터 기준 이미지의 다른 범주는 좌표/컬러 참조일 뿐 새 그림 산출 대상이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/accessory]
Anime VTuber ONE ACCESSORY ONLY: precise existing mounting anchor, nuanced material-specific lineweight, fine chains or ties in a readable neutral reference pose only when that item actually has flexible parts, crisp metal highlights and transparent glass alpha only if needed; never add a second ornament, face, body, hair or garment.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | accessory]
Use the same FACE-FIRST bust-up canvas only for scale, draw exactly one requested attached item, clear at streaming preview size with correct L/R and occlusion, no face/eye/body/hair/clothing regeneration and no extra ornaments.

기준 BODY와 동일 캔버스의 실제 부착점에 요청한 소품만 제작한다.
ONE ACCESSORY ONLY using approved body anchor.

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

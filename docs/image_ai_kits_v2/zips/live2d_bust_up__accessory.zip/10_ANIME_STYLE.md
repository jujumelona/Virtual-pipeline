# Live2D 방송용 바스트업 액세서리 애니풍 기준

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / accessory
**실제 제작:** 사용자가 지정한 한 종류의 액세서리 본체·부착 고정부·필요한 움직임 부품만.
**금지:** 신체·헤어·의상·얼굴·눈·입을 새로 만들지 않는다. 안경/귀걸이/목걸이/헤드셋을 모두 묶은 세트를 만들지 않는다.
**구도:** 방송용 바스트업은 머리 높이 1 : 보이는 목·어깨·상체 약 1~2의 레이아웃 기준이며, 헤어·의상·액세서리 ZIP에서는 제공된 기준 몸체를 새로 그리지 않고 해당 자산만 완성한다.


- 대상: 사용자가 지정한 한 종류의 액세서리 본체·부착 고정부·필요한 움직임 부품만. 신체·헤어·의상·얼굴·눈·입을 새로 만들지 않는다. 안경/귀걸이/목걸이/헤드셋을 모두 묶은 세트를 만들지 않는다.
- 애니풍: 검정에 가까운 짙은 가변 굵기 선화와 가늘어지는 테이퍼, 깔끔한 소재별 내부선, 2~3톤 셀 명암·높은 디자인 일관성.
- 이 자산의 미술적 특징: 지정한 한 물건의 부착 앵커·좌우 깊이·연결부 강도·투명 알파/금속 재질·방송 크기에서 표정 가림 없음.
- 기준 캐릭터의 눈매·머리/얼굴 비율은 **참조를 통한 크기·정체성 맞춤**이며 신체와 얼굴 이외 자산을 새로 생성하는 요구가 아니다.
- 머리 1높이에 화면에 보이는 상체 1~2높이라는 구도 기준만 적용한다. 전신의 하체/다리/발을 강제하지 않는다.

영어 이미지 프롬프트: “Professional premium anime VTuber bust-up accessory-only artwork, variable-weight tapered dark linework, detailed consistent 2-3 tone cel shading, faithful original character aesthetics, isolated requested accessory art on matching full canvas, no extra character parts or props.”


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / accessory]
### 이 ZIP에만 적용할 애니풍 프롬프트
Premium anime VTuber BUST-UP ACCESSORY ONLY, exactly one requested item, precise attachment to reference character, stable mounting hardware and optional authentic dangling parts, clean antialiased fine ink and material-specific subtle reflections, correct transparent alpha and L/R depth, visually readable at stream thumbnail size, no extra ornaments, no body hair clothing or face redraw.
**소유 픽셀:** 캐릭터 기준 이미지의 다른 범주는 좌표/컬러 참조일 뿐 새 그림 산출 대상이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/accessory]
Anime VTuber ONE ACCESSORY ONLY: precise existing mounting anchor, nuanced material-specific lineweight, fine chains or ties in a readable neutral reference pose only when that item actually has flexible parts, crisp metal highlights and transparent glass alpha only if needed; never add a second ornament, face, body, hair or garment.

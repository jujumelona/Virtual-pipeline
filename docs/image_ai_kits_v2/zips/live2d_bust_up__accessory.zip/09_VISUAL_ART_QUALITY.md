
## [2026-10-13 v5 live2d_bust_up/accessory 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.
ACCESSORY: 요청한 소품 한 종류만, BODY/헤어/의상 재생성 금지. 정확한 부착 앵커·좌우 의미·전후 가림·투명 알파와 독립 레이어·기준 몸체 캔버스 정합 검사. 임의 소품 세트 강제 금지.

# Live2D 바스트업 액세서리 고퀄리티 그림 검수

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / accessory
**실제 제작:** 사용자가 지정한 한 종류의 액세서리 본체·부착 고정부·필요한 움직임 부품만.
**금지:** 신체·헤어·의상·얼굴·눈·입을 새로 만들지 않는다. 안경/귀걸이/목걸이/헤드셋을 모두 묶은 세트를 만들지 않는다.


- 지정한 한 물건의 부착 앵커·좌우 깊이·연결부 강도·투명 알파/금속 재질·방송 크기에서 표정 가림 없음.
- 원본 기준 몸체/헤어의 부착 위치를 참조해 물체의 크기·좌우·앞뒤 순서·측면 깊이를 맞춘다. 가느다란 체인·안경다리·반투명 렌즈는 실제 선택된 물건에 있을 때만 그린다.
- **자산 순도:** 신체·헤어·의상·얼굴·눈·입을 새로 만들지 않는다. 안경/귀걸이/목걸이/헤드셋을 모두 묶은 세트를 만들지 않는다.
- 참조 몸체가 있다면 overlay로만 비교하고 실제 제작 PNG에는 대상 액세서리의 픽셀만 들어간다.
- 빛 방향과 두께/테이퍼·소재별 내부선·2~3톤 셀 셰이딩을 숙련 작화 수준으로 유지한다. 조악한 SVG/Pillow/Matplotlib 기초 도형·색면 인형은 최종 원화로 인정하지 않는다.
- 흰색/어두운 배경 모두에서 PNG 알파를 확인하고, 단독 PNG와 합성 미리보기를 번갈아 검수한다.
- 참고: https://www.live2d.com/en/learn/sample/ . 실제 이미지에 접근하지 않았다면 샘플을 봤다고 주장하지 않는다. 실제 필요한 그림을 그리지 못하면 ZIP 품질 통과를 선언하지 않는다.


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / accessory]
### 해당 ZIP의 미술 합격 기준
- 주문받은 **한 종류**만 생성했는가? 예시 소품을 세트로 덧그리지 않았는가?
- 부착 앵커·앞뒤·좌우가 실제 기준 캐릭터와 맞는가?
- 얇은 프레임·체인·장식 끝의 알파/두께가 깨끗하고 공중에 떠 보이지 않는가?
- 합성에서 눈·입·신체를 가리지 않으며 다른 자산의 픽셀을 포함하지 않는가?
**관점:** 원본 캐릭터의 미술적 정체성·선폭·명암·색이 같은가? 파츠 번호나 PNG 개수로 미술 품질을 대신할 수 없다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/accessory]
**[소품의 고급 완성도]** 부착점과 얇은 연결의 선폭 위계, 실제 재질의 반사와 투명 경계, 축소 시 인식되는 실루엣을 확인한다. 리본·체인·고리·렌즈는 요청한 물건에 존재할 때만 필요한 품질 항목이다.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | accessory]

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
기준 BODY와 동일 캔버스의 실제 부착점에 요청한 소품만 제작한다.
ACCESSORY 자산의 최종 산출은 해당 자산의 완성 원화와 실제 독립 PNG/숨은 면 보완, 같은 캔버스의 미리보기·레이어 순서·검증 기록, 실제 제작한 다층 PSD 및 필요 마스크를 포함한다. BODY 전용 최종 납품 옵션과 눈/피부 파츠 생성 조건을 이 자산에 강제하지 않는다. 미작성 산출물을 제작 완료로 표기하지 않는다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** live2d_bust_up / accessory; ACCESSORY — 지정된 부착 소품 한 종류. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 방송용 바스트업: 얼굴·목·양어깨·양팔·양손·상복부가 빠지지 않게. 전신·하체 이미지 생성은 납품 필수 아님.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 최소 참고 파일 후보: reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 위 PNG 목록은 **납품 필수**이고 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 부착점과 접촉 방향·앞뒤 깊이·고정부·가려지는 뒷면을 실제 원화로 만든다. 좌우 회전시 소품 두께와 고정점이 유지되어야 한다. 필요한 경우 서로 다른 깊이에서 움직이는 소품의 부위만 분리한다. 사용자가 요청한 종류가 머리 장식이 아닐 수 있으므로 실제 소품 형태에 맞춰 뷰를 조정한다.
- Colab 입력 파츠·경로 계약: ACCESSORY의 isolated_parts/ 파츠 ID는 accessory/ornament 계열로 시작하도록 적고, 한 파츠의 좌우·깊이 정보를 이름에 명확히 표시한다. 다른 자산의 이름이나 픽셀은 독립 파츠로 포함하지 않는다. layer_order.txt의 경로는 실제 isolated_parts/ PNG와 1:1 매칭한다.
- 자산 소유권 금지: 신체·헤어·의상을 다시 제작하거나 종합 액세서리 세트를 강제로 만들지 않는다.
- 2D ZIP의 실제 납품은 해당 자산의 기준 마스터 원화, 추가 참고 시점 그림, 독립 RGBA 원화 파츠와 마스크, 합성 미리보기, 편집 가능한 레이어 PSD 및 검수표다. 참고 시점 PNG가 자동으로 모션 키폼·메시가 되지는 않는다.
- 기존 MD에서 reference_views/를 '필요한 경우만' 또는 선택 사항으로 표현했더라도 위 지정 시점 파일은 최종 ZIP에서 필수다. 파일명 대소문자/확장자/경로를 변경하지 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

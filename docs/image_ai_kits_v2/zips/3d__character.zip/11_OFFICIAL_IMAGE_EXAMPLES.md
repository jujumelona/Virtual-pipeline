# 참고 이미지 자료

VRoid Studio https://vroid.com/en/studio : 형태·시점 참고만. VRM 생성은 이미지 AI의 산출 요구가 아니다.

예제 캐릭터의 디자인 자체를 베끼지 않는다. 3D VRM 참조도에서 필요한 CHARACTER 완성 캐릭터 2D 원화만 제작한다. 출력 경로는 04_OUTPUT_FILES.md의 실제 PNG 목록과 일치해야 한다.

## 3D_COMPLETE_CHARACTER_FROM_2D_V1
한 인물의 얼굴·헤어·의상 입은 전신을 실제로 모두 그린 2D 다각도 원화만 생성. 후속 3D 모델링이 별도 진행된다.


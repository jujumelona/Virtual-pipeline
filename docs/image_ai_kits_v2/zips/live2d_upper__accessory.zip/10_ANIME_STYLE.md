## [ART_SOURCE_AND_SEPARATION_V3]
### live2d_upper / accessory — 자산·모드·담당 단계 잠금
- 자산 경계: 액세서리 전용. 실제 주문된 장신구 한 종류만. 고정부·좌우 부착점·움직이는 날개와 가려진 부분만. 헤어·옷·신체 픽셀과 임의 장신구 세트 금지.
- 구도 경계: 상반신은 머리부터 허리 부근, 양팔·양손 끝까지. 다리·발 금지.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. accessory 실제 세분화 판단: ACCESSORY: 실제 요청된 한 장신구의 운동/가림 단위로 분리. 고정 머리핀은 한 레이어 허용, 좌우 귀걸이·안경 다리·움직이는 리본 날개는 별도. 붙어 있는 신체·헤어·옷 픽셀 혼입 금지.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** 정수리~허리의 애니풍 상반신. 큰 얼굴/눈 중심, 짧고 넓은 얼굴과 정확히 연결된 목·어깨·자연스러운 팔과 양손을 그린다. 가로로 뻗은 팔·작은 머리·길쭉한 실사 비율·납작한 밴드형 캐릭터는 거절한다.
- **해당 자산의 고품질 제작 조건:** ACCESSORY 전용. 지정 소품의 소재·윤곽·입체 두께·부착점·그림자·가려진 뒷면을 세련된 애니 원화로 그린다. 원/사각형·SVG 선만으로 구성한 임시 표시물을 완성품으로 제출하지 않으며 신체·의상·헤어를 중복 제작하지 않는다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
live2d_upper/accessory 원화 생성 우선 조건. 충돌하는 구형 미술 지침보다 우선한다.
- ACCESSORY: 기준 BODY/HAIR의 큰 두상과 짧고 둥근 얼굴을 보존. 장식/안경/귀걸이 비율이 얼굴을 길고 좁게 보이게 하면 불합격. 요청 소품만 제작하고 기준 얼굴·눈·헤어 재생성 금지.
- 공통: **큰 머리, 큰 눈과 홍채, 짧고 넓은 얼굴, 둥근 볼, 짧고 매끈한 U형 턱, 작은 코·입.** 말상·좁은 얼굴·길게 내려오는 V턱·성숙 실사 얼굴은 절대 불합격.
- 정면 얼굴 높이/폭 약 1.10~1.30은 참고 범위이며 강제 크롭/화면 점유율은 아님. 전신 6등신 유지, 바스트업·상반신은 머리를 작게 만들지 않음.
- 실패 판정: 머리가 작다 / 눈이 작다 / 얼굴이 길거나 좁다 / 턱이 뾰족하다 / 목이 길다 / 다른 자산이 혼입됐다. 하나라도 해당하면 불합격이며 무검증 납품 금지.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_upper/accessory]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **ACCESSORY만 생성:** 요청한 장식/부착점/겹침과 필요한 숨은 면만. BODY·얼굴·헤어·의상 전체를 재생성하지 않는다.
- 프레임: 정수리부터 허리와 양손까지 상반신. 자산 소유 범위에만 적용. 전신 캐릭터 기본 디자인은 6등신을 지향하나 크롭에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY 제공 시 얼굴 비율을 변경하지 않는다.


## [2026-10-13 v5 live2d_upper/accessory 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
ACCESSORY: 요청한 소품 한 종류만 제작, 기준 BODY/HAIR/OUTFIT는 정합을 위한 참조이므로 생성하지 않는다. 부착 앵커·앞/뒤·좌/우·투명 알파 및 얇은 부분 가림, 캔버스/원점 동일성, 합성 미리보기 실제 검수. 소품 예시를 실제 디자인에 강제하지 않는다.

# Live2D 상반신 액세서리 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.


작은 소품에도 분명한 실루엣·소재와 광택, 정확한 부착 구조·가변 선폭·깔끔한 투명 알파. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber accessory-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested accessory asset on the reference canvas, no unrelated character parts or props.”



## [2026-10-13 원화·애니풍 심화: live2d_upper/accessory]
Premium anime VTuber UPPER ACCESSORY ONLY, exactly one requested item with credible attachment, correct left right and occlusion, precise fine material edges and alpha when present; no second accessory and no redraw of character hair body skin or outfit.
Commercial Japanese anime, variable tapered dark ink and refined material cel shading, keep original character design.


## [고급 그림자·모근·소재·선폭 | live2d_upper/accessory]
Anime VTuber ONE ACCESSORY ONLY: precise existing mounting anchor, nuanced material-specific lineweight, fine chains or ties in a readable neutral reference pose only when that item actually has flexible parts, crisp metal highlights and transparent glass alpha only if needed; never add a second ornament, face, body, hair or garment.

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

# Live2D 상반신 / 액세서리만 출력 이미지
결과 ZIP: `live2d_upper__accessory__ARTWORK.zip`
```text
isolated_parts/accessory_headpiece_main.png
layer_order.txt
previews/overlay_preview.png
```
**실제 있는 파츠만 생성**하며, 고급 독립 움직임/가림이 있는 경우 02의 세부 이름 추가. 액세서리 headpiece 명칭은 해당 사용자가 요청한 물건의 이름으로 교체. 개별 RGBA 원화·동일 캔버스/원점·뒤→앞 목록. 미리보기는 생성된 파츠의 실제 합성.

**09 + 10의 고급 애니풍 품질 기준과 07 반복 점검을 충족한 경우에만 최종 ZIP 제공.**

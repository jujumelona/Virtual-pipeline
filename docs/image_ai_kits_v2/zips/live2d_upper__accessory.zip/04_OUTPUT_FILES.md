# Live2D 상반신 / 액세서리만 출력 이미지

**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.


> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 해당 2D 자산의 완성 기준 원화 먼저 제작 → 실제 RGBA 파츠만 분리 → 해당 자산의 숨은 면 추가 작화. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
결과 ZIP: `live2d_upper__accessory__ARTWORK.zip`
```text
isolated_parts/accessory_<requested_type>_main.png
layer_order.txt
previews/overlay_preview.png
```
**실제 있는 파츠만 생성**하며, 고급 독립 움직임/가림이 있는 경우 02의 세부 이름 추가. 액세서리 headpiece 명칭은 해당 사용자가 요청한 물건의 이름으로 교체. 개별 RGBA 원화·동일 캔버스/원점·뒤→앞 목록. 미리보기는 생성된 파츠의 실제 합성.

**09 + 10의 고급 애니풍 품질 기준과 07 반복 점검을 충족한 경우에만 최종 ZIP 제공.**


## ZIP 고유 작업 범위 잠금: live2d_upper / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기존 몸체·헤어·옷의 장착 위치 좌표만 참조. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 

04의 파일명은 이 ZIP의 대상 부위에만 적용한다. 다른 종류 파츠는 기준 몸체 overlay에만 참조할 수 있고 isolated_parts/나 source로 출력하면 안 된다.

**파일명 치환 주의:** `<requested_type>`는 고정 문자열이 아니며 사용자가 실제 요청한 소품 종류의 ASCII 이름으로 반드시 바꾼다. 예시는 실제 요청되지 않은 머리장식을 추가하라는 의미가 아니다.


## [필수: 2D 결과 ZIP 레이어 정확성 사전 차단]
# 2D 제작 AI 최종 ZIP: 레이어 순서·실제 PNG 일치 필수 계약

이 규칙은 Live2D/Inochi2D 2D 지시 ZIP에만 적용한다. 3D에는 적용하지 않는다.
외부 AI가 작성하는 결과 원화 ZIP을 검사하는 규칙이지 지시서 ZIP 자체의 레이어 목록은 아니다.

1. 고품질 기준 원화 `outputs/master.png`를 먼저 만든 다음, 해당 자산의 실제 움직이는 파츠만 분리·숨은 면을 보완한다. 파일명은 각 파츠 원화를 내보낼 때 확정한다. 27개 등 정해진 숫자를 맞추지 않는다.
2. 실제 PNG를 만들 때 작성한 **파츠 계획표**에 `part_id / 정확한 상대 경로 / 화면 뒤→앞 순서`를 기록한다. 파츠를 삭제·추가·이름 변경하면 계획표와 실파일을 함께 갱신하고 순서를 다시 사람이 판단한다.
3. 최종 결과 ZIP의 경로는 `outputs/master.png`, `isolated_parts/<part_id>.png`, `layer_order.txt`를 같은 루트에 놓는다. ZIP 내 한 개 최상위 폴더 안에 모두 넣는 방식도 가능하지만 두 구조를 섞지 않는다.
4. `layer_order.txt`는 **실제 존재하는 독립 PNG 각각을 정확히 한 번**, `isolated_parts/eye_L_iris.png` 같은 **루트 기준 상대 경로**로 한 줄씩 기록한다. ZIP 파일 전체 경로, `./` 접두, 대소문자 다른 이름, 디렉터리 접두를 쓰지 않는다. 순서는 ZIP 내부 저장 순서/알파벳순이 아니라 시각적으로 결정한 **뒤→앞 순서**다.
5. `previews/`, `reference_views/`, `outputs/` 내 PNG는 `layer_order.txt`에 포함하지 않는다. `isolated_parts/` 안의 실제 PNG는 누락·중복·미등록이 하나도 없어야 한다. 결과 ZIP에 `manifest.json`을 별도 생성하지 않는다 (단순 2D 형식).
6. 모든 파츠 PNG는 기준 원화와 동일한 **픽셀 크기·원점**, 실제 RGBA 알파, 의미 있는 불투명 픽셀과 일부 투명 픽셀을 갖는다. 부위가 삭제됐는데도 미리보기만 남거나, 시트 PNG만 남기는 납품은 금지한다.
7. **최종 ZIP을 완성한 뒤** 이 ZIP의 `04_OUTPUT_FILES.md`에 포함된 Python 검증 코드를 별도 검사 파일에 복사하여 **실제 결과 ZIP**을 대상으로 실행한다. 파일을 고친 경우 압축·검사를 다시 수행한다. 오류 하나라도 있으면 납품하지 말고 문제가 된 PNG/순서를 수정한다.
8. 코드 검증은 경로·개수·형식만 검증한다. 고급 원화 품질·목 회전용 언더페인트·전후 가림·알파 테두리·합성 비교는 별도로 시각 검수한다. 실제 실행하지 않았는데 PASS라고 쓰지 않는다.

**우회 금지:** 검사 통과를 위해 존재하는 PNG를 몰래 버리거나 임의로 `layer_order.txt`를 알파벳 정렬하거나, 비어 있는 가짜 PNG를 생성하거나, 이미지 AI 대신 PSD/리깅을 요구하지 않는다.

### 반드시 실행하는 결과 ZIP 검증
아래 코드를 작업 임시 폴더의 `validate_artwork_zip.py`로 저장해 **최종 압축 이후** `python validate_artwork_zip.py live2d_upper__accessory__ARTWORK.zip free`를 실행한다. PRO일 경우 마지막 인자를 `pro`로 설정한다. `PASS`가 안 나오면 수정·재압축하며, 실제 실행할 수 없으면 완료라고 하지 않는다. 이 검사 코드는 납품 그림 ZIP에 포함하지 않는다.

```python
"""Fail-closed structural validator for externally generated 2D artwork ZIPs.

Run: python validate_artwork_zip.py artwork.zip [free|pro]
This checks files and pixels, not whether the artwork is aesthetically correct.
"""
from collections import Counter
from io import BytesIO
from pathlib import Path
import re
import sys
from zipfile import ZipFile

from PIL import Image

_PART_ID = re.compile(r"[A-Za-z][A-Za-z0-9_-]*(?:\.[A-Za-z][A-Za-z0-9_-]*)*\Z")


def validate(path: str | Path, edition: str = "pro") -> None:
    if edition not in ("free", "pro"):
        raise ValueError("edition must be free or pro")
    with ZipFile(path) as archive:
        members = [m for m in archive.infolist() if not m.is_dir()]
        filenames = [m.filename for m in members]
        if len(filenames) != len(set(filenames)):
            raise ValueError("ZIP contains duplicate member paths")
        if not members or len(members) > 500:
            raise ValueError("ZIP empty or too many files")
        if sum(m.file_size for m in members) > 650 * 1024 * 1024:
            raise ValueError("ZIP uncompressed size limit exceeded")
        if archive.testzip() is not None:
            raise ValueError("ZIP CRC verification failed")
        order_paths = [n for n in filenames
                       if n == "layer_order.txt"
                       or (n.endswith("/layer_order.txt") and n.count("/") == 1)]
        if len(order_paths) != 1:
            raise ValueError("One root or single-parent layer_order.txt required")
        prefix = order_paths[0][:-len("layer_order.txt")]
        if any(not name.startswith(prefix) for name in filenames):
            raise ValueError("Mixed root and wrapped folders: choose one layout")
        if prefix + "manifest.json" in filenames:
            raise ValueError("Do not include manifest.json in simple image-only ZIP")
        master_name = prefix + "outputs/master.png"
        if master_name not in filenames:
            raise ValueError("Missing outputs/master.png")
        names = [n.strip() for n in archive.read(order_paths[0]).decode("utf-8-sig").splitlines()
                 if n.strip() and not n.lstrip().startswith("#")]
        counts = Counter(names)
        dupes = sorted(n for n, count in counts.items() if count != 1)
        isolated = [n[len(prefix):] for n in filenames
                    if n.startswith(prefix + "isolated_parts/")]
        invalid = sorted(n for n in isolated
                         if not n.startswith("isolated_parts/")
                         or not n.endswith(".png")
                         or not _PART_ID.fullmatch(n[len("isolated_parts/"):-4]))
        if invalid:
            raise ValueError(f"Invalid isolated sprite paths: {invalid}")
        actual = set(isolated)
        listed = set(names)
        missing = sorted(listed - actual)
        unlisted = sorted(actual - listed)
        if dupes or missing or unlisted:
            raise ValueError(
                f"layer_order mismatch: duplicate={dupes}; "
                f"listed_but_missing_png={missing}; "
                f"png_not_in_layer_order={unlisted}"
            )
        if not (1 if edition == "pro" else 2) <= len(names) <= (500 if edition == "pro" else 100):
            raise ValueError(f"Invalid part count for {edition}: {len(names)}")
        for name in names:
            if (not name.startswith("isolated_parts/") or not name.endswith(".png")
                    or not _PART_ID.fullmatch(name[len("isolated_parts/"):-4])):
                raise ValueError(f"Invalid sprite path: {name!r}")
        with Image.open(BytesIO(archive.read(master_name))) as master:
            if master.format != "PNG" or master.mode not in ("RGB", "RGBA"):
                raise ValueError("Master must be RGB/RGBA PNG")
            size = master.size
        if min(size) < 256 or size[0] * size[1] > 32_000_000:
            raise ValueError("Invalid master size")
        for name in names:
            with Image.open(BytesIO(archive.read(prefix + name))) as im:
                if im.format != "PNG" or im.mode != "RGBA" or im.size != size:
                    raise ValueError(f"PNG mode/canvas mismatch: {name}: {im.mode} {im.size} != {size}")
                alpha = im.getchannel("A")
                if alpha.getbbox() is None or alpha.getextrema()[0] == 255:
                    raise ValueError(f"Empty or fully opaque sprite: {name}")
        print(f"PASS: {len(names)} unique RGBA sprites match layer_order.txt and master canvas {size}")


if __name__ == "__main__":
    if len(sys.argv) not in (2, 3):
        raise SystemExit("Usage: python validate_artwork_zip.py ARTWORK.zip [free|pro]")
    validate(sys.argv[1], sys.argv[2] if len(sys.argv) == 3 else "pro")
```

# 출력 파일 계약

**SOURCE_ART_ONLY_V7 — 이미지 생성 AI 전용.** 이 ZIP에서는 완성 원화와 여러 시점의 참고 원화 PNG만 제작한다. 잘라낸 파츠 PNG, 각 파츠별 재생성, 마스크, 레이어 PSD, 메시, 리깅, MOC3, VRM 완성을 이미지 생성 AI에 절대 요구하지 않는다. **실제 파츠 분리·PSD 생성·리깅은 후속 Colab 노트북의 책임**이며, 노트북의 미구현 기능을 성공으로 표시해서는 안 된다.

ZIP: `live2d_upper__accessory__ARTWORK.zip`

- `outputs/master.png`
- `reference_views/accessory_front.png`
- `reference_views/accessory_three_quarter_L.png`
- `reference_views/accessory_three_quarter_R.png`
- `reference_views/accessory_profile_L.png`
- `reference_views/accessory_profile_R.png`
- `reference_views/accessory_back.png`
- `reference_views/accessory_attachment_anchor.png`
- `reference_views/accessory_occlusion.png`

PNG 파일 이름·폴더 이름을 정확히 지킨다. 그 외의 파츠 파일, PSD·레イヤ 순서 파일, JSON·가짜 MOC3/VRM은 넣지 않는다.

## ASSET_ONLY_V1
FACE·OUTFIT을 복제하지 않고 선택한 자산만 그린다.


# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 live2d_upper/accessory 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지·예시와 참고 이미지를 **모두 실제 비전으로 연다.**
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 자료 접근이 안 되거나 참고 그림이 보이지 않으면 **생성 중단** 후
   확인할 수 없는 항목을 구체적으로 보고하고 원본 이미지 첨부를 요청한다.
   허위 열람 완료나 임의 참고 그림 대체 금지.
7. 모든 자료가 실제 확인되고 충돌이 해결된 뒤에만 완성 원화 한 장 제작.
   그 원화의 품질 확인 후 파츠 분리/PSD 제작/합성·최종 ZIP 검수로 진행한다.

**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **live2d_upper / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** upper body through waist/hips with hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 live2d_upper/accessory 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
ACCESSORY: 요청한 소품 한 종류만 제작, 기준 BODY/HAIR/OUTFIT는 정합을 위한 참조이므로 생성하지 않는다. 부착 앵커·앞/뒤·좌/우·투명 알파 및 얇은 부분 가림, 캔버스/원점 동일성, 합성 미리보기 실제 검수. 소품 예시를 실제 디자인에 강제하지 않는다.

# Live2D 상반신 / 액세서리만 — 이미지 생성 AI 최우선 시작 지시

**ZIP 고유 작업 범위 잠금: live2d_upper / accessory**
**오직 이 자산만 그린다:** 사용자가 지정한 액세서리 딱 한 종류의 본체·고정부와 실제 필요한 흔들림 파츠만.
**다른 자산 생성 금지:** 헤어·신체·얼굴·눈·입·의상 및 여러 액세서리 세트를 새로 그리지 않는다.

## 실제 그림 제작
1. 사용자 디자인 또는 이전에 제작한 기준 몸체가 있으면 원본 정체성과 선화·색·축척을 고정한다. 기준 몸체는 참조로만 보고, 지정된 액세서리만의 완성 원화를 먼저 그린다. 기준 몸체 픽셀을 파츠 결과에 포함하지 않는다.
2. 기준 몸체/헤어/의상의 장착 앵커·원점·캔버스만 참조한다. 실제 요청된 소품에 따라 안경 프레임·체인·끈·반투명 렌즈 등의 얇은 알파와 부착점을 보완하고, 없는 소품 유형은 만들지 않는다. 얼굴·눈·입을 가리지 않는 크기인지 합성 확인한다.
3. 움직임과 앞뒤 가림에 필요한 **이 자산만의 파츠**를 원화에서 실제 RGBA 투명 PNG로 분리하고, 가려졌던 해당 자산 면만 추가 작화한다. 모든 PNG는 원본 기준 캐릭터와 동일 캔버스/원점/L/R 방향이다.
4. 실제 PNG 파일명 뒤→앞 순서를 `layer_order.txt`에 기록하고, 그 파츠만 다시 합성하여 미리보기로 만든다. 참고 몸체가 필요하면 별도 정합 overlay에만 표시한다.
5. `09_VISUAL_ART_QUALITY.md`·`10_ANIME_STYLE.md`·`11_OFFICIAL_IMAGE_EXAMPLES.md`의 고급 애니풍 선화·외곽선·테이퍼·2~3톤 셀 셰이딩을 적용한다. 샘플 원본의 특정 캐릭터 외형은 모방하지 않는다. 예시 링크를 열 수 없으면 봤다고 주장하지 않는다.
6. `02_ADVANCED_PARTS.md`의 해당 부위 디테일과 `07_REVIEW_BEFORE_FINAL_ZIP.md`의 검사에 따라 오류 파츠만 수정·재생성하고 다시 합성해 검수한다. `00_DELIVERY_AND_RECHECK.md`까지 적용해 실제 `live2d_upper__accessory__ARTWORK.zip`을 최종 납품한다.

**범위:** 이미지 AI가 실제 그림·PNG·미리보기·ZIP까지만 제작한다. PSD·Cubism ArtMesh/리깅·물리·모션·MOC3·VRM을 자동 제작했다고 말하지 않는다. 명시적 결과물 미제작 시 허위 완료 금지.

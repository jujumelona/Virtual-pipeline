## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**inochi2d_upper/accessory 생성 최상위 기준**: 아래 구형 규칙과 충돌하면 이 규칙을 우선한다.
- ACCESSORY는 기준 두상의 큰 비율과 짧고 부드러운 얼굴 인상에 크기·부착점을 맞춘다. 얼굴을 세로로 늘씬하거나 좁게 보이게 하는 안경·장식 배치 실패. 눈/턱/얼굴/헤어 재생성 없이 요청받은 소품만.
- 큰 머리, 큰 눈/홍채, 짧고 폭 넓은 얼굴, 둥근 볼, 부드럽고 짧은 U턱, 작은 코·입을 기본으로 한다. **긴/좁은 얼굴과 말상, 뾰족한 V턱, 성숙·실사 모델 인상은 절대 불합격.**
- 정면 얼굴 세로/가로 약 1.10~1.30은 귀여운 스타일의 권장 출발점이며 절대적인 크롭 수치가 아니다. 전신은 프로젝트 6등신, 상반신/바스트업은 큰 머리 존재감을 유지한다.
- 불합격 항목: 머리가 작아 보임, 눈이 작음, 얼굴이 길고 좁음, 뾰족한 턱, 긴 목, 다른 자산 혼입. 눈으로 검사하여 하나라도 발견되면 결과물 납품 금지.

## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_upper/accessory]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 액세서리만 제작. 부착점·가려진 면 보완. 신체·헤어·의상 재생성 금지.
- 구도: 허리까지 상반신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **inochi2d_upper / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 액세서리 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 액세서리의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 액세서리 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.


## [2026-10-13 v5 inochi2d_upper/accessory 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
ACCESSORY: 지정 액세서리 한 종류만 독립 제작하고 BODY/헤어/의상을 다시 생성하지 않는다. 부착 위치와 앵커·좌우 방향·깊이·얇은 연결부·알파, 기준 신체와 캔버스 정합, 합성 미리보기를 확인. 단일 자산 경계 및 Inochi Creator 후속 작업 계약 준수.

# Inochi2D 상반신 / 액세서리만의 2D 제작·납품 범위

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.


- **프레임:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 머리·얼굴·다리 등은 액세서리의 외형이나 위치를 판단하기 위한 기준이지 다른 자산 그림을 만들라는 뜻이 아니다.
- **실제 출력:** 지정한 소품 한 종류의 본체·필요 연결부·실제 뒷면. 없는 디자인과 독립 움직임이 불필요한 부분은 만들지 않는다.
- Inochi Creator의 Node/메시/파라미터/물리·동작 제작은 이미지 AI 출력 계약 밖이다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / accessory]
상반신의 기준 몸체 머리·어깨 비례는 배치에만 참고하고 **accessory 원화만 직접 새로 제작**한다. 신체 피부는 제작하지 않는다. 골반·다리·발의 생성은 강제하지 않는다. 다른 자산은 같은 기준 몸체 캔버스에 맞추되 새 신체 원화를 만들지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_upper/accessory]


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/accessory]

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** inochi2d_upper / accessory; ACCESSORY — 지정된 부착 소품 한 종류. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 최소 참고 파일 후보: reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: 신체·헤어·의상을 다시 제작하거나 종합 액세서리 세트를 강제로 만들지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** 실제로 존재하는 장식의 개별 움직임, 좌우·앞뒤 레이어와 착용 부착점. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: inochi2d_upper/accessory; 두상부터 상반신·양손까지. 다른 자산을 새로 제작하지 않는다.
- 1) 해당 자산의 디자인 마스터를 그려 정면 전체 실루엣, 원래 배치·좌우·눈/입·색을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: accessory.back, accessory.front; 실제 개별 장식과 부착점만. 실제 필요한 역할만 추가하되 홍채·흰자·윗속눈썹처럼 독립 움직임/가림이 필요한 역할은 하나로 합치지 않는다. 팔은 상완·전완·손, 옷은 몸에 붙는 뿌리와 흔들리는 부분을 구분한다.
- 5) `part_art/_order.txt`에 **맨 앞에 보이는 파츠부터 맨 뒤 파츠 순서로** 각 경로를 한 줄씩 적는다. PNG 이름과 경로만 기록하며 PSD, 알파 마스크, 3D 메시, MOC3는 만들지 않는다. 열린 입 `mouth.open`, `mouth.tooth.t`, `mouth.tongue`도 개별로 그려 넣되 **중립 미리보기에는 보이지 않게** 한다.
- 6) 같은 자산에서 두 눈의 좌우, 얼굴 윤곽, 목-턱-몸통, 팔꿈치, 머리뿌리/소매 부착점, 좌우 3/4·측면 참조를 교차 확인한다. **전체 중립 합성은 원래 `outputs/master.png`와 같은 캐릭터 한 명**이어야 한다. 입 중복/눈 통째 이동/가림 구멍/부유 손/원래 선화 상실은 실패다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png. BODY는 `expression_refs/mouth_closed.png` / `expression_refs/mouth_open.png`도 첨부하고 입안·치아·혀가 실제로 어떻게 겹치는지 명확히 묘사한다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 소품 부착점과 가려진 뒷면을 참고 시점 그림으로 보여준다.
- **지침 충돌 해결:** 과거 다른 문서의 '개별 파츠 PNG 금지/완성 PNG 한 장만/파츠는 무조건 Colab에서 전부 분리'는 이 최신 계약으로 대체한다. **이미지 AI는 파츠별 그림까지 직접 생성하지만, PSD 인코딩·메시·키폼·리깅은 절대 생성하지 않는다.** 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

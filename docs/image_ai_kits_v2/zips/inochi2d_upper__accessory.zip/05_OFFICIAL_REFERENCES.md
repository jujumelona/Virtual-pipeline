# inochi2d_upper / accessory — Inochi2D 해당 자산 공식 근거

> 00_MASTER_FIRST.md의 완성 원화 우선 계약을 따른다. Inochi Creator 실행/노드/리깅은 이 ZIP의 출력물이 아니다.

## 적용 대상: Inochi2D용 단일 액세서리
[Inochi Creator 공식 첫 모델](https://docs.inochi2d.com/en/latest/creator/first-model/tutorial01.html)은 독립된 원화 파츠와 그림자 합성을 참고할 수 있다. [공식 Node](https://docs.inochi2d.com/en/latest/creator/nodes/node.html)는 후속 파츠 부착/순서 작업에만 사용된다.
이미지 AI는 **요청받은 한 소품의 본체·고정부·실제로 필요한 움직이는 부속 RGBA**만 출력한다. 소품의 앵커는 기존 몸체에서 위치만 참조하고 피부·귀·눈·헤어·의상을 새로 그리지 않는다. Creator 노드/메시를 구현했다고 주장하지 않는다.

각 ZIP은 `00_MASTER_FIRST.md`의 자산·모드 범위를 우선한다. 이 문서에 열거된 파일명/예제는 이 프로젝트 산출 기준이지 공식 엔진의 고정 파츠/이미지 개수 규정이 아니다. 링크는 기법의 출처이며 모델링·PSD 처리 도구 실행 및 외부 다운로드/라이선스 확보를 이미지 생성 AI의 필수 단계로 만들지 않는다.

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
- 별도 PNG/PSD 파츠와 부착점·가림 깊이·참고 시점·합성 품질을 검증한다.
## [/MATTE_CLAY_BODY_V1]

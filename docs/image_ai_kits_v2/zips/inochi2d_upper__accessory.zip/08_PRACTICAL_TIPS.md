## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터에서도 액세서리 자산만 독립 제작한다. 신체·얼굴 원화는 제작하지 않는다.**
이 ZIP은 **inochi2d_upper / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 기존 자료 형식: INX examples and PSD resources (check each file)
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** 기준 신체와 동일한 캔버스·앵커에 액세서리 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 액세서리의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** 액세서리 파츠의 가림·좌우·앞뒤·경계와 기준 몸체의 합성 정합을 검수한다. 기준 신체가 없다면 실제 정합 미검증을 기록한다. 신체·눈 제작을 요구하지 않는다.
- **없는 부위:** 없는 액세서리 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 해당 자산 원화를 참조, 없으면 액세서리 자산 원화 생성) → 슬롯 매핑 → 필수 다각도·표정·숨은 면 원화 실제 제작 → 정합 검수 → 원화 파츠 분리·보완 → 실제 PSD·PNG·검증 기록·ZIP.
- **입력이 없는 신규 캐릭터:** 액세서리 자산만 독립 PSD·PNG·마스크로 제작한다. 기준 몸체가 없으면 공통 캔버스·앵커를 기록하고 정합 미검증을 표시한다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# Inochi2D 상반신 액세서리 전문 그림 제작자 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기존 몸체·헤어·옷의 장착 위치 좌표만 참조. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 비공식 실무 — 액세서리에만 적용
1. 지정 물건의 실제 앵커를 코·귀·머리카락·카라 중 맞는 위치에서 참조한다. 고정부와 흔들릴 부분만 분리하며 프레임·체인·렌즈 등 얇은 알파 영역과 좌우/앞뒤 관계를 정밀하게 보존한다.
2. 요청한 한 종류만, 올바른 앵커·크기·좌우·깊이, 투명 렌즈/체인·프레임 알파, 표정 가림·다른 자산 픽셀 혼입 없음.
3. 부위의 양끝/겹침은 납품 파츠 그림 자체 안에서 자연스럽게 이어지게 그린다. 뒷면을 전부 투명 구멍으로 두지 않는다.
4. 독립 움직임이 같은 고정 선화·그림자는 함께 유지하고 실제 다른 움직임/깊이를 가진 그림만 나눈다.
5. 각 파츠 PNG를 밝은 배경과 어두운 배경에서 따로 확대해 알파 프린지·선 잔상·누락된 밑색을 찾는다.
6. 사용자 기준 몸체가 있으면 **참조용으로만** 겹쳐 보고 좌우 L/R은 캐릭터 본인 기준으로 고정한다. 다른 카테고리의 원화·PNG를 만들거나 출력하지 않는다.
7. 작은 방송 화면과 확대 이미지 모두에서 애니풍 명암·선화 가독성을 확인하고 문제가 있으면 실제 그림만 다시 그린다.

## 비공식 참고
https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ ; 정렬·마스킹은 코드로 보조할 수 있지만 기본 도형 SVG/Pillow 그림을 완성 전문 원화로 가장하지 않는다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / accessory]
기준 몸체의 좌우·원점·스케일·부착점을 맞춘 뒤 소품만 그림으로 완성한다. 체인/프레임의 알파가 밝고 어두운 배경에서 끊기지 않는지 보고 그림자/투명 렌즈가 겹침으로 검게 변하는지 재합성 검토한다. 나중에 Inochi Creator에서 실제 노드 Sorting을 조정할 수 있지만 원화 AI가 노드를 만들었다고 하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_upper/accessory]
[단일 소품의 측면 앵커] **안경을 실제 요청한 경우만** 코받침·안경다리·귀 뒤 고정의 3/4 측면 관계, **귀걸이만 요청한 경우** 귓불 앞뒤, **헤어핀만 요청한 경우** 실제 해당 가닥 모근의 위치를 참조한다. 목록은 조건부 사례이고 전부 만들라는 뜻이 아니다. 원본 캐릭터 피부·귀·머리카락 자체를 소품 PNG에 복제하지 않는다.


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/accessory]
**[소품 소재·선폭·가림]** 원본 디자인의 고정부와 연결점은 읽히는 선폭으로, 체인·안경 프레임 같은 얇은 선은 축소 후 끊기지 않도록 유의한다. 체인/리본처럼 움직일 수 있는 부분은 실제 요청되었고 변형이 예정된 경우에만 중립 자세 참고를 제공한다. 금속은 좁고 대비 큰 반사, 렌즈는 진짜 투명 알파, 다른 재질은 각 소재에 맞춘다. 밝고 어두운 배경에서 알파/두께를 검수하되 눈·귀·신체를 새로 그리지 않는다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** inochi2d_upper / accessory; ACCESSORY — 지정된 부착 소품 한 종류. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: Inochi2D 상반신: 동일 캐릭터의 머리·목·양팔·손·상반신. Cubism 네이티브 파일은 요구하지 않는다.
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 최소 참고 파일 후보: reference_views/accessory_front.png, reference_views/accessory_three_quarter_L.png, reference_views/accessory_three_quarter_R.png, reference_views/accessory_profile_L.png, reference_views/accessory_profile_R.png, reference_views/accessory_back.png, reference_views/accessory_attachment_anchor.png, reference_views/accessory_occlusion.png.
- 위 PNG 목록은 **납품 필수**이고 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 정면 PNG의 단순 확대/축소/미러링/기하 왜곡으로 측면을 대신하지 않고, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 부착점과 접촉 방향·앞뒤 깊이·고정부·가려지는 뒷면을 실제 원화로 만든다. 좌우 회전시 소품 두께와 고정점이 유지되어야 한다. 필요한 경우 서로 다른 깊이에서 움직이는 소품의 부위만 분리한다. 사용자가 요청한 종류가 머리 장식이 아닐 수 있으므로 실제 소품 형태에 맞춰 뷰를 조정한다.
- Colab 입력 파츠·경로 계약: ACCESSORY의 isolated_parts/ 파츠 ID는 accessory/ornament 계열로 시작하도록 적고, 한 파츠의 좌우·깊이 정보를 이름에 명확히 표시한다. 다른 자산의 이름이나 픽셀은 독립 파츠로 포함하지 않는다. layer_order.txt의 경로는 실제 isolated_parts/ PNG와 1:1 매칭한다.
- 자산 소유권 금지: 신체·헤어·의상을 다시 제작하거나 종합 액세서리 세트를 강제로 만들지 않는다.
- 2D ZIP의 실제 납품은 해당 자산의 기준 마스터 원화, 추가 참고 시점 그림, 독립 RGBA 원화 파츠와 마스크, 합성 미리보기, 편집 가능한 레이어 PSD 및 검수표다. 참고 시점 PNG가 자동으로 모션 키폼·메시가 되지는 않는다.
- 2D의 필수 reference_views/ 시점 PNG는 선택사항이 아니다. 정확한 파일명과 경로를 지키고 다각도 원화를 완성한 뒤 파츠를 분리한다..
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### ACCESSORY — 찰흙형 BODY의 비변경 원칙
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 요청 액세서리 한 종류만 만들며 목·어깨·팔·몸체의 인체/피부 묘사를 새로 그리지 않는다.
- 요청된 목걸이/장식 등이 어깨·목과 겹쳐도, 원본 BODY의 목·어깨 연결 실루엣·회전용 숨은 면은 반드시 유지한다. 자동으로 복장이나 다른 액세서리를 추가하지 않는다.
- 별도 PNG/PSD 파츠와 부착점·가림 깊이·참고 시점·합성 품질을 검증한다.
## [/MATTE_CLAY_BODY_V1]

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **inochi2d_upper / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 기존 자료 형식: INX examples and PSD resources (check each file)
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** upper body through waist/hips with hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# Inochi2D 상반신 액세서리 전문 그림 제작자 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기존 몸체·헤어·옷의 장착 위치 좌표만 참조. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 비공식 실무 — 액세서리에만 적용
1. 지정 물건의 실제 앵커를 코·귀·머리카락·카라 중 맞는 위치에서 참조한다. 고정부와 흔들릴 부분만 분리하며 프레임·체인·렌즈 등 얇은 알파 영역과 좌우/앞뒤 관계를 정밀하게 보존한다.
2. 요청한 한 종류만, 올바른 앵커·크기·좌우·깊이, 투명 렌즈/체인·프레임 알파, 표정 가림·다른 자산 픽셀 혼입 없음.
3. 부위의 양끝/겹침은 납품 파츠 그림 자체 안에서 자연스럽게 이어지게 그린다. 뒷면을 전부 투명 구멍으로 두지 않는다.
4. 독립 움직임이 같은 고정 선화·그림자는 함께 유지하고 실제 다른 움직임/깊이를 가진 그림만 나눈다.
5. 각 파츠 PNG를 밝은 배경과 어두운 배경에서 따로 확대해 알파 프린지·선 잔상·누락된 밑색을 찾는다.
6. 사용자 기준 몸체가 있으면 **참조용으로만** 겹쳐 보고 좌우 L/R은 캐릭터 본인 기준으로 고정한다. 다른 카테고리의 원화·PNG를 만들거나 출력하지 않는다.
7. 작은 방송 화면과 확대 이미지 모두에서 애니풍 명암·선화 가독성을 확인하고 문제가 있으면 실제 그림만 다시 그린다.

## 비공식 참고
https://www.reddit.com/r/Live2D/comments/15lc7ku/ 및 https://www.reddit.com/r/Live2D/comments/1140xr5/ ; 정렬·마스킹은 코드로 보조할 수 있지만 기본 도형 SVG/Pillow 그림을 완성 전문 원화로 가장하지 않는다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / accessory]
기준 몸체의 좌우·원점·스케일·부착점을 맞춘 뒤 소품만 그림으로 완성한다. 체인/프레임의 알파가 밝고 어두운 배경에서 끊기지 않는지 보고 그림자/투명 렌즈가 겹침으로 검게 변하는지 재합성 검토한다. 나중에 Inochi Creator에서 실제 노드 Sorting을 조정할 수 있지만 원화 AI가 노드를 만들었다고 하지 않는다.


## [정량 추천과 옆얼굴·목 접합 개선 | inochi2d_upper/accessory]
[단일 소품의 측면 앵커] **안경을 실제 요청한 경우만** 코받침·안경다리·귀 뒤 고정의 3/4 측면 관계, **귀걸이만 요청한 경우** 귓불 앞뒤, **헤어핀만 요청한 경우** 실제 해당 가닥 모근의 위치를 참조한다. 목록은 조건부 사례이고 전부 만들라는 뜻이 아니다. 원본 캐릭터 피부·귀·머리카락 자체를 소품 PNG에 복제하지 않는다.


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/accessory]
**[소품 소재·선폭·가림]** 원본 디자인의 고정부와 연결점은 읽히는 선폭으로, 체인·안경 프레임 같은 얇은 선은 축소 후 끊기지 않도록 유의한다. 체인/리본처럼 움직일 수 있는 부분은 실제 요청되었고 변형이 예정된 경우에만 중립 자세 참고를 제공한다. 금속은 좁고 대비 큰 반사, 렌즈는 진짜 투명 알파, 다른 재질은 각 소재에 맞춘다. 밝고 어두운 배경에서 알파/두께를 검수하되 눈·귀·신체를 새로 그리지 않는다.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 독창적인 완성 원화를 처음부터 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **inochi2d_upper / accessory** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Inochi2D official Aka / Midori sample models** — https://github.com/Inochi2D/example-models
   - 기존 자료 형식: INX examples and PSD resources (check each file)
   - 실제 활용: Rig structure/parts examples; verify exact supplied parts before claiming full-body template.
   - 권리 확인: Repository describes Aka/Midori as CC BY 4.0; attribute creators and confirm selected source file provenance.

### 채울 슬롯
`one_requested_object`, `physical_attachment_anchor`, `front_occlusion`, `rear_occlusion`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** upper body through waist/hips with hands
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참조 PSD의 존재는 도움이 되지만 납품 필수 사용자 첨부물이 아니다. 공개 샘플 캐릭터의 실제 픽셀을 재사용하지 않고 원본 애니 캐릭터를 직접 디자인하며 완성 마스터에서 편집 가능한 다층 PSD·파츠 PNG·마스크를 만든다. 일러스트 생성/PSD 쓰기 도구가 없으면 그 도구의 한계를 보고한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 inochi2d_upper/accessory 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
ACCESSORY: 지정 액세서리 한 종류만 독립 제작하고 BODY/헤어/의상을 다시 생성하지 않는다. 부착 위치와 앵커·좌우 방향·깊이·얇은 연결부·알파, 기준 신체와 캔버스 정합, 합성 미리보기를 확인. 단일 자산 경계 및 Inochi Creator 후속 작업 계약 준수.

# Inochi2D 상반신 액세서리 전용 제작 규칙

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기존 몸체·헤어·옷의 장착 위치 좌표만 참조. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


## 실제 그림 제작
1. 사용자 원본/기준 몸체가 있다면 해당 캐릭터의 색·선화·원점·포즈를 참조하고, **액세서리만** 완성 원화로 먼저 생성한다.
2. 지정 물건의 실제 앵커를 코·귀·머리카락·카라 중 맞는 위치에서 참조한다. 고정부와 흔들릴 부분만 분리하며 프레임·체인·렌즈 등 얇은 알파 영역과 좌우/앞뒤 관계를 정밀하게 보존한다.
3. 해당 자산만 마스킹·추출해 동일 캔버스의 실제 RGBA PNG로 저장한다. 배경 격자 그림은 알파가 아니다.
4. 움직임/깊이와 가림에 필요한 숨은 **해당 자산의 그림만** underpaint 하고, 원본 보이는 픽셀은 유지한다.
5. 재합성으로 기준 아트와 정합 여부를 확인한다. 다른 자산은 합성 미리보기의 **참고용**으로만 허용하며 실제 파츠 ZIP의 source에 포함하지 않는다.
6. 이 자산에서는 신체를 새로 만들지 않고 기준 BODY의 불투명 중립색 실루엣/마스크를 참조한다. 옷·속옷처럼 보이는 구성은 BODY에 덧그리지 않으며, 요청된 HAIR/OUTFIT/ACCESSORY 파츠만 제작한다.

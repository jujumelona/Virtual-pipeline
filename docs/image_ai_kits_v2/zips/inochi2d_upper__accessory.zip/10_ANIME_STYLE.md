## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

### 실제 대형 이미지 AI 생성 → 고품질 원화 승인 → 다각도 → 분리 (최상위 품질 규칙)
- **작업 순서 강제:** 기존 14개 MD/이미지 참고 실제 열람 → 대상 자산·구도 확정 → 이미지 생성 AI 기능으로 고품질 기준 마스터 원화 직접 생성 → 마스터를 눈으로 보고 합격/재생성 결정 → 해당 캐릭터의 다각도/표정/숨은 면 실제 이미지 추가 생성 → 개별 파츠 채색 보존 분리·PSD/ZIP 조립 → 실제 완성본 시각 검증. 첫 번째 이미지 품질 통과 전에 PSD·파츠 개수 맞추기부터 하지 않는다.
- **이미지 생성 방식:** 마스터와 시점 원화의 **그림 자체를 생성형 이미지 모델로 그린다**. Python/Pillow/cairoSVG/SVG path/ellipse/rectangle/polygon/HTML Canvas/Matplotlib 좌표로 캐릭터의 얼굴·팔·손·헤어·옷을 조합하여 이미지로 출력한 것, 벡터 아이콘/교재용 도형/프록시는 **불합격**이다. 기존 벡터 도형 그림에 그림자·그라데이션만 더해도 불합격이다. 코드·스크립트는 완성도 높은 **실제 생성 원화**를 PSD·마스크·레이어로 가공/검증할 때만 사용한다. 이미지 생성 기능을 못 썼다면 코드로 대체하여 성공이라고 주장하지 않는다.
- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** Inochi2D 상반신. 얼굴과 큰 눈 중심의 손그림 애니풍 세밀함, 자연스러운 어깨·양팔·양손, 턱 뒤 목과 가림 표면을 유지한다.
- **해당 자산의 고품질 제작 조건:** ACCESSORY 전용. 지정 소품의 소재·윤곽·입체 두께·부착점·그림자·가려진 뒷면을 세련된 애니 원화로 그린다. 원/사각형·SVG 선만으로 구성한 임시 표시물을 완성품으로 제출하지 않으며 신체·의상·헤어를 중복 제작하지 않는다.
- **반드시 실제로 비교:** 마스터 원본과 다각도/표정 PNG를 열어 동일 인물·눈매·선 굵기·명암·가림·관절 이음의 일관성을 확인한다. 옆모습은 정면의 미러링/눌러 늘이기가 아니어야 하며, 정면의 분할 이미지를 다른 각도 파일에 복제하는 것은 실패다.
- **결과물:** 완성 마스터는 outputs/master.png, 독립 RGBA 파츠는 isolated_parts/*.png, 실제 가림 순서는 layer_order.txt, 고품질 다각도 원화는 reference_views/에 저장한다. 실제 생성한 원화에서 레이어를 분리하고 세부를 손상시키지 않는다. 편집 가능한 PSD는 고품질 기준 원화와 파츠 분리를 마친 후에 제작한다.
- **반려 기준:** 임시 벡터 도형 사람/투박한 몸통/손가락 없는 손/정면을 압축한 프로필/눈 감김과 입 벌림 원화 누락, 리깅용 목 연결 빈 공간, 이상한 이중 파츠, 낮은 미술 품질, 참조 이미지와 크게 다른 얼굴. 파츠 24개·PNG 9장·PSD 합성 오차 0·ZIP CRC 성공만으로 절대 승인하지 않는다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**inochi2d_upper/accessory 생성 최상위 기준**: 아래 구형 규칙과 충돌하면 이 규칙을 우선한다.
- ACCESSORY는 기준 두상의 큰 비율과 짧고 부드러운 얼굴 인상에 크기·부착점을 맞춘다. 얼굴을 세로로 늘씬하거나 좁게 보이게 하는 안경·장식 배치 실패. 눈/턱/얼굴/헤어 재생성 없이 요청받은 소품만.
- 큰 머리, 큰 눈/홍채, 짧고 폭 넓은 얼굴, 둥근 볼, 부드럽고 짧은 U턱, 작은 코·입을 기본으로 한다. **긴/좁은 얼굴과 말상, 뾰족한 V턱, 성숙·실사 모델 인상은 절대 불합격.**
- 정면 얼굴 세로/가로 약 1.10~1.30은 귀여운 스타일의 권장 출발점이며 절대적인 크롭 수치가 아니다. 전신은 프로젝트 6등신, 상반신/바스트업은 큰 머리 존재감을 유지한다.
- BODY 원본을 제공받았으면 얼굴형·눈 크기·두상·목을 재설계하지 않는다. 2D 원화와 분리 레이어 재합성 이미지 비교.
- 불합격 항목: 머리가 작아 보임, 눈이 작음, 얼굴이 길고 좁음, 뾰족한 턱, 긴 목, 다른 자산 혼입. 눈으로 검사하여 하나라도 발견되면 결과물 납품 금지.

## [2026-10-14 최우선 자산별 제작 규칙: inochi2d_upper/accessory]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 제작 소유권: 액세서리만 제작. 부착점·가려진 면 보완. 신체·헤어·의상 재생성 금지.
- 구도: 허리까지 상반신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 실제 PSD·3D 템플릿이 없으면 없다고 알린다. URL 및 그림 도식은 원본 템플릿이 아니다.
- 2D 완성 원화 먼저, 움직임별 분리와 가려진 면 보완, 실제 파일 산출 시에만 납품 완료.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.


## [2026-10-13 v5 inochi2d_upper/accessory 적용 최상위 기준]
공식 Inochi2D 완성 원화와 높은 품질의 실제 애니풍 버튜버 샘플 이미지를 *직접 열어서* 얼굴형·눈·귀·선화·비율을 비교 기록한다. URL만 읽었으면 REFERENCE_NOT_VIEWED로 표기하고 작업 시작/시각 PASS 금지. 사용자가 부정 예시로 준 실사 귀·뾰족턱·의상 혼입 이미지는 따라 만들지 않는다.
ACCESSORY: 지정 액세서리 한 종류만 독립 제작하고 BODY/헤어/의상을 다시 생성하지 않는다. 부착 위치와 앵커·좌우 방향·깊이·얇은 연결부·알파, 기준 신체와 캔버스 정합, 합성 미리보기를 확인. 단일 자산 경계 및 Inochi Creator 후속 작업 계약 준수.

# Inochi2D 상반신 액세서리 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: inochi2d_upper / accessory
**유일한 제작 대상:** 사용자가 지정한 한 종류의 액세서리와 그 부착 고정부·필요한 움직이는 소품 부품만.
**제작 금지:** 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기존 몸체·헤어·옷의 장착 위치 좌표만 참조. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


작은 소품에도 분명한 실루엣·소재와 광택, 정확한 부착 구조·가변 선폭·깔끔한 투명 알파. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 헤어스타일·신체·의상·얼굴·눈·입을 다시 생성하지 않는다. 안경/귀걸이/헤드셋/머리핀 예시를 전부 세트로 만들지 않는다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber accessory-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested accessory asset on the reference canvas, no unrelated character parts or props.”

특정 캐릭터의 디자인 복제 금지. 실제 2D 그림까지만, PSD/Inochi Creator 키폼은 사용자가 나중에 처리한다.


## [2026-10-13 Inochi2D 자산별 고급 노하우 / inochi2d_upper / accessory]
Premium anime Inochi2D SINGLE ACCESSORY ONLY, one explicitly requested piece with believable real attachment anchor, fine chains or transparent lenses only if specified, consistent L/R and clean alpha anti-aliasing, correct original character scale, zero additional accessories or copied character body parts.
Tapered, refined anime ink lines and material-aware cel shadows; keep the user's exact original design. No native Creator modeling output.


## [고급 그림자·모근·소재·선폭 | inochi2d_upper/accessory]
Anime VTuber ONE ACCESSORY ONLY: precise existing mounting anchor, nuanced material-specific lineweight, fine chains or ties in a readable neutral reference pose only when that item actually has flexible parts, crisp metal highlights and transparent glass alpha only if needed; never add a second ornament, face, body, hair or garment.

# 3D / 의상만 출력

> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 기준 원화 먼저 생성 → 2D 원본 분리/3D 참조 확장 → 숨은 부분 보완. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
**`3d__outfit__ARTWORK.zip`**
```text
views/outfit_front.png
views/outfit_back.png
views/outfit_left.png
views/outfit_right.png
details/garment_construction.png
details/material_color.png
previews/turnaround_sheet.png
```
네 방향 모두 동일한 애니 캐릭터/지정 자산의 다른 각도 이미지. 고급 세부 그림은 처음부터 독립 생성. 07+09+10의 작화·선화·셀셰이딩·정합을 반복 점검하여 최종 결과 ZIP 제공.

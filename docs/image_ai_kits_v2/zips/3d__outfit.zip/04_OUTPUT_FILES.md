# 3D / 의상만 출력

> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 기준 원화 먼저 생성 → 2D 원본 분리/3D 참조 확장 → 숨은 부분 보완. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
**`3d__outfit__ARTWORK.zip`**
```text
views/outfit_front.png
views/outfit_back.png
views/outfit_left.png
views/outfit_right.png
details/garment_construction.png
details/material_color.png
previews/turnaround_sheet.png
```
정면 기준 원화에서 출발해 동일한 캐릭터/지정 자산의 다른 각도를 일관되게 생성한다. 고급 세부 그림은 확정된 정면 기준 원화의 디자인을 참조해 필요한 경우만 추가 제작한다. 07+09+10의 작화·선화·셀셰이딩·정합을 반복 점검하여 최종 결과 ZIP 제공.

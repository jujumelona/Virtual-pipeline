# 3D / 의상만 — 결과 이미지 ZIP 이름
결과 ZIP: 3d__outfit__ARTWORK.zip
views/outfit_front.png
views/outfit_back.png
views/outfit_left.png
views/outfit_right.png
details/garment_construction.png
details/material_color.png
previews/turnaround_sheet.png
같은 자산의 앞·뒤·좌·우 실제 다른 관찰각도 이미지. 신체/의상에서는 같은 A/T pose와 비율·표현을 유지한다.
details 확대 그림은 같은 캐릭터를 새로 자세히 그린 참조 이미지, 정면을 잘라낸 자투리 이미지는 아님.
3D 도구가 필요로 하는 본·메시/UV/VRM·SpringBone·립싱크 데이터 생성은 요구하지 않는다. 4면도는 이미지 참조일 뿐.
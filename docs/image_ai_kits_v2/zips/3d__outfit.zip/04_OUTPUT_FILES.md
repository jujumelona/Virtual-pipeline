# 3D / 의상만 출력
**`3d__outfit__ARTWORK.zip`**
```text
views/outfit_front.png
views/outfit_back.png
views/outfit_left.png
views/outfit_right.png
details/garment_construction.png
details/material_color.png
previews/turnaround_sheet.png
```
네 방향 모두 동일한 애니 캐릭터/지정 자산의 다른 각도 이미지. 고급 세부 그림은 처음부터 독립 생성. 07+09+10의 작화·선화·셀셰이딩·정합을 반복 점검하여 최종 결과 ZIP 제공.

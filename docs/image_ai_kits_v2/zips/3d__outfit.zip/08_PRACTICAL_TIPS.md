## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **3d / outfit** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.

### 채울 슬롯
`collar`, `upper_torso_garment`, `sleeve_L`, `sleeve_R`, `cuff_L`, `cuff_R`, `garment_side_L`, `garment_side_R`, `front_back_overlap`, `lower_garment_or_leg_cover_if_requested`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 의상 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 의상의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **없는 부위:** 없는 의상 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 해당 자산 원화를 참조, 없으면 의상 자산 원화 생성) → 슬롯 매핑 → 필수 8방향 원화·가림 세부 1장 실제 제작 → 시점 간 디자인 정합·시각 검수 → 3D 참고 PNG·검증 기록·ZIP.
- **입력이 없는 신규 캐릭터:** 의상 자산 8방향 참조 PNG 및 가림 세부 1장을 제작한다. 네이티브 VRM 완성은 약속하지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.

# 3D 의상 전문 다각도 제작 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / outfit
**유일한 생성 대상:** 요청한 의상 한 벌의 정면·후면·좌우 구조, 재봉선·솔기·주름과 실제 있는 고정 장식.
**별도 카테고리 생성 금지:** 신체·얼굴·헤어·독립 귀걸이/안경/목걸이 같은 액세서리를 추가 제작하지 않는다. 없는 치마·바지·신발을 상상해서 추가하지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


## 비공식 3D 레퍼런스 작화 노하우
1. 기준 몸체의 A/T pose와 실제 어깨·가슴·허리·팔·다리 기준 높이를 참조하여 옷 자체의 앞·뒷판·칼라·소매·안감·솔기·두께를 8방향에서 그린다. 하의가 실제 포함된 의상만 치마·바지·신발을 추가한다. 의복의 무늬는 모든 방향에서 정합해야 하며 천/가죽/금속의 재질을 일치시킨다.
2. 같은 옷의 앞/뒤/측면 구조·원단 두께·소매·카라·솔기·패턴이 일치하는가? 신체나 얼굴을 따로 그리지 않았는가?
3. 정면 기준 높이·원점·중심축·좌우 비대칭과 빛 방향을 고정하고 후면/좌우 시점마다 깊이와 실제 가려진 면을 새로 그린다.
4. 몸체는 위치·체형·장착점 정합용으로만 참조하고 다른 자산 그림을 추가로 생성하지 않는다. 해당 자산만 그림 납품.
5. 큰 실루엣/색/무늬·접합의 방향별 정합을 먼저 확인한 뒤 얇은 선화·셀 명암·해당 의상의 옷깃·소매·솔기·안감의 방향별 연결을 검수한다..
6. 끝에서 하나의 turnaround_sheet.png로 비교하되 별도의 네 그림을 실제 파일로 보관한다.

## 비공식 참고
https://virmii.com/blog/tutorial/how-to-make-vtuber-reference-sheet (일반적인 시트 제작 경험), https://www.reddit.com/r/Live2D/comments/12nhr9v/ (좌우 명칭 팁만, 3D 공식 규격 아님).


## [2026-10-13 3D 다각도 전문 작화 노하우 / outfit]


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/outfit]
[옆목 카라 참조도] 정면 카라와 후면 뒤칼라, 좌우 측면에서 보이는 안쪽 천·카라 두께·어깨 솔기가 연속해야 한다. 피부 목은 기준 몸체 시트로만 정렬하고 **옷감만** 8방향으로 따로 그린다. 정면 옷깃 복사·미러링으로 가짜 측면을 생성하지 않는다.


## [고급 그림자·모근·소재·선폭 | 3d/outfit]
**[의상 턴어라운드]** 정면 봉제점과 어깨·팔꿈치·허리의 장력 축을 기준으로 실제 소매의 주름과 하의·옷자락을 각도별로 새로 그린다. 체크·스트라이프가 있다면 뒤쪽/옆쪽에서 솔기 위치가 연결되는지 비교한다. 망사/반투명 옷감은 실제 있을 때만 아래 안감과 겹침을 같은 원화의 반사/색면으로 설명한다. 3D 메시·UV 전개가 완성됐다고 하지 않는다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**작업 구분 잠금:** 3d / outfit; OUTFIT — 요청받은 의상 한 종류와 의상에 종속된 단추·프릴·리본. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 최종 결과 ZIP에 **반드시 포함할 필수 참조 시점 PNG** (동일 이미지 재사용/미러링 금지): views/outfit_front.png, views/outfit_front_three_quarter_L.png, views/outfit_left.png, views/outfit_back_three_quarter_L.png, views/outfit_back.png, views/outfit_back_three_quarter_R.png, views/outfit_right.png, views/outfit_front_three_quarter_R.png, views/outfit_detail_occlusion.png.
- 최소 참고 파일 후보: views/outfit_front.png, views/outfit_front_three_quarter_L.png, views/outfit_left.png, views/outfit_back_three_quarter_L.png, views/outfit_back.png, views/outfit_back_three_quarter_R.png, views/outfit_right.png, views/outfit_front_three_quarter_R.png, views/outfit_detail_occlusion.png.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산 소유권 금지: 신체 피부와 눈·목 등 BODY 원화를 의상 속에 합성한 독립 부품으로 납품하지 않는다. 별도 착용 소품은 ACCESSORY의 몫이다.
- 3D의 필수 8방향 원화와 가림 세부 1장은 모두 views/ 폴더의 명시된 정확한 파일명으로 납품한다. reference_views/ 안의 비율·표정 보조 가이드는 필수 턴어라운드를 대체하지 않는다..

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/front.png, views/front_three_quarter_L.png 등 8방향 개별 원화와 views/detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 옷깃·소매·안감·등 뒤 겹침을 참고 시점 그림으로 보여준다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 요청된 자산의 독창적인 원화를 새로 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **3d / outfit** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 기존 자료 형식: Interactive 3D app/preset; not PSD and not automatically present in ZIP
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.

### 채울 슬롯
`collar`, `upper_torso_garment`, `sleeve_L`, `sleeve_R`, `cuff_L`, `cuff_R`, `garment_side_L`, `garment_side_R`, `front_back_overlap`, `lower_garment_or_leg_cover_if_requested`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** full-body four-view turnaround
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참고 프리셋/공식 실제 그림을 확인한 뒤 새로운 캐릭터 전후좌우 원화를 만든다. 3D 이미지 AI 지시 ZIP은 PSD나 VRM 내보내기를 약속하지 않고 턴어라운드 참조 PNG와 시각 검증을 납품한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# 3D 의상 전문 다각도 제작 팁

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / outfit
**유일한 생성 대상:** 요청한 의상 한 벌의 정면·후면·좌우 구조, 재봉선·솔기·주름과 실제 있는 고정 장식.
**별도 카테고리 생성 금지:** 신체·얼굴·헤어·독립 귀걸이/안경/목걸이 같은 액세서리를 추가 제작하지 않는다. 없는 치마·바지·신발을 상상해서 추가하지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


## 비공식 3D 레퍼런스 작화 노하우
1. 기준 몸체의 A/T pose와 실제 어깨·가슴·허리·팔·다리 기준 높이를 참조하여 옷 자체의 앞·뒷판·칼라·소매·안감·솔기·두께를 4면으로 그린다. 하의가 실제 포함된 의상만 치마·바지·신발을 추가한다. 의복의 무늬는 모든 방향에서 정합해야 하며 천/가죽/금속의 재질을 일치시킨다.
2. 같은 옷의 앞/뒤/측면 구조·원단 두께·소매·카라·솔기·패턴이 일치하는가? 신체나 얼굴을 따로 그리지 않았는가?
3. 정면 기준 높이·원점·중심축·좌우 비대칭과 빛 방향을 고정하고 후면/좌우 시점마다 깊이와 실제 가려진 면을 새로 그린다.
4. 몸체는 위치·체형·장착점 정합용으로만 참조하고 다른 자산 그림을 추가로 생성하지 않는다. 해당 자산만 그림 납품.
5. 큰 실루엣/색/무늬·접합의 방향별 정합을 먼저 확인한 뒤 얇은 선화·셀 명암·해당 의상의 옷깃·소매·솔기·안감의 방향별 연결을 검수한다..
6. 끝에서 하나의 turnaround_sheet.png로 비교하되 별도의 네 그림을 실제 파일로 보관한다.

## 비공식 참고
https://virmii.com/blog/tutorial/how-to-make-vtuber-reference-sheet (일반적인 시트 제작 경험), https://www.reddit.com/r/Live2D/comments/12nhr9v/ (좌우 명칭 팁만, 3D 공식 규격 아님).


## [2026-10-13 3D 다각도 전문 작화 노하우 / outfit]
정면/후면에서 솔기가 시작하고 끝나는 위치를 잡은 뒤 좌우 측면에서 소매 두께, 카라·옷자락 겹침, 실제 존재하는 안감을 독립 작화한다. 무늬/배색 경계는 앞뒤 면에서 단절되면 안 된다. 니트·면·가죽·금속 등의 실제 재질별 주름·반사를 구별하되 옷에 없는 장식/하의를 상상해 추가하지 않는다. 이미지 참조가 완료되었다고 3D 스킨드 의상 메시·UV·리깅이 완료된 것은 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/outfit]
[옆목 카라 참조도] 정면 카라와 후면 뒤칼라, 좌우 측면에서 보이는 안쪽 천·카라 두께·어깨 솔기가 연속해야 한다. 피부 목은 기준 몸체 시트로만 정렬하고 **옷감만** 네 방향으로 따로 그린다. 정면 옷깃 복사·미러링으로 가짜 측면을 생성하지 않는다.


## [고급 그림자·모근·소재·선폭 | 3d/outfit]
**[의상 턴어라운드]** 정면 봉제점과 어깨·팔꿈치·허리의 장력 축을 기준으로 실제 소매의 주름과 하의·옷자락을 각도별로 새로 그린다. 체크·스트라이프가 있다면 뒤쪽/옆쪽에서 솔기 위치가 연결되는지 비교한다. 망사/반투명 옷감은 실제 있을 때만 아래 안감과 겹침을 같은 원화의 반사/색면으로 설명한다. 3D 메시·UV 전개가 완성됐다고 하지 않는다.

## [IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

**이 ZIP의 유일한 역할은 이미지 AI가 완성 원화와 참고도 및 필요한 원화 레이어를 충분히 생성하는 것이다.** Colab/노트북의 See-through·PSD2Live·image2live2d 설치, 실행, 명령어, 스크립트, 모델 변환 및 리깅은 이 ZIP에 넣지 않는다. 포토샵/PRO 유료 라이선스를 전제하지 않는다.
**작업 구분 잠금:** 3d / outfit; OUTFIT — 요청받은 의상 한 종류와 의상에 종속된 단추·프릴·리본. 기존 14개 MD와 제공된 실제 시각 참고 자료를 모두 확인한 뒤 생성한다.

### 해당 ZIP에서 생성할 다각도·세부 원화
- 모드 구도: 3D용 원화 참고: 앞·좌우 3/4·좌우 옆·좌우 뒤 3/4·후면(최소 8개 방향)의 동일 자산 턴어라운드. 2D PSD 파츠가 아닌 형태·재질·뒷면·앵커 참고 그림.
- 최소 참고 파일 후보: views/outfit_front.png, views/outfit_front_three_quarter_L.png, views/outfit_left.png, views/outfit_back_three_quarter_L.png, views/outfit_back.png, views/outfit_back_three_quarter_R.png, views/outfit_right.png, views/outfit_front_three_quarter_R.png, views/outfit_detail_occlusion.png.
- 위 목록은 **최소 작업 기준 후보**이지 파츠 개수 상한이 아니다. 실제 가림·회전·변형의 불일치가 발견되면 필요한 시점·표정·파츠 그림을 추가 생성한다. 반대로 의미 없는 정면 복제본으로 장수만 늘리지 않는다. 같은 캐릭터·같은 소재·같은 색과 조명·같은 앵커를 유지한다.
- 3D 턴어라운드의 실제 형태를 새로 묘사하며, 3/4/프로필의 앞뒤 관계·실루엣·두께·그림자 방향을 실제로 다르게 그린다.
- 자산별 상세: 앞/뒤 판·옷깃·목둘레·소매·어깨·팔꿈치·손목·옷 아래 가려진 원단과 안감, 필요한 경우 허리·치맛단·무릎 주변의 실제 천을 작화한다. 가동 부위와 가려지는 속면, 천의 두께·주름 방향이 다각도에서 이어져야 한다. 의상 고유 장식만 의상 파츠로 포함한다.
- 자산 소유권 금지: 신체 피부와 눈·목 등 BODY 원화를 의상 속에 합성한 독립 부품으로 납품하지 않는다. 별도 착용 소품은 ACCESSORY의 몫이다.
- 3D ZIP의 실제 납품은 동일 캐릭터/자산의 다각도 PNG 턴어라운드, 실루엣·재질·부착 앵커 참조, 상세 클로즈업 및 검수표다. PSD 층, 2D 눈 리깅 파츠, VRM 바이너리, Blender 실행 결과를 요구하거나 성공했다고 주장하지 않는다.
- 기존 문서의 '완성 원화 한 장을 먼저 만든다'는 **첫 번째 기준 마스터 제작 순서**이지 '한 장만 생성해 납품한다'는 뜻이 아니다. 기준 마스터가 합격한 다음 다각도 원화·숨은 면·표정/가동 참고를 더 생성하고 동일성 검수 후 부위 분리를 진행한다. 자료가 부족하면 파츠를 기계적으로 잘라서 채우지 않고 부족한 원화를 다시 그린다.
- **최종 이미지 품질 게이트:** 각 참고 시점의 식별 가능한 실제 시각 차이, 해당 자산의 비율·선화·그림자 통일, 움직일 가림 부위의 완성 픽셀, 올바른 깊이·레イヤ 소유권, 정면/측면 교차대조를 확인한다. 틀리면 이미지를 수정/재생성한다. PSD 레이어 수·ZIP CRC 통과만으로 시각 품질 PASS 금지.
- **후속 단계 구분:** See-through는 노트북에서 분리 후보를 내는 도구일 뿐이다. PSD2Live/image2live2d 등은 노트북의 후속 리깅 후보일 뿐이다. 이 ZIP의 이미지 AI는 그 프로그램을 설치/실행/인증하거나 실제 Cubism/Inochi/VRM 동작 결과가 있다고 주장하지 않는다.

## [/IMAGE_ART_MULTIVIEW_SOURCE_ONLY_V1]

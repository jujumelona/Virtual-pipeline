## [ART_SOURCE_AND_SEPARATION_V3]
### 3d / outfit — 자산·모드·담당 단계 잠금
- 자산 경계: 의상 전용. 승인 BODY는 배치 참조만. 앞뒤 천·좌우 소매·옷깃·리본·밑단 및 실제 있는 치마만. 피부·눈·헤어·별도 액세서리 픽셀 금지.
- 구도 경계: 3D: 전/후/좌/우 및 네 대각, 동일 캐릭터 8방향 참조와 가림 세부. 2D PSD·파츠 PNG 요구 금지.
- 이미지 생성 AI는 실제 8방향 원화 및 가림 참조만 생성. 정면 복사/미러링으로 방향을 위조하지 않는다.
- 3D 메시/UV/텍스처 분해/리깅은 후속 모델링 단계다. 2D 눈·머리카락 RGBA 분리나 PSD2Live를 3D 제작 조건으로 넣지 않는다.
## [/ART_SOURCE_AND_SEPARATION_V3]

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**3d/outfit 제작 우선 규칙:** 하위 구형 얼굴/두상 지시와 충돌하면 이 규칙이 우선한다.
- 3D OUTFIT은 기준 BODY의 큰 머리와 짧고 둥근 얼굴, 부드러운 U형 턱 인상을 유지한다. 어깨가 지나치게 넓거나 카라·소매가 커서 머리가 작게 보이거나 목이 길어 보이면 불합격. BODY 모델의 얼굴·눈·목·신체 비율을 고치지 않는다. 의상만 독립 제작한다.
- 공통: 상대적으로 큰 머리, 충분히 큰 눈/홍채, 짧고 넓은 얼굴, 부드러운 U형 턱, 작은 코·입. 긴 좁은 얼굴과 V턱 절대 불합격.
- 정면 얼굴 높이/폭 약 1.10~1.30은 권장 출발점이며 절대 화면 크롭 비율이 아니다. 전신 6등신을 유지한다.
- 정면·후면·좌우 8방향 시점에서 머리 크기·얼굴 윤곽의 일치 여부 확인. 기존 3D BODY 재설계 없이 이 ZIP의 대상 자산만 제작한다.

## [2026-10-14 최우선 자산별 제작 규칙: 3d/outfit]
이 규칙과 충돌하는 구형 문장·비율·예시·우회 지시는 폐기한다.
- 구도: 전신; 6등신 전신 디자인을 참고하되 얼굴 화면 점유율 52~61% 강제 금지.
- 사용자 기준 BODY가 있는 다른 자산은 이를 재설계하지 않는다. 사용자 기존 디자인과 다른 새 캐릭터가 나오면 실패.


## [2026-10-13 v5 3d/outfit 적용 최상위 기준]
3D OUTFIT: 요청한 의상 한 벌만 실제 전후좌우 소재·실루엣·재봉선·옷깃·소매가 대응하는 참조 원화를 만든다. 기준 몸체의 비율/동일 카메라 높이를 고정하고 신체를 새로 모델링/재설계하지 않는다. 의복 주름은 의상에만 있고 신체 자체의 살접힘을 새로 그리지 않는다. 사용자가 주문하지 않은 소품은 생성하지 않는다.

# 3D 의상 고급 애니 스타일 8방향 턴어라운드

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / outfit
**유일한 생성 대상:** 요청한 의상 한 벌의 정면·후면·좌우 구조, 재봉선·솔기·주름과 실제 있는 고정 장식.
**별도 카테고리 생성 금지:** 신체·얼굴·헤어·독립 귀걸이/안경/목걸이 같은 액세서리를 추가 제작하지 않는다. 없는 치마·바지·신발을 상상해서 추가하지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 8방향 턴어라운드와 필요한 세부도만 포함한다.**


기준 몸체의 A/T pose와 실제 어깨·가슴·허리·팔·다리 기준 높이를 참조하여 옷 자체의 앞·뒷판·칼라·소매·안감·솔기·두께를 8방향에서 그린다. 하의가 실제 포함된 의상만 치마·바지·신발을 추가한다. 의복의 무늬는 모든 방향에서 정합해야 하며 천/가죽/금속의 재질을 일치시킨다. 검정에 가까운 가변 선폭 테이퍼 윤곽과 소재별 얇은 내부선, 2~3톤 셀 셰이딩을 사용한다. 사용자 지정 화풍이 있다면 우선한다. 없는 얼굴·헤어·의상을 기계적으로 덧붙이지 않는다.

영어 이미지 프롬프트: “Professional anime VTuber outfit-only reference artwork, actual independently illustrated front, back, left and right orthographic-style views, consistent dimensions and original design, fine tapered ink outlines, expressive material-specific cel shading, accurate depth and silhouettes; show ONLY the requested outfit, no extra character anatomy or accessory sets.”



## [2026-10-13 3D 다각도 전문 작화 노하우 / outfit]
High-end anime VTuber ONE OUTFIT 3D REFERENCE ART, four separately illustrated front back left right views of same garment, faithfully consistent collar sleeves seam placements linings fabric thickness and actual patterns, beautiful tapered outlines, material-aware cel shading, correct fit to supplied body anchor; no new body hair jewelry, no automatic UV or VRM.
Original Japanese anime character-art design, dark tapered ink strokes, concise cel shading and correct independent viewpoints.


## [고급 그림자·모근·소재·선폭 | 3d/outfit]

## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 3D 결과는 이후의 3D 제작 단계에서 처리하며 See-through나 PSD2Live의 입력이 아니다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: views/outfit_front.png, views/outfit_front_three_quarter_L.png 등 8방향 개별 원화와 views/outfit_detail_occlusion.png 총 9장. 각도·캐릭터 동일성과 가림 실루엣을 지킨다.
- 옷깃·소매·안감·등 뒤 겹침을 참고 시점 그림으로 보여준다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. 실제 관절·가림·회전 연결은 후속 제작 단계에서 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] 대각·측면 그림에서 해당 자산의 뒷면, BODY 부착점, 파츠의 실제 앞뒤 순서를 확인한다. 기준 몸체·얼굴 자체를 다시 제작하지 않는다.
- [좌표/참조] 8방향은 각도별 완성 그림이지 움직이는 3D VRM·본·표정 계층 자체가 아니다.
- [엔진 확인] 현재 자동 3D 제작기는 8방향 원화에서 전 방향 메시를 자동 구축하는 것으로 검증되지 않았다. 정면·후면·좌우 참고 이외 대각 시점의 메시·뼈·가림 반영은 추가 구현/검사가 필요하다.
## [/IMAGE_AI_SOURCE_ONLY_V2]


## [2026-10-13 v5 3d/outfit 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D OUTFIT: 요청한 의상 한 벌만 실제 전후좌우 소재·실루엣·재봉선·옷깃·소매가 대응하는 참조 원화를 만든다. 기준 몸체의 비율/동일 카메라 높이를 고정하고 신체를 새로 모델링/재설계하지 않는다. 의복 주름은 의상에만 있고 신체 자체의 살접힘을 새로 그리지 않는다. 사용자가 주문하지 않은 소품은 생성하지 않는다.

# 3D 의상 고급 애니 스타일 4면도

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: 3d / outfit
**유일한 생성 대상:** 요청한 의상 한 벌의 정면·후면·좌우 구조, 재봉선·솔기·주름과 실제 있는 고정 장식.
**별도 카테고리 생성 금지:** 신체·얼굴·헤어·독립 귀걸이/안경/목걸이 같은 액세서리를 추가 제작하지 않는다. 없는 치마·바지·신발을 상상해서 추가하지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


기준 몸체의 A/T pose와 실제 어깨·가슴·허리·팔·다리 기준 높이를 참조하여 옷 자체의 앞·뒷판·칼라·소매·안감·솔기·두께를 4면으로 그린다. 하의가 실제 포함된 의상만 치마·바지·신발을 추가한다. 의복의 무늬는 모든 방향에서 정합해야 하며 천/가죽/금속의 재질을 일치시킨다. 검정에 가까운 가변 선폭 테이퍼 윤곽과 소재별 얇은 내부선, 2~3톤 셀 셰이딩을 사용한다. 사용자 지정 화풍이 있다면 우선한다. 없는 얼굴·헤어·의상을 기계적으로 덧붙이지 않는다.

영어 이미지 프롬프트: “Professional anime VTuber outfit-only reference artwork, actual independently illustrated front, back, left and right orthographic-style views, consistent dimensions and original design, fine tapered ink outlines, expressive material-specific cel shading, accurate depth and silhouettes; show ONLY the requested outfit, no extra character anatomy or accessory sets.”

VRM/메시/UV/본·리깅 등 3D 네이티브 파일을 그린 것처럼 주장하지 않는다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / outfit]
High-end anime VTuber ONE OUTFIT 3D REFERENCE ART, four separately illustrated front back left right views of same garment, faithfully consistent collar sleeves seam placements linings fabric thickness and actual patterns, beautiful tapered outlines, material-aware cel shading, correct fit to supplied body anchor; no new body hair jewelry, no automatic UV or VRM.
Original Japanese anime character-art design, dark tapered ink strokes, concise cel shading and correct independent viewpoints.


## [고급 그림자·모근·소재·선폭 | 3d/outfit]
ANIME OUTFIT TURNAROUND REFERENCE ONLY: four separately drawn front back left right views, believable fabric tension folds at seams and joints, accurate optional stripes and plaid across views, material-aware shading and refined outline hierarchy; no PSD masks, clothing mesh, UV, skin, hair or extra jewelry.

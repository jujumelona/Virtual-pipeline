## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**실제 참고 이미지·레이어 구조를 먼저 확인한 다음 제작한다. 사용자 PSD가 없는 신규 캐릭터라면 기존 샘플을 복제하지 말고 독창적인 완성 원화를 처음부터 제작한다. 회색 신체 도형 프록시는 금지한다.**
이 ZIP은 **3d / outfit** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **VRoid Studio actual customizable body, hair, outfit and accessory presets** — https://vroid.com/en/studio
   - 기존 자료 형식: Interactive 3D app/preset; not PSD and not automatically present in ZIP
   - 실제 활용: User opens app, starts preset, adjusts slots, exports reference views for 3D kit.
   - 권리 확인: Apply VRoid terms and each preset/outfit license. Do not copy proprietary assets into repository.

### 채울 슬롯
`collar`, `upper_torso_garment`, `sleeve_L`, `sleeve_R`, `cuff_L`, `cuff_R`, `garment_side_L`, `garment_side_R`, `front_back_overlap`, `lower_garment_or_leg_cover_if_requested`

- **실제 자료 열람:** PSD나 3D 프리셋을 실제 확보했다면 파일·레이어·형태를 열람한다. 공개 PSD에 접근할 수 없으면 확인한 그림 예제와 공개 레이어 제작 지침으로 새 원화를 제작한다. 열람하지 않은 파일을 열었다고 주장하지 않는다.
- **구도:** full-body four-view turnaround
- **입력 해결:** user_design_reference_if_recreating_existing_character_else_original_master_from_visual_references. 신규 캐릭터는 사용자 원본 PSD·승인 원화가 없어도 기본 설정과 실제 관찰 가능한 참고 이미지로 진행한다. 이미 존재하는 특정 캐릭터를 그대로 보존해야 할 때만 식별 가능한 기존 이미지/설정을 요청하며 PSD 확장자는 강제하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** maintain proportions and materials across front back left right
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Fill genuinely missing slots with ORIGINAL anime artwork after reviewing visuals and checking anatomy/anchor consistency. Request user input only if exact identity/PRO existing BODY alignment is required; never fake PSD/rig or use gray polygons.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **제작 순서:** 14개 MD 전체 읽기 → 접근 가능한 복수의 실제 이미지 시각 확인 및 실패 출처 기록 → 저작권·계약 정리 → (사용자 기존 디자인이 있으면 그 이미지 참조, 없으면 원본 캐릭터 완성 원화 생성) → 슬롯 매핑 → 실제 원화 검수 → 투명 레이어 분리·숨은 픽셀 보완 → 실물 PSD·PNG·마스크·검증 JSON·완성 ZIP.
- **입력이 없는 신규 캐릭터:** 참고 프리셋/공식 실제 그림을 확인한 뒤 새로운 캐릭터 전후좌우 원화를 만든다. 3D 이미지 AI 지시 ZIP은 PSD나 VRM 내보내기를 약속하지 않고 턴어라운드 참조 PNG와 시각 검증을 납품한다.
- **독립 PRO 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.
- **공식 샘플 권리:** 공개 다운로드가 개작/재배포 허락은 아니다. 공식 샘플의 개별 이용약관을 확인하고 원본 파츠/디자인을 사용자 원화로 복제하지 않는다.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 3d/outfit 적용 최상위 기준]
3D 자산 제작용 독립 참조 원화이다. 실제 애니풍 버튜버 참고 이미지를 열어 시각 비교/기록한다. URL만 보았으면 REFERENCE_NOT_VIEWED; 사용자가 불합격 처리한 실사 귀·긴 V턱·의상 섞인 신체 그림은 부정 예시다. VRM·메시·스켈레톤·리깅·내보내기 완료로 주장하지 않는다. **2D PNG 파츠/ArtMesh/Cubism 리깅 지시를 3D 참조 ZIP으로 가져오지 않는다.**
3D OUTFIT: 요청한 의상 한 벌만 실제 전후좌우 소재·실루엣·재봉선·옷깃·소매가 대응하는 참조 원화를 만든다. 기준 몸체의 비율/동일 카메라 높이를 고정하고 신체를 새로 모델링/재설계하지 않는다. 의복 주름은 의상에만 있고 신체 자체의 살접힘을 새로 그리지 않는다. 사용자가 주문하지 않은 소품은 생성하지 않는다.

# 3D 의상만 다각도 그림 제작 — 2D 파츠 리깅과 구분

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: 3d / outfit
**유일한 생성 대상:** 요청한 의상 한 벌의 정면·후면·좌우 구조, 재봉선·솔기·주름과 실제 있는 고정 장식.
**별도 카테고리 생성 금지:** 신체·얼굴·헤어·독립 귀걸이/안경/목걸이 같은 액세서리를 추가 제작하지 않는다. 없는 치마·바지·신발을 상상해서 추가하지 않는다.
**기준 몸체/캐릭터 그림은 위치 비교용이며 납품물에는 이 자산의 4면도와 필요한 세부도만 포함한다.**


- **views/**: 정면 `views/outfit_front.png`, 후면 `views/outfit_back.png`, 좌측 `views/outfit_left.png`, 우측 `views/outfit_right.png`의 실제 다른 시점 그림을 제작한다. 구체적 경로가 다를 경우 `04_OUTPUT_FILES.md`의 파일명을 우선한다.
- **고유 대상:** 정면·후면·좌측·우측 의상 4면도, 솔기/안감·실제 옷 고정부품 참고. 외형에 없는 가닥·속옷·후드·리본·안경 등 다른 카테고리는 요구하지 않는다.
- **기준 정합:** 기준 몸체의 A/T pose와 실제 어깨·가슴·허리·팔·다리 기준 높이를 참조하여 옷 자체의 앞·뒷판·칼라·소매·안감·솔기·두께를 4면으로 그린다. 하의가 실제 포함된 의상만 치마·바지·신발을 추가한다. 의복의 무늬는 모든 방향에서 정합해야 하며 천/가죽/금속의 재질을 일치시킨다.
- **previews/turnaround_sheet.png**는 실제 네 장의 그림을 같은 기준선으로 배열한 비교 결과. 2D 파츠/PSD 파일 대신 3D 자산의 독립적인 네 시점 `views/` 이미지와 실제 `turnaround_sheet.png`를 제출한다.
- 결과는 **참조 그림**이지 3D 메시·VRM·UV·본·리깅·모션 파일이 아니다.


## [2026-10-13 3D 다각도 전문 작화 노하우 / outfit]
**3D 참조도 전용:** 이 ZIP은 모델이나 UV가 아닌 같은 자산의 독립된 정면/후면/좌측/우측 참조 원화를 만든다. 6등신은 신체 ZIP의 디자인 조건이고 헤어/의상/소품에는 같은 몸체 기준선을 정렬하는 데만 사용한다. 실제 3D 모델·Rig·SpringBone·VRM이 완성됐다고 주장하지 않는다. 미러링/크롭·라벨만 바꾼 가짜 측면도 금지.


## [정량 추천과 옆얼굴·목 접합 개선 | 3d/outfit]
3D용은 실제 다른 네 방향의 outfit 참조 그림만 생성한다. 기준 6H 신체의 눈·귀·코·목은 소품/헤어/의상 장착 위치를 위한 참고일 뿐 새로 그리지 않는다. 메시·UV·VRM은 이미지 AI 산출물이 아니다.


## [고급 그림자·모근·소재·선폭 | 3d/outfit]
그림으로만 전후좌우 독립된 4면도/세부 참조를 만든다. 2D PNG 레이어·PSD 마스크·Multiply 설정을 요구하지 않고, 재질 하이라이트·선폭·관절 기준선이 같은 물건의 다른 시점에서 일치하는지만 검수한다.

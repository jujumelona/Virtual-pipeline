## [ART_SOURCE_AND_SEPARATION_V3]
### live2d_bust_up / outfit — 자산·모드·담당 단계 잠금
- 자산 경계: OUTFIT: 실제 옷감·소매·옷깃·밑단·의상에 붙은 디자인 요소만. BODY·얼굴·눈·피부·헤어·독립 장신구 픽셀은 0개. OUTFIT 납품물에는 피부·눈·얼굴·머리카락을 복사하지 않는다. 합성은 previews에서만 가능.
- 명시적 생성 제외: OUTFIT에서는 옷감과 의복 일체형 부속만. 머리카락·얼굴·눈·입·몸통 피부·양팔·양손·다리 피부·장신구 독립 파츠 생성 금지. 기준 BODY/HAIR는 참조이고 의상 이미지에 합치지 않는다.
- 실물 납품 차단: OUTFIT master/납품 PNG에 피부·얼굴·눈·머리카락·독립 장신구가 있으면 CROSS_ASSET_CONTAMINATION: FAIL. 기준 캐릭터 합성은 별도 previews/에서만 허용.
- 구도 경계: 바스트업은 얼굴과 큰 눈이 화면 중심, 머리부터 상복부, 양어깨·상완·전완·양손 끝까지. 골반·다리 금지.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. outfit 실제 세분화 판단: OUTFIT: 앞뒤 몸판·좌우 소매·독립 이동하는 칼라/리본/밑단·치맛자락을 필요한 경우 나눈다. 봉제선·무늬는 본래 천에 유지. 감춰진 겹침면 색 복원, 피부·헤어 픽셀 혼입 금지.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

## [GPT_ARTWORK_SEGMENTER_HANDOFF_V5]
### live2d_bust_up / outfit — GPT 마스터 원화에서 실제 분리 AI까지
**최상위 역할 계약. 이 ZIP은 GPT의 원화 생성 지시서이지 GPT에게 PSD·파츠 분리를 시키는 지시서가 아니다.** 모든 14개 MD의 기존 `part_art/`, `_order.txt`, `isolated_parts/`, PSD, 알파, 개별 눈·목 세분화, 합성 검수 지시는 **별도 후속 분리 엔진의 출력/검사 명세**로 해석한다. 이미지 생성 AI가 그 파일을 생성했다고 주장해서는 안 된다.
1. GPT는 `outputs/master.png` **실제 정면 원화 PNG 1장**(RGB 또는 진짜 RGBA)을 생성한다. 콜라주, 부품을 떨어뜨려 배치한 시트, 가짜 투명 PNG, 기존 이미지와 다른 인물로 그린 설정화는 불합격이다.
2. 다음은 투명 파츠가 아닌, 같은 캐릭터의 다른 시점/숨은 부분 참고 원화이다. **각각 별도의 실제 PNG**로 그린다.
  - `reference_views/outfit_front.png`
  - `reference_views/outfit_three_quarter_L.png`
  - `reference_views/outfit_three_quarter_R.png`
  - `reference_views/outfit_profile_L.png`
  - `reference_views/outfit_profile_R.png`
  - `reference_views/outfit_back.png`
  - `reference_views/outfit_inside_seams.png`
  - `reference_views/outfit_joint_clearance.png`
3. 마스터와 front/three_quarter/profile/pitch 참고는 **동일한 원본 캔버스 가로·세로 픽셀 크기, 인물 스케일·중심좌표**를 유지한다. 뷰 이름을 바꾸거나 정면을 복제해 다른 시점으로 위장하지 않는다.
4. **모드 구도:** 머리와 눈이 큰 방송용 바스트업. 상복부·양팔·양손가락 끝까지 포함. 골반·다리·발 없음.
5. **자산 경계:** 기준 BODY 위에 교체해 입힐 요청 의상·안감·소매만. 몸체·얼굴·눈·머리카락·별개 장신구 제외.
6. **See-through 분리를 고려한 원화:** 한 이미지에 한 시점·한 캐릭터, 흰색/단순 단색 배경, 선명한 애니 셀 셰이딩/파츠 윤곽·깔끔한 경계; 글자·워터마크·장식 배경·눈 위의 불필요한 손/머리카락 겹침·과도한 발광 금지. 구분을 위해 머리·팔을 물리적으로 잘라 떼어 놓거나 전체 원화 품질을 저하시키지 않는다.
- 현재 자산 외의 BODY/얼굴/눈/의상/장신구 픽셀을 결과 이미지에 합치지 않는다. 원래 캐릭터는 위치·색·디자인 참조로만 사용한다.
7. **GPT 결과물:** `live2d_bust_up__outfit__ARTWORK.zip`에 `outputs/master.png`, 위 `reference_views/*.png` 및 BODY에서 `expression_refs/*.png`만 저장한다. `manifest.json`, `layer_order.txt`, `part_art/_order.txt`, `part_art/*.png`, `isolated_parts/`, PSD, MOC3 등 분리/리깅 파일은 생성하지 않는다. 원화 ZIP 납품과 Live2D 완료를 혼동하지 않는다.
8. **후속 파이프라인:** `tools/vts_source_only_pack.py`가 실물 마스터·뷰의 PNG 형식/중복/크기 등을 확인한다. 이후 See-through V3/NF4로 분리 PSD 후보를 만들고, 관찰된 파츠를 공식 좌우/깊이 세분화 또는 SAM 정밀 마스크로 필요 시 개선한다. Qwen-Image-Layered는 기존 런타임에서 해당 자산에 **실제로 연결된 경우에만** 추가 RGBA 분해에 사용한다. Qwen은 텍스트만으로 L/R 홍채·흰자·속눈썹 레이어를 정확히 지정하는 기능을 보장하지 않는다.
9. **후속 검수:** 원본 보이는 RGB 보존, 실제 알파, 가려진 부분 복원, PSD 순서/캔버스 좌표, 좌우 눈 흰자·홍채·속눈썹, 턱-목-몸통·팔-손 접합, 마스터 중립 합성 일치와 변형을 검사한다. 불합격 부위는 분리 작업에서만 재시도/인페인팅하고 GPT가 파츠 시트를 대신 그리게 하지 않는다. 결과 PSD는 Cubism/Inochi2D 모델 리깅/방송 동작 성공을 뜻하지 않는다.
10. 위에 적힌 PNG를 실제 제작할 수 없으면 그 누락을 명확히 보고한다. 분리 엔진 오류는 GPT 원화 생성 완료와 별도로 보고한다.
## [/GPT_ARTWORK_SEGMENTER_HANDOFF_V5]

## [MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
### live2d_bust_up / outfit — 24개 자산별 실제 분리 경로
**V5의 GPT 원화 역할을 유지한 채, 후속 분리 AI가 무엇을 어떻게 나눌지 정하는 최신 자산 전용 기준.** 모드·자산을 서로 바꿔 처리하면 실패다.
- 작업 범위: Live2D 방송용 바스트업: 큰 두상, 머리~상복부, 양팔과 양손가락 끝. 다리·발·골반 파츠 금지.
- 대상 경계: 기준 BODY는 정렬 참조로만 이용. 실제 옷과 필요한 안감/소매만, 피부/눈/머리카락 픽셀 금지.
- **See-through V3의 실제 기본 태그 중 이 자산 관련 항목:** topwear, neckwear, handwear, bottomwear, legwear, footwear. 23개 태그 이외의 파츠 명칭을 모델이 직접 출력한다고 간주하지 않는다.
- **실제 후속 세부 분리·검수 대상:** 의상 앞·뒤, 각 소매 좌/우, 안감·주름·겹침·관절 경계 (실제 해당 의상에 존재하는 부위만)
- **V3만으로 불가능/불충분:** topwear 등은 의복 의미 영역이며 소매 좌/우·안감·허리 접합·주름 단위가 아니다. handwear=장갑, legwear=다리 의복, footwear=신발이다.
- **어떤 엔진이 실제 수행:** 실행 경로: 독립 자산 PNG의 진짜 알파가 있으면 보존; 아니면 단색 배경에서 실물 전경 마스크를 검사해 추출 → 독립 자산 PSD 1개 후보 → 별도 세부 분리·가림 면 보정 필요. **이 자산만 있는 PNG에는 See-through V3 전체 캐릭터용 head crop을 실행하지 않는다.** V3의 의미 태그는 캐릭터 전체 PSD가 별도로 제공된 경우의 참고 카테고리일 뿐이다.
- **완성 조건:** 이미지 생성 GPT가 한 장짜리 가짜 파츠 시트를 만들면 실패. See-through 결과 PSD만 생성되거나 레이어 이름/개수만 맞으면 **분리 성공 아님**. 실제 움직일 파츠의 서로 다른 원본 RGB/알파/레이어/가려진 면이 검증돼야 한다. 실패 항목은 해당 파츠만 정밀 분리·인페인팅하여 재검사하고, 전체 원화를 매번 재생성하지 않는다.
- 3D HAIR/OUTFIT처럼 제작 엔진이 없는 경우 또는 독립 2D 자산의 세부 분리가 남아 있으면 `NOT_YET_RIG_READY`로 명시한다. 중간 PSD를 완성된 방송 모델로 제출 금지.
- 경로 규정의 코드 기준: `tools/vts_segmentation_profiles.py`. Live2D/Inochi2D 실행은 `notebooks/VTuber_Finished_AI_ZIP_All_Modes.ipynb`의 모드/자산 선택을 따른다.
## [/MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
# [READ_ALL_BEFORE_IMAGE_GENERATION_V1] — 모든 지침/참고 이미지 확인 전 생성 절대 금지

**[실제 원화 작화 방식: 02_ADVANCED_PARTS.md의 EXPLICIT_DRAWING_STEPS_V1을 반드시 먼저 열어 따르며, 07_REVIEW_BEFORE_FINAL_ZIP.md의 REAL_VISUAL_REVIEW_V1로 실제 그림을 비교한다.]**

**최상위 순서 계약: 여기까지 끝나기 전에는 이미지 생성·수정 도구를 호출하지 않는다.**
이 ZIP에서 제작할 자산은 live2d_bust_up/outfit 한 종류뿐이다.

1. ZIP을 전부 열어 **14개 MD를 파일명만이 아니라 본문 마지막 줄까지 전부 읽는다.**
   00/01/02/03/04/05/06/07/08/09/10/11의 우선순위·금지사항·자산 범위를 대조한다.
2. 사용자 첨부 원화·BODY 기준 이미지가 **제공된 경우** 실제 이미지를 확인한다. 신규 캐릭터의 경우 사용자 PSD·원화가 없어도 정상이며, 실제 접근 가능한 공개 원화 및 파츠 구조 자료를 참고한다.
   05_OFFICIAL_REFERENCES.md, 06_ADVANCED_OFFICIAL_COMMUNITY.md,
   11_OFFICIAL_IMAGE_EXAMPLES.md 및 다른 MD에 링크된 그림·작품 페이지도 확인한다.
   작품 페이지는 제목/HTML을 읽는 데서 멈추지 말고 **보이는 이미지까지 열어** 확인한다.
3. 이미지마다 URL/원본 파일, 실제 열람 상태, 얼굴·눈·목·어깨·상체 구도·선화 등
   **직접 관찰한 해당 자산의 특징**을 간단히 기록한다. URL만 알고 있는 것은 열람이 아니다.
4. 구형 FACE-FIRST 극단적 크롭, 회색 도형 몸체 등 문서 간 충돌을 찾아
   사용자 요구를 최우선으로 정리하고 최종 프레이밍·레이어 범위를 확정한다.
5. **생성 이전 첫 응답은 이미지가 아니라** 14개 MD 확인 내역,
   참고 이미지 전체 열람 내역, 실제 관찰과 충돌 해결 기록·제작 계획으로 작성한다.
   전부 확인 전에는 image_gen, OpenArt, Adobe, Canva 등 **모든 생성/수정 호출 금지**.
6. 접근 불가능한 외부 참고 링크는 `unavailable` 상태·원인으로 기록하고 실제 열 수 있는 적절한 다른 공개 그림을 조사해 대체한다. 참고용 외부 PSD 하나를 못 열었다는 이유로 사용자에게 BODY PSD 첨부를 요구하거나 신규 캐릭터 제작을 중단하지 않는다.
   단, 특정 기존 캐릭터·BODY와 동일성을 보존해야 하는데 필수 사용자 참조가 없거나, 실제 시각 참고 이미지를 전혀 볼 수 없다면 사유를 정확하게 보고하고 해당 단계만 보류한다. 허위 열람 완료 금지.
7. 필수 사용자 자료·실제 시각 참고·템플릿 슬롯 검토 및 충돌 해결 후 기준 캐릭터 디자인을 확정한다. 공개 예제 캐릭터의 픽셀·외형을 그대로 복제하지 않는다.
이미지 생성 AI는 현재 자산의 고품질 마스터 한 장 및 각도·가림 참고 그림을 먼저 만든다. 원본의 세부 픽셀을 보존한 독립 RGBA PNG는 후속 전문 분리 단계에서 추출·숨은 면 보정 후 검증한다. 파츠 순서 파일은 분리 단계만 작성하고 PSD·리깅은 그 이후 작업이다.
**기존 문서의 '즉시/먼저 원화 생성'은 이 열람 게이트 완료 이후만 뜻한다.**
**GPT가 이 문서를 읽기 전에 이미지를 생성했다면 그 출력은 납품 실패다.**

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 옷감·주름·봉제선·몸판·소매·옷깃·가려진 원단과 다른 자산 픽셀 혼입을 실제 시각 확인. 예시의 완성 캐릭터 눈·몸을 그대로 복사하지 않는다.
- **모드별 실제 구도:** 방송용 바스트업: 머리·얼굴을 크게, 아래쪽은 상복부와 양손 손가락 끝까지만. 골반·허벅지·무릎·발·전신 그림 생성 금지. OUTFIT: 실제 옷감·소매·옷깃·밑단·의상에 붙은 디자인 요소만. BODY·얼굴·눈·피부·헤어·독립 장신구 픽셀은 0개.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 옷감·주름·봉제선·몸판·소매·옷깃·가려진 원단과 다른 자산 픽셀 혼입을 실제 시각 확인. 증거 없으면 ART_QUALITY_UNVERIFIED.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**live2d_bust_up/outfit 전용 생성 최우선 규칙.** 이 조항보다 아래의 구형 구도·얼굴형 설명이 충돌하면 이 조항을 우선한다.
- 공통 스타일: 귀여운 애니/VTuber, 머리가 상대적으로 크게 보이고, **짧고 폭이 있는 얼굴·부드럽고 짧은 U형 턱·큰 눈과 홍채·작은 코와 입**. 긴/좁은 얼굴, 말상, 길게 내려온 뾰족한 턱, 현실/성숙 모델 인상은 절대 불합격.
- 기준 얼굴 비율(참조만): 승인된 얼굴·눈·팔·몸통은 위치와 가림 참조다. 옷감만 독립 원화로 그리며 피부를 함께 칠하지 않는다. 신체 6등신/머리 크기는 해당 자산 그림의 생성 명령이 아니다.
- 실물 기준 BODY가 제공되면 원본 두상/얼굴을 바꾸지 않는다. 2D는 완성 원화·파트 재합성에서 기준 얼굴과 실제 시각 비교한다.
- **검수 필수:** 머리 크기, 얼굴의 넓고 짧은 윤곽, 둥근 턱끝, 눈/홍채 크기, 자연스러운 목·어깨 비율, 기준 캐릭터 동일성, 다른 자산 혼입 여부. 과장된 어깨·긴 목·BODY 합쳐진 의상 발견 시 불합격.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_bust_up/outfit]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **OUTFIT만 생성:** 제공된 BODY 좌표에 옷깃·소매·안감·장식·그림자와 가려진 옷감 부분을 정렬한다. 터틀넥·민소매·드레스 등 의상 형태는 디자인에 따라 허용되나 BODY 피부에 절대 합치지 않는다. BODY 신체를 새로 그리지 않는다.
- 프레임: 방송용 바스트업: 머리·얼굴을 크게, 아래쪽은 상복부와 양손 손가락 끝까지만. 골반·허벅지·무릎·발·전신 그림 생성 금지. OUTFIT: 실제 옷감·소매·옷깃·밑단·의상에 붙은 디자인 요소만. BODY·얼굴·눈·피부·헤어·독립 장신구 픽셀은 0개.
- 기준 얼굴 정합(참조만): 승인된 얼굴·눈·팔·몸통은 위치와 가림 참조다. 옷감만 독립 원화로 그리며 피부를 함께 칠하지 않는다. 얼굴·눈 자체는 이 ZIP의 제작 항목이 아니다.

## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

이 ZIP은 **live2d_bust_up / outfit** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
- 2. **Live2D Haru arm/outfit swap model** — https://www.live2d.com/en/learn/sample/haru/

### 채울 슬롯
`collar`, `upper_torso_garment`, `sleeve_L`, `sleeve_R`, `cuff_L`, `cuff_R`, `garment_side_L`, `garment_side_R`, `front_back_overlap`

- **구도:** 기준 신체와 동일한 캔버스·앵커에 의상 자산만 배치한다. 신체 전체를 새로 생성하지 않는다.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 의상의 원본 외형만 보존하고 신체·눈·얼굴은 참조만 한다. 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** FREE: create one original completed master, then split. PRO: keep fixed agreed common BODY canvas+anchors; if no existing BODY, define a new original BODY canvas and mark dependent-asset alignment pending until visual verification.
- **없는 부위:** 없는 의상 슬롯만 원화에 맞게 복원한다. 기준 신체의 얼굴·눈·팔·손을 새로 그리거나 납품하지 않는다.
- **검증:** 슬롯별 출처·파일 실제 열람 여부·참고 그림 실제 관찰·외부 불가 URL/사유·저작권 구분·기준 캔버스 앵커·새 원화/기존 캐릭터 선택·시각 검수 기록을 남긴다. 명시적 사용자 승인이 없는 새로운 디자인은 자동 승인됐다고 쓰지 않는다.
- **독립 자산 모드:** 기존 BODY가 없으면 새 캐릭터용 공통 캔버스·앵커 명세를 먼저 고정한다. 기존 BODY와의 합성 정합을 통과했다고 가장하지 않는다.

# 최우선 제작 계약: live2d_bust_up / outfit

## [2026-10-13 v5 live2d_bust_up/outfit 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.


## ZIP 고유 작업 범위 잠금: live2d_bust_up / outfit
**실제 제작:** 선택된 바스트업 의상 한 벌의 카라·옷깃 안쪽·상의 앞/뒷판·실제 보이는 좌우 소매·옷에 부착된 장식만.
**금지:** 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.


이 ZIP은 의상만 전용이며 전신/일반 상반신 ZIP과 다르다. **00_MASTER_FIRST.md**를 먼저 읽고 **00_DELIVERY_AND_RECHECK.md**까지 모두 따른다.


기준 몸체와 동일 캔버스·원점·축척을 유지하여 요청된 한 가지 상반신 의상만 만든다. 옷깃·몸통·어깨선·좌우 소매·소맷부리·옷자락·리본/지퍼(실제로 있을 때)를 구분한다. 목이나 어깨 회전에 필요한 안쪽 천을 보완한다. 신체를 다시 그리지 않고 가슴과 목을 불투명 옷감으로 충분히 덮는다.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | outfit]


## [필수: 2D 결과 ZIP 레이어 정확성 사전 차단]

완성 BODY의 목·어깨·팔·손·상복부 기준 동일 캔버스에 실제 의상만 제작하며 신체는 재작화하지 않는다.



## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

## [BROADCAST_HANDS_BODY_COLOR_V1]
### 최상위 방송 프레이밍·손·몸색 제작 명령
**범위 우선순위:** 이 지침은 같은 ZIP의 오래된 '가슴 위까지만', '손이 보일 때만 손' 같은 조건보다 우선한다. 바스트업의 원본에는 양손 끝까지 무조건 포함한다. 작업 자산 소유권·2D/3D 형식 규칙은 유지한다.
### 바스트업 OUTFIT: BODY 양손·목 보존과 자산별 정확한 정렬

- **바스트업 위치 참고 범위:** 기준 BODY 원화에서 정수리·양어깨·상완·전완·양손 열 손가락 끝·윗배 및 작업 여백까지 눈으로 확인한다. HAIR/OUTFIT/ACCESSORY에서는 손을 새로 생성하지 않는다. 기존 BODY의 손과 목을 가리지 않는 현재 자산의 그림만 동일 캔버스 좌표에 납품한다.
- **현재 ZIP은 OUTFIT만 생성한다.** 기준 BODY의 양손·팔·목과 윗배는 위치 및 가림 참조로만 사용한다. BODY의 피부/클레이 RGB 픽셀을 현재 자산의 독립 산출물에 복사하거나, BODY 손이 잘린 상태로 둔 채 의상·머리카락·장식으로 숨기지 않는다. 소매 좌우의 윗단은 옷판 안쪽, 소매 끝은 손목 피부 바깥에 실제로 겹치게 한다. 커프를 그려 손가락 잘림을 감추지 않는다. 옷깃 안쪽과 겨드랑이/어깨의 숨은 천만 의상 재질색으로 채색한다. 2D는 실제 독립 자산 PNG만 납품하고, BODY 원화는 참고 합성으로만 사용한다.
- **보정색:** 가림에 감춰지는 BODY 피부/무광 외피를 임의 회색 면으로 교체하지 않는다. 보이는 BODY RGB와 연속된 원래 색을 유지하도록 참고하되, 현재 자산의 숨은 픽셀은 현재 자산 고유의 재질색으로 그린다. 별도의 알파/클리핑 마스크를 몸색 RGB로 채워 버리지 않는다.
## [/BROADCAST_HANDS_BODY_COLOR_V1]

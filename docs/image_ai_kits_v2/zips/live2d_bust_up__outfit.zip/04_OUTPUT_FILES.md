# 의상만 납품 파일 구조

00_MASTER_FIRST.md에 따라 실제 그림 제작. live2d_bust_up__outfit__ARTWORK.zip
outputs/master.png — 최종 바스트업 기준 원화
outputs/master_original.png — 원본 저장
isolated_parts/ — 실제 RGBA PNG 파츠
layer_order.txt — 레이어 순서와 L/R
previews/composite_preview.png — 재합성 원화 비교
previews/reference_bust_up.png — 머리~가슴 윗부분 구도 비교
reference_views/ — 회전 보조(필요한 경우만)
README.md — 수작업 보완 및 실제 납품 범위

원화가 없는 그림·가짜 PSD·moc3·cmo3는 제출하지 않는다. 이 이미지 AI 지시서에서 Cubism PRO 설치·리깅을 요구하지 않는다.

## ZIP 고유 작업 범위 잠금: live2d_bust_up / outfit
**실제 제작:** 선택된 바스트업 의상 한 벌의 카라·옷깃 안쪽·상의 앞/뒷판·실제 보이는 좌우 소매·옷에 부착된 장식만.
**금지:** 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.
**구도:** 기존 기준 신체의 얼굴 중심 근접 바스트업을 그대로 유지하면서 이 ZIP의 outfit 한 자산만 실제 제작한다. 신체·눈·얼굴·목 피부나 전신 비율은 재설계하지 않는다.

`outputs/master.png`는 이 ZIP의 의상 원화만, `isolated_parts/`는 의상의 RGBA PNG만 의미한다. 기준 몸체가 들어간 화면은 위치 확인용 preview로 구분한다. 다른 카테고리 픽셀을 파츠로 납품하지 않는다.

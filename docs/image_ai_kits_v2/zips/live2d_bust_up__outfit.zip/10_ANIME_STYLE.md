# Live2D 방송용 바스트업 의상 애니풍 기준

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / outfit
**실제 제작:** 선택된 바스트업 의상 한 벌의 카라·옷깃 안쪽·상의 앞/뒷판·실제 보이는 좌우 소매·옷에 부착된 장식만.
**금지:** 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.
**구도:** 방송용 바스트업은 머리 높이 1 : 보이는 목·어깨·상체 약 1~2의 레이아웃 기준이며, 헤어·의상·액세서리 ZIP에서는 제공된 기준 몸체를 새로 그리지 않고 해당 자산만 완성한다.


- 대상: 선택된 바스트업 의상 한 벌의 카라·옷깃 안쪽·상의 앞/뒷판·실제 보이는 좌우 소매·옷에 부착된 장식만. 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.
- 애니풍: 검정에 가까운 짙은 가변 굵기 선화와 가늘어지는 테이퍼, 깔끔한 소재별 내부선, 2~3톤 셀 명암·높은 디자인 일관성.
- 이 자산의 미술적 특징: 카라/옷깃/안감의 끊김 방지, 좌우 소매와 어깨/목의 자연스러운 정합, 옷감 질감·주름·알파, 안전한 불투명 가림.
- 기준 캐릭터의 눈매·머리/얼굴 비율은 **참조를 통한 크기·정체성 맞춤**이며 신체와 얼굴 이외 자산을 새로 생성하는 요구가 아니다.
- 머리 1높이에 화면에 보이는 상체 1~2높이라는 구도 기준만 적용한다. 전신의 하체/다리/발을 강제하지 않는다.

영어 이미지 프롬프트: “Professional premium anime VTuber bust-up outfit-only artwork, variable-weight tapered dark linework, detailed consistent 2-3 tone cel shading, faithful original character aesthetics, isolated requested outfit art on matching full canvas, no extra character parts or props.”


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / outfit]
### 이 ZIP에만 적용할 애니풍 프롬프트
High-end anime VTuber BUST-UP OUTFIT ONLY, one user-specified garment, elegant clean neckline/collar and shoulder construction, believable sleeve overlaps and lining, fine fabric seams and tailored cel shading matching the actual material, transparent garment on original body coordinates, opaque modest coverage, no skin/face/hair/jewelry, no unrequested skirt or shoes.
**소유 픽셀:** 캐릭터 기준 이미지의 다른 범주는 좌표/컬러 참조일 뿐 새 그림 산출 대상이 아니다.

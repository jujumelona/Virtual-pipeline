## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** 방송용 바스트업. 얼굴·눈을 화면의 주인공으로, 큰 두상과 짧고 넓은 U형 하관을 그린다. 머리·얼굴·눈이 작게 보이는 멀리서 찍은 전체 몸통 및 양팔을 수평으로 활짝 펼친 T/A 포즈는 불합격. 팔꿈치·손목·손가락은 보이게 그리되 양손은 몸통 양옆·하단에 자연스럽게 배치해 캐릭터 얼굴보다 시선을 빼앗지 않게 한다. 민머리 BODY 원화라도 납작한 계란 얼굴·이마만 큰 도형은 금지. 헤어는 HAIR ZIP의 자산이므로 BODY 레이어에 합치지 않는다. 실제 입과 눈을 중심으로 방송 축소 크기에서도 눈매·표정이 읽히게 한다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
**live2d_bust_up/outfit 전용 생성 최우선 규칙.** 이 조항보다 아래의 구형 구도·얼굴형 설명이 충돌하면 이 조항을 우선한다.
- 공통 스타일: 귀여운 애니/VTuber, 머리가 상대적으로 크게 보이고, **짧고 폭이 있는 얼굴·부드럽고 짧은 U형 턱·큰 눈과 홍채·작은 코와 입**. 긴/좁은 얼굴, 말상, 길게 내려온 뾰족한 턱, 현실/성숙 모델 인상은 절대 불합격.
- 정면 얼굴 높이/폭(귀 제외) 약 1.10~1.30은 스타일 **출발 참고값**이며 신체/프레임 전체 비율은 강제하지 않는다. 전신은 프로젝트의 6등신 유지, 바스트업·상반신은 실사형으로 머리를 축소하지 않는다.
- 실물 기준 BODY가 제공되면 원본 두상/얼굴을 바꾸지 않는다. 2D는 완성 원화·파트 재합성에서 기준 얼굴과 실제 시각 비교한다.
- **검수 필수:** 머리 크기, 얼굴의 넓고 짧은 윤곽, 둥근 턱끝, 눈/홍채 크기, 자연스러운 목·어깨 비율, 기준 캐릭터 동일성, 다른 자산 혼입 여부. 과장된 어깨·긴 목·BODY 합쳐진 의상 발견 시 불합격.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_bust_up/outfit]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **OUTFIT만 생성:** 제공된 BODY 좌표에 옷깃·소매·안감·장식·그림자와 가려진 옷감 부분을 정렬한다. 터틀넥·민소매·드레스 등 의상 형태는 디자인에 따라 허용되나 BODY 피부에 절대 합치지 않는다. BODY 신체를 새로 그리지 않는다.
- 프레임: 정수리부터 상복부/허리 위 및 양손까지 방송용 바스트업. 자산 소유 범위에만 적용. 전신 캐릭터의 기본 디자인은 6등신을 지향하나 크롭 프레임에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 극단적 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY가 제공되면 얼굴 비율을 변경하지 않는다.


## [2026-10-13 v5 live2d_bust_up/outfit 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.

# Live2D 방송용 바스트업 의상 애니풍 기준

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / outfit
**실제 제작:** 선택된 바스트업 의상 한 벌의 카라·옷깃 안쪽·상의 앞/뒷판·실제 보이는 좌우 소매·옷에 부착된 장식만.
**금지:** 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.


- 대상: 선택된 바스트업 의상 한 벌의 카라·옷깃 안쪽·상의 앞/뒷판·실제 보이는 좌우 소매·옷에 부착된 장식만. 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.
- 애니풍: 검정에 가까운 짙은 가변 굵기 선화와 가늘어지는 테이퍼, 깔끔한 소재별 내부선, 2~3톤 셀 명암·높은 디자인 일관성.
- 이 자산의 미술적 특징: 카라/옷깃/안감의 끊김 방지, 좌우 소매와 어깨/목의 자연스러운 정합, 옷감 질감·주름·알파, 안전한 불투명 가림.
- 기준 캐릭터의 눈매·머리/얼굴 비율은 **참조를 통한 크기·정체성 맞춤**이며 신체와 얼굴 이외 자산을 새로 생성하는 요구가 아니다.

영어 이미지 프롬프트: “Professional premium anime VTuber bust-up outfit-only artwork, variable-weight tapered dark linework, detailed consistent 2-3 tone cel shading, faithful original character aesthetics, isolated requested outfit art on matching full canvas, no extra character parts or props.”


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / outfit]
### 이 ZIP에만 적용할 애니풍 프롬프트
High-end anime VTuber BUST-UP OUTFIT ONLY, one user-specified garment, elegant clean neckline/collar and shoulder construction, believable sleeve overlaps and lining, fine fabric seams and tailored cel shading matching the actual material, transparent garment on original body coordinates, opaque modest coverage, no skin/face/hair/jewelry, no unrequested skirt or shoes.
**소유 픽셀:** 캐릭터 기준 이미지의 다른 범주는 좌표/컬러 참조일 뿐 새 그림 산출 대상이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/outfit]
Anime VTuber OUTFIT ONLY: user-specified material, tension-driven folds from actual seams and joints, accurate stripe or plaid continuity only if present, believable layered collar and sleeve linings, selective contact lineweight and clean fabric cel shading, check overlaps of optional translucent mesh; no skin, hairstyle, face or separate jewelry.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | outfit]
Use the supplied FACE-FIRST bust-up body canvas. Only the actual requested garment visible around short shoulders, collar and upper chest; material-accurate anime folds and lining; transparent outfit pixels only, no long torso/waist/skirts unless genuinely visible in reference, no face/eye/skin/hair.

완성 BODY의 목·어깨·팔·손·상복부 기준 동일 캔버스에 실제 의상만 제작하며 신체는 재작화하지 않는다.
OUTFIT ONLY aligned with existing arms and abdomen BODY.

## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### 이미지 생성 AI 업무: 완성 원화만
- 해당 자산의 완성 원화와 다각도 그림을 **이미지 생성 모델로 직접 그려 PNG ZIP을 전달**한다.
- **부위별 절단, 개별 파츠 PNG, 알파 마스크, 다층 PSD, 레이어 순서, 리깅/메쉬/키폼 제작은 맡지 않는다.** 후속 Colab에서 See-through가 파츠를 분리하고 리깅 단계가 사용한다.
- 원본 자료는 실제 열람하고, 사용자가 PSD 템플릿을 제공하지 않아도 신규 디자인 원화를 진행한다.
- 결과 ZIP: outputs/master.png 한 장과 다음 실제 시점 그림: reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png. 필요한 경우 expression_refs/에 완성된 표정 참고 PNG를 더한다.
- 옷깃·소매·안감·등 뒤 겹침을 참고 시점 그림으로 보여준다.
- 참고 시점 이미지는 회전 키폼 자체가 아니다. See-through 분리 이후 리깅 시 실제 관절·가림·회전 연결을 별도로 검증해야 한다.
- 기존 14개 MD의 공식 PSD·파츠 기술 링크는 **작화 참고 문헌**이지 이미지 생성 AI의 파일 출력 요구가 아니다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

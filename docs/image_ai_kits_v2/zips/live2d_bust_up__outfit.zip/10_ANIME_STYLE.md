
## [2026-10-13 v5 live2d_bust_up/outfit 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.
OUTFIT: 사용자 요청 의상 한 벌만, BODY 기준 원화의 얼굴/몸·귀를 재생성 금지. 어깨·목깃·소매·안감·숨은 옷감을 실제 의상 파츠로 제작하고 주름/끈은 의상에만 남긴다. 몸통에 의복 압박 살접힘·쇄골 음영을 추가하지 않는다. 같은 캔버스와 원점·배율 및 합성 미리보기 검수.

# Live2D 방송용 바스트업 의상 애니풍 기준

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / outfit
**실제 제작:** 선택된 바스트업 의상 한 벌의 카라·옷깃 안쪽·상의 앞/뒷판·실제 보이는 좌우 소매·옷에 부착된 장식만.
**금지:** 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.


- 대상: 선택된 바스트업 의상 한 벌의 카라·옷깃 안쪽·상의 앞/뒷판·실제 보이는 좌우 소매·옷에 부착된 장식만. 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.
- 애니풍: 검정에 가까운 짙은 가변 굵기 선화와 가늘어지는 테이퍼, 깔끔한 소재별 내부선, 2~3톤 셀 명암·높은 디자인 일관성.
- 이 자산의 미술적 특징: 카라/옷깃/안감의 끊김 방지, 좌우 소매와 어깨/목의 자연스러운 정합, 옷감 질감·주름·알파, 안전한 불투명 가림.
- 기준 캐릭터의 눈매·머리/얼굴 비율은 **참조를 통한 크기·정체성 맞춤**이며 신체와 얼굴 이외 자산을 새로 생성하는 요구가 아니다.

영어 이미지 프롬프트: “Professional premium anime VTuber bust-up outfit-only artwork, variable-weight tapered dark linework, detailed consistent 2-3 tone cel shading, faithful original character aesthetics, isolated requested outfit art on matching full canvas, no extra character parts or props.”


## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / outfit]
### 이 ZIP에만 적용할 애니풍 프롬프트
High-end anime VTuber BUST-UP OUTFIT ONLY, one user-specified garment, elegant clean neckline/collar and shoulder construction, believable sleeve overlaps and lining, fine fabric seams and tailored cel shading matching the actual material, transparent garment on original body coordinates, opaque modest coverage, no skin/face/hair/jewelry, no unrequested skirt or shoes.
**소유 픽셀:** 캐릭터 기준 이미지의 다른 범주는 좌표/컬러 참조일 뿐 새 그림 산출 대상이 아니다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/outfit]
Anime VTuber OUTFIT ONLY: user-specified material, tension-driven folds from actual seams and joints, accurate stripe or plaid continuity only if present, believable layered collar and sleeve linings, selective contact lineweight and clean fabric cel shading, check overlaps of optional translucent mesh; no skin, hairstyle, face or separate jewelry.


## [2026-10-13 FACE-FIRST 애니 바스트업 긴급 교정 | outfit]
Use the supplied FACE-FIRST bust-up body canvas. Only the actual requested garment visible around short shoulders, collar and upper chest; material-accurate anime folds and lining; transparent outfit pixels only, no long torso/waist/skirts unless genuinely visible in reference, no face/eye/skin/hair.

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
완성 BODY의 목·어깨·팔·손·상복부 기준 동일 캔버스에 실제 의상만 제작하며 신체는 재작화하지 않는다.
실제 다층 PSD, 같은 캔버스 투명 RGBA PNG와 파츠별 알파 마스크, 원본 입력과 원본 PSD(있다면), 원본-결과 및 PRO BODY 정합 미리보기, 레이어 좌표/순서·검증·분할 JSON, 사용자 제작·시각검수·Cubism 안내 MD는 최종 필수. PSD와 마스크가 없으면 중간 PNG 검사 PASS여도 최종 납품 불가. BODY 최종 납품에 --final-live2d-body를 사용한다. HAIR/OUTFIT/ACCESSORY도 PSD·마스크 필수. 실제 이미지/Editor 확인 없이 미술·리깅 품질 PASS 금지.
OUTFIT ONLY aligned with existing arms and abdomen BODY.

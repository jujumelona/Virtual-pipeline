# Live2D 바스트업 outfit 공식·제작자 팁

공식 원화 분리 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 옷깃·몸통·소매의 겹침 원화. 공식 Clipping https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ 및 Glue https://docs.live2d.com/en/cubism-editor-manual/glue/ — 실제 적용은 Cubism Editor에서. 비공식 Live2D 커뮤니티 https://www.reddit.com/r/Live2D/ — 숨은 옷감 연장과 움직이는 주름만 분할하는 팁.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / outfit]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 옷깃·가디건·리본 등 필요에 따른 분리와 가림 보완. https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ — Clipping은 이후 Editor의 구현 기능으로 원화 PNG가 자동 리깅되는 것이 아니다. **비공식 작화 경험:** 옷의 장력·소재별 명암과 가려진 안감 보완은 사용자가 요청한 디자인에 맞춰 선택.
**공통 주의:** Live2D/Cubism 공식은 원화 분리·편집기 구현을 설명하지만, '정확한 6등신', '홍채 가로폭 몇 %', '2~3톤만 허용'을 기술 규격으로 요구하지 않는다. Cubism Editor의 키폼·클리핑·Skinning은 이미지 AI의 자동 납품 대상이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/outfit]
**[Live2D 공식]** https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 목·몸통의 분리, 카라·가디건은 필요할 때만 분리하며 고정된 부분은 함께 둘 수 있다. **[비공식 디자인 실무]** 목이 3/4로 보이는 상황을 가정하고 카라 안쪽의 가려진 천을 충분히 그린다. 목 파츠는 신체 ZIP 소유이며 의상 ZIP에 포함하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/outfit]
**[출처 구분]** Live2D 공식은 카라/가디건을 필요에 따라 나누거나 묶을 수 있다고 설명한다: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . **어깨·팔꿈치·허리 등 장력점에서 시작되는 천 주름, 체크무늬/망사의 연결, 반투명 소매 이중 암영 방지**는 전문 일러스트레이터의 미술 설계·검수 기법이며 공식 고정 파츠 구성이나 필수 의상 요소는 아니다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

## [BUSTUP_COMPLETE_BODY_FINAL_PSD_V4]
완성 BODY의 목·어깨·팔·손·상복부 기준 동일 캔버스에 실제 의상만 제작하며 신체는 재작화하지 않는다.
OUTFIT 자산의 최종 산출은 해당 자산의 완성 원화와 실제 독립 PNG/숨은 면 보완, 같은 캔버스의 미리보기·레이어 순서·검증 기록, 실제 제작한 다층 PSD 및 필요 마스크를 포함한다. BODY 전용 최종 납품 옵션과 눈/피부 파츠 생성 조건을 이 자산에 강제하지 않는다. 미작성 산출물을 제작 완료로 표기하지 않는다.

## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
- 동일 캔버스·앵커에 맞춘 독립 의상 파츠·가림 후면·마스크·PSD를 납품한다. 합성 미리보기의 BODY는 언제나 불투명 단색 베이스 상태다.
## [/MATTE_CLAY_BODY_V1]

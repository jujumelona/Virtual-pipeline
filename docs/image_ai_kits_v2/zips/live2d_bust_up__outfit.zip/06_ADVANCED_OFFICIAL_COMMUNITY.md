# Live2D 바스트업 outfit 공식·제작자 팁

공식 원화 분리 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 옷깃·몸통·소매의 겹침 원화. 공식 Clipping https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ 및 Glue https://docs.live2d.com/en/cubism-editor-manual/glue/ — 실제 적용은 Cubism Editor에서. 비공식 Live2D 커뮤니티 https://www.reddit.com/r/Live2D/ — 숨은 옷감 연장과 움직이는 주름만 분할하는 팁.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.
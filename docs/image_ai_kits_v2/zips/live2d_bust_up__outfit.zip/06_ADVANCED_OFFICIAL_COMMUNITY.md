# Live2D 바스트업 outfit 공식·제작자 팁

공식 원화 분리 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 옷깃·몸통·소매의 겹침 원화. 공식 Clipping https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ 및 Glue https://docs.live2d.com/en/cubism-editor-manual/glue/ — 실제 적용은 Cubism Editor에서. 비공식 Live2D 커뮤니티 https://www.reddit.com/r/Live2D/ — 숨은 옷감 연장과 움직이는 주름만 분할하는 팁.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / outfit]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 옷깃·가디건·리본 등 필요에 따른 분리와 가림 보완. https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ — Clipping은 이후 Editor의 구현 기능으로 원화 PNG가 자동 리깅되는 것이 아니다. **비공식 작화 경험:** 옷의 장력·소재별 명암과 가려진 안감 보완은 사용자가 요청한 디자인에 맞춰 선택.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/outfit]
**[Live2D 공식]** https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ — 목·몸통의 분리, 카라·가디건은 필요할 때만 분리하며 고정된 부분은 함께 둘 수 있다. **[비공식 디자인 실무]** 목이 3/4로 보이는 상황을 가정하고 카라 안쪽의 가려진 천을 충분히 그린다. 목 파츠는 신체 ZIP 소유이며 의상 ZIP에 포함하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/outfit]
**[출처 구분]** Live2D 공식은 카라/가디건을 필요에 따라 나누거나 묶을 수 있다고 설명한다: https://docs.live2d.com/en/cubism-editor-tutorials/psd/ . **어깨·팔꿈치·허리 등 장력점에서 시작되는 천 주름, 체크무늬/망사의 연결, 반투명 소매 이중 암영 방지**는 전문 일러스트레이터의 미술 설계·검수 기법이며 공식 고정 파츠 구성이나 필수 의상 요소는 아니다.
[Live2D 공식 문서 — 분리/기술] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 필요한 눈/입/머리카락/몸 파츠의 분리와 숨은 부분의 추가 작화. https://docs.live2d.com/en/cubism-editor-manual/reimport-psd/ : 후속 가져오기 PSD는 파츠마다 필요한 선화·채색을 합쳐 준비하고 분리 작업용 원본은 별도로 보관한다. 이 내용은 이미지 AI에 Photoshop 플러그인, Cubism 키폼/Glue/물리를 실행하라는 지시가 아니다.

완성 BODY의 목·어깨·팔·손·상복부 기준 동일 캔버스에 실제 의상만 제작하며 신체는 재작화하지 않는다.

## [MATTE_CLAY_BODY_V1]
### OUTFIT — 찰흙형 BODY와 독립된 실제 의상
- 정렬 기준 BODY는 **불투명 무광 단색 찰흙형 몸통**이다. 사용자 주문 의상만 실제로 제작하고, BODY의 얼굴·목·어깨·팔·몸체나 숨은 면을 새로 그리거나 지우지 않는다.
- OUTFIT에는 사용자가 지정한 의상 고유의 재질·봉제선·주름·안감 및 원하는 넥라인(하이넥·어깨끈 포함)을 그릴 수 있다. 그 묘사를 BODY의 해부학적 원화로 역전파하거나 BODY 기본 가림으로 재정의하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.live2d.com/en/cubism-editor-tutorials/template/
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** 실제 입힌 옷의 앞/뒤, 소매 좌우, 옷깃, 따로 흔들리는 리본·밑단과 겨드랑이 안쪽. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: live2d_bust_up/outfit; 얼굴 크게, 목·양어깨·양팔·양손·상복부까지. 다른 자산을 새로 제작하지 않는다.
- 1) 해당 자산의 디자인 마스터를 그려 정면 전체 실루엣, 원래 배치·좌우·눈/입·색을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: outfit.back, outfit.front, sleeve.left, sleeve.right; 실제 존재하는 칼라·리본·밑단만. 실제 필요한 역할만 추가하되 홍채·흰자·윗속눈썹처럼 독립 움직임/가림이 필요한 역할은 하나로 합치지 않는다. 팔은 상완·전완·손, 옷은 몸에 붙는 뿌리와 흔들리는 부분을 구분한다.
- 5) `part_art/_order.txt`에 **맨 앞에 보이는 파츠부터 맨 뒤 파츠 순서로** 각 경로를 한 줄씩 적는다. PNG 이름과 경로만 기록하며 PSD, 알파 마스크, 3D 메시, MOC3는 만들지 않는다. 열린 입 `mouth.open`, `mouth.tooth.t`, `mouth.tongue`도 개별로 그려 넣되 **중립 미리보기에는 보이지 않게** 한다.
- 6) 같은 자산에서 두 눈의 좌우, 얼굴 윤곽, 목-턱-몸통, 팔꿈치, 머리뿌리/소매 부착점, 좌우 3/4·측면 참조를 교차 확인한다. **전체 중립 합성은 원래 `outputs/master.png`와 같은 캐릭터 한 명**이어야 한다. 입 중복/눈 통째 이동/가림 구멍/부유 손/원래 선화 상실은 실패다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/outfit_front.png, reference_views/outfit_three_quarter_L.png, reference_views/outfit_three_quarter_R.png, reference_views/outfit_profile_L.png, reference_views/outfit_profile_R.png, reference_views/outfit_back.png, reference_views/outfit_inside_seams.png, reference_views/outfit_joint_clearance.png. BODY는 `expression_refs/mouth_closed.png` / `expression_refs/mouth_open.png`도 첨부하고 입안·치아·혀가 실제로 어떻게 겹치는지 명확히 묘사한다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 옷깃·소매·안감·등 뒤 겹침을 참고 시점 그림으로 보여준다.
- **제작 단계 확정:** 이미지 AI는 위에 명시한 독립 파츠의 실제 그림과 다각도 참조를 하나씩 제작한다. PSD 인코딩·메시·키폼·리깅은 별도 단계다. 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

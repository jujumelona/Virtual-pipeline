# Live2D 바스트업 outfit 공식·제작자 팁

공식 원화 분리 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 옷깃·몸통·소매의 겹침 원화. 공식 Clipping https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ 및 Glue https://docs.live2d.com/en/cubism-editor-manual/glue/ — 실제 적용은 Cubism Editor에서. 비공식 Live2D 커뮤니티 https://www.reddit.com/r/Live2D/ — 숨은 옷감 연장과 움직이는 주름만 분할하는 팁.

공식 PSD 주의사항 https://docs.live2d.com/en/cubism-editor-manual/precautions-for-psd-data/ : RGB 8bit/channel, sRGB 권장. 공식 synthesize-corners https://docs.live2d.com/en/cubism-editor-manual/synthesize-corners/ 는 Editor 키폼 작업일 뿐 이미지 AI 자동 리깅이 아닙니다.

비공식 조언은 공식 규격이 아니며, 열람하지 못한 링크는 직접 봤다고 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / outfit]
### 자료의 근거 분류 — 직접 적용/참고만 구별
**Live2D 공식:** https://docs.live2d.com/en/cubism-editor-tutorials/psd/ — 옷깃·가디건·리본 등 필요에 따른 분리와 가림 보완. https://docs.live2d.com/en/cubism-editor-manual/clipping-mask/ — Clipping은 이후 Editor의 구현 기능으로 원화 PNG가 자동 리깅되는 것이 아니다. **비공식 작화 경험:** 옷의 장력·소재별 명암과 가려진 안감 보완은 사용자가 요청한 디자인에 맞춰 선택.
**공통 주의:** Live2D/Cubism 공식은 원화 분리·편집기 구현을 설명하지만, '정확한 6등신', '홍채 가로폭 몇 %', '2~3톤만 허용'을 기술 규격으로 요구하지 않는다. Cubism Editor의 키폼·클리핑·Skinning은 이미지 AI의 자동 납품 대상이 아니다.

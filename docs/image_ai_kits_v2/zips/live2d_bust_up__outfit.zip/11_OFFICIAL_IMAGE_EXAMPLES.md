# Live2D 바스트업 의상 전용 시각 참고

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / outfit
**실제 제작:** 선택된 바스트업 의상 한 벌의 카라·옷깃 안쪽·상의 앞/뒷판·실제 보이는 좌우 소매·옷에 부착된 장식만.
**금지:** 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.
**구도:** 방송용 바스트업은 머리 높이 1 : 보이는 목·어깨·상체 약 1~2의 레이아웃 기준이며, 헤어·의상·액세서리 ZIP에서는 제공된 기준 몸체를 새로 그리지 않고 해당 자산만 완성한다.


아래 공식 Live2D 전체 캐릭터 샘플은 **애니풍 선화·작화 수준을 참고할 목적만** 있고, 의상 외의 얼굴/옷/머리/악세서리를 추가로 그리라는 명령은 아니다. 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.

![Live2D official Tsumiki](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-tsumiki.png)
![Live2D official Izumi](https://www.live2d.com/wp-content/themes/cubism_new/assets/img/sample/sample-img-izumi.jpg)

공식 샘플: https://www.live2d.com/en/learn/sample/ . 원본 파일을 ZIP에 복제하지 않았으며 열람 불가면 보았다고 주장하지 않는다.

# 참고 이미지 자료

Live2D 공식 예제 https://www.live2d.com/en/learn/sample/haru-receptionist/ 와 원화 안내 https://docs.live2d.com/en/cubism-editor-tutorials/psd/ : 선화·구도·연결을 참고하고 기존 캐릭터를 복제하지 않는다.

예제 캐릭터의 디자인 자체를 베끼지 않는다. Live2D 방송 바스트업에서 필요한 OUTFIT 착의 몸통·팔·손 원화만 제작한다. 출력 경로는 04_OUTPUT_FILES.md의 실제 PNG 목록과 일치해야 한다.

## OUTFIT_CLOTHED_BODY_V1
얼굴을 제외한 몸통·양팔·양손을 실제 의상을 착용한 모습으로 그린다. 의복은 불투명하고 목깃과 소매가 확실하다. 신체를 벗겨낸 원화는 만들지 않는다.


## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **live2d_bust_up / outfit** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.
- 2. **Live2D Haru arm/outfit swap model** — https://www.live2d.com/en/learn/sample/haru/
   - 기존 자료 형식: Cubism model
   - 실제 활용: Reference for alternative sleeves, arms and garment replacement; not an interchangeable PSD automatically.
   - 권리 확인: Official sample terms; model-only reference unless a user-owned licensed source PSD is supplied.

### 채울 슬롯
`collar`, `upper_torso_garment`, `sleeve_L`, `sleeve_R`, `cuff_L`, `cuff_R`, `garment_side_L`, `garment_side_R`, `front_back_overlap`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** head to upper abdomen/waist with complete shoulders arms and hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.

# Live2D 바스트업 outfit 고유 실무 노하우

1. 바스트업의 의상은 목·어깨·카라·소매·가슴 위쪽 범위에 시각적 집중도를 둔다. 치마·신발을 필수 생성하지 않는다.
2. 목 아래 옷깃 안쪽, 뒤판과 어깨 소매 연결부의 천을 넉넉하게 그려 움직일 때 빈 구멍을 막는다.
3. 좌우 소매와 흔들리는 리본 등의 필요한 단위만 나누고 고정 주름·그림자를 무작정 작은 파츠로 만들지 않는다.
4. 옷감의 재질(천·니트·가죽 등)과 색을 유지하고 실사 인체 흉곽·근육 음영으로 바꾸지 않는다.
5. 착용되는 불투명 의복 자체가 안전한 가림이며 별도의 노출 몸체나 제거용 노출 레이어를 만들지 않는다.
6. 기존 몸체의 **원본 기준 원화**와 캔버스·원점·쇄골/어깨선이 맞는지, 소매 절단·옷깃 틈·안감·알파를 재합성 검수한다.

공통 작업: 실제 원본 기준 원화의 동일 캔버스·원점·스케일을 보존하고 투명 PNG를 원래 순서로 재합성합니다. 다른 자산 원화를 새로 만들거나 리깅 결과를 주장하지 않습니다.

## [2026-10-13 고급 원화·애니풍 검수 확장 — live2d_bust_up / outfit]
### 작업 순서·아티스트 실전 노하우
1. 바스트업에서는 얼굴 아래 **옷깃과 상체 실루엣이 브랜드 인상**을 좌우한다. 작은 방송 창에서 카라·리본/넥타이가 실제 있을 때만 읽히도록 한다.
2. 소매와 몸통, 목과 옷깃, 리본과 옷감이 겹치는 뒤쪽 천을 추가 작화하여 위치 변화 시 배경 구멍이 생기지 않게 한다.
3. 면직물은 넓고 정돈된 음영, 니트는 두께/늘어짐, 가죽/금속은 대비 높은 반사 등 **실제 선택한 재질만** 표현한다.
4. 정적인 솔기·문양을 전부 별도 PNG로 만들지 않는다. 움직일 옷깃·리본 등만 분리하고 다른 파츠와 색/빛 방향을 일치시킨다.
5. 불투명 가림을 유지한 기준 몸체에 같은 캔버스로 재합성하며 카라 틈·소매 연결 오류·피부/헤어 혼입을 검토한다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_bust_up/outfit]
**목·카라의 다른 소유권:** 신체가 담당하는 턱 뒤 피부/앞목·옆목은 만들지 않는다. 이 의상에서 담당할 것은 목깃 **안쪽 천·뒤칼라·좌우 카라·소매 뒤쪽**의 숨은 옷감이다. 턱을 돌려 뒷목과 카라 안쪽이 드러나는 경우에도 카라 뒤로 배경색 구멍이 나타나지 않도록 실제 천을 연장한다. 목 피부와 옷감이 한 PNG에 섞이지 않도록 분리한다.


## [고급 그림자·모근·소재·선폭 | live2d_bust_up/outfit]
**[의상 원화 고급 기법]** 주름은 옷의 무게·두께·관절 움직임과 실제 고정점(어깨·팔꿈치·허리/소매)에서 출발해 장력에 맞춰 퍼진다. 고정 자수/인쇄·체크무늬는 옷감의 위치를 따라 휘고 앞뒤 면·양 소매에서 연결해야 한다. 투명 원단이 실제 있을 때만 서로 겹친 부분의 합성 어두워짐을 점검하고, 내부 안감/아래에 보일 원단 색을 따로 준비한다. 입체감을 이유로 피부·귀·헤어를 의상 ZIP에서 다시 그리지 않는다.

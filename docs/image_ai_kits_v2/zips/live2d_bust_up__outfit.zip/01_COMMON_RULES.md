## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **live2d_bust_up / outfit** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.
- 2. **Live2D Haru arm/outfit swap model** — https://www.live2d.com/en/learn/sample/haru/
   - 기존 자료 형식: Cubism model
   - 실제 활용: Reference for alternative sleeves, arms and garment replacement; not an interchangeable PSD automatically.
   - 권리 확인: Official sample terms; model-only reference unless a user-owned licensed source PSD is supplied.

### 채울 슬롯
`collar`, `upper_torso_garment`, `sleeve_L`, `sleeve_R`, `cuff_L`, `cuff_R`, `garment_side_L`, `garment_side_R`, `front_back_overlap`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** head to upper abdomen/waist with complete shoulders arms and hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 live2d_bust_up/outfit 적용 최상위 기준]
공식 완성 버튜버 샘플의 실제 이미지를 열어서 큰 눈·머리 비율·얼굴 하관·귀·애니 선화 및 스타일을 비교·기록한다. 링크만 확인하고 이미지를 보지 못하면 REFERENCE_NOT_VIEWED, 시각 품질 PASS 금지. 사용자 부정 예시(뾰족 V턱·실사 귀·옷이 붙은 BODY)는 긍정 정답이 아니다.
OUTFIT: 사용자 요청 의상 한 벌만, BODY 기준 원화의 얼굴/몸·귀를 재생성 금지. 어깨·목깃·소매·안감·숨은 옷감을 실제 의상 파츠로 제작하고 주름/끈은 의상에만 남긴다. 몸통에 의복 압박 살접힘·쇄골 음영을 추가하지 않는다. 같은 캔버스와 원점·배율 및 합성 미리보기 검수.

# Live2D 바스트업 의상 독립 원화 공통 원칙

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: live2d_bust_up / outfit
**실제 제작:** 선택된 바스트업 의상 한 벌의 카라·옷깃 안쪽·상의 앞/뒷판·실제 보이는 좌우 소매·옷에 부착된 장식만.
**금지:** 신체·피부·얼굴·헤어·귀걸이 등 별도 액세서리 및 보이지 않는 하체 의상을 새로 생성하지 않는다.
**구도:** 기존 기준 신체의 얼굴 중심 근접 바스트업을 그대로 유지하면서 이 ZIP의 outfit 한 자산만 실제 제작한다. 신체·눈·얼굴·목 피부나 전신 비율은 재설계하지 않는다.


1. 기준 몸체는 **좌표·캐릭터 정체성·선화와 색감의 참조**이며, 실제 제작은 의상 하나만이다. 몸은 옷을 붙일 위치에만 참조하고 피부·헤어·얼굴을 의상 파츠에 붙여 출력하지 않는다.
2. 옷깃 안쪽·어깨/소매 접합 뒤 숨은 옷감, 소재별 솔기·명암·주름을 보완한다. 실제 없는 리본·넥타이·치마를 강제로 추가하지 않는다. 불투명 천으로 중요 부위를 가린다.
3. 실제 그린 대상 원화를 기준으로 RGBA 파츠를 마스킹·추출한다. 체크무늬 배경을 투명도라고 주장하지 않는다.
4. 파츠가 움직여 보일 **해당 자산의 가려진 그림만** 추가 보완한다. 다른 자산의 얼굴/목/옷 안감을 임의로 만들어 납품하지 않는다.
5. 동일 캔버스·원점·레이어 순서를 유지하고 최종 PNG를 재합성해 확인한다.
6. 안전: 기준 신체의 불투명 의복·마스크를 유지할 뿐 이 자산에서 피부·속옷·가림용 의복을 새로 생성하지 않는다.

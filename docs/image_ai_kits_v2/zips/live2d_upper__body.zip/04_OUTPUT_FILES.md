# Live2D 상반신 / 신체만 결과 이미지 ZIP
결과 이름: live2d_upper__body__ARTWORK.zip
PNG 예시(캐릭터에 실제 있는 부위만, 고급 파츠 추가는 02 지침 참조):
isolated_parts/face_skin.png
isolated_parts/nose.png
isolated_parts/brow_L.png
isolated_parts/brow_R.png
isolated_parts/eye_L_white.png
isolated_parts/eye_L_iris.png
isolated_parts/eye_L_upper_lash.png
isolated_parts/eye_R_white.png
isolated_parts/eye_R_iris.png
isolated_parts/eye_R_upper_lash.png
isolated_parts/mouth_upper.png
isolated_parts/mouth_lower.png
isolated_parts/mouth_inside.png
isolated_parts/neck.png
isolated_parts/torso.png
isolated_parts/arm_L_upper.png
isolated_parts/arm_L_forearm.png
isolated_parts/hand_L.png
isolated_parts/arm_R_upper.png
isolated_parts/arm_R_forearm.png
isolated_parts/hand_R.png
layer_order.txt
previews/composite_preview.png
모든 2D 파츠 PNG는 진짜 RGBA 투명·같은 기준 캔버스와 원점. 동작이 다르면 처음부터 독립 이미지로 그린다.
layer_order.txt는 실제 있는 부품 파일명들을 뒤→앞으로 한 줄씩. 프리뷰는 마지막에 생성된 PNG를 합성해서 만든다.
액세서리 파일명 HEADPIECE 등은 요청된 실제 물건 명칭으로 치환한다. 꺾쇠괄호나 다른 자리표시자를 문자 그대로 파일명으로 쓰지 않는다.
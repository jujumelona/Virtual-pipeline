# Live2D 상반신 / 신체만 출력 이미지

> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 기준 원화 먼저 생성 → 2D 원본 분리/3D 참조 확장 → 숨은 부분 보완. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
결과 ZIP: `live2d_upper__body__ARTWORK.zip`
```text
isolated_parts/face_skin.png
isolated_parts/nose.png
isolated_parts/ear_L.png
isolated_parts/ear_R.png
isolated_parts/brow_L.png
isolated_parts/brow_R.png
isolated_parts/eye_L_white.png
isolated_parts/eye_L_iris.png
isolated_parts/eye_L_upper_lash.png
isolated_parts/eye_L_lower_lash.png
isolated_parts/eye_R_white.png
isolated_parts/eye_R_iris.png
isolated_parts/eye_R_upper_lash.png
isolated_parts/eye_R_lower_lash.png
isolated_parts/mouth_upper.png
isolated_parts/mouth_lower.png
isolated_parts/mouth_inside.png
isolated_parts/neck.png
isolated_parts/torso.png
isolated_parts/arm_L_upper.png
isolated_parts/arm_L_forearm.png
isolated_parts/hand_L.png
isolated_parts/arm_R_upper.png
isolated_parts/arm_R_forearm.png
isolated_parts/hand_R.png
layer_order.txt
previews/composite_preview.png
```
**실제 있는 파츠만 생성**하며, 고급 독립 움직임/가림이 있는 경우 02의 세부 이름 추가. 액세서리 headpiece 명칭은 해당 사용자가 요청한 물건의 이름으로 교체. 개별 RGBA 원화·동일 캔버스/원점·뒤→앞 목록. 미리보기는 생성된 파츠의 실제 합성.

**09 + 10의 고급 애니풍 품질 기준과 07 반복 점검을 충족한 경우에만 최종 ZIP 제공.**

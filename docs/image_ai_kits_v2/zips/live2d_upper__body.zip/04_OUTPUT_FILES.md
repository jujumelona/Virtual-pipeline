# Live2D 상반신 / 신체만 실제 이미지 결과 ZIP

결과: live2d_upper__body__ARTWORK.zip
isolated_parts/face_skin.png
isolated_parts/nose.png
isolated_parts/brow_L.png
isolated_parts/brow_R.png
isolated_parts/eye_L_white.png
isolated_parts/eye_L_iris.png
isolated_parts/eye_L_upper_lash.png
isolated_parts/eye_R_white.png
isolated_parts/eye_R_iris.png
isolated_parts/eye_R_upper_lash.png
isolated_parts/mouth_upper.png
isolated_parts/mouth_lower.png
isolated_parts/mouth_inside.png
isolated_parts/neck.png
isolated_parts/torso.png
isolated_parts/arm_L_upper.png
isolated_parts/arm_L_forearm.png
isolated_parts/hand_L.png
isolated_parts/arm_R_upper.png
isolated_parts/arm_R_forearm.png
isolated_parts/hand_R.png
layer_order.txt
previews/composite_preview.png

세부 파츠 명칭은 02_ADVANCED_PARTS.md에서 필요에 따라 추가한다. 없는 부위는 만들지 않는다. 눈·입 등은 신체 범주 내부 파츠다.
각 PNG는 투명 RGBA, 같은 크기의 기준 캔버스와 원점, 해당 부위만 그린다. layer_order.txt는 실제 PNG를 뒤→앞으로 나열한다. 생성한 파츠를 마지막에 합성한다.
사용자가 요청하지 않은 별도 신체/헤어/의상/액세서리 세트는 추가하지 않는다. PSD/리깅/키폼/모션 테스트는 요구하지 않는다.
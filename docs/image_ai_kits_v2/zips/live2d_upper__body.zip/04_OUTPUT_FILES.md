# Live2D 상반신 / 신체만 출력 이미지

**최우선 실행·납품:** `00_DELIVERY_AND_RECHECK.md`에 따라 실제 이미지 제작, 2회 이상 적용 가능한 점검, 결함 수정, 최종 ZIP 저장·재확인·링크 제공까지 진행한다. 중간 설명만으로 종료하지 않는다.


> **최우선 제작 순서:** `00_MASTER_FIRST.md`. 해당 2D 자산의 완성 기준 원화 먼저 제작 → 실제 RGBA 파츠만 분리 → 해당 자산의 숨은 면 추가 작화. 모순되는 파츠 선생성 지시보다 이 순서를 우선한다.
결과 ZIP: `live2d_upper__body__ARTWORK.zip`
```text
isolated_parts/face_skin.png
isolated_parts/nose.png
isolated_parts/ear_L.png
isolated_parts/ear_R.png
isolated_parts/brow_L.png
isolated_parts/brow_R.png
isolated_parts/eye_L_white.png
isolated_parts/eye_L_iris.png
isolated_parts/eye_L_upper_lash.png
isolated_parts/eye_L_lower_lash.png
isolated_parts/eye_R_white.png
isolated_parts/eye_R_iris.png
isolated_parts/eye_R_upper_lash.png
isolated_parts/eye_R_lower_lash.png
isolated_parts/mouth_upper.png
isolated_parts/mouth_lower.png
isolated_parts/mouth_inside.png
isolated_parts/neck.png
isolated_parts/torso.png
isolated_parts/arm_L_upper.png
isolated_parts/arm_L_forearm.png
isolated_parts/hand_L.png
isolated_parts/arm_R_upper.png
isolated_parts/arm_R_forearm.png
isolated_parts/hand_R.png
layer_order.txt
previews/composite_preview.png
```
**실제 있는 파츠만 생성**하며, 고급 독립 움직임/가림이 있는 경우 02의 세부 이름 추가. 액세서리 headpiece 명칭은 해당 사용자가 요청한 물건의 이름으로 교체. 개별 RGBA 원화·동일 캔버스/원점·뒤→앞 목록. 미리보기는 생성된 파츠의 실제 합성.

**09 + 10의 고급 애니풍 품질 기준과 07 반복 점검을 충족한 경우에만 최종 ZIP 제공.**


## Colab에서 바로 읽을 수 있는 실제 결과 ZIP 입력 계약 (필수)

**새로 생성할 결과 ZIP에는 다음 실제 파일을 포함한다. 이 제작 지시서 ZIP 자체가 아니라 AI가 그린 결과 ZIP의 내부 경로이다.**

- `outputs/master.png` — 신체만의 기준 원화 한 장. 반드시 실제 PNG이며 가짜 빈 캔버스/텍스트 파일이 아니다. 개별 파츠와 정확히 같은 픽셀 크기·기준 위치를 사용한다. 배경이 있는 RGB/RGBA 기준 그림도 허용한다.
- `isolated_parts/<실제부위명>.png` — 부위별 **전체 캔버스 크기와 위치가 일치하는 RGBA 투명 PNG**. 파츠 외 영역은 실제 alpha=0. 눈·목·팔 등 필요한 가려진 부분은 그림으로 보완한다.
- `layer_order.txt` — 실제 존재하는 `isolated_parts/` PNG 경로를 **뒤→앞 순서로 중복/누락 없이 각 한 번씩** 기록한다.
- `previews/composite_preview.png` — `layer_order.txt`에 따라 실제 납품 PNG를 순서대로 합성한 미리보기. 원본과 정체성/비율·표시 부위가 일치해야 한다.

**파일명 실수 방지:** 기준 원화를 `master_original.png`처럼 다른 이름으로만 저장하고 `outputs/master.png`를 빠뜨리지 않는다. 단, *이미 제작해 놓은 ZIP*이 `master_original.png` 한 장만 갖는다면 그림을 다시 생성하거나 파츠를 다시 그리지 않는다. 최신 Colab 가져오기는 이 이름도 수용한다. 신규 납품은 위 표준 경로를 우선한다.

**미리 확인:** ZIP을 다시 열어 마스터 파일의 실제 존재, 2D PNG 크기·알파, 레이어 순서의 1:1 대응 및 미리보기 재합성을 점검한다. 모델/리깅 수행이나 자동 미술 합격 판단을 요구하는 규칙이 아니다.

**분류 유의:** 이 ZIP의 자산은 **상반신 신체만**이다. 머리카락·외출복·장식까지 갖춘 완성 캐릭터가 아니다. FREE/PRO 모두에서 사용할 수 있는 독립 신체 베이스다. 신체만이라는 이유로 PRO를 강제하지 않는다. 완성 Live2D 방송 모델이라고 표기하거나 `.moc3`·`.cmo3`를 만들어 냈다고 주장하지 않는다.


## 7가지 결함을 막기 위한 신체 참조·상태 이미지

아래 파일은 기존 파츠 납품에 **추가**한다. 이름만 있는 플레이스홀더·정면 복사·이미지 미생성은 납품으로 인정하지 않는다.

```text
reference_views/head_front.png
reference_views/head_three_quarter_L.png
reference_views/head_three_quarter_R.png
reference_views/head_profile_L.png
reference_views/head_profile_R.png
previews/mouth_closed.png
previews/mouth_open.png
previews/neck_overlap.png
```

`mouth_closed`는 닫힌 입 한 개만, `mouth_open`은 열린 입 한 개만 합성한 이미지여야 한다. `neck_overlap`에서는 얼굴/몸통 가림을 걷었을 때 목 피부의 실제 연장 그림이 드러나야 한다. **측면 참조 이미지는 Cubism의 측면 키폼을 자동으로 생성하지 않는다.** 후속 Editor 작업을 위한 실제 추가 원화다.

## 실제 6등신 디자인·큰 눈 확인용 참고 원화
`reference_views/upper_body_proportion_guide.png` — 머리카락을 제외한 정수리~턱 H와 실제 화면에 보이는 목·어깨·상체의 상대 비례를 표시한 **상반신 전용 가이드**다. 6등신 프로젝트 스타일과 큰 애니 눈 인상은 유지하되 가이드 제작을 위해 골반·다리·발이나 전신 이미지를 새로 그리지 않는다. 파츠 입력 대신 작화 참고용이며 `layer_order.txt`에는 넣지 않는다.

`reference_views/face_large_anime_eyes.png` — 얼굴을 확대한 애니 눈·큰 홍채·아이라인·눈매 참조. 실사 작은 눈/작은 홍채 금지. `eye_L_*` 및 `eye_R_*`의 실제 합성본과 일치하며, 원화의 눈 비례가 실사로 줄어들지 않아야 한다.


## ZIP 고유 작업 범위 잠금: live2d_upper / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 

04의 파일명은 이 ZIP의 대상 부위에만 적용한다. 다른 종류 파츠는 기준 몸체 overlay에만 참조할 수 있고 isolated_parts/나 source로 출력하면 안 된다.

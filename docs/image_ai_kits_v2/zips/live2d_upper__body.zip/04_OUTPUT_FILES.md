# Live2D 상반신 / 신체만 최종 이미지 ZIP 규격

**결과명: `live2d_upper__body__ARTWORK.zip`**
```text
live2d_upper__body__ARTWORK.zip
  isolated_parts/face_skin.png
  isolated_parts/nose.png
  isolated_parts/ear_L.png
  isolated_parts/ear_R.png
  isolated_parts/brow_L.png
  isolated_parts/brow_R.png
  isolated_parts/eye_L_white.png
  isolated_parts/eye_L_iris.png
  isolated_parts/eye_L_upper_lash.png
  isolated_parts/eye_L_lower_lash.png
  isolated_parts/eye_R_white.png
  isolated_parts/eye_R_iris.png
  isolated_parts/eye_R_upper_lash.png
  isolated_parts/eye_R_lower_lash.png
  isolated_parts/mouth_upper.png
  isolated_parts/mouth_lower.png
  isolated_parts/mouth_inside.png
  isolated_parts/neck.png
  isolated_parts/torso.png
  isolated_parts/arm_L_upper.png
  isolated_parts/arm_L_forearm.png
  isolated_parts/hand_L.png
  isolated_parts/arm_R_upper.png
  isolated_parts/arm_R_forearm.png
  isolated_parts/hand_R.png
  layer_order.txt
  previews/composite_preview.png
```

**실제 캐릭터에 존재하는 항목만 제작하는 파츠명 예시**다. 02/06/08을 참고하여 **정말 다르게 움직이거나 깊이·가림이 다른 추가 파츠는 처음부터 생성**한다. 임의 수량 맞추기 금지.

모든 독립 PNG는 실제 투명 RGBA이며 **동일 캔버스 크기와 원점, 원래 부착 위치**에 그 파츠만 놓는다. `layer_order.txt`에는 실제 파일명을 **뒤→앞** 순서로 누락·중복 없이 적고, 미리보기는 최종 PNG들을 조합한다. 

**`07_REVIEW_BEFORE_FINAL_ZIP.md`에 따른 반복 그림/파일 점검을 통과했을 때만 이 결과 ZIP을 최종 납품한다.** 못 만든 그림을 합격·완성으로 표기하지 않는다. 리깅·구동 검사 파일을 넣지 않는다.

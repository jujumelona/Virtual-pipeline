
## [2026-10-13 v5 live2d_upper/body 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
BODY: 얼굴/눈/입의 애니 작화와 목 아래 중립색 기하학적 프록시를 **별도** 제작 후 한 캔버스에 조립. 얼굴은 짧고 둥근 U형 턱, 작고 내부선 1~2개인 귀, 큰 눈과 짧고 단정한 목, 과대한 정수리 방지. 홍채색은 사용자 지정값을 우선하고 분홍/노랑 고정 금지. 몸통은 이미지 모델이 아니라 코드의 불투명 단색 도형(예: Pillow)으로 만들며 속옷·의상·목깃·가슴/쇄골/겨드랑이 명암·팔 옆 살접힘/눌림을 그리지 않는다. 기존 '신체 전부 AI 원화로', '기본 슈트' 규칙을 실행하지 않는다. 도형 코드 실행 기록·정합 미리보기 없이 완료 선언 금지. 이 모드는 상반신 범위를 유지하고 하체를 추가하지 않는다.

## 2026-10-13 사용자 지정 BODY 최상위 제작 규칙 — 기존 묘사 지시보다 우선
이 ZIP은 머리·얼굴 및 재사용용 몸체 실루엣을 위한 신체 전용 지시서다. 외부 생성 AI에게 얼굴부터 몸까지 완성한 인체 일러스트를 한 장으로 요구하지 않는다.
얼굴·눈·입을 애니풍으로 작업하고 BODY 몸체는 별도의 중립색 불투명 2D 도형 프록시를 프로그램으로 만든다. 몸체 도형에는 옷/속옷/튜브탑/리본/목깃/어깨 압박 주름/쇄골 윤곽/가슴 굴곡/겨드랑이 피부 접힘/근육/갈비뼈의 그림과 음영을 그리지 않는다.
정면 얼굴은 짧고 부드러운 U형 하관과 둥근 볼, 작은 애니 귀(내부 선 1~2개), 균형 잡힌 두상과 단순한 목을 사용한다. 기존의 긴 V자 턱과 실사형 큰 귀, 과도한 정수리와 긴 목을 다시 생성하면 FAIL이다. 눈 크기만으로 애니형 판정하지 않는다.
홍채 색은 사용자가 지정하거나 캐릭터별 팔레트에서 선정한다. 특정 분홍/노랑 눈색 고정 금지. 헤어와 의상, 액세서리는 BODY에 병합하지 않는다.
제작 순서: 공식 완성 VTuber 참고 이미지를 실제로 열어 비교·기록 → 얼굴 원화 시각 검수 → 단색 BODY 도형 생성 → 한 캔버스에서 조립 → RGBA 분리/가려진 면 검사 → 합성 QA → 최종 ZIP. 링크 확인만으로 이미지 시각검수 완료라고 보고하지 않는다.
도형 코드를 실행하지 않고 생성 AI에 통짜 몸통을 그리게 하면 본 지시 미준수다. 실행이 막히면 거짓 완료 판정 대신 제작 불가를 보고한다. PSD/리깅은 별도 단계.
신체 도형은 완성 캐릭터 일러스트가 아니라 의상 교체용 레이어이므로 미술적 화려함/인체 곡선을 요구하지 않는다. 사용자 얼굴 정체성과 전체 6등신 디자인 계약(전신인 경우)을 보존한다.

# Live2D 상반신 신체 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


큰 홍채·깊이 있는 속눈썹·작은 코와 입·부드러운 턱·매끈한 셀 피부. 사실적인 갈비뼈/복근/흉근·성인 실사 비례는 금지. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber body-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested body asset on the reference canvas, no unrelated character parts or props.”

특정 캐릭터의 디자인 복제 금지. 실제 2D 그림까지만, PSD/Cubism 키폼은 사용자가 나중에 처리한다.


## [2026-10-13 원화·애니풍 심화: live2d_upper/body]
Commercial-grade anime VTuber UPPER BODY BASE ONLY: large expressive irises, tapered lashes, petite stylized nose and mouth, natural neck and shoulders and visible arms, polished cel shadows, opaque modest basewear, no hair, fashion outfit, jewelry or lower-body parts.
Commercial Japanese anime, variable tapered dark ink and refined material cel shading, keep original character design.


## [고급 그림자·모근·소재·선폭 | live2d_upper/body]
Anime VTuber BODY ONLY: preserve the existing eye shape and facial identity, tapered eyelash and mouth linework, delicate colored interior contours and clean skin cel-shadows, no baked-in moving hair-cast shadow on the permanent face skin, no duplicated facial linework, no hairstyle/clothing/accessory generation.

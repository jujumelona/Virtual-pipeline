## [BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 회색/살구색/중립 파스텔색 등의 균일한 불투명 색 면을 허용한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/BODY_DEFAULT_OPAQUE_SWIMWEAR_V1]

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** 정수리~허리의 애니풍 상반신. 큰 얼굴/눈 중심, 짧고 넓은 얼굴과 정확히 연결된 목·어깨·자연스러운 팔과 양손을 그린다. 가로로 뻗은 팔·작은 머리·길쭉한 실사 비율·납작한 밴드형 캐릭터는 거절한다.
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 선화·얼굴·눈·원화 해상도/세부 수준·해당 자산만 제작됐는지 시각 확인한 증거가 없으면 ART_QUALITY_UNVERIFIED로 표기하고 납품하지 않는다.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
live2d_upper/body 원화 생성 우선 조건. 충돌하는 구형 미술 지침보다 우선한다.
- 공통: **큰 머리, 큰 눈과 홍채, 짧고 넓은 얼굴, 둥근 볼, 짧고 매끈한 U형 턱, 작은 코·입.** 말상·좁은 얼굴·길게 내려오는 V턱·성숙 실사 얼굴은 절대 불합격.
- 정면 얼굴 높이/폭 약 1.10~1.30은 참고 범위이며 강제 크롭/화면 점유율은 아님. 전신 6등신 유지, 바스트업·상반신은 머리를 작게 만들지 않음.
- 실패 판정: 머리가 작다 / 눈이 작다 / 얼굴이 길거나 좁다 / 턱이 뾰족하다 / 목이 길다 / 다른 자산이 혼입됐다. 하나라도 해당하면 불합격이며 무검증 납품 금지.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_upper/body]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **BODY만 생성:** 귀여운 애니풍 두상·큰 눈/홍채·짧고 둥근 하관, 단순한 피부와 목·어깨·필요한 신체·손. 갈비뼈/복근/배꼽/쇄골·힘줄을 선으로 과잉 묘사하지 않는다. 디자인 의상은 OUTFIT 전용이며 BODY에는 위 기본 불투명한 어깨끈 없는 반도형 불투명 단색 외피로 덮인다. 몸통은 불투명 무광 단색 찰흙형 베이스. 얼굴과 눈은 높은 품질의 애니풍 원화. 헤어·탈착 의상·액세서리를 BODY에 붙이지 않는다.
- 프레임: 정수리부터 허리와 양손까지 상반신. 자산 소유 범위에만 적용. 전신 캐릭터 기본 디자인은 6등신을 지향하나 크롭에서 머리의 화면 점유율을 52~61% 등으로 고정하지 않는다.
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY 제공 시 얼굴 비율을 변경하지 않는다.


## [2026-10-13 v5 live2d_upper/body 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.

## 2026-10-13 사용자 지정 BODY 최상위 제작 규칙 — 기존 묘사 지시보다 우선
이 ZIP은 머리·얼굴 및 재사용용 몸체 실루엣을 위한 신체 전용 지시서다. 외부 생성 AI에게 얼굴부터 몸까지 완성한 인체 일러스트를 한 장으로 요구하지 않는다.
정면 얼굴은 짧고 부드러운 U형 하관과 둥근 볼, 작은 애니 귀(내부 선 1~2개), 균형 잡힌 두상과 단순한 목을 사용한다. 기존의 긴 V자 턱과 실사형 큰 귀, 과도한 정수리와 긴 목을 다시 생성하면 FAIL이다. 눈 크기만으로 애니형 판정하지 않는다.
홍채 색은 사용자가 지정하거나 캐릭터별 팔레트에서 선정한다. 특정 분홍/노랑 눈색 고정 금지. 헤어와 의상, 액세서리는 BODY에 병합하지 않는다.
BODY는 의상 교체용 공통 베이스로서 몸통은 불투명한 비해부학적 무광 단색 찰흙 외피로 제작한다. 해부학적 내부선은 생략하고 큰 머리·짧고 둥근 얼굴·부드러운 턱·큰 눈을 유지한다.

# Live2D 상반신 신체 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.


큰 홍채·깊이 있는 속눈썹·작은 코와 입·부드러운 턱·매끈한 셀 피부. 사실적인 갈비뼈/복근/흉근·성인 실사 비례는 금지. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber body-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested body asset on the reference canvas, no unrelated character parts or props.”



## [2026-10-13 원화·애니풍 심화: live2d_upper/body]
Commercial-grade anime VTuber UPPER BODY BASE ONLY: large expressive irises, tapered lashes, petite stylized nose and mouth, natural neck and shoulders and visible arms, polished cel shadows, opaque modest basewear, no hair, fashion outfit, jewelry or lower-body parts.
Commercial Japanese anime, variable tapered dark ink and refined material cel shading, keep original character design.


## [고급 그림자·모근·소재·선폭 | live2d_upper/body]
Anime VTuber BODY ONLY: preserve the existing eye shape and facial identity, tapered eyelash and mouth linework, delicate colored interior contours and clean skin cel-shadows, no baked-in moving hair-cast shadow on the permanent face skin, no duplicated facial linework, no hairstyle/clothing/accessory generation.

## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스 (필수)
- 20세 이상 성인의 비성적이고 귀여운 애니 VTuber 디자인. 얼굴은 짧고 넓으며 부드러운 U형 턱, 큰 눈·홍채, 간결한 코·하나의 입을 선명한 완성 애니 원화로 그린다. 머리카락은 HAIR에서 만든다.
- **몸통은 해부학적 피부 원화가 아니라 불투명한 단색의 매끈한 무광 찰흙·마네킹형 가림 외피**로 그린다. 회색/살구색/중립 파스텔색 등의 균일한 불투명 색 면을 허용한다. 피부 조직, 가슴 형태, 흉근·복근·갈비뼈·배꼽·속옷/옷 주름, 인체 음영과 사실적인 골격 묘사는 추가하지 않는다. 실사 나체나 정교한 미해부 모델을 생성하지 않는다.
- 상체 중심부는 형태가 강조되지 않는 평평하고 불투명한 무광 표면이다. 선명한 인체 굴곡·가슴 모양·실사 피부 셰이딩이 생기면 **몸통 영역만** 단색으로 수정한다. 얼굴·눈·손과 연결부의 필요한 선화 품질은 낮추지 않는다.
- 기본 마스터·참고 시점·합성 미리보기는 모두 **가려진 중성형 모델**로 유지한다. 무광 외피를 벗긴 노출 신체 참고 이미지나 세부 해부학 언더페인트를 생성하지 않는다. 가린 부분의 교차 면은 단색 비해부학적 픽셀로만 연장한다.
- 2D에서 기존 호환 파일명 removable_neutral_modesty_band_upper, 화면에 실제 하체가 보이는 경우 removable_neutral_modesty_band_lower를 그대로 사용한다. 이 명칭은 예전 입력 계약 이름일 뿐 시각적으로 수영복이나 브라를 그리라는 지시가 **아니다**. 가림용 레이어는 합성에서 ON, 숨은 면/표정 대체 레이어는 필요 상태에서만 ON이다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
### [ONE_PART_PER_GENERATION_V1] 실제 VTuber 파츠를 하나씩 그리는 작업 계약
**이 단계는 '완성 이미지 한 장만 그린 뒤 남에게 전부 잘라 달라'가 아니다.**
- 먼저 제공된 템플릿의 이미지와 실제 레이어/파츠 구조를 열어 눈으로 확인한다. 템플릿을 링크만 적어두고 미열람 상태로 생성하지 않는다. 참조: https://docs.live2d.com/en/cubism-editor-tutorials/template/
- [공식 Live2D 원화 분리 예제] https://docs.live2d.com/en/cubism-editor-tutorials/psd/ ; [자유 재사용 가능 예시 PSD] https://github.com/tsunehimatoi/psd2live-examples (CC0, 개별 샘플 표시 조건 검토).
- **참고 슬롯:** 해당 플랫폼 실제 PSD 템플릿의 레이어·가림 계층, 눈-흰자/홍채/윗속눈썹, 입-닫힌선/입안/윗니/혀, 얼굴/귀/목, 좌우 상완/전완/손. 공식 템플릿은 구성·앞뒤·숨은 영역의 예시다. 그 캐릭터 모습, 스타일, 인체 비율을 복사하지 않는다. Inochi Aka는 얼굴 구조 참고이지 전신 팔까지 있는 템플릿이 아니다.
- 자산과 프레이밍: live2d_upper/body; 두상부터 상반신·허리까지. 다른 자산을 새로 제작하지 않는다.
- 1) 이 자산의 디자인 마스터를 확정하고 얼굴·눈·입·목·몸통·팔과 색상을 고정한다.
- 2) 다음부터는 **한 번의 생성/수정에서 정확히 한 파츠**만 그린다. 해당 파츠와 원래 마스터, 실제 공식 템플릿의 대응 슬롯, 직전 승인된 파츠를 함께 시각적으로 참고한다. 결과를 확인하고 다음 파츠로 넘어간다. 시트 한 장에 여러 작은 파츠를 한꺼번에 그리는 것으로 대체 금지.
- 3) 각 파츠는 **마스터와 동일한 전체 캔버스 좌표의 RGBA PNG**를 `part_art/<semantic_name>.png`에 저장한다. 한 파일에는 그 파츠와 **원래 가려졌지만 회전할 때 노출되는 연장 픽셀만** 그리고, 다른 얼굴/몸/옷을 같이 넣지 않는다. 배경·가이드·레이블·텍스트·캐릭터 실루엣 중복을 투명 영역에 남기지 않는다.
- 4) 권장 파츠 역할: face, ear.left, ear.right, eye.left.white, eye.left.iris, eye.left.upper.lash, eye.right.white, eye.right.iris, eye.right.upper.lash, eyebrow.left, eyebrow.right, nose, mouth.close, mouth.open, mouth.tooth.t, mouth.tongue, neck, torso, arm.left.upper, arm.left.forearm, hand.left, arm.right.upper, arm.right.forearm, hand.right. 눈 흰자·홍채·윗속눈썹, 닫힌 입·열린 입안·윗니·혀, 상완·전완·손을 각각 독립 작화한다. 다른 자산에 속한 파츠를 추가하거나 누락을 이름만으로 통과시키지 않는다.
- 5) `part_art/_order.txt`에는 앞에서 뒤로 각 개별 PNG 경로를 한 줄씩 쓴다. PSD·마스크·MOC3·리깅은 제작하지 않는다. 열린 입안·치아·혀의 대체 그림은 각각 생성하되 중립 합성에서만 감춘다.
- 6) 양쪽 눈·목·어깨·팔·손목을 정면·3/4·측면 참조와 대조하고, 중립 파츠 합성이 `outputs/master.png`와 일치해야 한다. 접합 틈·중복·부유 파츠는 반려한다.
- 7) 필수 납품: `outputs/master.png`, `part_art/_order.txt`, 각 파츠의 개별 `part_art/*.png`, 다음 다각도 참조 PNG: reference_views/body_front.png, reference_views/head_three_quarter_L.png, reference_views/head_three_quarter_R.png, reference_views/head_profile_L.png, reference_views/head_profile_R.png, reference_views/head_pitch_up.png, reference_views/head_pitch_down.png, reference_views/neck_underpaint.png, reference_views/body_joint_overlaps.png. BODY는 `expression_refs/mouth_closed.png` 및 `expression_refs/mouth_open.png`를 별개의 완성 표정 참고 원화로 추가한다.
- 8) 신뢰할 수 있는 투명 배경을 이미지 생성기가 지원하지 못하면 **하얀 배경 PNG를 투명 파츠라고 이름만 바꿔 내지 말고** 별도 검수 실패로 표시한다. 원본 파츠를 보존한 채 Colab에 See-through 분리 경로를 요청할 수 있다.
- 목·턱·좌우 어깨·상완·전완·손의 실루엣을 시점마다 정합되게 그린다. 단색 무광 찰흙형 비해부학 BODY를 유지한다. neck_underpaint와 body_joint_overlaps는 **부품이 아니라 목·턱·몸통·어깨의 가림·연결을 설명하는 완성 참고 그림**이다. 정면·좌우 3/4·측면에서 턱 아래 목과 귀 뒤, 목-어깨 접점을 보여준다. 정면 그림을 늘이거나 머리만 좌우 이동해 옆모습으로 속이지 않는다.
- **제작 단계 확정:** 이미지 AI는 위에 명시한 독립 파츠의 실제 그림과 다각도 참조를 하나씩 제작한다. PSD 인코딩·메시·키폼·리깅은 별도 단계다. 후속 Colab에서 실제 PNG 픽셀과 레이어 순서를 확인하여 PSD를 만들고 Live2D이면 PSD2Live에서 리깅한다. 이미지 AI는 코드를 실행하거나 리깅 성공을 주장하지 않는다.
- 기존 실제 템플릿을 열지 않았거나 파츠를 하나하나 생성하지 않은 결과는 완료라고 보고하지 않는다.

- [VTUBER_SIDE_NECK_RIG_ACCEPTANCE_V1] [그림과 실제 리깅의 차이] part_art/neck.png는 턱 아래 잘린 얇은 조각이 아니어야 한다. 정면에서 턱 뒤 피부를 입 높이 가까이까지 위쪽으로 실제 그려 두고, 아래는 part_art/torso.png의 상부와 실질적인 알파 교집합을 만들어 놓는다. 얼굴 아래·목·몸통이 알파로 단순히 접하는 선은 실패다. head_three_quarter_L/R는 약 45°, head_profile_L/R는 실제 90° 형태 참고다. 각각 코·입·턱·귀·목뿌리·양어깨가 한 그림 안에서 연결되고 좌우 반전 복제로 대체하지 않는다. head_pitch_up/down에서 턱 아래 목의 드러남/가림을 실제로 바꾼다. neck_underpaint와 body_joint_overlaps 참고 그림을 따로 그리는 것만으로는 실제 part_art/neck.png의 가려진 픽셀이 생기지 않는다.
- [좌표/참조] 정면·좌우 3/4·양측면 및 상하 자세 비교 원화는 outputs/master.png와 동일한 전체 캔버스 치수·기준 크기로 그린다. 확대 클로즈업은 별도 보조 그림으로만 남긴다. 이미지 AI의 다각도 그림은 PSD2Live/Inochi 실제 키폼에 자동 등록되지 않는다.
- [엔진 확인] PSD2Live 기본 머리 ParamAngleX 범위는 -45..+45°, ParamAngleY는 -30..+30°다. 실제 -90/+90° 옆모습 PNG는 자동으로 키폼이 되지 않는다. 실제 MOC3 극한 각도 렌더링과 턱·목·귀·헤어 가림을 확인할 때까지 90° 가능이라고 보고하지 않는다.
## [/IMAGE_AI_SOURCE_ONLY_V2]

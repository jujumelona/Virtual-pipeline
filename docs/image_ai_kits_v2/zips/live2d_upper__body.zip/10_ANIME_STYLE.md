## [SAFE_GENERATION_STAGE_V3]
성인(20세 이상)의 비성적 애니 VTuber 원화. BODY의 몸통과 팔은 단정한 목둘레와 소매 끝이 보이는 **불투명 무광 청회색(#526B7D) 긴소매 스튜디오 제작복**으로 실제 완전히 가린다. 피부/해부학 묘사 대신 민무늬 마네킹형 실루엣을 유지한다. 얼굴·귀·목·손의 노출 피부는 동일한 FACE_SKIN_BASE로 통일하며, 원화 제작복은 피부색과 구분한다. 이후 마스킹도 착의 경계는 지킨다. 민머리·짧고 둥근 얼굴·큰 주황 홍채·자연스러운 목/어깨 연결·양팔/양손 다섯 손가락을 유지한다. 패션 의상·헤어·액세서리 추가 금지. 2D 원화는 master와 각도/표정 PNG만, 3D는 기존 8방향 참조만 생성하며 PSD/리깅 완성을 주장하지 않는다.
IMAGE_MODEL_SOURCE_PROMPT: "Original high-quality Japanese anime adult VTuber reference illustration, fully clothed in an opaque matte slate-blue long-sleeved crew-neck studio practice suit with clearly visible neck opening and cuffs. Smooth simple stylized torso and arms. Big bald rounded head, cute short wide rounded U jaw, large detailed amber eyes, clean small nose and mouth, unified warm-peach visible skin on face, neck and hands. Natural linked shoulders, complete arms and five-finger hands. Crisp tapered anime line art and clean cel shading; single character on plain light background, no hair, costume designs or jewelry."
이미지 생성기에는 이 긍정적 원화 프롬프트 및 모드별 구도/시점만 전달한다. 14개 MD 전체를 생성 프롬프트에 붙이지 않는다. 안전 정책을 끄거나 우회하지 않는다.
## [/SAFE_GENERATION_STAGE_V3]

## [ART_SOURCE_AND_SEPARATION_V3]
### live2d_upper / body — 자산·모드·담당 단계 잠금
- 자산 경계: BODY: 민머리 두상·얼굴 피부·양눈·입·코·귀·목·어깨·몸통 무광 외피·양팔·양손만. 머리카락·패션 의상·장신구 픽셀 0개(기본 스튜디오 제작복은 BODY 필수). BODY 제작 도중 완성 캐릭터 참고 이미지에 보이는 HAIR·OUTFIT·ACCESSORY를 복제하지 않는다. 민머리 완성 BODY만 납품.
- 명시적 생성 제외: BODY에서 머리카락 전부 제외: 앞머리·옆머리·뒷머리·잔머리·묶음머리·포니테일·헤어 장식·머리핀·리본·귀걸이·안경·목걸이·독립 액세서리·패션 의상·불필요한 주름 생성 금지(기술 제작복의 목둘레·소매는 예외). 민머리 신체 베이스만 만든다. 참조 캐릭터에 머리카락/의상이 보여도 BODY 마스터나 각도·표정 참고 그림에 복사하지 않는다.
- 실물 납품 차단: BODY master 및 정면·3/4·측면·후면 참조에서 머리카락 한 가닥, 헤어핀, 의상 디자인, 독립 장신구가 보이면 CROSS_ASSET_CONTAMINATION: FAIL. 참고 합성본은 별도 previews/로 격리하고 실제 BODY 납품에 섞지 않는다. 실제 눈으로 확인하기 전 PASS 선언 금지; 위반 시 BODY 원화를 수정·재검수.
- 구도 경계: 상반신은 머리부터 허리 부근, 양팔·양손 끝까지. 다리·발 금지.
종전 ONE_PART_PER_GENERATION_V1 직접 파츠 생성 지시는 폐기. 생성 AI와 분리 AI는 서로 다른 작업이다.

A. 이미지 생성 AI: 승인된 캐릭터의 고품질 해당 자산 원화 outputs/master.png를 먼저 그린다. 일관된 정면/좌우 3/4/측면 및 필요한 가림·표정 reference_views/ 와 expression_refs/를 그림으로 만든다. 참조용 다른 자산 픽셀은 실제 master에 넣지 않는다. 캐릭터 시트/콜라주/레이어명이 붙은 눈 그림을 독립 파츠로 위장 금지. 눈·모발·옷의 한 조각씩 재생성하지 않는다. 이 단계에서는 part_art/*.png, part_art/_order.txt, PSD, 실제 리깅 성공을 주장하지 않는다.

B. 전문 분리·원화 가공 단계: 기존 계층형 PSD가 있으면 원본 레이어 우선. 단일 원화면 See-through/LayerDiff 및 SemanticSam 19개 클래스는 큰 영역 후보일 뿐이다. SemanticSam의 eyes는 좌우·흰자·홍채·속눈썹 개별 레이어가 **아니다**. 고해상도 해당 부위 crop을 이용하고 박스/클릭/거친 마스크 안내로 SAM2류 정밀 분리 또는 별도 전용 소재 분리 가공과 수동 수정이 필요하다. 무검수 완전 자동 가능하다고 주장하지 않는다. 눈을 새 그림으로 재생성하지 말고 보이는 RGB 픽셀을 마스터에서 정확히 복사한다. 숨겨진 부분만 참고 원화에 맞춰 연장 작화·인페인팅한다. 같은 전체 캔버스 좌표·원점/좌우/레이어 순서로 보정하고, 분리 검증 후에만 part_art/*.png와 part_art/_order.txt를 납품한다.

C. body 실제 세분화 판단: BODY 필수: 얼굴 바탕(눈·입·귀를 구워 넣지 않음), 귀·눈썹 L/R, 코, 닫힌 입·열린 입안, 목·몸통·상완·전완·손 L/R. 전신만 다리와 발. 양쪽 눈은 각각 eye_L_white, eye_L_iris, eye_L_upper_lash 및 right 대응 세 독립 RGBA 레이어가 필수. 필요할 때 동공·하이라이트·눈꺼풀·아랫속눈썹 추가. eyes라는 한 장짜리 영역·눈 통째 추출·같은 텍스처를 세 파일명으로 복제한 결과는 실패. 홍채 뒤 가려진 흰자까지 실제 픽셀로 보완하고 시선 이동·눈 깜빡임·입 열고 닫기 상태를 각각 합성 검증한다. 실패 시 EYE_MICRO_SPLIT_UNRESOLVED로 차단 후 정밀 마스크 또는 수동 가공. 목 상단은 턱 뒤, 하단은 몸통 아래까지. 어깨·팔꿈치·손목 숨은 면 복원. 얼굴-목-몸통-손 피부색 통일.

D. 검사/실패 처분: 합성한 중립 이미지가 마스터와 일치하는지, 눈 흰자·홍채를 단독 표시했을 때 중복 눈이 아닌지, 투명 구멍·접합선·가림 뒤 색 누락이 없는지 확인. 레이어 이름/PNG 숫자/SAM 마스크 출력만으로 성공 처리하지 않는다. 미완료는 EYE_MICRO_SPLIT_UNRESOLVED, UNDERPAINT_MISSING, SOURCE_PIXEL_MISMATCH, PART_ALPHA_INVALID 중 해당 원인으로 보류하고 같은 생성 AI에 다시 파츠 시트를 그리라고 보내지 않는다. PSD/Live2D/Inochi2D 리깅과 측면 키폼 성공은 후속 단계에서 따로 검증한다.
- 근거: https://docs.live2d.com/ko/cubism-editor-tutorials/psd/ ; https://docs.live2d.com/ko/cubism-editor-manual/divide-the-material/ ; https://github.com/shitagaki-lab/see-through ; https://ai.meta.com/research/sam2/
## [/ART_SOURCE_AND_SEPARATION_V3]

## [GPT_ARTWORK_SEGMENTER_HANDOFF_V5]
### live2d_upper / body — GPT 마스터 원화에서 실제 분리 AI까지
**최상위 역할 계약. 이 ZIP은 GPT의 원화 생성 지시서이지 GPT에게 PSD·파츠 분리를 시키는 지시서가 아니다.** 모든 14개 MD의 기존 `part_art/`, `_order.txt`, `isolated_parts/`, PSD, 알파, 개별 눈·목 세분화, 합성 검수 지시는 **별도 후속 분리 엔진의 출력/검사 명세**로 해석한다. 이미지 생성 AI가 그 파일을 생성했다고 주장해서는 안 된다.
1. GPT는 `outputs/master.png` **실제 정면 원화 PNG 1장**(RGB 또는 진짜 RGBA)을 생성한다. 콜라주, 부품을 떨어뜨려 배치한 시트, 가짜 투명 PNG, 기존 이미지와 다른 인물로 그린 설정화는 불합격이다.
2. 다음은 투명 파츠가 아닌, 같은 캐릭터의 다른 시점/숨은 부분 참고 원화이다. **각각 별도의 실제 PNG**로 그린다.
  - `reference_views/body_front.png`
  - `reference_views/head_three_quarter_L.png`
  - `reference_views/head_three_quarter_R.png`
  - `reference_views/head_profile_L.png`
  - `reference_views/head_profile_R.png`
  - `reference_views/head_pitch_up.png`
  - `reference_views/head_pitch_down.png`
  - `reference_views/neck_underpaint.png`
  - `reference_views/body_joint_overlaps.png`
  - `expression_refs/mouth_closed.png`, `expression_refs/mouth_open.png`: 서로 다른 실제 표정 참고 원화; 중립 마스터와 같은 크기/얼굴 위치.
3. 마스터와 front/three_quarter/profile/pitch 참고는 **동일한 원본 캔버스 가로·세로 픽셀 크기, 인물 스케일·중심좌표**를 유지한다. 뷰 이름을 바꾸거나 정면을 복제해 다른 시점으로 위장하지 않는다.
4. **모드 구도:** 머리~허리 부근, 양어깨·양팔·양손 포함. 다리·발 없음.
5. **자산 경계:** 민머리 두상, 크고 선명한 눈, 짧고 넓은 얼굴, 코·입·귀, 목·어깨, 비해부학적 불투명 무광 베이스 몸통, 양팔·양손만. 헤어·별도 패션 의상·장신구 픽셀 0개(기술 제작복은 예외). 얼굴·목·손 피부색 통일(몸통/팔은 청회색 불투명 스튜디오 제작복).
6. **See-through 분리를 고려한 원화:** 한 이미지에 한 시점·한 캐릭터, 흰색/단순 단색 배경, 선명한 애니 셀 셰이딩/파츠 윤곽·깔끔한 경계; 글자·워터마크·장식 배경·눈 위의 불필요한 손/머리카락 겹침·과도한 발광 금지. 구분을 위해 머리·팔을 물리적으로 잘라 떼어 놓거나 전체 원화 품질을 저하시키지 않는다.
- 눈 흰자·홍채·속눈썹은 고품질 애니 원화에서 식별되게 그리지만, 그들을 개별 PNG로 만들어야 할 책임은 후속 분리 단계에 있다. 각 눈의 세 개 층이 실제 서로 다른 RGB·알파 픽셀인지 검증하고 불완전하면 해당 영역만 정밀 분리/가림 복원한다.
- 턱과 목·어깨의 자연스러운 정면 연결은 원화에서 보존한다. 턱/목/팔꿈치/손목의 숨겨진 이어지는 영역은 분리 단계에서 실제 인페인팅하고 위치·색을 검사한다.
7. **GPT 결과물:** `live2d_upper__body__ARTWORK.zip`에 `outputs/master.png`, 위 `reference_views/*.png` 및 BODY에서 `expression_refs/*.png`만 저장한다. `manifest.json`, `layer_order.txt`, `part_art/_order.txt`, `part_art/*.png`, `isolated_parts/`, PSD, MOC3 등 분리/리깅 파일은 생성하지 않는다. 원화 ZIP 납품과 Live2D 완료를 혼동하지 않는다.
8. **후속 파이프라인:** `tools/vts_source_only_pack.py`가 실물 마스터·뷰의 PNG 형식/중복/크기 등을 확인한다. 이후 See-through V3/NF4로 분리 PSD 후보를 만들고, 관찰된 파츠를 공식 좌우/깊이 세분화 또는 SAM 정밀 마스크로 필요 시 개선한다. Qwen-Image-Layered는 기존 런타임에서 해당 자산에 **실제로 연결된 경우에만** 추가 RGBA 분해에 사용한다. Qwen은 텍스트만으로 L/R 홍채·흰자·속눈썹 레이어를 정확히 지정하는 기능을 보장하지 않는다.
9. **후속 검수:** 원본 보이는 RGB 보존, 실제 알파, 가려진 부분 복원, PSD 순서/캔버스 좌표, 좌우 눈 흰자·홍채·속눈썹, 턱-목-몸통·팔-손 접합, 마스터 중립 합성 일치와 변형을 검사한다. 불합격 부위는 분리 작업에서만 재시도/인페인팅하고 GPT가 파츠 시트를 대신 그리게 하지 않는다. 결과 PSD는 Cubism/Inochi2D 모델 리깅/방송 동작 성공을 뜻하지 않는다.
10. 위에 적힌 PNG를 실제 제작할 수 없으면 그 누락을 명확히 보고한다. 분리 엔진 오류는 GPT 원화 생성 완료와 별도로 보고한다.
## [/GPT_ARTWORK_SEGMENTER_HANDOFF_V5]

## [MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
### live2d_upper / body — 24개 자산별 실제 분리 경로
**V5의 GPT 원화 역할을 유지한 채, 후속 분리 AI가 무엇을 어떻게 나눌지 정하는 최신 자산 전용 기준.** 모드·자산을 서로 바꿔 처리하면 실패다.
- 작업 범위: Live2D 상반신: 머리~허리, 양어깨·팔·손. 다리·발 파츠 금지.
- 대상 경계: 원본 BODY는 민머리이며 의상·장식·머리카락 픽셀이 없어야 한다. 얼굴·목·손 피부 기본색을 동일하게 유지하고 몸통·팔은 제작복으로 덮는다.
- **See-through V3의 실제 기본 태그 중 이 자산 관련 항목:** face, irides, eyebrow, eyewhite, eyelash, ears, nose, mouth, neck. 23개 태그 이외의 파츠 명칭을 모델이 직접 출력한다고 간주하지 않는다.
- **실제 후속 세부 분리·검수 대상:** 양쪽 흰자·홍채·속눈썹 각각 실제 독립 RGBA, 양 눈썹, 얼굴바탕·코·중립 입/열린 입안, 두피·목·몸통·양 상완·전완·손·숨은 관절면
- **V3만으로 불가능/불충분:** See-through V3에는 bare hand, forearm, upper arm, fingers, individual eyelids, inner mouth, torso/neck underpaint가 없다. 'handwear'는 손 자체가 아니라 장갑/손 착용품이다. 몸통 무광 베이스가 topwear로 오인되어도 의상으로 단정하지 않는다.
- **어떤 엔진이 실제 수행:** 실행 경로: 원화 ZIP 형식/시점 검사 → See-through V3의 body/head 2단계 NF4 추론 → 실제 PSD·관측된 태그 검사 → 필요하면 공식 left/right 및 depth 분할 → 전용 눈·관절 정밀 마스크/가림 면 보정 → 개별 RGBA·PSD·합성 검수. V3에서 얻은 눈 의미 영역은 좌우 각각 재검증한다.
- **완성 조건:** 이미지 생성 GPT가 한 장짜리 가짜 파츠 시트를 만들면 실패. See-through 결과 PSD만 생성되거나 레이어 이름/개수만 맞으면 **분리 성공 아님**. 실제 움직일 파츠의 서로 다른 원본 RGB/알파/레이어/가려진 면이 검증돼야 한다. 실패 항목은 해당 파츠만 정밀 분리·인페인팅하여 재검사하고, 전체 원화를 매번 재생성하지 않는다.
- 3D HAIR/OUTFIT처럼 제작 엔진이 없는 경우 또는 독립 2D 자산의 세부 분리가 남아 있으면 `NOT_YET_RIG_READY`로 명시한다. 중간 PSD를 완성된 방송 모델로 제출 금지.
- 경로 규정의 코드 기준: `tools/vts_segmentation_profiles.py`. Live2D/Inochi2D 실행은 `notebooks/VTuber_Finished_AI_ZIP_All_Modes.ipynb`의 모드/자산 선택을 따른다.
## [/MODE_ASSET_SEETHROUGH_V3_ROUTING_V6]
## [FACE_BODY_COLOR_LOCK_V5]
얼굴·귀·두피·목·손은 동일한 피부색 FACE_SKIN_BASE로 유지한다. 몸통·어깨·팔은 별도 청회색 불투명 긴소매 스튜디오 제작복으로 덮고 목둘레·소매 경계를 유지한다. 숨은 면은 피부/제작복 각 영역에 맞춰 동일 RGB로 보완한다.
## [/FACE_BODY_COLOR_LOCK_V5]

## [BODY_SAFE_STUDIO_SUIT_V3]
성인(20세 이상)의 비성적 애니 VTuber 원화. BODY의 몸통과 팔은 단정한 목둘레와 소매 끝이 보이는 **불투명 무광 청회색(#526B7D) 긴소매 스튜디오 제작복**으로 실제 완전히 가린다. 피부/해부학 묘사 대신 민무늬 마네킹형 실루엣을 유지한다. 얼굴·귀·목·손의 노출 피부는 동일한 FACE_SKIN_BASE로 통일하며, 원화 제작복은 피부색과 구분한다. 이후 마스킹도 착의 경계는 지킨다. 민머리·짧고 둥근 얼굴·큰 주황 홍채·자연스러운 목/어깨 연결·양팔/양손 다섯 손가락을 유지한다. 패션 의상·헤어·액세서리 추가 금지. 2D 원화는 master와 각도/표정 PNG만, 3D는 기존 8방향 참조만 생성하며 PSD/리깅 완성을 주장하지 않는다.
## [/BODY_SAFE_STUDIO_SUIT_V3]

## [IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]

- **선화/채색 목표:** 숙련된 애니 원화가의 방송용 Live2D/VTuber 스타일. 일관된 실루엣·강약 있는 섬세한 선화·풍부한 표정·세련된 셀 그림자/미묘한 색 변주·눈/소재별 충분한 내부 디테일. 평면 SVG 인형·클립아트·초등 교재 그림·아이콘·스틱 피겨는 거절한다. 단색 타원으로만 된 눈/귀/입/손은 원화가 아니다.
- **모드별 실제 구도:** Live2D 상반신: 머리부터 허리 부근까지, 양어깨·양팔·양손 포함. 골반 아래 다리·발·전신 생성 금지. BODY: 민머리 두상·얼굴 피부·양눈·입·코·귀·목·어깨·몸통 무광 외피·양팔·양손만. 머리카락·패션 의상·장신구 픽셀 0개(기본 스튜디오 제작복은 BODY 필수).
- **도구 불가 시:** 실제 이미지 생성기가 사용 불가능하거나 거절하면 성인·완전 착의·비성적 디자인 조건을 유지해 적절히 고치고, 그래도 불가능하면 해당 생성 단계를 미완료로 정확히 보고한다. 생성 기능 없이 낮은 수준의 프로그래밍 그림을 만들어 완료라고 제출하지 않는다.
- **최종 시각 검수:** 얼굴·눈·피부·무광 몸통·팔·손의 선화·채색·연결·구도, 다른 자산 혼입 여부를 실제 시각 확인. 증거 없으면 ART_QUALITY_UNVERIFIED.

## [/IMAGE_AI_NATIVE_ART_FIRST_QUALITY_V1]


## [2026-10-14 큰 머리·짧고 둥근 얼굴 강제 계약 v2]
live2d_upper/body 원화 생성 우선 조건. 충돌하는 구형 미술 지침보다 우선한다.
- 공통: **큰 머리, 큰 눈과 홍채, 짧고 넓은 얼굴, 둥근 볼, 짧고 매끈한 U형 턱, 작은 코·입.** 말상·좁은 얼굴·길게 내려오는 V턱·성숙 실사 얼굴은 절대 불합격.
- 정면 얼굴 높이/폭 약 1.10~1.30은 참고 범위이며 강제 크롭/화면 점유율은 아님. 전신 원화 신규 제작 금지, 바스트업·상반신은 머리를 작게 만들지 않음.
- 실패 판정: 머리가 작다 / 눈이 작다 / 얼굴이 길거나 좁다 / 턱이 뾰족하다 / 목이 길다 / 다른 자산이 혼입됐다. 하나라도 해당하면 불합격이며 무검증 납품 금지.

## [2026-10-14 CANONICAL ASSET CONTRACT | live2d_upper/body]
**이 블록을 모든 구형 예시·구도·형태 규칙보다 우선한다. 서로 모순되는 옛 문장은 생성 지시가 아니라 폐기된 내용으로 취급한다.**
- 자산 소유권: **BODY만 생성:** 귀여운 애니풍 두상·큰 눈/홍채·짧고 둥근 하관, 단순한 피부와 목·어깨·필요한 신체·손. 갈비뼈/복근/배꼽/쇄골·힘줄을 선으로 과잉 묘사하지 않는다. 디자인 의상은 OUTFIT 전용이며 BODY에는 위 기본 목둘레와 소매 경계가 있는 불투명 스튜디오 제작복로 덮인다. 몸통은 불투명 무광 단색 찰흙형 베이스. 얼굴과 눈은 높은 품질의 애니풍 원화. 헤어·탈착 의상·액세서리를 BODY에 붙이지 않는다.
- 프레임: Live2D 상반신: 머리부터 허리 부근까지, 양어깨·양팔·양손 포함. 골반 아래 다리·발·전신 생성 금지. BODY: 민머리 두상·얼굴 피부·양눈·입·코·귀·목·어깨·몸통 무광 외피·양팔·양손만. 머리카락·패션 의상·장신구 픽셀 0개(기본 스튜디오 제작복은 BODY 필수).
- 눈·얼굴: 큰 홍채, 충분한 흰자, 선명한 속눈썹, 작은 코/입, 둥글고 귀여운 두상. 실사/해부학적 표현과 뾰족한 V턱을 피한다. 기준 BODY 제공 시 얼굴 비율을 변경하지 않는다.


## [2026-10-13 v5 live2d_upper/body 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.

## 2026-10-13 사용자 지정 BODY 최상위 제작 규칙 — 기존 묘사 지시보다 우선
이 ZIP은 머리·얼굴 및 재사용용 몸체 실루엣을 위한 신체 전용 지시서다. 이미지 생성 AI는 얼굴·눈·목·어깨·팔·손과 무광 몸통이 자연스럽게 연결된 해당 모드의 BODY 마스터 한 장을 완성한다. 헤어·의상·액세서리는 합치지 않는다.
정면 얼굴은 짧고 부드러운 U형 하관과 둥근 볼, 작은 애니 귀(내부 선 1~2개), 균형 잡힌 두상과 단순한 목을 사용한다. 기존의 긴 V자 턱과 실사형 큰 귀, 과도한 정수리와 긴 목을 다시 생성하면 FAIL이다. 눈 크기만으로 애니형 판정하지 않는다.
홍채 색은 사용자가 지정하거나 캐릭터별 팔레트에서 선정한다. 특정 분홍/노랑 눈색 고정 금지. 헤어와 의상, 액세서리는 BODY에 병합하지 않는다.
BODY는 의상 교체용 공통 베이스로서 몸통은 불투명한 비해부학적 무광 단색 찰흙 외피로 제작한다. 해부학적 내부선은 생략하고 큰 머리·짧고 둥근 얼굴·부드러운 턱·큰 눈을 유지한다.

# Live2D 상반신 신체 애니풍 고퀄리티 지침

00_MASTER_FIRST.md 우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.


큰 홍채·깊이 있는 속눈썹·작은 코와 입·부드러운 턱·매끈한 셀 피부. 사실적인 갈비뼈/복근/흉근·성인 실사 비례는 금지. 검정에 가까운 또렷한 가변 굵기 외곽선과 가늘어지는 테이퍼 끝, 내부의 짙은 소재색 선화, 깨끗한 2~3톤 셀 셰이딩을 사용한다. 사용자 스타일이 명확하면 이를 우선한다. 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.

이미지 생성용 영어 프롬프트: “Professional high-end anime VTuber body-only artwork, precision variable-weight tapered ink lines, sophisticated material-aware cel shading, clean silhouettes, original consistent character design, render only the requested body asset on the reference canvas, no unrelated character parts or props.”



## [2026-10-13 원화·애니풍 심화: live2d_upper/body]
Commercial-grade anime VTuber UPPER BODY BASE ONLY: large expressive irises, tapered lashes, petite stylized nose and mouth, natural neck and shoulders and visible arms, polished cel shadows, opaque modest basewear, no hair, fashion outfit, jewelry or lower-body parts.
Commercial Japanese anime, variable tapered dark ink and refined material cel shading, keep original character design.


## [고급 그림자·모근·소재·선폭 | live2d_upper/body]
Anime VTuber BODY ONLY: preserve the existing eye shape and facial identity, tapered eyelash and mouth linework, delicate colored interior contours and clean skin cel-shadows, no baked-in moving hair-cast shadow on the permanent face skin, no duplicated facial linework, no hairstyle/clothing/accessory generation.

## [MATTE_CLAY_BODY_V1]
### BODY — 불투명 단색 무광 찰흙형 베이스
성인(20세 이상)의 비성적 애니 VTuber 원화. BODY의 몸통과 팔은 단정한 목둘레와 소매 끝이 보이는 **불투명 무광 청회색(#526B7D) 긴소매 스튜디오 제작복**으로 실제 완전히 가린다. 피부/해부학 묘사 대신 민무늬 마네킹형 실루엣을 유지한다. 얼굴·귀·목·손의 노출 피부는 동일한 FACE_SKIN_BASE로 통일하며, 원화 제작복은 피부색과 구분한다. 이후 마스킹도 착의 경계는 지킨다. 민머리·짧고 둥근 얼굴·큰 주황 홍채·자연스러운 목/어깨 연결·양팔/양손 다섯 손가락을 유지한다. 패션 의상·헤어·액세서리 추가 금지. 2D 원화는 master와 각도/표정 PNG만, 3D는 기존 8방향 참조만 생성하며 PSD/리깅 완성을 주장하지 않는다.
## [/MATTE_CLAY_BODY_V1]

## [IMAGE_AI_SOURCE_ONLY_V2]
예전 ONE_PART_PER_GENERATION_V1 단일 파츠 그림 직접 생성 규칙은 폐기한다. ART_SOURCE_AND_SEPARATION_V3를 적용한다. 이미지 생성 AI는 outputs/master.png + reference_views를 납품한다. part_art/_order.txt는 전문 분리 단계에서만 작성.
## [/IMAGE_AI_SOURCE_ONLY_V2]

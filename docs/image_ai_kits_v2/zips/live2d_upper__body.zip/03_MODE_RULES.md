## [EXISTING_VTUBER_TEMPLATE_SLOTS_V1]

**가장 먼저 '이미 존재하는 실제 템플릿/프리셋'을 구한다. 빈 종이에서 캐릭터를 새로 그리거나 회색 신체 도형을 만들지 않는다.**
이 ZIP은 **live2d_upper / body** 전용이다. 아래 원본 파일은 이 ZIP에 동봉되지 않은 제3자 자료다.
출처·이용 약관·파일 유형·다운로드/로컬 열림을 확인해야 실제 템플릿 사용 완료다.

### 적용 가능한 기존 템플릿
- 1. **Live2D Haru receptionist before/after material-separation PSD** — https://www.live2d.com/en/learn/sample/haru-receptionist/
   - 기존 자료 형식: PSD
   - 실제 활용: Real part separation, torso/neck/collar relationship and editable layers; use structure, not Haru character copy.
   - 권리 확인: Live2D sample-data terms govern user download, modification and redistribution. Do not bundle original PSD.
- 2. **Live2D official Boy/Girl SD guide PSD** — https://docs.live2d.com/en/cubism-editor-tutorials/template/
   - 기존 자료 형식: PSD
   - 실제 활용: Editable layer hierarchy and draw-in slots; SD proportions are NOT the user's six-head-body dimensions.
   - 권리 확인: Download individually after checking official sample/template terms; original files excluded from repository.

### 채울 슬롯
`head`, `face`, `eyes_L`, `eyes_R`, `iris_L`, `iris_R`, `ears_L`, `ears_R`, `jaw`, `neck_underpaint`, `shoulder_L`, `shoulder_R`, `torso`, `upper_arm_L`, `upper_arm_R`, `forearm_L`, `forearm_R`, `hand_L`, `hand_R`

- **템플릿 원본 열람 필수:** PSD라면 실제 레이어 패널과 그림을 열어 눈/머리·목/팔/손/의상 가림을 확인한다. 3D는 VRoid Studio에서 실제 해당 프리셋을 열어 형태와 텍스처를 확인한다. 페이지 URL만 확인하고 실제 PSD/프리셋 열람 완료라 하지 않는다.
- **구도:** upper body through waist/hips with hands
- **입력 요구:** real_PSD_or_user_owned_layered_template_file. 실제 원본이 없는 경우 생성 중단 및 소스 제공 요청.
- **슬롯 채우기:** 템플릿에 있는 부위와 사용자 원화부터 선택·매핑하고, 빈 슬롯은 동일 정합을 유지하며 독립적으로 작화한다. 색상·눈·얼굴 윤곽·목·어깨는 사용자 캐릭터와 실제 원화가 우선이며 예제 캐릭터 외형을 복제하지 않는다.
- **동일 좌표:** PRO parts match exactly the supplied approved base BODY canvas, coordinates and scale; FREE complete character uses one approved master source.
- **절대 불합격:** Reject flat gray mannequin, disconnected neck, missing required hands/arms, abruptly cropped torso and unrelated face. Never certify via shape or hashes alone.
- **없는 부위:** Request source/reference or artist creation for missing slots. Never fill missing body slots with a one-color polygon or invent a fake native rig.
- **검증:** 슬롯별 source/template-id, 외부 파일 로컬 접근 여부, 원본 파일 종류, 실제 레이어/프리셋 시각 관찰 여부, 기준 캔버스 앵커, 라이선스 확인과 사용자 승인 기록을 남긴다.
- **제작 순서:** 14개 MD 전체 읽기 → 실제 참고 이미지·위 템플릿 전부 열람 → 요구사항 충돌 해결 → 승인된 템플릿과 슬롯 매핑 → 빈 부위만 원화 제작 → 실제 원화 검수 → 분할 PSD·마스크·완성 ZIP.
- **중요:** 기존 템플릿 PSD는 자동 Cubism 리깅이 아니다. Inochi2D PSD도 Live2D 네이티브 모션 파일이 아니다. VRoid 프리셋은 2D PSD가 아니다. 이를 혼동하거나 가짜 CMO3/MOC3/VRM을 생성했다고 주장하지 않는다.


## [2026-10-13 v5 live2d_upper/body 적용 최상위 기준]
공식 Live2D 완성 버튜버 샘플 이미지를 실제로 열어 얼굴형/머리크기/눈/귀/작화 비율을 관찰하고 기록한다. URL만 읽었거나 사용자 불합격 이미지(실사 귀, 뾰족한 턱, 옷 있는 BODY)를 긍정 예시로 쓰면 REFERENCE_NOT_VIEWED/FAIL. 사용자 디자인과 요청 자산만 제작한다.
BODY: 얼굴/눈/입의 애니 작화와 목 아래 중립색 기하학적 프록시를 **별도** 제작 후 한 캔버스에 조립. 얼굴은 짧고 둥근 U형 턱, 작고 내부선 1~2개인 귀, 큰 눈과 짧고 단정한 목, 과대한 정수리 방지. 홍채색은 사용자 지정값을 우선하고 분홍/노랑 고정 금지. 몸통은 이미지 모델이 아니라 코드의 불투명 단색 도형(예: Pillow)으로 만들며 속옷·의상·목깃·가슴/쇄골/겨드랑이 명암·팔 옆 살접힘/눌림을 그리지 않는다. 기존 '신체 전부 AI 원화로', '기본 슈트' 규칙을 실행하지 않는다. 도형 코드 실행 기록·정합 미리보기 없이 완료 선언 금지. 이 모드는 상반신 범위를 유지하고 하체를 추가하지 않는다.

## 2026-10-13 사용자 지정 BODY 최상위 제작 규칙 — 기존 묘사 지시보다 우선
이 ZIP은 머리·얼굴 및 재사용용 몸체 실루엣을 위한 신체 전용 지시서다. 외부 생성 AI에게 얼굴부터 몸까지 완성한 인체 일러스트를 한 장으로 요구하지 않는다.
얼굴·눈·입을 애니풍으로 작업하고 BODY 몸체는 별도의 중립색 불투명 2D 도형 프록시를 프로그램으로 만든다. 몸체 도형에는 옷/속옷/튜브탑/리본/목깃/어깨 압박 주름/쇄골 윤곽/가슴 굴곡/겨드랑이 피부 접힘/근육/갈비뼈의 그림과 음영을 그리지 않는다.
정면 얼굴은 짧고 부드러운 U형 하관과 둥근 볼, 작은 애니 귀(내부 선 1~2개), 균형 잡힌 두상과 단순한 목을 사용한다. 기존의 긴 V자 턱과 실사형 큰 귀, 과도한 정수리와 긴 목을 다시 생성하면 FAIL이다. 눈 크기만으로 애니형 판정하지 않는다.
홍채 색은 사용자가 지정하거나 캐릭터별 팔레트에서 선정한다. 특정 분홍/노랑 눈색 고정 금지. 헤어와 의상, 액세서리는 BODY에 병합하지 않는다.
제작 순서: 공식 완성 VTuber 참고 이미지를 실제로 열어 비교·기록 → 얼굴 원화 시각 검수 → 단색 BODY 도형 생성 → 한 캔버스에서 조립 → RGBA 분리/가려진 면 검사 → 합성 QA → 최종 ZIP. 링크 확인만으로 이미지 시각검수 완료라고 보고하지 않는다.
도형 코드를 실행하지 않고 생성 AI에 통짜 몸통을 그리게 하면 본 지시 미준수다. 실행이 막히면 거짓 완료 판정 대신 제작 불가를 보고한다. PSD/리깅은 별도 단계.
신체 도형은 완성 캐릭터 일러스트가 아니라 의상 교체용 레이어이므로 미술적 화려함/인체 곡선을 요구하지 않는다. 사용자 얼굴 정체성과 전체 6등신 디자인 계약(전신인 경우)을 보존한다.

# Live2D 상반신 / 신체만의 2D 제작·납품 범위

00_MASTER_FIRST.md 최우선. ## ZIP 고유 작업 범위 잠금: live2d_upper / body
**유일한 제작 대상:** 큰 애니 눈·홍채·좌우 눈꺼풀·눈썹·코·입안·귀·목·몸통·팔·손과 안전하게 가린 신체 베이스.
**제작 금지:** 교체형 헤어·패션 의상·귀걸이 등 독립 액세서리·하체를 추가로 그리지 않는다.
**그릴 범위:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 기준 신체 원화 자체. 참조 몸체/얼굴/의상은 위치 비교·선화 정합을 위한 것이며 납품 파츠에 포함하지 않는다. 


- **프레임:** 머리·목·어깨·실제로 화면에 보이는 상반신(해당 자산만). 머리·얼굴·다리 등은 신체의 외형이나 위치를 판단하기 위한 기준이지 다른 자산 그림을 만들라는 뜻이 아니다.
- **실제 출력:** 얼굴·눈·입·목·상체·양팔·손. 없는 디자인과 독립 움직임이 불필요한 부분은 만들지 않는다.
- 같은 캔버스·좌표·기준 신체/캐릭터 배율을 유지하는 **투명 RGBA PNG**. `isolated_parts/`에는 이 자산의 픽셀만 포함한다.
- `layer_order.txt`는 실제 생성된 해당 자산 PNG 파일명만 캐릭터 본인 기준 L/R·뒤→앞 순으로 기록한다.
- `previews/composite_preview.png`는 실제 파츠를 합성한다. 기준 몸체가 보이는 별도 overlay는 위치 확인용일 뿐 납품 파츠에 신체를 포함시킨 증거가 아니다.
- Live2D Cubism의 ArtMesh/Deformer/키폼/물리/모션/PSD·MOC3 제작은 이미지 AI 출력 계약 밖이다.


## [2026-10-13 원화·애니풍 심화: live2d_upper/body]
이 프로젝트의 **6등신 전신 캐릭터 기준**과 머리/어깨 비례를 참고해 **상반신 원화를 처음부터 제작**한다. 전신을 완성한 뒤 자르는 것이 납품 필수가 아니다. 신체는 실제 보이는 머리·목·어깨·팔과 상체만, 다른 자산은 같은 기준 몸체의 캔버스/원점에 해당 부분만 작업한다. 이 비율은 Cubism 공식 제한이 아니다.


## [정량 추천과 옆얼굴·목 접합 개선 | live2d_upper/body]
상반신의 상대 두상·어깨 비율은 6등신 전신 설정을 참고하되 하체를 그리지 않는다. 바스트업 전용 화면 점유율 수치를 강제하지 않는다.


## [고급 그림자·모근·소재·선폭 | live2d_upper/body]
어깨·상완·소매·실제 헤어 끝의 화면 안 가시성, 피부·머리·옷 사이 접합을 우선한다. 하체나 프레임 밖 의상/소품은 필요조건이 아니다.
